# Connect the ebook store to Razorpay (ahirevipul1994@gmail.com → vipmagicalphysio.com)

Simple steps for Dr. Vipul. Takes about 45 minutes. Test mode first, live mode after one successful test.

## 1. Razorpay account (ahirevipul1994@gmail.com)
1. Log in at **dashboard.razorpay.com** with ahirevipul1994@gmail.com.
2. Finish **KYC / Activation** (PAN, bank account, business details). Website = `https://vipmagicalphysio.com`.
   Razorpay checks that the site has Terms, Refund, Privacy and Contact pages — they already exist at
   `/en/legal/terms`, `/en/legal/refund`, `/en/legal/privacy`, `/en/contact`.
3. **Account & Settings → API Keys → Generate Test Key.** You get a **Key ID** (`rzp_test_…`) and a **Key Secret**.
   - The Key ID is public; it goes in `pay-config.js` → `keyId`.
   - The **Key Secret must never go in the website code.** It goes only in Netlify (step 3).

## 2. Supabase (free)
1. Create a project at **supabase.com** (region: Mumbai).
2. Go to **SQL editor**, paste `supabase/schema.sql` and click **Run**. This creates the tables, the security rules, the private `ebooks` bucket and your 5 products.
3. Go to **Storage → ebooks** and upload each PDF. Name the files to match the product id, e.g. `stronger-after-40.pdf`. Then set `file_path` in the products table to that file name.
4. **Project settings → API**: copy the `URL` and the `service_role` key. The service_role key is secret; it goes only in Netlify.

## 3. Netlify environment variables
Go to **Site settings → Environment variables** and add:

| Name | Value |
|---|---|
| RAZORPAY_KEY_ID | rzp_test_… |
| RAZORPAY_KEY_SECRET | (from step 1) |
| RAZORPAY_WEBHOOK_SECRET | any long random text — use the same text in step 4 |
| SUPABASE_URL | https://xxxx.supabase.co |
| SUPABASE_SERVICE_ROLE_KEY | (from step 2) |
| DOWNLOAD_SECRET | another long random text |
| SITE_URL | https://vipmagicalphysio.com |
| BREVO_API_KEY | from brevo.com → SMTP & API (free: 300 emails/day) |
| MAIL_FROM | books@vipmagicalphysio.com (verify this sender in Brevo) |
| MAIL_ADMIN | ahirevipul1994@gmail.com |

Then push the `netlify/functions` folder to GitHub. Netlify deploys it automatically.

## 4. Webhook (makes delivery automatic even if the buyer closes the page)
1. In Razorpay go to **Settings → Webhooks → Add new webhook**.
2. URL: `https://vipmagicalphysio.com/.netlify/functions/razorpay-webhook`
3. Secret: the same text as RAZORPAY_WEBHOOK_SECRET.
4. Events: `payment.captured`, `payment.failed`, `refund.processed`.

## 5. Switch the website on
In `pay-config.js`, set `live: true` and `keyId: "rzp_test_…"`. Deploy, then buy a book using Razorpay's test UPI `success@razorpay`. Check that:
- [ ] the download works
- [ ] an email arrives at the buyer's address
- [ ] the order shows as **paid** in Supabase
- [ ] a duplicate webhook doesn't create a second payment

**Going live:** generate **Live** keys, replace the test values in Netlify and in `pay-config.js` (`rzp_live_…`), update the webhook secret for live mode, and redeploy.

## How a sale works (automation)
1. The buyer clicks **Buy now**. `create-order` reads the price from the database (the browser can't change it), applies any coupon, and creates the Razorpay order.
2. Razorpay Checkout takes the payment by UPI, card or net-banking.
3. `verify-payment` checks the signature. **The webhook `payment.captured` confirms it a second time.** Both calls are safe to repeat; the order is only fulfilled once.
4. The order is marked **paid**, a payment is recorded, the coupon count goes up, and a Brevo email with the secure download links is sent to the buyer. A sale alert goes to ahirevipul1994@gmail.com.
5. Download links are signed and checked on every use. Each link works 5 times, and the PDF itself is served from a private bucket through a 60-second URL.
6. Refunds are started from the admin, go through Razorpay, and the `refund.processed` webhook marks the order refunded so it is excluded from revenue.

## Costs
- **Razorpay:** about 2% per domestic transaction (UPI, cards, net-banking), plus GST on that fee. No monthly fee.
- **Supabase, Netlify and Brevo:** free tiers are enough to start.
