/* Shell: language, routing, SEO, header/footer, shared bits */
const { useState, useEffect, useMemo, useRef, createContext, useContext } = React;
const LANG_CODES = ["en", "mr", "hi"];
const LangCtx = createContext(null);

function detectLang() {
  const saved = localStorage.getItem("vmp_lang");
  if (LANG_CODES.includes(saved)) return saved;
  const nav = (navigator.languages || [navigator.language || "en"]).map((l) => l.toLowerCase());
  for (const l of nav) { if (l.startsWith("mr")) return "mr"; if (l.startsWith("hi")) return "hi"; if (l.startsWith("en")) return "en"; }
  return "en";
}
function parseHash() {
  const parts = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  let lang = null;
  if (LANG_CODES.includes(parts[0])) lang = parts.shift();
  return { lang, path: parts };
}
function useRoute() {
  const [r, setR] = useState(parseHash());
  useEffect(() => {
    const f = () => { setR(parseHash()); window.scrollTo(0, 0); };
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);
  return r;
}
function useL() { return useContext(LangCtx); }

/* Build translator */
function makeT(lang) {
  const i = LANG_CODES.indexOf(lang);
  const t = (k, vars) => {
    const v = window.UI[k]; if (!v) return k;
    let s = Array.isArray(v) ? v[i] : v;
    if (vars && typeof s === "string") Object.keys(vars).forEach((x) => (s = s.replace("{" + x + "}", vars[x])));
    return s;
  };
  t.i = i; t.lang = lang;
  t.pick = (obj) => (obj ? obj[lang] || obj.en : "");
  t.row = (k) => window.UI[k].map((r) => r[i]); // for [[en,mr,hi],...] rows
  return t;
}

function A({ to = "", children, className, onClick, ...rest }) {
  const { lang } = useL();
  return <a href={"#/" + lang + (to ? "/" + to : "")} className={className} onClick={onClick} {...rest}>{children}</a>;
}

/* SEO: per-page title, description, canonical + hreflang (production uses /en/ /mr/ /hi/ paths) */
function useSeo(title, desc) {
  const { lang, path } = useL();
  useEffect(() => {
    document.title = title + " | VIP MAGICAL PHYSIO, Shirur";
    document.documentElement.lang = lang;
    const set = (sel, make) => { let el = document.head.querySelector(sel); if (!el) { el = make(); document.head.appendChild(el); } return el; };
    set('meta[name="description"]', () => Object.assign(document.createElement("meta"), { name: "description" })).content = desc || "";
    const p = path.join("/");
    set('link[rel="canonical"]', () => Object.assign(document.createElement("link"), { rel: "canonical" })).href = "https://vipmagicalphysio.com/" + lang + "/" + p;
    LANG_CODES.concat("x-default").forEach((l) => {
      const el = set('link[hreflang="' + l + '"]', () => Object.assign(document.createElement("link"), { rel: "alternate", hreflang: l }));
      el.href = "https://vipmagicalphysio.com/" + (l === "x-default" ? "" : l + "/") + p;
    });
  }, [title, desc, lang, path.join("/")]);
}

function isOpenNow() {
  const n = new Date(); const o = window.BUSINESS.open;
  return o.days.includes(n.getDay()) && n.getHours() >= o.start && n.getHours() < o.end;
}
function waLink(text) { return "https://wa.me/" + window.BUSINESS.wa + (text ? "?text=" + encodeURIComponent(text) : ""); }

const WA_ICON = (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.3a.5.5 0 0 0 0-.5l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.2 2.2 2.2 0 0 0 .1-1.3c0-.1-.2-.2-.5-.3Z"/></svg>
);
const PHONE_ICON = (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2Z"/></svg>
);

function LangSwitch() {
  const { lang, setLang } = useL();
  return (
    <div className="lang-sw" role="group" aria-label="Language">
      {window.LANGS.map((l) => (
        <button key={l.code} className={lang === l.code ? "on" : ""} onClick={() => setLang(l.code)} lang={l.code} aria-pressed={lang === l.code}>{l.short}</button>
      ))}
    </div>
  );
}

const NAV = [["", "nav_home"], ["about", "nav_about"], ["services", "nav_services"], ["store", "nav_store"], ["videos", "nav_videos"], ["reviews", "nav_reviews"], ["faq", "nav_faq"], ["contact", "nav_contact"]];

function Header() {
  const { t, path } = useL();
  const [open, setOpen] = useState(false);
  const cur = path[0] || "";
  const openNow = isOpenNow();
  return (
    <>
      <div className="topbar">
        <div className="wrap">
          <span><i className={"dot" + (openNow ? "" : " off")}></i>{openNow ? t("open_now") : t("closed_now")} · {t("hours_short")}</span>
          <span>{t("call")}: <a href={"tel:" + window.BUSINESS.tel}>{window.BUSINESS.phone}</a></span>
        </div>
      </div>
      <header className="header">
        <div className="wrap">
          <A className="brand" aria-label="VIP MAGICAL PHYSIO home">
            <img className="brand-mark" src="assets/logo-256.png" alt="VIP MAGICAL PHYSIO logo" width="54" height="54" />
            <span><b>VIP MAGICAL PHYSIO</b><small>{t("tagline_a")} {t("tagline_b")}</small></span>
          </A>
          <nav className="nav" aria-label="Main">
            {NAV.map(([to, k]) => <A key={k} to={to} className={cur === to ? "on" : ""}>{t(k)}</A>)}
          </nav>
          <LangSwitch />
          <A to="book" className="btn btn-primary btn-sm btn-book">{t("nav_book")}</A>
          <button className="menu-btn" onClick={() => setOpen(true)} aria-expanded={open}>{t("menu")}</button>
        </div>
      </header>
      {open && (
        <div className="mnav" role="dialog" aria-label={t("menu")}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <LangSwitch />
            <button className="menu-btn" style={{ display: "block", margin: 0 }} onClick={() => setOpen(false)}>{t("close")}</button>
          </div>
          {NAV.map(([to, k]) => <A key={k} to={to} onClick={() => setOpen(false)}>{t(k)}</A>)}
          <A to="book" className="btn btn-primary" onClick={() => setOpen(false)} style={{ marginTop: 18, color: "#fff", border: 0, justifyContent: "center" }}>{t("nav_book")}</A>
        </div>
      )}
    </>
  );
}

function Footer() {
  const { t } = useL();
  const B = window.BUSINESS;
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="ft-grid">
          <div>
            <div className="brand" style={{ color: "#fff", marginBottom: 14 }}>
              <img className="brand-mark" src="assets/logo-256.png" alt="" width="64" height="64" style={{ width: 64, height: 64 }} />
              <span><b style={{ color: "#fff" }}>VIP MAGICAL PHYSIO</b></span>
            </div>
            <p>{t("ft_about")}</p>
            <p style={{ margin: 0 }}>{t("address")}<br /><a href={"tel:" + B.tel} style={{ display: "inline", fontWeight: 600 }}>{B.phone}</a> · {t("hours_short")}</p>
          </div>
          <div>
            <h4>{t("ft_pages")}</h4>
            {NAV.slice(1).map(([to, k]) => <A key={k} to={to}>{t(k)}</A>)}
            <A to="book">{t("nav_book")}</A>
          </div>
          <div>
            <h4>{t("ft_legal")}</h4>
            <A to="legal/privacy">{t("privacy")}</A>
            <A to="legal/terms">{t("terms")}</A>
            <A to="legal/refund">{t("refund")}</A>
            <A to="legal/disclaimer">{t("disclaimer")}</A>
          </div>
          <div>
            <h4>{t("ft_follow")}</h4>
            <a href={B.youtube} target="_blank" rel="noopener">YouTube — Dr. Vipul Ahire</a>
            <a href={B.instagram} target="_blank" rel="noopener">Instagram — Dard E Body</a>
            <a href={B.reviewUrl} target="_blank" rel="noopener">{t("rv_button")}</a>
            <a href={waLink()} target="_blank" rel="noopener">{t("whatsapp")}</a>
            <div style={{ marginTop: 12 }}><LangSwitch /></div>
          </div>
        </div>
        <div className="ft-emerg">{t("emergency")}</div>
        <div className="ft-bottom">
          <span>© 2026 VIP MAGICAL PHYSIO · Dr. Vipul Ahire (BPTh). {t("rights")}</span>
          <span>Dard E Body Care</span>
        </div>
      </div>
    </footer>
  );
}

function ActionBar() {
  const { t } = useL();
  return (
    <>
      <div className="actbar">
        <a href={"tel:" + window.BUSINESS.tel} style={{ background: "var(--sand)", color: "var(--navy)" }}>{PHONE_ICON}{t("call")}</a>
        <a href={waLink()} target="_blank" rel="noopener" style={{ background: "#1f9d55", color: "#fff" }}>{WA_ICON}{t("whatsapp")}</a>
        <A to="book" style={{ background: "var(--teal)", color: "#fff" }}>{t("nav_book")}</A>
      </div>
      <a className="fab-wa" href={waLink()} target="_blank" rel="noopener" aria-label="WhatsApp">{WA_ICON}</a>
    </>
  );
}

function Slot({ id, ph, className, style }) {
  const { t } = useL();
  return <image-slot id={id} placeholder={t(ph)} class={className} style={style}></image-slot>;
}

function ytThumb(id) { return "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg"; }

function VideoCard({ v, onPlay }) {
  const { t } = useL();
  return (
    <button className="vid" onClick={() => onPlay(v)} style={{ border: "1px solid var(--line)", cursor: "pointer" }}>
      <div className="vid-thumb" style={{ backgroundImage: "url(" + ytThumb(v.id) + ")" }}><span className="play"></span></div>
      <div className="vid-meta"><b>{v.t}</b>{v.v > 0 && <small>{v.v.toLocaleString("en-IN")} {t("views")}</small>}</div>
    </button>
  );
}
function VideoModal({ v, onClose }) {
  const { t } = useL();
  if (!v) return null;
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 900, background: "#000" }} onClick={(e) => e.stopPropagation()}>
        <iframe className="vid-frame" src={"https://www.youtube-nocookie.com/embed/" + v.id + "?autoplay=1&rel=0"} title={v.t} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen></iframe>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, padding: "14px 18px", background: "#fff", flexWrap: "wrap" }}>
          <b style={{ fontSize: 17 }}>{v.t}</b>
          <div className="btn-row">
            <a className="btn btn-sm btn-ghost" href={window.BUSINESS.youtubeSub} target="_blank" rel="noopener">{t("subscribe")}</a>
            <button className="btn btn-sm btn-navy" onClick={onClose}>{t("close")}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BookCover({ b, small }) {
  return (
    <div className="cover" style={{ background: b.hue, color: b.accent }}>
      <small style={{ color: "#fff" }}>Dard E Body Care</small>
      <div>
        <h4 lang={b.lang} style={small ? { fontSize: 22 } : null}>{b.title}</h4>
        <div className="sunline" style={{ background: b.accent }}></div>
        <div className="au" style={{ color: "#fff" }}>Dr. Vipul Ahire (Physio)</div>
      </div>
    </div>
  );
}

function ReviewStrip() {
  const { t } = useL();
  return (
    <div className="rv-strip">
      <div className="stars" aria-hidden="true">★★★★★</div>
      <div><h3>{t("rv_strip_title")}</h3><p>{t("rv_strip_body")}</p></div>
      <div className="btn-row">
        <a className="btn btn-sun" href={window.BUSINESS.reviewUrl} target="_blank" rel="noopener">{t("rv_button")}</a>
      </div>
    </div>
  );
}

Object.assign(window, { LangCtx, useL, makeT, detectLang, useRoute, A, useSeo, isOpenNow, waLink, WA_ICON, PHONE_ICON, LangSwitch, Header, Footer, ActionBar, Slot, VideoCard, VideoModal, ytThumb, BookCover, ReviewStrip, LANG_CODES });
