/* Admin v2 — Overview, CRM (contacts, pipeline, tasks), Appointments, Availability, Enquiries, Reviews */

function Overview({ db, go, openContact }) {
  const A = db.appointments, P = db.payments || [];
  const t0 = today();
  const mStart = new Date(); mStart.setDate(1); const mKey = mStart.toISOString().slice(0, 7);
  const paidM = P.filter((p) => p.status === "paid" && (p.createdAt || "").slice(0, 7) === mKey);
  const revM = paidM.reduce((s, p) => s + p.amount, 0);
  const due = (db.paylinks || []).filter((p) => p.status === "unpaid");
  const pending = A.filter((a) => a.status === "requested");
  const todays = A.filter((a) => a.date === t0 && ["requested", "confirmed"].includes(a.status)).sort((a, b) => a.time.localeCompare(b.time));
  const ready = (db.outbox || []).filter((m) => m.status === "ready" && m.channel === "whatsapp");
  const tasks = (db.tasks || []).filter((t) => !t.done);
  const months = Array.from({ length: 6 }, (_, i) => { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 5 + i); return { k: d.toLocaleString("en-IN", { month: "short" }), key: d.toISOString().slice(0, 7) }; });
  const split = months.map((m) => { const r = { k: m.k }; ["service", "ebook"].forEach((g) => (r[g] = P.filter((p) => p.status === "paid" && (p.createdAt || "").slice(0, 7) === m.key && (g === "ebook" ? p.kind === "ebook" : p.kind !== "ebook")).reduce((s, p) => s + p.amount, 0))); return r; });
  const max = Math.max(1, ...split.map((r) => r.service + r.ebook));
  const conv = A.length ? Math.round((A.filter((a) => ["confirmed", "completed"].includes(a.status)).length / A.length) * 100) : 0;
  return (
    <>
      <div className="kpis">
        <KPI label="To confirm" value={pending.length} sub="booking requests" tone={pending.length ? "#b3402a" : null} onClick={() => go("appointments")} />
        <KPI label="WhatsApp to send" value={ready.length} sub="automation outbox" tone={ready.length ? "#c98a12" : null} onClick={() => go("automations")} />
        <KPI label="Open tasks" value={tasks.length} onClick={() => go("tasks")} />
        <KPI label="Revenue this month" value={inr(revM)} sub={paidM.length + " paid transactions"} tone="#0d7f7a" onClick={() => go("payments")} />
        <KPI label="Outstanding dues" value={inr(due.reduce((s, p) => s + p.amount, 0))} sub={due.length + " payment links unpaid"} onClick={() => go("payments")} />
        <KPI label="Contacts" value={buildContacts(db).length} onClick={() => go("contacts")} />
        <KPI label="Upcoming confirmed" value={A.filter((a) => a.status === "confirmed" && a.date >= t0).length} />
        <KPI label="Completed visits" value={A.filter((a) => a.status === "completed").length} />
        <KPI label="Ebooks sold" value={db.orders.filter((o) => o.status === "paid").length} onClick={() => go("payments")} />
        <KPI label="Request → confirmed" value={conv + "%"} />
      </div>
      <div className="two">
        <Panel title="Revenue · last 6 months" right={<><span className="lg s"></span><small>Services</small><span className="lg e"></span><small>Ebooks</small></>}>
          <div className="bars">{split.map((r) => <div className="bar-col" key={r.k}><span className="bar-v">{r.service + r.ebook ? inr(r.service + r.ebook) : ""}</span>
            <div className="stack" style={{ height: ((r.service + r.ebook) / max) * 160 + 4 }}><i className="e" style={{ flex: r.ebook || 0.0001 }}></i><i className="s" style={{ flex: r.service || 0.0001 }}></i></div><small>{r.k}</small></div>)}</div>
          <p className="muted small">Only verified, paid transactions. Refunds and unpaid links are excluded.</p>
        </Panel>
        <Panel title="Today">
          {todays.length ? todays.map((a) => <button className="row-mini btnrow" key={a.id} onClick={() => openContact(a.mobile)}><b>{S.fmtTime(a.time)}</b><span>{a.name} · {MODE[a.mode]}{a.area ? " · " + a.area : ""}</span><Badge s={a.status} /></button>) : <Empty>No appointments today.</Empty>}
          <h3 style={{ marginTop: 18 }}>Needs attention</h3>
          {tasks.slice(0, 4).map((t) => <div className="task" key={t.id}><input type="checkbox" onChange={() => mutate((d) => { const x = d.tasks.find((y) => y.id === t.id); x.done = true; }, "Task done", t.id)} /><span>{t.title}</span>{t.due < t0 && <Badge s="overdue">overdue</Badge>}</div>)}
          {due.filter((p) => p.due && p.due < t0).map((p) => <div className="task warn" key={p.id}><span>Overdue payment: {p.name} · {inr(p.amount)}</span><button className="mini" onClick={() => go("payments")}>Open</button></div>)}
          {!tasks.length && !due.length && <Empty>All clear.</Empty>}
        </Panel>
      </div>
    </>
  );
}

/* ---------------- Contacts ---------------- */
function Contacts({ db, openContact }) {
  const all = useMemo(() => buildContacts(db), [db]);
  const [q, setQ] = useState(""); const [stage, setStage] = useState("all"); const [tag, setTag] = useState("");
  const tags = [...new Set(all.flatMap((c) => c.tags))];
  const list = all.filter((c) => (stage === "all" || c.stage === stage) && (!tag || c.tags.includes(tag)) && (!q || (c.name + c.mobile + c.email + c.tags.join(" ")).toLowerCase().includes(q.toLowerCase())));
  const exportCsv = () => {
    const rows = [["name", "mobile", "email", "language", "stage", "tags", "visits", "lifetime_value", "dues", "subscribed", "last_activity"]].concat(list.map((c) => [c.name, c.mobile, c.email, c.lang, c.stage, c.tags.join("|"), c.done.length, c.ltv, c.due, c.subscribed ? "yes" : "no", c.last]));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map((r) => r.map((x) => '"' + String(x).replace(/"/g, '""') + '"').join(",")).join("\n")], { type: "text/csv" })); a.download = "vmp-contacts.csv"; a.click();
  };
  const [adding, setAdding] = useState(false);
  return (
    <>
      <div className="toolbar">
        <input className="search" placeholder="Search name, mobile, email, tag…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={stage} onChange={(e) => setStage(e.target.value)}><option value="all">All stages</option>{STAGES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        <select value={tag} onChange={(e) => setTag(e.target.value)}><option value="">All tags</option>{tags.map((t) => <option key={t}>{t}</option>)}</select>
        <button className="btn-s ghost" onClick={exportCsv}>Export CSV</button>
        <button className="btn-s" onClick={() => setAdding(true)}>+ Add contact</button>
      </div>
      <Panel>
        <div className="tbl-wrap"><table className="tbl">
          <thead><tr><th>Name</th><th>Mobile</th><th>Stage</th><th>Tags</th><th>Visits</th><th>Paid</th><th>Due</th><th>Last activity</th></tr></thead>
          <tbody>{list.map((c) => <tr key={c.key} className="click" onClick={() => openContact(c.key)}>
            <td><b>{c.name || "—"}</b><div className="muted small">{c.sources.slice(0, 3).join(" · ")}</div></td>
            <td>{c.mobile}<div className="muted small">{(c.lang || "").toUpperCase()}</div></td>
            <td><span className={"stage st-" + c.stage}>{(STAGES.find((s) => s[0] === c.stage) || [, c.stage])[1]}</span></td>
            <td>{c.tags.map((t) => <span className="tag" key={t}>{t}</span>)}</td>
            <td>{c.done.length}{c.upcoming.length ? <span className="muted small"> +{c.upcoming.length}</span> : null}</td>
            <td>{c.ltv ? inr(c.ltv) : "—"}</td>
            <td>{c.due ? <b style={{ color: "#b3402a" }}>{inr(c.due)}</b> : "—"}</td>
            <td>{fmtDay(c.last)}</td>
          </tr>)}
            {!list.length && <tr><td colSpan="8"><Empty>No contacts yet — they are created automatically from bookings, enquiries, orders and payments.</Empty></td></tr>}
          </tbody></table></div>
      </Panel>
      <AddContact open={adding} onClose={() => setAdding(false)} openContact={openContact} />
    </>
  );
}
function AddContact({ open, onClose, openContact }) {
  const [f, setF] = useState({ name: "", mobile: "", email: "", lang: "mr", msg: "" });
  const save = () => {
    if (!f.name || normMobile(f.mobile).length !== 10) return toast("Name and 10-digit mobile needed", "warn");
    S.add("enquiries", { name: f.name, mobile: normMobile(f.mobile), email: f.email, lang: f.lang, msg: f.msg || "Added by staff (walk-in / phone)", status: "contacted", by: "admin", silent: true }, "Contact added by staff");
    onClose(); openContact(normMobile(f.mobile)); setF({ name: "", mobile: "", email: "", lang: "mr", msg: "" });
  };
  return <Modal open={open} onClose={onClose} title="Add contact (walk-in / phone call)">
    <div className="fg"><F label="Name"><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></F><F label="Mobile"><input value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} /></F>
      <F label="Email"><input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></F><F label="Language"><select value={f.lang} onChange={(e) => setF({ ...f, lang: e.target.value })}>{LANGS3.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
      <F label="Note" span><textarea rows="2" value={f.msg} onChange={(e) => setF({ ...f, msg: e.target.value })} /></F></div>
    <div className="row end"><button className="btn-s" onClick={save}>Save contact</button></div>
  </Modal>;
}

/* Contact profile drawer */
function ContactDrawer({ db, k, onClose, go, newPayLink, newBooking }) {
  const c = useMemo(() => buildContacts(db).find((x) => x.key === k), [db, k]);
  const [note, setNote] = useState(""); const [tag, setTag] = useState("");
  if (!k) return null;
  if (!c) return <Drawer open onClose={onClose} title="Contact"><Empty>Not found.</Empty></Drawer>;
  const setMeta = (fn, action) => mutate((d) => { d.contactsMeta = d.contactsMeta || {}; const m = d.contactsMeta[c.key] || (d.contactsMeta[c.key] = {}); fn(m); }, action, c.name);
  const timeline = [
    ...c.appts.map((a) => ({ at: a.createdAt, ic: "📅", t: MODE[a.mode] + " · " + dmy(a.date) + " " + S.fmtTime(a.time), s: a.status, sub: svcName(a.service) })),
    ...c.enquiries.map((e) => ({ at: e.createdAt, ic: "💬", t: "Enquiry", s: e.status, sub: e.msg })),
    ...c.orders.map((o) => ({ at: o.createdAt, ic: "📘", t: "Ebook · " + o.title, s: o.status, sub: inr(o.amount) })),
    ...c.payments.map((p) => ({ at: p.createdAt, ic: "₹", t: "Payment " + inr(p.amount) + " · " + p.method, s: p.status, sub: p.purpose + " · " + (p.receipt || "") })),
    ...c.paylinks.map((p) => ({ at: p.createdAt, ic: "🔗", t: "Payment link " + inr(p.amount), s: p.status, sub: p.purpose })),
    ...(db.outbox || []).filter((m) => normMobile(m.to) === c.mobile || (c.email && m.to === c.email)).map((m) => ({ at: m.sentAt || m.createdAt, ic: "✉", t: m.rule + " (" + m.channel + ")", s: m.status, sub: m.text.slice(0, 90) + "…" })),
    ...c.notes.map((n) => ({ at: n.at, ic: "📝", t: "Note", s: null, sub: n.text }))
  ].sort((a, b) => (b.at || "").localeCompare(a.at || ""));
  return (
    <Drawer open onClose={onClose} title={c.name || c.mobile} wide>
      <div className="prof-h">
        <div className="avatar">{(c.name || "?").split(" ").map((x) => x[0]).slice(0, 2).join("")}</div>
        <div style={{ flex: 1 }}>
          <div className="row"><a href={"tel:+91" + c.mobile}>{c.mobile}</a>{c.email && <span className="muted">· {c.email}</span>}<span className="muted">· {(c.lang || "en").toUpperCase()}</span>{c.subscribed && <span className="tag">Newsletter</span>}</div>
          <div className="row" style={{ marginTop: 8 }}>
            <select value={c.stage} onChange={(e) => setMeta((m) => (m.stage = e.target.value === c.autoStage ? undefined : e.target.value), "Stage → " + e.target.value)}>{STAGES.map(([kk, l]) => <option key={kk} value={kk}>{l}{kk === c.autoStage ? " (auto)" : ""}</option>)}</select>
            {c.tags.map((t) => <span className="tag" key={t}>{t}<button onClick={() => setMeta((m) => (m.tags = (m.tags || []).filter((x) => x !== t)))}>×</button></span>)}
            <input className="tag-in" placeholder="+ tag" value={tag} onChange={(e) => setTag(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && tag.trim()) { setMeta((m) => (m.tags = [...new Set([...(m.tags || []), tag.trim()])]), "Tag added"); setTag(""); } }} />
          </div>
        </div>
      </div>
      <div className="kpis" style={{ gridTemplateColumns: "repeat(4,1fr)", margin: "14px 0" }}>
        <KPI label="Visits" value={c.done.length} /><KPI label="Upcoming" value={c.upcoming.length} /><KPI label="Lifetime paid" value={inr(c.ltv)} /><KPI label="Due" value={inr(c.due)} tone={c.due ? "#b3402a" : null} />
      </div>
      <div className="row" style={{ marginBottom: 16 }}>
        <a className="btn-s wa" href={waTo(c.mobile, "Hello " + (c.name || "") + ", ")} target="_blank">WhatsApp</a>
        <a className="btn-s ghost" href={"tel:+91" + c.mobile}>Call</a>
        <button className="btn-s ghost" onClick={() => newBooking(c)}>+ Book appointment</button>
        <button className="btn-s ghost" onClick={() => newPayLink(c)}>+ Payment link</button>
        <button className="btn-s ghost" onClick={() => mutate((d) => d.tasks.unshift({ id: S.uid("TSK"), createdAt: new Date().toISOString(), title: "Follow up with " + c.name, due: today(), done: false, mobile: c.mobile }), "Task created", c.name) || toast("Task added")}>+ Task</button>
      </div>
      <Panel title="Notes (private — never shown to patient)">
        <div className="row"><input style={{ flex: 1 }} placeholder="Add a note… e.g. prefers mornings, uses walker" value={note} onChange={(e) => setNote(e.target.value)} onKeyDown={(e) => e.key === "Enter" && note.trim() && (setMeta((m) => (m.notes = [{ at: new Date().toISOString(), text: note.trim() }, ...(m.notes || [])]), "Note added"), setNote(""))} />
          <button className="btn-s" disabled={!note.trim()} onClick={() => { setMeta((m) => (m.notes = [{ at: new Date().toISOString(), text: note.trim() }, ...(m.notes || [])]), "Note added"); setNote(""); }}>Add</button></div>
        <p className="muted small" style={{ margin: "8px 0 0" }}>Keep clinical details minimal here — detailed records belong in the secure patient file.</p>
      </Panel>
      <Panel title="Timeline">
        <div className="timeline">{timeline.map((e, i) => <div className="tl" key={i}><span className="tl-ic">{e.ic}</span><div><div className="row"><b>{e.t}</b>{e.s && <Badge s={e.s} />}<span className="muted small">{fmtD(e.at)}</span></div>{e.sub && <div className="muted small">{e.sub}</div>}</div></div>)}</div>
      </Panel>
    </Drawer>
  );
}

/* Pipeline (kanban) */
function Pipeline({ db, openContact }) {
  const all = useMemo(() => buildContacts(db), [db]);
  const [drag, setDrag] = useState(null);
  const move = (key, stage) => mutate((d) => { d.contactsMeta = d.contactsMeta || {}; (d.contactsMeta[key] = d.contactsMeta[key] || {}).stage = stage; }, "Pipeline → " + stage, key);
  return (
    <div className="kanban">{STAGES.map(([k, l]) => {
      const col = all.filter((c) => c.stage === k);
      return <div className={"kcol" + (drag ? " droppable" : "")} key={k} onDragOver={(e) => e.preventDefault()} onDrop={() => { drag && move(drag, k); setDrag(null); }}>
        <div className="kcol-h"><b>{l}</b><span>{col.length}</span></div>
        {col.map((c) => <div key={c.key} className="kcard" draggable onDragStart={() => setDrag(c.key)} onDragEnd={() => setDrag(null)} onClick={() => openContact(c.key)}>
          <b>{c.name || c.mobile}</b>
          <small>{c.upcoming[0] ? "Next: " + dmy(c.upcoming[0].date) + " " + S.fmtTime(c.upcoming[0].time) : c.sources.slice(0, 2).join(" · ")}</small>
          <div className="row">{c.tags.slice(0, 2).map((t) => <span className="tag" key={t}>{t}</span>)}{c.due ? <span className="tag red">Due {inr(c.due)}</span> : null}</div>
        </div>)}
      </div>;
    })}</div>
  );
}

function Tasks({ db, openContact }) {
  const [title, setTitle] = useState(""); const [due, setDue] = useState(today()); const [show, setShow] = useState("open");
  const list = (db.tasks || []).filter((t) => (show === "open" ? !t.done : t.done)).sort((a, b) => (a.due || "").localeCompare(b.due || ""));
  const add = () => { if (!title.trim()) return; mutate((d) => d.tasks.unshift({ id: S.uid("TSK"), createdAt: new Date().toISOString(), title: title.trim(), due, done: false }), "Task created"); setTitle(""); };
  return (
    <Panel title="Tasks" right={<Seg value={show} options={[["open", "Open"], ["done", "Done"]]} onChange={setShow} />}>
      <div className="row" style={{ marginBottom: 12 }}><input style={{ flex: 1 }} placeholder="New task…" value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} /><input type="date" value={due} onChange={(e) => setDue(e.target.value)} /><button className="btn-s" onClick={add}>Add</button></div>
      {list.map((t) => <div className={"task" + (t.due < today() && !t.done ? " warn" : "")} key={t.id}>
        <input type="checkbox" checked={t.done} onChange={(e) => mutate((d) => { d.tasks.find((x) => x.id === t.id).done = e.target.checked; }, e.target.checked ? "Task done" : "Task reopened", t.id)} />
        <span style={{ flex: 1 }}>{t.title}{t.auto && <span className="muted small"> · auto: {t.auto}</span>}</span>
        <span className="muted small">{dmy(t.due)}</span>
        {t.mobile && <><a className="mini" href={"tel:+91" + t.mobile}>Call</a><button className="mini" onClick={() => openContact(normMobile(t.mobile))}>Profile</button></>}
        <button className="mini" onClick={() => mutate((d) => (d.tasks = d.tasks.filter((x) => x.id !== t.id)), "Task deleted")}>×</button>
      </div>)}
      {!list.length && <Empty>{show === "open" ? "No open tasks. Automations add call-backs here when bookings arrive." : "Nothing completed yet."}</Empty>}
    </Panel>
  );
}

/* ---------------- Appointments ---------------- */
function Appointments({ db, openContact, newBooking }) {
  const [view, setView] = useState("week"); const [mode, setMode] = useState("all"); const [st, setSt] = useState("all"); const [q, setQ] = useState("");
  const [wk, setWk] = useState(0);
  const act = (a, status) => {
    S.update("appointments", a.id, { status }, "Appointment " + status);
    const m = S.load().outbox.find((x) => x.ref === a.id && x.status === "ready" && x.channel === "whatsapp");
    if (m) { window.open(AU.waUrl(m), "_blank"); AU.markSent(m.id); }
    toast("Marked " + status + (m ? " · WhatsApp opened" : ""), "ok");
  };
  const Actions = ({ a }) => <div className="acts">
    {a.status === "requested" && <><button className="ok" onClick={() => act(a, "confirmed")}>Confirm</button><button onClick={() => act(a, "declined")}>Decline</button></>}
    {a.status === "confirmed" && <><button className="ok" onClick={() => act(a, "completed")}>Completed</button><button onClick={() => act(a, "cancelled")}>Cancel</button></>}
    {a.status === "completed" && !(db.payments || []).some((p) => p.ref === a.id) && <button onClick={() => window.dispatchEvent(new CustomEvent("vmp-collect", { detail: a }))}>Collect payment</button>}
  </div>;
  const start = new Date(); start.setDate(start.getDate() - ((start.getDay() + 6) % 7) + wk * 7);
  const days = Array.from({ length: 6 }, (_, i) => { const d = new Date(start); d.setDate(d.getDate() + i); return d; });
  const hours = []; for (let h = window.BUSINESS.open.start; h < window.BUSINESS.open.end; h++) hours.push(h);
  const list = db.appointments.filter((a) => (mode === "all" || a.mode === mode) && (st === "all" || a.status === st) && (!q || (a.name + a.mobile + a.id).toLowerCase().includes(q.toLowerCase())));
  return (
    <>
      <div className="toolbar">
        <Seg value={view} options={[["week", "Week calendar"], ["list", "List"]]} onChange={setView} />
        {view === "week" && <div className="row"><button className="mini" onClick={() => setWk(wk - 1)}>‹</button><b>{days[0].toLocaleDateString("en-IN", { day: "numeric", month: "short" })} – {days[5].toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</b><button className="mini" onClick={() => setWk(wk + 1)}>›</button>{wk !== 0 && <button className="mini" onClick={() => setWk(0)}>This week</button>}</div>}
        <select value={mode} onChange={(e) => setMode(e.target.value)}><option value="all">All types</option>{Object.entries(MODE).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        {view === "list" && <><select value={st} onChange={(e) => setSt(e.target.value)}><option value="all">All status</option>{["requested", "confirmed", "completed", "cancelled", "declined"].map((s) => <option key={s}>{s}</option>)}</select><input className="search" placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} /></>}
        <button className="btn-s" onClick={() => newBooking({})}>+ New appointment</button>
      </div>
      {view === "week" ? (
        <Panel>
          <div className="cal" style={{ gridTemplateColumns: "60px repeat(6,1fr)" }}>
            <div></div>{days.map((d) => <div key={d} className={"cal-h" + (d.toISOString().slice(0, 10) === today() ? " today" : "")}>{d.toLocaleDateString("en-IN", { weekday: "short" })}<b>{d.getDate()}</b></div>)}
            {hours.map((h) => <React.Fragment key={h}><div className="cal-t">{S.fmtTime(String(h).padStart(2, "0") + ":00").replace(":00", "")}</div>
              {days.map((d) => { const k = d.toISOString().slice(0, 10); const ap = list.filter((a) => a.date === k && parseInt(a.time) === h && !["cancelled", "declined"].includes(a.status));
                return <div className="cal-c" key={k + h}>{ap.map((a) => <button key={a.id} className={"ev ev-" + a.mode + " s-" + a.status} onClick={() => openContact(a.mobile)} title={a.status}><b>{a.time.slice(3) !== "00" ? S.fmtTime(a.time) + " " : ""}{a.name}</b><small>{MODE[a.mode]} · {a.status}</small></button>)}</div>; })}
            </React.Fragment>)}
          </div>
          <div className="row small muted" style={{ marginTop: 10 }}><span className="lg ev-opd"></span>Clinic <span className="lg ev-home"></span>Home <span className="lg ev-online"></span>Online · dashed border = awaiting confirmation</div>
        </Panel>
      ) : (
        <Panel><div className="tbl-wrap"><table className="tbl">
          <thead><tr><th>Ref</th><th>When</th><th>Patient</th><th>Type</th><th>Problem</th><th>Status</th><th></th></tr></thead>
          <tbody>{list.sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time)).map((a) => <tr key={a.id}>
            <td className="mono">{a.id}</td><td><b>{dmy(a.date)}</b><div className="muted small">{S.fmtTime(a.time)}</div></td>
            <td><button className="linkbtn" onClick={() => openContact(a.mobile)}><b>{a.name}</b></button><div className="muted small">{a.mobile} · {(a.plang || "en").toUpperCase()}</div></td>
            <td>{MODE[a.mode]}{a.area && <div className="muted small">{a.area}</div>}</td><td>{svcName(a.service)}</td><td><Badge s={a.status} /></td><td><Actions a={a} /></td></tr>)}
            {!list.length && <tr><td colSpan="7"><Empty>No appointments.</Empty></td></tr>}</tbody></table></div></Panel>
      )}
      <Panel title="Awaiting confirmation">{db.appointments.filter((a) => a.status === "requested").map((a) => <div className="row-mini" key={a.id}><b>{dmy(a.date)} {S.fmtTime(a.time)}</b><span>{a.name} · {MODE[a.mode]} · {svcName(a.service)}</span><Actions a={a} /></div>)}
        {!db.appointments.some((a) => a.status === "requested") && <Empty>Nothing to confirm.</Empty>}</Panel>
    </>
  );
}

function NewBooking({ seed, onClose }) {
  const [f, setF] = useState(() => ({ name: seed.name || "", mobile: seed.mobile || "", plang: seed.lang || "mr", mode: "opd", date: today(), time: "", service: "", area: "", status: "confirmed" }));
  const slots = S.slots(f.date, f.mode);
  const save = () => {
    if (!f.name || normMobile(f.mobile).length !== 10 || !f.time) return toast("Name, mobile and a free slot are needed", "warn");
    if (!S.isFree(f.date, f.time, f.mode)) return toast("That slot is taken", "warn");
    S.add("appointments", { ...f, mobile: normMobile(f.mobile), consent: true, by: "admin", status: "requested" }, "Appointment added by staff");
    const a = S.load().appointments[0];
    if (f.status === "confirmed") S.update("appointments", a.id, { status: "confirmed" }, "Appointment confirmed");
    toast("Appointment saved"); onClose();
  };
  return <Modal open onClose={onClose} title="New appointment (phone / walk-in)" width={640}>
    <div className="fg">
      <F label="Patient name"><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></F>
      <F label="Mobile"><input value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} /></F>
      <F label="Type"><select value={f.mode} onChange={(e) => setF({ ...f, mode: e.target.value, time: "" })}>{Object.entries(MODE).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
      <F label="Language"><select value={f.plang} onChange={(e) => setF({ ...f, plang: e.target.value })}>{LANGS3.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
      <F label="Problem"><select value={f.service} onChange={(e) => setF({ ...f, service: e.target.value })}><option value="">—</option>{window.SERVICE_META.map((m) => <option key={m.slug} value={m.slug}>{svcName(m.slug)}</option>)}</select></F>
      <F label="Date"><input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value, time: "" })} /></F>
      {f.mode === "home" && <F label="Area" span><input value={f.area} onChange={(e) => setF({ ...f, area: e.target.value })} /></F>}
      <F label="Time" span>{slots.closed ? <span className="muted">Clinic closed this day</span> : <div className="slotpick">{slots.list.map((s) => <button key={s.t} disabled={!s.free} className={f.time === s.t ? "on" : ""} onClick={() => setF({ ...f, time: s.t })}>{S.fmtTime(s.t)}</button>)}</div>}</F>
      <F label="Save as" span><Seg value={f.status} options={[["confirmed", "Confirmed (sends confirmation)"], ["requested", "Requested"]]} onChange={(v) => setF({ ...f, status: v })} /></F>
    </div>
    <div className="row end"><button className="btn-s" onClick={save}>Save appointment</button></div>
  </Modal>;
}

function Availability({ db }) {
  const [date, setDate] = useState(today());
  const slots = S.slots(date, "opd");
  const blockedDay = db.blocked.some((b) => b.date === date && !b.time);
  const toggle = (t) => mutate((d) => { const ex = d.blocked.find((b) => b.date === date && b.time === t); d.blocked = ex ? d.blocked.filter((b) => !(b.date === date && b.time === t)) : d.blocked.concat({ date, time: t }); }, "Slot toggled " + date + " " + t);
  const toggleDay = () => mutate((d) => { d.blocked = blockedDay ? d.blocked.filter((b) => !(b.date === date && !b.time)) : d.blocked.concat({ date, time: null }); }, (blockedDay ? "Opened " : "Closed day ") + date);
  return (
    <Panel title="Availability" right={<><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /><button className={"btn-s " + (blockedDay ? "" : "ghost")} onClick={toggleDay}>{blockedDay ? "Re-open day" : "Close whole day (leave)"}</button></>}>
      <p className="muted">One calendar for clinic, home and online — double-booking is impossible. Tap a free slot to block it. Working hours are edited in Website content → Clinic details.</p>
      {slots.closed ? <Empty>Closed day.</Empty> : <div className="slotgrid">{slots.list.map((s) => {
        const manual = db.blocked.some((b) => b.date === date && b.time === s.t);
        const ap = db.appointments.find((a) => a.date === date && a.time === s.t && ["requested", "confirmed"].includes(a.status));
        return <button key={s.t} className={"sl " + (ap ? "booked" : manual ? "blocked" : s.free ? "free" : "busy")} disabled={!!ap} onClick={() => toggle(s.t)}><b>{S.fmtTime(s.t)}</b><small>{ap ? ap.name.split(" ")[0] + " · " + MODE[ap.mode] : manual ? "Blocked" : s.free ? "Free" : blockedDay ? "Closed" : "Unavailable"}</small></button>;
      })}</div>}
    </Panel>
  );
}

function Enquiries({ db, openContact }) {
  return <Panel title="Enquiries"><div className="tbl-wrap"><table className="tbl">
    <thead><tr><th>Received</th><th>Name</th><th>Message</th><th>Status</th><th></th></tr></thead>
    <tbody>{db.enquiries.map((e) => <tr key={e.id}><td>{fmtD(e.createdAt)}</td><td><button className="linkbtn" onClick={() => openContact(e.mobile)}><b>{e.name}</b></button><div className="muted small">{e.mobile} · {(e.lang || "").toUpperCase()}</div></td><td>{e.msg}</td><td><Badge s={e.status} /></td>
      <td className="acts"><select value={e.status} onChange={(x) => S.update("enquiries", e.id, { status: x.target.value }, "Enquiry → " + x.target.value)}>{["new", "contacted", "converted", "closed"].map((s) => <option key={s}>{s}</option>)}</select><a className="mini" href={waTo(e.mobile, "Hello " + e.name + ", thank you for contacting VIP MAGICAL PHYSIO. ")} target="_blank">WhatsApp</a></td></tr>)}
      {!db.enquiries.length && <tr><td colSpan="5"><Empty>No enquiries yet.</Empty></td></tr>}</tbody></table></div></Panel>;
}

function Reviews({ db }) {
  const done = db.appointments.filter((a) => a.status === "completed");
  const msgs = (db.outbox || []).filter((m) => m.ruleId === "r8");
  const asked = (id) => msgs.find((m) => m.ref === id && m.status === "sent") || (db.reviewRequests || []).find((r) => r.appt === id);
  const send = (a) => {
    let m = msgs.find((x) => x.ref === a.id && x.status !== "sent");
    if (!m) { const rule = AU.rules(db).find((r) => r.id === "r8"); const text = AU.fill(rule.tpl[a.plang] || rule.tpl.en, { name: a.name, review: window.BUSINESS.reviewUrl }); m = { id: S.uid("MSG"), to: a.mobile, text, ref: a.id }; mutate((d) => d.outbox.unshift({ ...m, createdAt: new Date().toISOString(), dueAt: new Date().toISOString(), ruleId: "r8", rule: rule.name, channel: "whatsapp", name: a.name, lang: a.plang, status: "ready" })); }
    window.open(AU.waUrl(m), "_blank"); AU.markSent(m.id); toast("Review request sent");
  };
  const q = window.qrcode(0, "M"); q.addData(window.BUSINESS.reviewUrl); q.make();
  return (
    <div className="two">
      <Panel title="Completed patients" right={<span className="muted small">Ask every patient the same way — no filtering, no incentives</span>}>
        {done.map((a) => { const r = asked(a.id); return <div className="row-mini" key={a.id}><b>{a.name}</b><span className="muted">{svcName(a.service)} · {dmy(a.date)}</span>{r ? <Badge s="sent">asked</Badge> : <button className="mini ok" onClick={() => send(a)}>Send on WhatsApp</button>}</div>; })}
        {!done.length && <Empty>Mark visits completed to see them here. A review request is also queued automatically 2 hours after completion.</Empty>}
      </Panel>
      <Panel title="Review link & QR">
        <div className="row"><img src={q.createDataURL(4, 1)} width="120" height="120" alt="QR" style={{ imageRendering: "pixelated", borderRadius: 10, border: "1px solid #eee" }} />
          <div><div className="mono small" style={{ wordBreak: "break-all" }}>{window.BUSINESS.reviewUrl}</div><div className="row" style={{ marginTop: 8 }}><a className="mini" href={window.BUSINESS.reviewUrl} target="_blank">Open</a><a className="mini" href="Review QR Poster.html" target="_blank">Print poster</a></div></div></div>
        <div className="kpis" style={{ gridTemplateColumns: "1fr 1fr", marginTop: 16 }}><KPI label="Requests sent" value={msgs.filter((m) => m.status === "sent").length + (db.reviewRequests || []).length} /><KPI label="Not yet asked" value={done.filter((a) => !asked(a.id)).length} /></div>
        <p className="muted small">Edit the message wording in Automations → "Google review request".</p>
      </Panel>
    </div>
  );
}

Object.assign(window, { Overview, Contacts, ContactDrawer, Pipeline, Tasks, Appointments, NewBooking, Availability, Enquiries, Reviews });
