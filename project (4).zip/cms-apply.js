/* Editable content layer. Admin → "Website content" saves overrides to localStorage key vmp_cms_v1
   (production: a Supabase `site_content` table read at build/SSR time). Loaded after data/i18n/services, before the app. */
(function () {
  const KEY = "vmp_cms_v1";
  const clone = (x) => JSON.parse(JSON.stringify(x));
  // Snapshot shipped defaults once so the admin can diff / reset.
  window.CMS_DEFAULTS = window.CMS_DEFAULTS || {
    business: clone(window.BUSINESS), ui: clone(window.UI), services: clone(window.SERVICES),
    serviceMeta: clone(window.SERVICE_META), ebooks: clone(window.EBOOKS), ebookText: clone(window.EBOOK_TEXT),
    videos: clone(window.VIDEOS), legal: clone(window.LEGAL)
  };
  const CMS = {
    KEY,
    load() { try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) { return {}; } },
    save(c) { c.updatedAt = new Date().toISOString(); localStorage.setItem(KEY, JSON.stringify(c)); window.dispatchEvent(new Event("vmp-cms")); },
    reset() { localStorage.removeItem(KEY); window.dispatchEvent(new Event("vmp-cms")); },
    /* Effective (merged) content, for the editor */
    effective() {
      const d = window.CMS_DEFAULTS, c = CMS.load();
      return {
        business: Object.assign(clone(d.business), c.business || {}, { open: Object.assign(clone(d.business.open), (c.business || {}).open || {}) }),
        ui: Object.assign(clone(d.ui), c.ui || {}),
        services: (() => { const s = clone(d.services); Object.keys(c.services || {}).forEach((k) => (s[k] = Object.assign(s[k] || {}, c.services[k]))); return s; })(),
        serviceMeta: c.serviceMeta || clone(d.serviceMeta),
        ebooks: c.ebooks || clone(d.ebooks).map((b) => Object.assign(b, { active: true })).concat([{ id: "complete-health-bundle", type: "bundle", title: "Complete Health Bundle — all 4 ebooks", titleLatin: "Complete Health Bundle", lang: "en", price: 1299, compareAt: 1696, items: d.ebooks.map((x) => x.id), hue: "#0e2742", accent: "#f2b33d", active: true }]),
        ebookText: Object.assign(clone(d.ebookText), { "complete-health-bundle": { blurb: { en: "All four Dard E Body Care ebooks in one download — strength after 40, health after 35, and both Hindi guides for older adults and daily habits. Best value for families.", mr: "दर्द ए बॉडी केअरची चारही ई-पुस्तके एकाच डाउनलोडमध्ये — ४० नंतरची ताकद, ३५ नंतरचे आरोग्य आणि ज्येष्ठ व रोजच्या सवयींवरील दोन्ही हिंदी मार्गदर्शक. कुटुंबासाठी सर्वोत्तम किंमत.", hi: "दर्द ए बॉडी केयर की चारों ई-बुक्स एक ही डाउनलोड में — 40 के बाद ताकत, 35 के बाद स्वास्थ्य, और बुज़ुर्गों व रोज़ की आदतों पर दोनों हिंदी गाइड। परिवारों के लिए सबसे अच्छी कीमत।" }, for: { en: "Families who want the full set at a lower price.", mr: "कमी किमतीत पूर्ण संच हवा असलेली कुटुंबे.", hi: "जो परिवार कम कीमत में पूरा सेट चाहते हैं।" } } }, c.ebookText || {}),
        videos: c.videos || clone(d.videos),
        announcement: c.announcement || { active: false, tone: "sun", text: { en: "", mr: "", hi: "" } },
        updatedAt: c.updatedAt
      };
    },
    apply() {
      const e = CMS.effective();
      Object.assign(window.BUSINESS, e.business);
      const digits = String(e.business.phone || "").replace(/\D/g, "").slice(-10);
      if (digits.length === 10) { window.BUSINESS.tel = "+91" + digits; window.BUSINESS.wa = "91" + digits; }
      Object.assign(window.UI, e.ui);
      Object.keys(e.services).forEach((k) => (window.SERVICES[k] = e.services[k]));
      window.SERVICE_META = e.serviceMeta;
      window.CMS_ALL_EBOOKS = e.ebooks;
      window.EBOOKS = e.ebooks.filter((b) => b.active !== false);
      window.EBOOK_TEXT = e.ebookText;
      window.VIDEOS = e.videos;
      window.ANNOUNCEMENT = e.announcement;
    }
  };
  window.VMPCMS = CMS;
  CMS.apply();
})();
