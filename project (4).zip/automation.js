/* VIP MAGICAL PHYSIO — Automation engine (runs on site + admin).
   Rules live in db.rules. Events from the store become outbox messages / tasks.
   Production: Supabase DB triggers + Edge Function cron → Brevo (email/SMS) ; WhatsApp stays click-to-chat. */
(function () {
  const S = () => window.VMPStore;
  const B = () => window.BUSINESS;
  const MODE_TXT = {
    opd: { en: "Clinic OPD", mr: "क्लिनिक OPD", hi: "क्लिनिक OPD" },
    home: { en: "Home visit", mr: "घरी भेट", hi: "होम विज़िट" },
    online: { en: "Online consultation", mr: "ऑनलाइन सल्ला", hi: "ऑनलाइन परामर्श" }
  };
  const EVENTS = {
    "appointment.requested": "Appointment requested (website)",
    "appointment.confirmed": "Appointment confirmed",
    "appointment.reminder": "24 h before appointment",
    "appointment.cancelled": "Appointment cancelled",
    "appointment.declined": "Appointment declined",
    "appointment.completed": "Appointment completed",
    "appointment.followup": "7 days after completed visit",
    "enquiry.new": "New enquiry",
    "order.paid": "Ebook payment verified",
    "order.failed": "Ebook payment failed",
    "subscriber.new": "New newsletter subscriber",
    "paylink.created": "Payment link created",
    "paylink.overdue": "Payment link unpaid after due date",
    "payment.received": "Payment received"
  };
  const CHANNELS = { whatsapp: "WhatsApp (1-tap)", email: "Email (Brevo)", sms: "SMS (Brevo)", task: "Task for staff", admin: "Alert to clinic" };

  const T = (en, mr, hi) => ({ en, mr, hi });
  const DEFAULT_RULES = [
    { id: "r1", name: "Booking request acknowledgement", on: "appointment.requested", channel: "email", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, we received your {mode} request for {date} at {time}. Ref {ref}. It is NOT yet confirmed — the clinic will call you. VIP MAGICAL PHYSIO · {phone}",
        "नमस्कार {name}, {date} रोजी {time} साठी तुमची {mode} विनंती मिळाली. संदर्भ {ref}. अजून निश्चित नाही — क्लिनिक तुम्हाला कॉल करेल. VIP MAGICAL PHYSIO · {phone}",
        "नमस्ते {name}, {date} को {time} के लिए आपका {mode} अनुरोध मिला। संदर्भ {ref}. अभी पक्का नहीं — क्लिनिक आपको कॉल करेगा। VIP MAGICAL PHYSIO · {phone}") },
    { id: "r2", name: "Alert clinic: new booking", on: "appointment.requested", channel: "admin", delayMin: 0, active: true, audience: "internal",
      tpl: T("New {mode} request: {name} ({mobile}) · {date} {time} · {service}. Ref {ref}", "", "") },
    { id: "r3", name: "Task: call to confirm", on: "appointment.requested", channel: "task", delayMin: 0, active: true, audience: "internal",
      tpl: T("Call {name} ({mobile}) to confirm {mode} on {date} {time}", "", "") },
    { id: "r4", name: "Confirmation message", on: "appointment.confirmed", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, your {mode} appointment at VIP MAGICAL PHYSIO is CONFIRMED for {date} at {time}. Ref {ref}. Pabal Phata, Shirur · {phone}",
        "नमस्कार {name}, VIP MAGICAL PHYSIO येथे तुमची {mode} अपॉइंटमेंट {date} रोजी {time} वाजता निश्चित झाली आहे. संदर्भ {ref}. पाबळ फाटा, शिरूर · {phone}",
        "नमस्ते {name}, VIP MAGICAL PHYSIO में आपकी {mode} अपॉइंटमेंट {date} को {time} बजे पक्की हो गई है। संदर्भ {ref}. पाबल फाटा, शिरूर · {phone}") },
    { id: "r5", name: "Reminder 24 h before", on: "appointment.reminder", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Reminder: your {mode} appointment at VIP MAGICAL PHYSIO is tomorrow ({date}) at {time}. Reply to reschedule. Ref {ref}",
        "आठवण: VIP MAGICAL PHYSIO येथे तुमची {mode} अपॉइंटमेंट उद्या ({date}) {time} वाजता आहे. वेळ बदलायची असल्यास कळवा. संदर्भ {ref}",
        "याद दिलाना: VIP MAGICAL PHYSIO में आपकी {mode} अपॉइंटमेंट कल ({date}) {time} बजे है। समय बदलना हो तो बताएँ। संदर्भ {ref}") },
    { id: "r6", name: "Cancellation notice", on: "appointment.cancelled", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, your appointment on {date} at {time} (Ref {ref}) has been cancelled. Call {phone} to book again.",
        "नमस्कार {name}, {date} रोजी {time} ची तुमची अपॉइंटमेंट (संदर्भ {ref}) रद्द झाली आहे. पुन्हा बुक करण्यासाठी {phone} वर कॉल करा.",
        "नमस्ते {name}, {date} को {time} की आपकी अपॉइंटमेंट (संदर्भ {ref}) रद्द हो गई है। फिर से बुक करने के लिए {phone} पर कॉल करें।") },
    { id: "r7", name: "Slot not available", on: "appointment.declined", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, sorry — {time} on {date} is not available. Please call {phone} or reply for another time.",
        "नमस्कार {name}, क्षमस्व — {date} रोजी {time} ची वेळ उपलब्ध नाही. कृपया {phone} वर कॉल करा किंवा दुसऱ्या वेळेसाठी कळवा.",
        "नमस्ते {name}, क्षमा करें — {date} को {time} का समय उपलब्ध नहीं है। कृपया {phone} पर कॉल करें या दूसरे समय के लिए बताएँ।") },
    { id: "r8", name: "Google review request", on: "appointment.completed", channel: "whatsapp", delayMin: 120, active: true, audience: "treatment",
      tpl: T("Thank you for visiting VIP MAGICAL PHYSIO, {name}. If you have a minute, please share your honest experience on Google — it helps other families in Shirur: {review}",
        "{name}, VIP MAGICAL PHYSIO ला भेट दिल्याबद्दल धन्यवाद. एक मिनिट असल्यास कृपया तुमचा प्रामाणिक अनुभव Google वर लिहा — शिरूरमधील इतर कुटुंबांना मदत होईल: {review}",
        "{name}, VIP MAGICAL PHYSIO आने के लिए धन्यवाद। एक मिनट हो तो कृपया अपना ईमानदार अनुभव Google पर लिखें — इससे शिरूर के दूसरे परिवारों को मदद मिलती है: {review}") },
    { id: "r9", name: "Follow-up check-in", on: "appointment.followup", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, Dr. Vipul here. How are your exercises going? Reply if you need a review visit.",
        "नमस्कार {name}, मी डॉ. विपुल. तुमचे व्यायाम कसे चालू आहेत? पुन्हा तपासणी हवी असल्यास कळवा.",
        "नमस्ते {name}, मैं डॉ. विपुल। आपके व्यायाम कैसे चल रहे हैं? दोबारा जाँच चाहिए तो बताएँ।") },
    { id: "r10", name: "Enquiry acknowledgement", on: "enquiry.new", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, thank you for contacting VIP MAGICAL PHYSIO. We will reply within working hours (Mon–Sat, 9–5).",
        "नमस्कार {name}, VIP MAGICAL PHYSIO शी संपर्क केल्याबद्दल धन्यवाद. कामाच्या वेळेत (सोम–शनि, ९–५) आम्ही उत्तर देऊ.",
        "नमस्ते {name}, VIP MAGICAL PHYSIO से संपर्क करने के लिए धन्यवाद। काम के समय (सोम–शनि, 9–5) में हम जवाब देंगे।") },
    { id: "r11", name: "Ebook delivery email", on: "order.paid", channel: "email", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Thank you {name}! Your payment of ₹{amount} for \"{product}\" is verified. Download: {link} (5 downloads, valid 7 days). Order {ref}.",
        "धन्यवाद {name}! \"{product}\" साठी ₹{amount} चे पेमेंट निश्चित झाले. डाउनलोड: {link} (५ वेळा, ७ दिवस). ऑर्डर {ref}.",
        "धन्यवाद {name}! \"{product}\" के लिए ₹{amount} का भुगतान पक्का हुआ। डाउनलोड: {link} (5 बार, 7 दिन)। ऑर्डर {ref}.") },
    { id: "r12", name: "Failed payment help", on: "order.failed", channel: "email", delayMin: 30, active: true, audience: "treatment",
      tpl: T("Hello {name}, your payment for \"{product}\" did not complete. No money was taken. You can try again here: {link}",
        "नमस्कार {name}, \"{product}\" साठी पेमेंट पूर्ण झाले नाही. पैसे घेतले नाहीत. पुन्हा प्रयत्न करा: {link}",
        "नमस्ते {name}, \"{product}\" के लिए भुगतान पूरा नहीं हुआ। पैसा नहीं लिया गया। फिर से कोशिश करें: {link}") },
    { id: "r13", name: "Newsletter welcome", on: "subscriber.new", channel: "email", delayMin: 0, active: true, audience: "marketing",
      tpl: T("Welcome to Dard E Body Care health tips! One short, useful tip every fortnight. Unsubscribe anytime.",
        "दर्द ए बॉडी केअर आरोग्य टिप्समध्ये स्वागत! दर पंधरा दिवसांनी एक छोटी, उपयुक्त टीप. कधीही बंद करा.",
        "दर्द ए बॉडी केयर स्वास्थ्य टिप्स में स्वागत! हर पंद्रह दिन एक छोटी, उपयोगी टिप। कभी भी बंद करें।") },
    { id: "r14", name: "Send payment link", on: "paylink.created", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Hello {name}, here is your secure payment link for {product}: ₹{amount}. Pay by UPI/card: {link} — VIP MAGICAL PHYSIO",
        "नमस्कार {name}, {product} साठी तुमची सुरक्षित पेमेंट लिंक: ₹{amount}. UPI/कार्डने भरा: {link} — VIP MAGICAL PHYSIO",
        "नमस्ते {name}, {product} के लिए आपका सुरक्षित भुगतान लिंक: ₹{amount}. UPI/कार्ड से भरें: {link} — VIP MAGICAL PHYSIO") },
    { id: "r15", name: "Payment reminder (overdue)", on: "paylink.overdue", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Gentle reminder {name}: ₹{amount} for {product} is pending. Pay here: {link}. Ignore if already paid.",
        "सौम्य आठवण {name}: {product} साठी ₹{amount} बाकी आहे. येथे भरा: {link}. आधीच भरले असल्यास दुर्लक्ष करा.",
        "विनम्र याद {name}: {product} के लिए ₹{amount} बाकी है। यहाँ भरें: {link}. पहले ही भर दिया हो तो अनदेखा करें।") },
    { id: "r16", name: "Payment receipt", on: "payment.received", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment",
      tpl: T("Received ₹{amount} for {product}. Receipt {ref}. Thank you — VIP MAGICAL PHYSIO",
        "{product} साठी ₹{amount} मिळाले. पावती {ref}. धन्यवाद — VIP MAGICAL PHYSIO",
        "{product} के लिए ₹{amount} प्राप्त हुए। रसीद {ref}. धन्यवाद — VIP MAGICAL PHYSIO") }
  ];

  const pad = (n) => String(n).padStart(2, "0");
  const dmy = (d) => (d ? d.split("-").reverse().join("/") : "");
  const siteBase = () => location.href.replace(/[^/]*(\?.*)?(#.*)?$/, "") + "index.html";

  function rules(db) { return db.rules || JSON.parse(JSON.stringify(DEFAULT_RULES)); }
  function fill(tpl, v) { return String(tpl || "").replace(/\{(\w+)\}/g, (_, k) => (v[k] != null ? v[k] : "")); }

  function vars(type, r) {
    const lang = r.plang || r.lang || "en";
    const base = { name: r.name || "", mobile: r.mobile || "", phone: B().phone, review: B().reviewUrl, ref: r.id, lang };
    if (type === "appointments") {
      const svc = window.SERVICES && window.SERVICES[r.service] ? window.SERVICES[r.service].title[lang] || window.SERVICES[r.service].title.en : "";
      return Object.assign(base, { mode: (MODE_TXT[r.mode] || {})[lang] || r.mode, date: dmy(r.date), time: S().fmtTime(r.time), service: svc });
    }
    if (type === "orders") return Object.assign(base, { amount: r.amount, product: r.title, link: siteBase() + "#/" + lang + "/store/" + r.product });
    if (type === "paylinks") return Object.assign(base, { amount: r.amount, product: r.purpose, link: siteBase() + "#/" + lang + "/pay/" + r.id });
    if (type === "payments") return Object.assign(base, { amount: r.amount, product: r.purpose, ref: r.receipt || r.id });
    if (type === "subscribers") return Object.assign(base, { name: r.email });
    return base;
  }

  function eventFor(type, before, after) {
    if (type === "appointments") {
      if (!before) return "appointment." + (after.status || "requested");
      if (before.status !== after.status) return "appointment." + after.status;
      return null;
    }
    if (type === "enquiries" && !before && !after.silent) return "enquiry.new";
    if (type === "orders") { if (before && before.status !== after.status && (after.status === "paid" || after.status === "failed")) return "order." + after.status; return null; }
    if (type === "subscribers" && !before) return "subscriber.new";
    if (type === "paylinks" && !before) return "paylink.created";
    if (type === "payments" && !before && after.status === "paid" && !after.silent) return "payment.received";
    return null;
  }

  function enqueue(db, rule, type, rec, dueAt) {
    const v = vars(type, rec);
    const lang = ["en", "mr", "hi"].includes(v.lang) ? v.lang : "en";
    const text = fill(rule.tpl[lang] || rule.tpl.en, v);
    const now = new Date();
    const due = dueAt || new Date(now.getTime() + (rule.delayMin || 0) * 60000);
    if (rule.channel === "task") {
      db.tasks.unshift({ id: S().uid("TSK"), createdAt: now.toISOString(), title: text, due: due.toISOString().slice(0, 10), done: false, ref: rec.id, mobile: rec.mobile, auto: rule.name });
      return;
    }
    const to = rule.channel === "email" ? rec.email : rule.channel === "admin" ? "clinic" : rec.mobile;
    let status = due > now ? "scheduled" : "ready";
    let note = "";
    if (!to) { status = "skipped"; note = rule.channel === "email" ? "No email on record" : "No mobile on record"; }
    if (rule.audience === "marketing" && !rec.consent) { status = "skipped"; note = "No marketing consent"; }
    db.outbox.unshift({ id: S().uid("MSG"), createdAt: now.toISOString(), dueAt: due.toISOString(), ruleId: rule.id, rule: rule.name, channel: rule.channel, to: to || "", name: rec.name || rec.email || "", lang, text, ref: rec.id, status, note });
  }

  const Auto = {
    EVENTS, CHANNELS, DEFAULT_RULES, MODE_TXT, fill, rules, siteBase,
    handle(type, before, after) {
      const ev = eventFor(type, before, after); if (!ev) return;
      const db = S().load();
      rules(db).filter((r) => r.active && r.on === ev).forEach((r) => enqueue(db, r, type, after));
      // schedule time-based follow-ons
      if (ev === "appointment.confirmed") {
        const start = new Date(after.date + "T" + after.time + ":00");
        const due = new Date(start.getTime() - 24 * 3600000);
        rules(db).filter((r) => r.active && r.on === "appointment.reminder").forEach((r) => enqueue(db, r, type, after, due < new Date() ? new Date() : due));
      }
      if (ev === "appointment.completed") {
        const due = new Date(Date.now() + 7 * 86400000);
        rules(db).filter((r) => r.active && r.on === "appointment.followup").forEach((r) => enqueue(db, r, type, after, due));
      }
      if (["appointment.cancelled", "appointment.declined"].includes(ev)) {
        db.outbox.forEach((m) => { if (m.ref === after.id && m.status === "scheduled") { m.status = "skipped"; m.note = "Appointment " + after.status; } });
      }
      S().save(db);
      Auto.tick();
    },
    /* Runs every 30 s: release due messages, auto-send email/SMS/admin (via Brevo in production), flag overdue payment links. */
    tick() {
      const db = S().load(); const now = new Date(); let changed = false;
      db.outbox.forEach((m) => {
        if (m.status === "scheduled" && new Date(m.dueAt) <= now) { m.status = "ready"; changed = true; }
        if (m.status === "ready" && ["email", "sms", "admin"].includes(m.channel)) {
          m.status = "sent"; m.sentAt = now.toISOString(); m.note = m.channel === "admin" ? "Shown in dashboard + email to clinic" : "Sent via Brevo (simulated)"; changed = true;
        }
      });
      (db.paylinks || []).forEach((p) => {
        if (p.status === "unpaid" && p.due && new Date(p.due + "T23:59:59") < now && !p.overdueSent) {
          p.overdueSent = true; changed = true;
          rules(db).filter((r) => r.active && r.on === "paylink.overdue").forEach((r) => enqueue(db, r, "paylinks", p));
        }
      });
      if (changed) S().save(db);
    },
    markSent(id) { const db = S().load(); const m = db.outbox.find((x) => x.id === id); if (m) { m.status = "sent"; m.sentAt = new Date().toISOString(); m.note = "Sent by staff (WhatsApp)"; S().save(db); } },
    waUrl(m) { return "https://wa.me/91" + String(m.to).replace(/\D/g, "").slice(-10) + "?text=" + encodeURIComponent(m.text); },
    test(rule, lang) {
      const sample = { id: "VMP-DEMO1", name: "Sunita Pawar", mobile: "9822000000", email: "sunita@example.com", mode: "home", date: "2026-11-25", time: "10:00", service: "knee-pain", plang: lang, amount: 499, title: "Stronger After 40", purpose: "Home visit session", product: "stronger-after-40" };
      const type = rule.on.split(".")[0];
      const map = { appointment: "appointments", enquiry: "enquiries", order: "orders", subscriber: "subscribers", paylink: "paylinks", payment: "payments" };
      return fill(rule.tpl[lang] || rule.tpl.en, vars(map[type], sample));
    }
  };
  window.VMPAuto = Auto;
  setInterval(() => { try { Auto.tick(); } catch (e) {} }, 30000);
})();
