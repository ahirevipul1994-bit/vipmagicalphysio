/* Admin v2 — shared helpers & UI primitives */
const { useState, useEffect, useMemo, useRef, useCallback } = React;
const S = window.VMPStore, AU = window.VMPAuto, CMS = window.VMPCMS;
const MODE = { opd: "Clinic OPD", home: "Home visit", online: "Online" };
const LANGS3 = [["en", "English"], ["mr", "मराठी"], ["hi", "हिंदी"]];
const STATUS_B = { requested: "b-req", confirmed: "b-conf", completed: "b-done", cancelled: "b-can", declined: "b-can", new: "b-req", contacted: "b-conf", converted: "b-done", closed: "b-can", created: "b-req", paid: "b-paid", failed: "b-fail", refunded: "b-can", unpaid: "b-req", overdue: "b-fail", scheduled: "b-conf", ready: "b-req", sent: "b-done", skipped: "b-can" };
const inr = (n) => "₹" + Math.round(n || 0).toLocaleString("en-IN");
const fmtD = (s) => (s ? new Date(s).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "");
const fmtDay = (s) => (s ? new Date(s).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) : "");
const dmy = (d) => (d ? d.split("-").reverse().join("/") : "");
const today = () => new Date().toISOString().slice(0, 10);
const svcName = (s) => (window.SERVICES[s] ? window.SERVICES[s].title.en : s === "other" ? "Other" : "—");
const normMobile = (m) => String(m || "").replace(/\D/g, "").slice(-10);
const waTo = (m, txt) => "https://wa.me/91" + normMobile(m) + "?text=" + encodeURIComponent(txt || "");

function useDB() {
  const [db, setDb] = useState(S.load());
  useEffect(() => {
    const f = () => setDb(S.load());
    window.addEventListener("vmp-store", f); window.addEventListener("storage", f);
    const iv = setInterval(f, 15000);
    return () => { window.removeEventListener("vmp-store", f); window.removeEventListener("storage", f); clearInterval(iv); };
  }, []);
  return db;
}
function mutate(fn, action, ref) { const db = S.load(); fn(db); if (action) db.log.unshift({ at: new Date().toISOString(), who: "admin", action, ref: ref || "—" }); S.save(db); }

/* Toasts */
let pushToast = () => {};
function Toasts() {
  const [list, setList] = useState([]);
  pushToast = (msg, tone) => { const id = Math.random(); setList((l) => [...l, { id, msg, tone }]); setTimeout(() => setList((l) => l.filter((x) => x.id !== id)), 2600); };
  return <div className="toasts">{list.map((t) => <div key={t.id} className={"toast " + (t.tone || "")}>{t.msg}</div>)}</div>;
}
const toast = (m, tone) => pushToast(m, tone);

function Badge({ s, children }) { return <span className={"badge " + (STATUS_B[s] || "b-can")}>{children || s}</span>; }
function KPI({ label, value, sub, tone, onClick }) {
  return <button className={"kpi" + (onClick ? " click" : "")} onClick={onClick} style={tone ? { background: tone, borderColor: tone } : null}>
    <small style={tone ? { color: "rgba(255,255,255,.8)" } : null}>{label}</small>
    <b style={tone ? { color: "#fff" } : null}>{value}</b>
    {sub && <span style={tone ? { color: "rgba(255,255,255,.85)" } : null}>{sub}</span>}
  </button>;
}
function Panel({ title, right, children, style }) {
  return <section className="panel" style={style}>{(title || right) && <div className="panel-h"><h3>{title}</h3><div className="row">{right}</div></div>}{children}</section>;
}
function Drawer({ open, onClose, title, children, wide }) {
  if (!open) return null;
  return <div className="drawer-bg" onClick={onClose}><aside className={"drawer" + (wide ? " wide" : "")} onClick={(e) => e.stopPropagation()}>
    <div className="drawer-h"><h2>{title}</h2><button className="x" onClick={onClose} aria-label="Close">×</button></div>
    <div className="drawer-b">{children}</div></aside></div>;
}
function Modal({ open, onClose, title, children, width }) {
  if (!open) return null;
  return <div className="drawer-bg center-m" onClick={onClose}><div className="modal-c" style={{ maxWidth: width || 520 }} onClick={(e) => e.stopPropagation()}>
    <div className="drawer-h"><h2>{title}</h2><button className="x" onClick={onClose}>×</button></div><div className="drawer-b">{children}</div></div></div>;
}
function F({ label, children, hint, span }) { return <label className="f" style={span ? { gridColumn: "1/-1" } : null}><span>{label}</span>{children}{hint && <em>{hint}</em>}</label>; }
function Empty({ children }) { return <div className="empty">{children}</div>; }
function Seg({ value, options, onChange }) {
  return <div className="seg">{options.map(([v, l]) => <button key={v} className={value === v ? "on" : ""} onClick={() => onChange(v)}>{l}</button>)}</div>;
}
function Toggle({ on, onChange, label }) { return <label className="tgl"><input type="checkbox" checked={!!on} onChange={(e) => onChange(e.target.checked)} /><i></i>{label && <span>{label}</span>}</label>; }

/* Trilingual text editor with AI translate from English */
function Tri({ value, onChange, rows, label }) {
  const v = value || { en: "", mr: "", hi: "" };
  const [busy, setBusy] = useState(false);
  const translate = async () => {
    if (!v.en) return toast("Write the English text first", "warn");
    if (!window.genspark && !window.claude) return toast("AI translate is not available here", "warn");
    setBusy(true);
    try {
      const ask = (window.genspark || window.claude).complete;
      const out = await ask(`Translate this physiotherapy clinic website text into natural, simple Marathi and Hindi for Indian patients. Keep names (VIP MAGICAL PHYSIO, Dr. Vipul Ahire, Shirur), numbers and placeholders like {name} unchanged. Reply ONLY with JSON {"mr":"...","hi":"..."}.\n\nText: ${v.en}`);
      const j = JSON.parse(out.slice(out.indexOf("{"), out.lastIndexOf("}") + 1));
      onChange({ ...v, mr: j.mr || v.mr, hi: j.hi || v.hi });
      toast("Translated — please review Marathi & Hindi", "ok");
    } catch (e) { toast("Translation failed — try again", "warn"); }
    setBusy(false);
  };
  return (
    <div className="tri">
      {label && <div className="tri-h"><b>{label}</b><button className="mini" onClick={translate} disabled={busy}>{busy ? "Translating…" : "✦ AI translate EN → मराठी/हिंदी"}</button></div>}
      <div className="tri-g">
        {LANGS3.map(([k, l]) => <label key={k}><small>{l}</small>
          {rows > 1 ? <textarea rows={rows} value={v[k] || ""} lang={k} onChange={(e) => onChange({ ...v, [k]: e.target.value })} /> : <input value={v[k] || ""} lang={k} onChange={(e) => onChange({ ...v, [k]: e.target.value })} />}
        </label>)}
      </div>
    </div>
  );
}

/* ---- Contacts (CRM) are derived from every touchpoint and keyed by mobile (or email) ---- */
function buildContacts(db) {
  const map = {};
  const keyOf = (r) => normMobile(r.mobile) || (r.email || "").toLowerCase();
  const touch = (r, kind, extra) => {
    const k = keyOf(r); if (!k) return;
    const c = map[k] || (map[k] = { key: k, name: "", mobile: normMobile(r.mobile), email: "", lang: "", first: r.createdAt, last: r.createdAt, appts: [], enquiries: [], orders: [], payments: [], paylinks: [], subscribed: false, sources: new Set() });
    if (r.name && (!c.name || kind === "appt")) c.name = r.name;
    if (r.email && !c.email) c.email = r.email;
    if (!c.mobile && r.mobile) c.mobile = normMobile(r.mobile);
    c.lang = c.lang || r.plang || r.lang || "";
    const at = r.createdAt || "";
    if (at && (!c.first || at < c.first)) c.first = at;
    if (at && (!c.last || at > c.last)) c.last = at;
    c.sources.add(extra || kind);
    return c;
  };
  db.appointments.forEach((a) => { const c = touch(a, "appt", MODE[a.mode]); c && c.appts.push(a); });
  db.enquiries.forEach((e) => { const c = touch(e, "enquiry", "Enquiry"); c && c.enquiries.push(e); });
  db.orders.forEach((o) => { const c = touch(o, "order", "Ebook"); c && c.orders.push(o); });
  (db.payments || []).forEach((p) => { const c = touch(p, "payment", "Payment"); c && c.payments.push(p); });
  (db.paylinks || []).forEach((p) => { const c = touch(p, "paylink", "Payment link"); c && c.paylinks.push(p); });
  db.subscribers.forEach((s) => { const c = touch(s, "sub", "Newsletter"); if (c) c.subscribed = true; });
  const meta = db.contactsMeta || {};
  return Object.values(map).map((c) => {
    const m = meta[c.key] || {};
    const paid = c.payments.filter((p) => p.status === "paid").reduce((s, p) => s + p.amount, 0);
    const refunded = c.payments.filter((p) => p.status === "refunded").reduce((s, p) => s + p.amount, 0);
    const upcoming = c.appts.filter((a) => ["requested", "confirmed"].includes(a.status) && a.date >= today());
    const done = c.appts.filter((a) => a.status === "completed");
    let stage = "lead";
    if (upcoming.length && done.length) stage = "treatment";
    else if (upcoming.length) stage = "booked";
    else if (done.length) stage = "followup";
    else if (c.orders.some((o) => o.status === "paid")) stage = "customer";
    return Object.assign(c, { sources: [...c.sources], ltv: paid - refunded, stage: m.stage || stage, autoStage: stage, tags: m.tags || [], notes: m.notes || [], due: c.paylinks.filter((p) => p.status === "unpaid").reduce((s, p) => s + p.amount, 0), upcoming, done });
  }).sort((a, b) => (b.last || "").localeCompare(a.last || ""));
}
const STAGES = [["lead", "New lead"], ["booked", "Booked"], ["treatment", "In treatment"], ["followup", "Completed · follow-up"], ["customer", "Ebook customer"], ["inactive", "Inactive"]];

/* ---- Demo data ---- */
function seedDemo() {
  const names = [["Sunita Pawar", "mr"], ["Ramesh Gaikwad", "mr"], ["Anil Shinde", "mr"], ["Priya Kulkarni", "en"], ["Rajesh Yadav", "hi"], ["Meena Bhosale", "mr"], ["Vikas Sharma", "hi"], ["Asha Jadhav", "mr"], ["Kiran Thorat", "en"], ["Savita More", "mr"], ["Ganesh Lande", "mr"], ["Pooja Verma", "hi"]];
  const mob = (i) => "98" + String(22001000 + i * 1373).slice(0, 8);
  const svcs = ["knee-pain", "back-pain", "stroke-rehab", "neck-pain", "post-op-rehab", "shoulder-pain", "geriatric", "balance-falls"];
  const db = S.empty();
  const ymd = (d) => d.toISOString().slice(0, 10);
  const used = {};
  const fee = { opd: 500, home: 800, online: 400 };
  for (let i = 0; i < 30; i++) {
    const d = new Date(); d.setDate(d.getDate() + (i < 18 ? -Math.floor(i * 2.6) - 1 : i - 17));
    if (d.getDay() === 0) d.setDate(d.getDate() + 1);
    const mode = ["opd", "opd", "home", "online", "opd"][i % 5];
    let h = 9 + (i % 7); while (used[ymd(d) + h]) h = h >= 15 ? 9 : h + 1; used[ymd(d) + h] = 1;
    const n = i % names.length; const past = i < 18;
    const status = past ? ["completed", "completed", "completed", "cancelled", "completed", "declined"][i % 6] : ["requested", "confirmed", "confirmed", "requested"][i % 4];
    const a = { id: "VMP-" + (1100 + i), createdAt: new Date(d.getTime() - 2 * 86400000).toISOString(), mode, date: ymd(d), time: String(h).padStart(2, "0") + ":00", name: names[n][0], mobile: mob(n), email: n % 3 === 0 ? names[n][0].split(" ")[0].toLowerCase() + "@gmail.com" : "", plang: names[n][1], service: svcs[i % svcs.length], area: mode === "home" ? ["Shirur city", "Ramling", "Baburaonagar", "Sharadwadi", "Annapur"][i % 5] : "", address: mode === "home" ? "Near main road" : "", msg: "", consent: true, status };
    db.appointments.push(a);
    if (status === "completed") db.payments.push({ id: "PAY-" + (2000 + i), createdAt: new Date(d.getTime() + 3600000).toISOString(), kind: mode, ref: a.id, name: a.name, mobile: a.mobile, purpose: MODE[mode] + " · " + svcName(a.service), amount: fee[mode], method: ["Cash", "UPI", "UPI", "Razorpay"][i % 4], status: "paid", receipt: "RCPT-" + (3000 + i), silent: true });
  }
  window.EBOOKS.forEach(() => {});
  for (let i = 0; i < 16; i++) {
    const b = window.EBOOKS[i % window.EBOOKS.length]; const d = new Date(); d.setDate(d.getDate() - Math.floor(i * 4.7));
    const st = i % 7 === 3 ? "failed" : "paid"; const n = (i + 4) % names.length;
    const o = { id: "ORD-" + (5100 + i), createdAt: d.toISOString(), product: b.id, title: b.titleLatin || b.title, amount: b.price, name: names[n][0], email: "reader" + i + "@gmail.com", mobile: mob(n), status: st, paymentId: st === "paid" ? "pay_demo" + i : "", downloads: st === "paid" ? 1 + (i % 3) : 0, lang: names[n][1] };
    db.orders.push(o);
    if (st === "paid") db.payments.push({ id: "PAY-E" + i, createdAt: d.toISOString(), kind: "ebook", ref: o.id, name: o.name, mobile: o.mobile, email: o.email, purpose: "Ebook: " + o.title, amount: o.amount, method: "Razorpay", gatewayId: o.paymentId, status: i === 8 ? "refunded" : "paid", receipt: "RCPT-E" + i, silent: true });
  }
  const plDue = (k) => { const d = new Date(); d.setDate(d.getDate() + k); return ymd(d); };
  db.paylinks.push({ id: "PL-7001", createdAt: new Date(Date.now() - 6 * 86400000).toISOString(), name: names[2][0], mobile: mob(2), lang: "mr", purpose: "Stroke rehab — 10 home sessions", amount: 7000, kind: "package", due: plDue(-2), status: "unpaid" });
  db.paylinks.push({ id: "PL-7002", createdAt: new Date(Date.now() - 86400000).toISOString(), name: names[3][0], mobile: mob(3), lang: "en", purpose: "Online consultation · 45 min", amount: 600, kind: "online", due: plDue(2), status: "unpaid" });
  db.paylinks.push({ id: "PL-7003", createdAt: new Date(Date.now() - 9 * 86400000).toISOString(), name: names[6][0], mobile: mob(6), lang: "hi", purpose: "Post-op knee rehab package", amount: 4500, kind: "package", due: plDue(-6), status: "paid", paidAt: new Date(Date.now() - 7 * 86400000).toISOString() });
  db.payments.push({ id: "PAY-L3", createdAt: new Date(Date.now() - 7 * 86400000).toISOString(), kind: "package", ref: "PL-7003", name: names[6][0], mobile: mob(6), purpose: "Post-op knee rehab package", amount: 4500, method: "Razorpay", status: "paid", receipt: "RCPT-L3", silent: true });
  db.paylinks[2].paymentId = "PAY-L3";
  ["Is home visit available in Ramling?", "Fees for knee pain?", "Online consult from Pune possible?", "Mother has stroke, need home physio", "Do you treat sciatica?"].forEach((m, i) => {
    const d = new Date(); d.setDate(d.getDate() - i * 3); const n = (i + 7) % names.length;
    db.enquiries.push({ id: "ENQ-" + (40 + i), createdAt: d.toISOString(), name: names[n][0], mobile: mob(n), msg: m, lang: names[n][1], status: ["new", "contacted", "converted", "new", "closed"][i] });
  });
  for (let i = 0; i < 9; i++) db.subscribers.push({ id: "SUB-" + i, createdAt: new Date(Date.now() - i * 5 * 86400000).toISOString(), email: "sub" + i + "@gmail.com", lang: ["mr", "en", "hi"][i % 3], source: ["website", "ebook", "booking"][i % 3], consent: true });
  db.contactsMeta[mob(0)] = { tags: ["Knee OA", "Senior"], notes: [{ at: new Date().toISOString(), text: "Prefers morning slots. Daughter brings her." }] };
  db.contactsMeta[mob(2)] = { tags: ["Stroke", "Home visit"], notes: [{ at: new Date().toISOString(), text: "Family trained on transfers. Review in 2 weeks." }] };
  db.coupons = [{ code: "WELCOME10", type: "pct", value: 10, products: "all", maxUses: 0, expires: "", used: 3, active: true, createdAt: new Date().toISOString() }, { code: "YOUTUBE50", type: "flat", value: 50, products: ["stronger-after-40"], maxUses: 100, expires: "", used: 7, active: true, createdAt: new Date().toISOString() }];
  db.ratings = [
    { id: "RT-1", createdAt: new Date(Date.now() - 5 * 86400000).toISOString(), product: "stronger-after-40", orderId: "ORD-5100", name: "Ganesh Lande", stars: 5, text: "Simple exercises, clearly explained. My knees feel more confident on stairs.", hidden: false },
    { id: "RT-2", createdAt: new Date(Date.now() - 12 * 86400000).toISOString(), product: "aap-ab-bhi-anmol", orderId: "ORD-5102", name: "Vikas Sharma", stars: 5, text: "Bought for my father. Hindi is easy to read.", hidden: false },
    { id: "RT-3", createdAt: new Date(Date.now() - 20 * 86400000).toISOString(), product: "stronger-after-40", orderId: "ORD-5104", name: "Asha Jadhav", stars: 4, text: "Useful. Would love a Marathi version.", hidden: false }
  ];
  db.settings = { gstin: "", gstRate: 0, upiId: "", legalName: "VIP MAGICAL PHYSIO", receiptPrefix: "RCPT", razorpayMode: "test", razorpayKeyId: "", fees: { opd: 500, home: 800, online: 400 } };
  db.log.push({ at: new Date().toISOString(), who: "admin", action: "Demo data loaded", ref: "—" });
  S.save(db);
  // Two live website bookings → fires real automations (outbox + tasks)
  const d1 = new Date(); d1.setDate(d1.getDate() + 3); if (d1.getDay() === 0) d1.setDate(d1.getDate() + 1);
  S.add("appointments", { mode: "home", date: ymd(d1), time: "16:00", name: "Lata Kale", mobile: "9890011223", email: "", plang: "mr", service: "geriatric", area: "Sharadwadi", address: "Behind school", consent: true, status: "requested" }, "Appointment requested (home)");
  S.add("enquiries", { name: "Imran Shaikh", mobile: "9860044551", msg: "Back pain since 2 months, can I come today?", lang: "hi", status: "new" }, "New enquiry");
}

Object.assign(window, { S, AU, CMS, MODE, LANGS3, inr, fmtD, fmtDay, dmy, today, svcName, normMobile, waTo, useDB, mutate, Toasts, toast, Badge, KPI, Panel, Drawer, Modal, F, Empty, Seg, Toggle, Tri, buildContacts, STAGES, seedDemo, STATUS_B });
