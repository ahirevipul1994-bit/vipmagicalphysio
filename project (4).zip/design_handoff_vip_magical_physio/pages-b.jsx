/* Booking (3 flows), Store, Product + Razorpay checkout, Reviews, FAQ, Contact, Legal */
const pad2 = (n) => String(n).padStart(2, "0");
const ymd = (d) => d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());
const DAYS = { en: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], mr: ["रवि", "सोम", "मंगळ", "बुध", "गुरु", "शुक्र", "शनि"], hi: ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"] };
const MONTHS = { en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], mr: ["जाने", "फेब्रु", "मार्च", "एप्रि", "मे", "जून", "जुलै", "ऑग", "सप्टें", "ऑक्टो", "नोव्हें", "डिसें"], hi: ["जन", "फ़र", "मार्च", "अप्रै", "मई", "जून", "जुला", "अग", "सित", "अक्टू", "नव", "दिस"] };

function useStoreTick() { const [n, setN] = useState(0); useEffect(() => { const f = () => setN((x) => x + 1); window.addEventListener("vmp-store", f); window.addEventListener("storage", f); return () => { window.removeEventListener("vmp-store", f); window.removeEventListener("storage", f); }; }, []); return n; }

function BookingPage({ mode: initMode, svc: initSvc }) {
  const { t, lang } = useL();
  useSeo(t("nav_book"), t("bk_p"));
  useStoreTick();
  const [mode, setMode] = useState(["opd", "home", "online"].includes(initMode) ? initMode : "opd");
  const days = useMemo(() => Array.from({ length: 14 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() + i); return d; }), []);
  const firstOpen = days.find((d) => window.BUSINESS.open.days.includes(d.getDay()));
  const [date, setDate] = useState(ymd(firstOpen));
  const [time, setTime] = useState("");
  const [f, setF] = useState({ name: "", mobile: "", email: "", plang: lang, service: initSvc || "", address: "", area: "", msg: "", consent: false, marketing: false, hp: "" });
  const [errs, setErrs] = useState({});
  const [done, setDone] = useState(null);
  const slots = window.VMPStore.slots(date, mode);
  useEffect(() => { setTime(""); }, [date, mode]);
  const up = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const submit = (e) => {
    e.preventDefault();
    if (f.hp) return; // spam honeypot
    const er = {};
    if (!f.name.trim()) er.name = t("err_name");
    if (!/^[6-9]\d{9}$/.test(f.mobile.replace(/\D/g, "").slice(-10))) er.mobile = t("err_mobile");
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) er.email = t("err_email");
    if (!time) er.slot = t("err_slot");
    if (mode === "home" && (!f.address.trim() || !f.area)) er.address = t("err_loc");
    if (!f.consent) er.consent = t("err_consent");
    setErrs(er);
    if (Object.keys(er).length) return;
    if (!window.VMPStore.isFree(date, time, mode)) { setErrs({ slot: t("err_taken") }); setTime(""); return; }
    const rec = window.VMPStore.add("appointments", {
      mode, date, time, name: f.name.trim(), mobile: f.mobile.replace(/\D/g, "").slice(-10), email: f.email, plang: f.plang,
      service: f.service, address: f.address, area: f.area, msg: f.msg, consent: true, marketing: f.marketing, status: "requested", siteLang: lang
    }, "Appointment requested (" + mode + ")");
    if (f.marketing && f.email) window.VMPStore.add("subscribers", { email: f.email, lang: f.plang, source: "booking", consent: true }, "Subscriber via booking");
    setDone(rec);
    window.scrollTo(0, 0);
  };

  if (done) {
    const msg = `${t("ref_no")}: ${done.id}\n${t("mode_" + done.mode)} · ${done.date} · ${window.VMPStore.fmtTime(done.time)}\n${done.name}`;
    return (
      <main className="sec"><div className="wrap" style={{ maxWidth: 720 }}>
        <div className="form-card success">
          <div className="tick"></div>
          <h2>{t("ok_h")}</h2>
          <p className="lead" style={{ margin: "0 auto" }}>{t("ok_p", { m: done.mobile })}</p>
          <div className="ref">
            <div><small>{t("ref_no")}</small><b>{done.id}</b></div>
            <div><small>{t("mode_" + done.mode)}</small><b>{done.date.split("-").reverse().join("/")} · {window.VMPStore.fmtTime(done.time)}</b></div>
            <div><small>{t("status")}</small><span className="badge b-req">{t("st_requested")}</span></div>
          </div>
          <p className="muted">{t("ok_change")}</p>
          <div className="btn-row" style={{ justifyContent: "center" }}>
            <a className="btn btn-wa" href={waLink(msg)} target="_blank" rel="noopener">{WA_ICON}{t("ok_reschedule")}</a>
            <button className="btn btn-ghost" onClick={() => { setDone(null); setTime(""); }}>{t("book_another")}</button>
          </div>
        </div>
      </div></main>
    );
  }

  const modeInfo = { opd: [t("mode_opd"), t("fee_opd")], home: [t("mode_home"), t("fee_home")], online: [t("mode_online"), t("fee_online")] };
  return (
    <main className="sec">
      <div className="wrap" style={{ maxWidth: 940 }}>
        <span className="kicker">{t("bk_k")}</span>
        <h1 style={{ fontSize: "clamp(36px,5vw,58px)" }}>{t("bk_h")}</h1>
        <p className="lead">{t("bk_p")}</p>
        <form className="form-card" onSubmit={submit} noValidate style={{ marginTop: 28 }}>
          <div className="step-h"><i>1</i><h3>{t("bk_s1")}</h3></div>
          <div className="mode-pick">
            {["opd", "home", "online"].map((m) => (
              <button type="button" key={m} className={mode === m ? "on" : ""} onClick={() => setMode(m)} aria-pressed={mode === m}>
                <b>{modeInfo[m][0]}</b><span>{modeInfo[m][1]}</span>
              </button>
            ))}
          </div>
          {mode === "home" && <div className="note" style={{ marginTop: 14 }}>{t("home_limit")}</div>}
          {mode === "online" && (
            <div style={{ marginTop: 14 }}>
              <div className="steps" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))", marginBottom: 12 }}>
                {window.UI.online_how[t.i].map((x, i) => <div className="step" key={i} style={{ padding: 14 }}><b style={{ fontSize: 28 }}>{i + 1}</b><p style={{ fontSize: 15, color: "var(--ink)" }}>{x}</p></div>)}
              </div>
              <div className="note warn">{t("online_limit")} {t("emergency").split("—")[0]}— 108.</div>
            </div>
          )}

          <div className="step-h"><i>2</i><h3>{t("bk_s2")}</h3></div>
          <div className="date-row" role="listbox" aria-label="Date">
            {days.map((d) => {
              const k = ymd(d); const closed = !window.BUSINESS.open.days.includes(d.getDay());
              return <button type="button" key={k} className={(date === k ? "on " : "") + (closed ? "closed" : "")} onClick={() => setDate(k)}>
                <small>{DAYS[lang][d.getDay()]}</small><b>{d.getDate()}</b><small>{MONTHS[lang][d.getMonth()]}</small></button>;
            })}
          </div>
          {slots.closed ? <div className="note sun">{t("closed_day")}</div> : (
            <>
              <div style={{ fontWeight: 600, color: "var(--navy)", margin: "6px 0 10px" }}>{t("choose_time")}</div>
              {slots.list.every((s) => !s.free) ? <div className="note sun">{t("no_slots")}</div> : (
                <div className="slots">
                  {slots.list.map((s) => <button type="button" key={s.t} disabled={!s.free} className={time === s.t ? "on" : ""} onClick={() => setTime(s.t)} title={s.free ? "" : t("booked")}>{window.VMPStore.fmtTime(s.t)}</button>)}
                </div>
              )}
            </>
          )}
          {errs.slot && <div className="err" style={{ marginTop: 8 }}>{errs.slot}</div>}

          <div className="step-h"><i>3</i><h3>{t("bk_s3")}</h3></div>
          <div className="grid g2" style={{ gap: "0 18px" }}>
            <div className="field"><label htmlFor="bn">{t("f_name")} *</label><input id="bn" value={f.name} onChange={up("name")} autoComplete="name" />{errs.name && <span className="err">{errs.name}</span>}</div>
            <div className="field"><label htmlFor="bm">{t("f_mobile")} *</label><input id="bm" value={f.mobile} onChange={up("mobile")} inputMode="numeric" autoComplete="tel" placeholder="98XXXXXXXX" />{errs.mobile && <span className="err">{errs.mobile}</span>}</div>
            <div className="field"><label htmlFor="be">{t("f_email")}</label><input id="be" type="email" value={f.email} onChange={up("email")} autoComplete="email" />{errs.email && <span className="err">{errs.email}</span>}</div>
            <div className="field"><label htmlFor="bl">{t("f_lang")}</label>
              <select id="bl" value={f.plang} onChange={up("plang")}>{window.LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}</select></div>
          </div>
          <div className="field"><label htmlFor="bs">{t("f_service")}</label>
            <select id="bs" value={f.service} onChange={up("service")}>
              <option value="">{t("f_service_ph")}</option>
              {SVC_ORDER.map((s) => <option key={s} value={s}>{t.pick(window.SERVICES[s].title)}</option>)}
              <option value="other">{t("f_other")}</option>
            </select></div>
          {mode === "home" && (
            <div className="grid g2" style={{ gap: "0 18px" }}>
              <div className="field"><label htmlFor="ba">{t("f_location")} *</label><input id="ba" value={f.address} onChange={up("address")} /></div>
              <div className="field"><label htmlFor="bar">{t("f_area")} *</label>
                <select id="bar" value={f.area} onChange={up("area")}><option value=""></option>{window.UI.areas[t.i].map((a, i) => <option key={a} value={window.UI.areas[0][i]}>{a}</option>)}<option value="other">{t("f_other")}</option></select></div>
              {errs.address && <span className="err" style={{ gridColumn: "1/-1", marginTop: -8, marginBottom: 12 }}>{errs.address}</span>}
            </div>
          )}
          <div className="field"><label htmlFor="bmsg">{t("f_msg")}</label><textarea id="bmsg" value={f.msg} onChange={up("msg")} maxLength={400} /></div>
          <input className="sr" tabIndex={-1} autoComplete="off" value={f.hp} onChange={up("hp")} aria-hidden="true" />
          <label className="check"><input type="checkbox" checked={f.consent} onChange={up("consent")} />{t("f_consent")}</label>
          {errs.consent && <div className="err" style={{ marginTop: -6, marginBottom: 10 }}>{errs.consent}</div>}
          <label className="check"><input type="checkbox" checked={f.marketing} onChange={up("marketing")} />{t("f_marketing")}</label>
          <div className="btn-row" style={{ marginTop: 18 }}>
            <button className="btn btn-primary" type="submit">{t("bk_submit")}</button>
            <a className="btn btn-wa" href={waLink(t("nav_book") + " — " + modeInfo[mode][0])} target="_blank" rel="noopener">{WA_ICON}{t("bk_wa")}</a>
          </div>
        </form>
      </div>
    </main>
  );
}

function OldStorePage() {
  const { t } = useL();
  useSeo(t("store_h"), t("sec_store_p"));
  return (
    <main className="sec"><div className="wrap">
      <span className="kicker">{t("sec_store_k")}</span>
      <h1 style={{ fontSize: "clamp(36px,5vw,60px)" }}>{t("store_h")}</h1>
      <p className="lead" style={{ marginBottom: 36 }}>{t("sec_store_p")}</p>
      <BookGrid />
      <div className="note" style={{ marginTop: 36 }}>{t("secure_pay")} · {t("instant")}</div>
    </div></main>
  );
}

function OldProductPage({ id }) {
  const { t, lang } = useL();
  const b = window.EBOOKS.find((x) => x.id === id);
  const tx = window.EBOOK_TEXT[id];
  useSeo((b.titleLatin || b.title) + " — Ebook", t.pick(tx.blurb));
  useEffect(() => {
    const ld = { "@context": "https://schema.org", "@type": "Book", name: b.title, author: { "@type": "Person", name: "Dr. Vipul Ahire" }, inLanguage: b.lang, bookFormat: "EBook", offers: { "@type": "Offer", price: b.price, priceCurrency: "INR", availability: "https://schema.org/InStock" } };
    let el = document.getElementById("ld-book"); if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = "ld-book"; document.head.appendChild(el); }
    el.textContent = JSON.stringify(ld); return () => el.remove();
  }, [id]);
  const [stage, setStage] = useState("view"); // view | form | rz | verifying | paid | failed
  const [f, setF] = useState({ name: "", email: "", mobile: "", consent: false, marketing: false });
  const [errs, setErrs] = useState({});
  const [order, setOrder] = useState(null);

  const start = (e) => {
    e.preventDefault();
    const er = {};
    if (!f.name.trim()) er.name = t("err_name");
    if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = t("err_email");
    if (!/^[6-9]\d{9}$/.test(f.mobile.replace(/\D/g, "").slice(-10))) er.mobile = t("err_mobile");
    if (!f.consent) er.consent = t("err_consent");
    setErrs(er); if (Object.keys(er).length) return;
    // 1. backend creates Razorpay order (status: created)
    const o = window.VMPStore.add("orders", { product: b.id, title: b.titleLatin || b.title, amount: b.price, name: f.name, email: f.email, mobile: f.mobile, status: "created", lang, marketing: f.marketing }, "Order created");
    setOrder(o); setStage("rz");
  };
  const pay = (ok) => {
    setStage("verifying");
    setTimeout(() => {
      // 2. server verifies signature + webhook before marking paid
      if (ok) {
        const pid = "pay_" + Math.random().toString(36).slice(2, 12);
        const o = window.VMPStore.update("orders", order.id, { status: "paid", paymentId: pid, downloads: 0 }, "Payment verified (webhook)", "razorpay");
        window.VMPStore.add("payments", { kind: "ebook", ref: o.id, name: o.name, mobile: o.mobile, email: o.email, purpose: "Ebook: " + o.title, amount: o.amount, method: "Razorpay", gatewayId: pid, status: "paid", receipt: "RCPT-" + Date.now().toString().slice(-6), lang, silent: true }, "Payment recorded (ebook)");
        if (f.marketing) window.VMPStore.add("subscribers", { email: f.email, lang, source: "ebook", consent: true }, "Subscriber via ebook");
        setOrder(o); setStage("paid");
      } else {
        window.VMPStore.update("orders", order.id, { status: "failed" }, "Payment failed", "razorpay");
        setStage("failed");
      }
    }, 1600);
  };

  return (
    <main className="sec"><div className="wrap">
      <div className="crumbs"><A>{t("nav_home")}</A> / <A to="store">{t("nav_store")}</A> / {b.titleLatin || b.title}</div>
      <div className="grid" style={{ gridTemplateColumns: "minmax(0,.8fr) minmax(0,1.2fr)", gap: 48, alignItems: "start" }} id="prod-grid">
        <div style={{ maxWidth: 380, width: "100%" }}><BookCover b={b} /></div>
        <div>
          <span className="lang-pill">{t("lang_" + b.lang)}</span>
          <h1 lang={b.lang} style={{ fontSize: "clamp(34px,4.4vw,54px)", marginTop: 10 }}>{b.title}</h1>
          <p className="muted" style={{ marginTop: -6 }}>{t("by_author")}</p>
          <p className="lead">{t.pick(tx.blurb)}</p>
          <div className="facts" style={{ gridTemplateColumns: "repeat(2,1fr)" }}>
            <div className="fact"><small>{t("bk_language")}</small><b>{t("lang_" + b.lang)}</b></div>
            <div className="fact"><small>{t("bk_format")}</small><b style={{ fontSize: 16 }}>{t("bk_pdf")}</b></div>
          </div>
          <h3>{t("bk_for")}</h3><p>{t.pick(tx.for)}</p>
          <h3>{t("bk_inside")}</h3><p className="muted">{t("bk_inside_note")}</p>

          {stage === "view" && (
            <div className="card" style={{ marginTop: 20, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 18, flexWrap: "wrap" }}>
              <div><div className="price" style={{ fontSize: 40 }}>₹{b.price}</div><small className="muted">{t("incl_tax")} · {t("instant")}</small></div>
              <button className="btn btn-primary" onClick={() => setStage("form")}>{t("buy_now")}</button>
            </div>
          )}
          {stage === "form" && (
            <form className="form-card" onSubmit={start} noValidate style={{ marginTop: 20 }}>
              <h3>{t("ck_h")}</h3>
              <div className="field"><label htmlFor="cn">{t("f_name")} *</label><input id="cn" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />{errs.name && <span className="err">{errs.name}</span>}</div>
              <div className="field"><label htmlFor="ce">{t("f_email_req")} *</label><input id="ce" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />{errs.email && <span className="err">{errs.email}</span>}</div>
              <div className="field"><label htmlFor="cm">{t("f_mobile")} *</label><input id="cm" inputMode="numeric" value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} />{errs.mobile && <span className="err">{errs.mobile}</span>}</div>
              <label className="check"><input type="checkbox" checked={f.consent} onChange={(e) => setF({ ...f, consent: e.target.checked })} />{t("f_consent").replace(/appointment|अपॉइंटमेंट/g, (m) => m)}</label>
              {errs.consent && <div className="err">{errs.consent}</div>}
              <label className="check"><input type="checkbox" checked={f.marketing} onChange={(e) => setF({ ...f, marketing: e.target.checked })} />{t("f_marketing")}</label>
              <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid var(--line)", paddingTop: 14, margin: "8px 0 16px" }}><b>{t("ck_total")}</b><b className="price" style={{ fontSize: 24 }}>₹{b.price}</b></div>
              <button className="btn btn-primary" style={{ width: "100%" }}>{t("ck_pay", { p: b.price })}</button>
              <p className="muted" style={{ fontSize: 14, marginTop: 12 }}>{t("ck_note")}</p>
            </form>
          )}
          {stage === "paid" && (
            <div className="form-card success" style={{ marginTop: 20 }}>
              <div className="tick"></div><h3>{t("ck_success")}</h3>
              <p>{t("ck_success_p", { e: f.email })}</p>
              <div className="ref"><div><small>{t("order_no")}</small><b>{order.id}</b></div><div><small>{t("status")}</small><span className="badge b-paid">Paid · ₹{b.price}</span></div></div>
              <div><button className="btn btn-primary" onClick={() => window.VMPStore.update("orders", order.id, { downloads: (order.downloads || 0) + 1 }, "Download link used", "customer")}>↓ {t("ck_download")}</button></div>
              <p className="muted" style={{ fontSize: 15, marginTop: 14 }}>{t("support")}</p>
            </div>
          )}
          {stage === "failed" && (
            <div className="form-card" style={{ marginTop: 20 }}>
              <h3 style={{ color: "var(--red)" }}>{t("ck_failed")}</h3><p>{t("ck_failed_p")}</p>
              <button className="btn btn-primary" onClick={() => setStage("form")}>{t("try_again")}</button>
            </div>
          )}
          <p className="muted" style={{ fontSize: 15, marginTop: 16 }}>{t("secure_pay")}</p>
        </div>
      </div>
      <style>{`@media (max-width:820px){#prod-grid{grid-template-columns:1fr!important}}`}</style>

      {(stage === "rz" || stage === "verifying") && (
        <div className="modal-bg">
          <div className="modal">
            <div className="rz-head"><b>{t("rz_title")}</b><span>₹{b.price}</span></div>
            <div className="rz-body">
              {stage === "rz" ? (<>
                <div style={{ fontSize: 15 }}><b>VIP MAGICAL PHYSIO</b><br /><span className="muted">{b.titleLatin || b.title} · {order.id}</span></div>
                <div className="chips"><span className="chip">UPI</span><span className="chip">Cards</span><span className="chip">Net-banking</span><span className="chip">Wallets</span></div>
                <button className="btn btn-primary" onClick={() => pay(true)}>{t("rz_pay_ok")}</button>
                <button className="btn btn-ghost" onClick={() => pay(false)}>{t("rz_pay_fail")}</button>
                <small className="muted">{t("rz_demo")}</small>
              </>) : (<><div className="spinner"></div><p className="center" style={{ margin: 0 }}>{t("ck_verifying")}</p></>)}
            </div>
          </div>
        </div>
      )}
    </div></main>
  );
}

function QR({ text, size = 220 }) {
  const src = useMemo(() => {
    if (!window.qrcode) return null;
    const q = window.qrcode(0, "M"); q.addData(text); q.make();
    return q.createDataURL(8, 2);
  }, [text]);
  return src ? <img src={src} alt="QR code" width={size} height={size} /> : null;
}

function ReviewsPage() {
  const { t } = useL();
  useSeo(t("rvp_k") + " — VIP MAGICAL PHYSIO", t("rvp_p"));
  const [copied, setCopied] = useState(false);
  const url = window.BUSINESS.reviewUrl;
  const share = async () => {
    const text = t("rv_strip_body") + " " + url;
    if (navigator.share) { try { await navigator.share({ text, url }); } catch (e) {} }
    else { navigator.clipboard && navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 2000); }
  };
  return (
    <main className="sec"><div className="wrap">
      <div className="grid" style={{ gridTemplateColumns: "minmax(0,1.3fr) minmax(0,.7fr)", gap: 48, alignItems: "center" }} id="rv-grid">
        <div className="big-review">
          <span className="kicker">{t("rvp_k")}</span>
          <h1 style={{ fontSize: "clamp(36px,5vw,60px)" }}>{t("rvp_h")}</h1>
          <p className="lead">{t("rvp_p")}</p>
          <div className="stars" style={{ fontSize: 40 }}>★★★★★</div>
          <a className="btn btn-sun" href={url} target="_blank" rel="noopener">{t("rv_button")}</a>
          <div className="btn-row">
            <button className="btn btn-ghost btn-sm" onClick={share}>{copied ? t("copied") : t("rvp_share")}</button>
            <a className="btn btn-ghost btn-sm" href={window.BUSINESS.mapsUrl} target="_blank" rel="noopener">{t("rv_read")}</a>
          </div>
        </div>
        <div className="qr-card">
          <QR text={url} />
          <b style={{ fontFamily: "var(--f-head)", fontSize: 22, color: "var(--navy)" }}>{t("rvp_qr")}</b>
          <p className="muted" style={{ fontSize: 15, margin: "4px 0 14px" }}>VIP MAGICAL PHYSIO · Shirur</p>
          <a className="btn btn-navy btn-sm" href="Review QR Poster.html" target="_blank">{t("rvp_print")}</a>
        </div>
      </div>
      <style>{`@media (max-width:820px){#rv-grid{grid-template-columns:1fr!important}}`}</style>

      <div className="grid g2" style={{ marginTop: 64, gap: 24 }}>
        <div className="card">
          <h3>{t("rvp_steps_h")}</h3>
          <div style={{ display: "grid", gap: 14 }}>
            {window.UI.rvp_steps[t.i].map((s, i) => <div className="why-item" key={i}><span className="why-ico">{i + 1}</span><p style={{ margin: "10px 0 0" }}>{s}</p></div>)}
          </div>
        </div>
        <div className="card">
          <h3>{t("rvp_ideas_h")}</h3>
          <ul className="ticks">{window.UI.rvp_ideas[t.i].map((s) => <li key={s}>{s}</li>)}</ul>
          <div className="note sun" style={{ marginTop: 16 }}>{t("rvp_privacy")}</div>
        </div>
      </div>
      <div className="card" style={{ marginTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 18, flexWrap: "wrap", background: "var(--sand)" }}>
        <div><h3 style={{ marginBottom: 4 }}>{t("rvp_feedback_h")}</h3><p className="muted mb0">{t("rvp_feedback_p")}</p></div>
        <a className="btn btn-wa" href={waLink()} target="_blank" rel="noopener">{WA_ICON}{t("whatsapp")}</a>
      </div>
    </div></main>
  );
}

function FaqPage() {
  const { t } = useL();
  useSeo(t("faq_h"), t("faq_h"));
  useEffect(() => {
    const ld = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: t.row("faq").map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) };
    const el = document.createElement("script"); el.type = "application/ld+json"; el.textContent = JSON.stringify(ld); document.head.appendChild(el);
    return () => el.remove();
  }, [t.lang]);
  return (
    <main className="sec"><div className="wrap" style={{ maxWidth: 880 }}>
      <span className="kicker">{t("nav_faq")}</span>
      <h1 style={{ fontSize: "clamp(36px,5vw,58px)" }}>{t("faq_h")}</h1>
      <div style={{ marginTop: 28 }}>{t.row("faq").map(([q, a], i) => <details className="faq" key={i} open={i === 0}><summary>{q}</summary><p>{a}</p></details>)}</div>
      <div className="note warn" style={{ marginTop: 28 }}>{t("emergency")}</div>
    </div></main>
  );
}

function ContactPage() {
  const { t, lang } = useL();
  useSeo(t("nav_contact"), t("ct_p"));
  const [f, setF] = useState({ name: "", mobile: "", msg: "", consent: false }); const [err, setErr] = useState(""); const [ok, setOk] = useState(false);
  const submit = (e) => {
    e.preventDefault();
    if (!f.name.trim()) return setErr(t("err_name"));
    if (!/^[6-9]\d{9}$/.test(f.mobile.replace(/\D/g, "").slice(-10))) return setErr(t("err_mobile"));
    if (!f.consent) return setErr(t("err_consent"));
    window.VMPStore.add("enquiries", { name: f.name, mobile: f.mobile, msg: f.msg, lang, status: "new" }, "New enquiry");
    setOk(true); setErr("");
  };
  return (
    <main>
      <section className="sec"><div className="wrap">
        <span className="kicker">{t("nav_contact")}</span>
        <h1 style={{ fontSize: "clamp(36px,5vw,60px)" }}>{t("ct_h")}</h1>
        <p className="lead" style={{ marginBottom: 32 }}>{t("ct_p")}</p>
        <MapBlock />
      </div></section>
      <section className="sec alt"><div className="wrap" style={{ maxWidth: 760 }}>
        <h2>{t("enq_h")}</h2>
        {ok ? <div className="note" style={{ fontWeight: 600, fontSize: "1.05em" }}>{t("enq_ok")}</div> : (
          <form className="form-card" onSubmit={submit} noValidate>
            <div className="grid g2" style={{ gap: "0 18px" }}>
              <div className="field"><label htmlFor="en">{t("f_name")} *</label><input id="en" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
              <div className="field"><label htmlFor="em">{t("f_mobile")} *</label><input id="em" inputMode="numeric" value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} /></div>
            </div>
            <div className="field"><label htmlFor="emsg">{t("f_msg")}</label><textarea id="emsg" value={f.msg} onChange={(e) => setF({ ...f, msg: e.target.value })} maxLength={400} /></div>
            <label className="check"><input type="checkbox" checked={f.consent} onChange={(e) => setF({ ...f, consent: e.target.checked })} />{t("f_consent")}</label>
            {err && <div className="err">{err}</div>}
            <div className="btn-row" style={{ marginTop: 14 }}><button className="btn btn-primary">{t("enq_btn")}</button><a className="btn btn-wa" href={waLink()} target="_blank" rel="noopener">{WA_ICON}{t("whatsapp")}</a></div>
          </form>
        )}
      </div></section>
    </main>
  );
}

function LegalPage({ which }) {
  const { t } = useL();
  const key = ["privacy", "terms", "refund", "disclaimer"].includes(which) ? which : "privacy";
  useSeo(t(key), t(key));
  return (
    <main className="sec"><div className="wrap legal" style={{ maxWidth: 820 }}>
      <span className="kicker">{t("ft_legal")}</span>
      <h1 style={{ fontSize: "clamp(34px,4.6vw,54px)" }}>{t(key)}</h1>
      <p className="muted">{t("updated")}</p>
      {window.LEGAL[key].map((row, i) => <div key={i}><h3>{row[t.i][0]}</h3><p>{row[t.i][1]}</p></div>)}
      <div className="note" style={{ marginTop: 28 }}>VIP MAGICAL PHYSIO · Dr. Vipul Ahire (BPTh) · {t("address")} · {window.BUSINESS.phone}</div>
    </div></main>
  );
}

/* Patient payment-link page: #/<lang>/pay/<PL-id>. Production: Razorpay Payment Links / Orders + webhook. */
function PayPage({ id }) {
  const { t, lang } = useL();
  useStoreTick();
  useSeo(t("pay_k"), t("pay_h"));
  const db = window.VMPStore.load();
  const pl = (db.paylinks || []).find((p) => p.id === id);
  const [stage, setStage] = useState("view");
  const [rcpt, setRcpt] = useState(null);
  const pay = (ok) => {
    setStage("verifying");
    setTimeout(() => {
      if (!ok) { setStage("failed"); return; }
      const receipt = "RCPT-" + Date.now().toString().slice(-6);
      const p = window.VMPStore.add("payments", { kind: pl.kind || "service", ref: pl.id, name: pl.name, mobile: pl.mobile, email: pl.email, purpose: pl.purpose, amount: pl.amount, method: "Razorpay", gatewayId: "pay_" + Math.random().toString(36).slice(2, 12), status: "paid", receipt, lang: pl.lang || lang }, "Payment received via link");
      window.VMPStore.update("paylinks", pl.id, { status: "paid", paidAt: new Date().toISOString(), paymentId: p.id }, "Payment link paid", "razorpay");
      setRcpt(p); setStage("paid");
    }, 1500);
  };
  const Shell = ({ children }) => <main className="sec"><div className="wrap" style={{ maxWidth: 620 }}>{children}</div></main>;
  if (!pl) return <Shell><div className="form-card center"><h2>{t("pay_k")}</h2><p className="lead" style={{ margin: "0 auto" }}>{t("pay_missing")}</p><a className="btn btn-wa" href={waLink()} target="_blank" rel="noopener" style={{ marginTop: 18 }}>{WA_ICON}{t("whatsapp")}</a></div></Shell>;
  if (pl.status === "cancelled") return <Shell><div className="form-card center"><h2>{t("pay_k")}</h2><p className="lead" style={{ margin: "0 auto" }}>{t("pay_cancelled")}</p></div></Shell>;
  if (stage === "paid" || (pl.status === "paid" && stage === "view")) {
    const r = rcpt || db.payments.find((p) => p.id === pl.paymentId) || {};
    return <Shell><div className="form-card success">
      <div className="tick"></div>
      <h2>{stage === "paid" ? t("pay_done_h") : t("pay_already")}</h2>
      {r.receipt && <p>{t("pay_done_p", { r: r.receipt })}</p>}
      <div className="ref"><div><small>{t("pay_for")}</small><b>{pl.purpose}</b></div><div><small>{t("pay_amount")}</small><b>₹{pl.amount}</b></div>{r.receipt && <div><small>{t("receipt")}</small><b>{r.receipt}</b></div>}</div>
      <div><button className="btn btn-ghost" onClick={() => print()}>{t("print_receipt")}</button></div>
    </div></Shell>;
  }
  return (
    <Shell>
      <span className="kicker">{t("pay_k")}</span>
      <h1 style={{ fontSize: "clamp(30px,4.4vw,46px)" }}>{t("pay_h")}</h1>
      <div className="form-card" style={{ marginTop: 22 }}>
        <div className="info-row"><div><small>{t("pay_to")}</small><b>{pl.name}</b></div></div>
        <div className="info-row"><div><small>{t("pay_for")}</small><b>{pl.purpose}</b></div></div>
        {pl.due && <div className="info-row"><div><small>{t("pay_due")}</small><b>{pl.due.split("-").reverse().join("/")}</b></div></div>}
        <div className="info-row"><div><small>{t("pay_amount")}</small><b className="price" style={{ fontSize: 40 }}>₹{pl.amount}</b><div className="muted" style={{ fontSize: 15 }}>{t("incl_tax")}</div></div></div>
        {stage === "failed" && <div className="note warn" style={{ margin: "10px 0" }}><b>{t("ck_failed")}.</b> {t("ck_failed_p")}</div>}
        <button className="btn btn-primary" style={{ width: "100%", marginTop: 14 }} onClick={() => setStage("rz")}>{t("pay_btn", { p: pl.amount })}</button>
        <p className="muted" style={{ fontSize: 14, marginTop: 12 }}>{t("secure_pay")}</p>
      </div>
      {(stage === "rz" || stage === "verifying") && (
        <div className="modal-bg"><div className="modal">
          <div className="rz-head"><b>{t("rz_title")}</b><span>₹{pl.amount}</span></div>
          <div className="rz-body">
            {stage === "rz" ? (<>
              <div style={{ fontSize: 15 }}><b>VIP MAGICAL PHYSIO</b><br /><span className="muted">{pl.purpose} · {pl.id}</span></div>
              <div className="chips"><span className="chip">UPI</span><span className="chip">Cards</span><span className="chip">Net-banking</span></div>
              <button className="btn btn-primary" onClick={() => pay(true)}>{t("rz_pay_ok")}</button>
              <button className="btn btn-ghost" onClick={() => pay(false)}>{t("rz_pay_fail")}</button>
              <small className="muted">{t("rz_demo")}</small>
            </>) : (<><div className="spinner"></div><p className="center" style={{ margin: 0 }}>{t("ck_verifying")}</p></>)}
          </div>
        </div></div>
      )}
    </Shell>
  );
}

function AnnouncementBar() {
  const { t } = useL();
  const a = window.ANNOUNCEMENT;
  if (!a || !a.active) return null;
  const txt = a.text[t.lang] || a.text.en; if (!txt) return null;
  const tones = { sun: ["var(--sun)", "var(--navy-2)"], teal: ["var(--teal)", "#fff"], red: ["var(--red)", "#fff"] };
  const [bg, fg] = tones[a.tone] || tones.sun;
  return <div style={{ background: bg, color: fg, textAlign: "center", padding: "10px 18px", fontWeight: 600, fontSize: 16 }}>{txt}</div>;
}

Object.assign(window, { PayPage, AnnouncementBar, BookingPage, OldStorePage, OldProductPage, ReviewsPage, FaqPage, ContactPage, LegalPage, QR, useStoreTick });
