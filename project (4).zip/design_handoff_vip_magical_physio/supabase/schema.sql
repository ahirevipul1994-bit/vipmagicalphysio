-- VIP MAGICAL PHYSIO — Supabase schema for the ebook store + payments (run in Supabase → SQL editor)
create extension if not exists pgcrypto;

create table if not exists profiles (user_id uuid primary key references auth.users on delete cascade, role text not null check (role in ('admin','clinician','staff')), created_at timestamptz default now());

create table if not exists products (
  id text primary key, type text not null default 'ebook' check (type in ('ebook','bundle')),
  title text not null, title_latin text, lang text not null check (lang in ('en','mr','hi')),
  price_paise int not null check (price_paise >= 0), compare_at_paise int, pwyw boolean default false, min_price_paise int default 0,
  bundle_items text[], file_path text, pages int, size_label text, active boolean default true,
  description jsonb, audience jsonb, features jsonb, cover jsonb, sort int default 0, created_at timestamptz default now()
);

create table if not exists coupons (
  code text primary key, kind text not null check (kind in ('pct','flat')), value int not null check (value > 0),
  product_ids text[], max_uses int, used int default 0, expires_on date, active boolean default true, created_at timestamptz default now()
);
create or replace function increment_coupon(p_code text) returns void language sql security definer as $$ update coupons set used = used + 1 where code = p_code $$;

create sequence if not exists order_seq start 5001;
create table if not exists orders (
  id text primary key default ('ORD-' || nextval('order_seq')),
  product_id text references products(id), items text[],
  base_paise int not null, discount_paise int default 0, amount_paise int not null, coupon_code text,
  customer_name text, customer_email text not null, customer_mobile text, lang text default 'en',
  status text not null default 'created' check (status in ('created','paid','failed','abandoned','refunded')),
  razorpay_order_id text unique, razorpay_payment_id text unique,
  download_counts jsonb default '{}'::jsonb, max_downloads int default 5, download_expires_at timestamptz,
  paid_at timestamptz, refunded_at timestamptz, created_at timestamptz default now()
);
create index if not exists orders_email on orders (customer_email);

create table if not exists payments (
  id uuid primary key default gen_random_uuid(), order_id text references orders(id), kind text, amount_paise int not null,
  method text, gateway_id text, status text check (status in ('paid','refunded','failed')), customer_email text, customer_name text,
  receipt_no text default ('RCPT-' || to_char(now(),'YYMMDDHH24MISS')), created_at timestamptz default now()
);

create table if not exists payment_events (id text primary key, type text, payload jsonb, received_at timestamptz default now());

create table if not exists ratings (
  id uuid primary key default gen_random_uuid(), product_id text references products(id), order_id text references orders(id),
  stars int check (stars between 1 and 5), body text, hidden boolean default false, created_at timestamptz default now(),
  unique (order_id, product_id)
);

create table if not exists subscribers (email text primary key, lang text, source text, consent_at timestamptz default now(), unsubscribed_at timestamptz);
create table if not exists admin_logs (id bigserial primary key, at timestamptz default now(), actor text, action text, ref text);

-- Row Level Security
alter table products enable row level security;
alter table coupons enable row level security;
alter table orders enable row level security;
alter table payments enable row level security;
alter table payment_events enable row level security;
alter table ratings enable row level security;
alter table subscribers enable row level security;
alter table admin_logs enable row level security;
alter table profiles enable row level security;

create or replace function is_admin() returns boolean language sql stable security definer as $$ select exists (select 1 from profiles where user_id = auth.uid() and role in ('admin','staff')) $$;

-- Public can read the active catalogue and visible ratings. Everything else: admin only.
-- Orders/payments are written ONLY by Netlify Functions using the service-role key (bypasses RLS).
create policy "catalogue public" on products for select using (active);
create policy "ratings public" on ratings for select using (not hidden);
create policy "admin products" on products for all using (is_admin()) with check (is_admin());
create policy "admin coupons" on coupons for all using (is_admin()) with check (is_admin());
create policy "admin orders" on orders for select using (is_admin());
create policy "admin payments" on payments for select using (is_admin());
create policy "admin ratings" on ratings for update using (is_admin());
create policy "admin subscribers" on subscribers for all using (is_admin());
create policy "admin logs" on admin_logs for select using (is_admin());
create policy "own profile" on profiles for select using (user_id = auth.uid());

-- Private bucket for PDFs (no public access; downloads go through the signed-URL function)
insert into storage.buckets (id, name, public) values ('ebooks', 'ebooks', false) on conflict do nothing;

-- Seed catalogue
insert into products (id, type, title, title_latin, lang, price_paise, compare_at_paise, bundle_items, sort) values
 ('stronger-after-40','ebook','Stronger After 40',null,'en',39900,null,null,1),
 ('new-beginning-35','ebook','A New Beginning for Health After 35',null,'en',29900,null,null,2),
 ('aap-ab-bhi-anmol','ebook','आप अब भी अनमोल हैं','Aap Ab Bhi Anmol Hain','hi',49900,null,null,3),
 ('chhoti-aadatein','ebook','छोटी आदतें, लंबा उजाला','Chhoti Aadatein, Lamba Ujala','hi',49900,null,null,4),
 ('complete-health-bundle','bundle','Complete Health Bundle — all 4 ebooks','Complete Health Bundle','en',129900,169600,
   array['stronger-after-40','new-beginning-35','aap-ab-bhi-anmol','chhoti-aadatein'],5)
on conflict (id) do nothing;
