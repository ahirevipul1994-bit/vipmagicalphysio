/* Dard E Body Care — creator ebook store (storefront, product, checkout sheet, library).
   Live mode: Razorpay Checkout + Netlify Functions (/netlify/functions). Prototype mode: simulated gateway. */
const ST = {
  creator: ["Dard E Body Care", "दर्द ए बॉडी केअर", "दर्द ए बॉडी केयर"],
  by: ["by Dr. Vipul Ahire (BPTh)", "डॉ. विपुल अहिरे (BPTh) यांचे", "डॉ. विपुल अहिरे (BPTh) द्वारा"],
  bio: ["Plain-language health guides from a practising physiotherapist in Shirur. Instant download, read on any phone.", "शिरूरमधील प्रॅक्टिस करणाऱ्या फिजिओथेरपिस्टचे सोप्या भाषेतील आरोग्य मार्गदर्शक. लगेच डाउनलोड, कोणत्याही फोनवर वाचा.", "शिरूर के प्रैक्टिसिंग फिजियोथेरेपिस्ट की आसान भाषा में स्वास्थ्य गाइड। तुरंत डाउनलोड, किसी भी फ़ोन पर पढ़ें।"],
  library: ["My library", "माझी लायब्ररी", "मेरी लाइब्रेरी"],
  all: ["All", "सर्व", "सभी"],
  sort_feat: ["Featured", "निवडक", "चुनिंदा"],
  sort_low: ["Price: low to high", "किंमत: कमी ते जास्त", "कीमत: कम से ज़्यादा"],
  sort_high: ["Price: high to low", "किंमत: जास्त ते कमी", "कीमत: ज़्यादा से कम"],
  products: ["products", "उत्पादने", "उत्पाद"],
  bundle: ["Bundle", "संच", "बंडल"],
  save: ["Save ₹{n}", "₹{n} वाचवा", "₹{n} बचाएँ"],
  includes: ["Includes", "समाविष्ट", "शामिल"],
  get: ["Buy now", "आत्ता खरेदी करा", "अभी खरीदें"],
  get_free: ["Get it free", "मोफत मिळवा", "मुफ़्त पाएँ"],
  pwyw: ["Name a fair price", "योग्य किंमत ठरवा", "उचित कीमत तय करें"],
  pwyw_min: ["₹{n} or more", "₹{n} किंवा अधिक", "₹{n} या अधिक"],
  coupon: ["Have a coupon code?", "कूपन कोड आहे?", "कूपन कोड है?"],
  apply: ["Apply", "लागू करा", "लागू करें"],
  coupon_ok: ["Coupon {c} applied", "कूपन {c} लागू झाले", "कूपन {c} लागू हुआ"],
  coupon_bad: ["This code is not valid for this book.", "हा कोड या पुस्तकासाठी वैध नाही.", "यह कोड इस किताब के लिए मान्य नहीं है।"],
  feats: [["Instant PDF download after payment", "Read on phone, tablet or computer", "Written in plain language by a practising physiotherapist", "Kept safe in your library — re-download anytime"], ["पेमेंटनंतर लगेच PDF डाउनलोड", "फोन, टॅबलेट किंवा संगणकावर वाचा", "प्रॅक्टिस करणाऱ्या फिजिओथेरपिस्टने सोप्या भाषेत लिहिलेले", "तुमच्या लायब्ररीत सुरक्षित — कधीही पुन्हा डाउनलोड करा"], ["भुगतान के बाद तुरंत PDF डाउनलोड", "फ़ोन, टैबलेट या कंप्यूटर पर पढ़ें", "प्रैक्टिसिंग फिजियोथेरेपिस्ट द्वारा आसान भाषा में लिखी गई", "आपकी लाइब्रेरी में सुरक्षित — कभी भी दोबारा डाउनलोड करें"]],
  youget: ["What you get", "तुम्हाला काय मिळेल", "आपको क्या मिलेगा"],
  details: ["Details", "तपशील", "विवरण"],
  pages: ["Pages", "पाने", "पेज"],
  size: ["File size", "फाइल आकार", "फ़ाइल आकार"],
  secure: ["Secure checkout · UPI · Cards · Net-banking", "सुरक्षित चेकआउट · UPI · कार्ड · नेट-बँकिंग", "सुरक्षित चेकआउट · UPI · कार्ड · नेट-बैंकिंग"],
  powered: ["Payments processed by Razorpay", "पेमेंट Razorpay द्वारे", "भुगतान Razorpay द्वारा"],
  share: ["Share", "शेअर करा", "शेयर करें"],
  copied: ["Link copied", "लिंक कॉपी झाली", "लिंक कॉपी हुआ"],
  bought: ["Already bought? Open your library", "आधीच खरेदी केले? लायब्ररी उघडा", "पहले खरीदा है? लाइब्रेरी खोलें"],
  more: ["More from Dr. Vipul", "डॉ. विपुल यांची आणखी पुस्तके", "डॉ. विपुल की और किताबें"],
  ratings: ["Ratings from verified buyers", "खऱ्या खरेदीदारांचे रेटिंग", "असली खरीदारों की रेटिंग"],
  no_ratings: ["No ratings yet. Only people who bought this book can rate it.", "अजून रेटिंग नाही. फक्त हे पुस्तक खरेदी केलेलेच रेटिंग देऊ शकतात.", "अभी कोई रेटिंग नहीं। सिर्फ़ इस किताब के खरीदार ही रेटिंग दे सकते हैं।"],
  verified: ["Verified buyer", "खरा खरेदीदार", "असली खरीदार"],
  ck_title: ["Checkout", "चेकआउट", "चेकआउट"],
  email: ["Email — your download link is sent here", "ईमेल — डाउनलोड लिंक येथे पाठवली जाईल", "ईमेल — डाउनलोड लिंक यहाँ भेजा जाएगा"],
  name: ["Your name", "तुमचे नाव", "आपका नाम"],
  mobile: ["Mobile (optional, for WhatsApp receipt)", "मोबाइल (ऐच्छिक, व्हॉट्सॲप पावतीसाठी)", "मोबाइल (वैकल्पिक, व्हाट्सऐप रसीद के लिए)"],
  subtotal: ["Subtotal", "उप-एकूण", "उप-योग"],
  discount: ["Discount", "सवलत", "छूट"],
  total: ["Total", "एकूण", "कुल"],
  pay: ["Pay ₹{n}", "₹{n} भरा", "₹{n} भरें"],
  agree: ["I agree to the Terms and Refund policy. Send me my receipt and download link.", "मी नियम व परतावा धोरण मान्य करतो/करते. मला पावती व डाउनलोड लिंक पाठवा.", "मैं नियम और रिफ़ंड नीति से सहमत हूँ। मुझे रसीद और डाउनलोड लिंक भेजें।"],
  optin: ["Send me occasional free health tips (optional)", "मला अधूनमधून मोफत आरोग्य टिप्स पाठवा (ऐच्छिक)", "मुझे कभी-कभी मुफ़्त स्वास्थ्य टिप्स भेजें (वैकल्पिक)"],
  processing: ["Confirming your payment with Razorpay…", "Razorpay कडून पेमेंटची खात्री करत आहोत…", "Razorpay से भुगतान की पुष्टि हो रही है…"],
  ready: ["Your ebook is ready!", "तुमचे ई-पुस्तक तयार आहे!", "आपकी ई-बुक तैयार है!"],
  ready_p: ["Receipt and download link sent to {e}. It's also saved in your library.", "पावती व डाउनलोड लिंक {e} वर पाठवली. ती तुमच्या लायब्ररीतही जतन आहे.", "रसीद और डाउनलोड लिंक {e} पर भेजा गया। यह आपकी लाइब्रेरी में भी सुरक्षित है।"],
  download: ["Download PDF", "PDF डाउनलोड करा", "PDF डाउनलोड करें"],
  open_lib: ["Open my library", "माझी लायब्ररी उघडा", "मेरी लाइब्रेरी खोलें"],
  failed: ["Payment didn't go through. No money was taken — please try again.", "पेमेंट झाले नाही. पैसे घेतले नाहीत — कृपया पुन्हा प्रयत्न करा.", "भुगतान नहीं हुआ। पैसा नहीं लिया गया — कृपया फिर से कोशिश करें।"],
  dismissed: ["Payment window closed. You can try again.", "पेमेंट विंडो बंद झाली. पुन्हा प्रयत्न करू शकता.", "भुगतान विंडो बंद हुई। आप फिर से कोशिश कर सकते हैं।"],
  lib_h: ["Your library", "तुमची लायब्ररी", "आपकी लाइब्रेरी"],
  lib_p: ["Enter the email you used at checkout. We'll send a 6-digit code to open your purchases.", "चेकआउटला वापरलेला ईमेल लिहा. खरेदी उघडण्यासाठी आम्ही ६ अंकी कोड पाठवू.", "चेकआउट में इस्तेमाल किया ईमेल लिखें। खरीदारी खोलने के लिए हम 6 अंकों का कोड भेजेंगे।"],
  send_code: ["Send code", "कोड पाठवा", "कोड भेजें"],
  code: ["6-digit code", "६ अंकी कोड", "6 अंकों का कोड"],
  verify: ["Open library", "लायब्ररी उघडा", "लाइब्रेरी खोलें"],
  code_demo: ["Prototype: your code is {c} (in the live site it is emailed).", "प्रोटोटाइप: तुमचा कोड {c} आहे (लाइव्ह साइटवर ईमेलने येतो).", "प्रोटोटाइप: आपका कोड {c} है (लाइव साइट पर ईमेल से आता है)।"],
  code_bad: ["That code is not correct.", "कोड चुकीचा आहे.", "कोड सही नहीं है।"],
  none: ["No purchases found for this email yet.", "या ईमेलवर अजून कोणतीही खरेदी नाही.", "इस ईमेल पर अभी कोई खरीदारी नहीं मिली।"],
  bought_on: ["Bought", "खरेदी", "खरीदा"],
  left: ["{n} downloads left", "{n} डाउनलोड बाकी", "{n} डाउनलोड बाकी"],
  receipt: ["Receipt", "पावती", "रसीद"],
  rate: ["Rate this book", "या पुस्तकाला रेटिंग द्या", "इस किताब को रेटिंग दें"],
  rate_ph: ["A few words for other readers (optional)", "इतर वाचकांसाठी काही शब्द (ऐच्छिक)", "दूसरे पाठकों के लिए कुछ शब्द (वैकल्पिक)"],
  rate_send: ["Post rating", "रेटिंग द्या", "रेटिंग दें"],
  thanks: ["Thank you!", "धन्यवाद!", "धन्यवाद!"],
  signout: ["Sign out", "बाहेर पडा", "साइन आउट"],
  no_file: ["The PDF is being uploaded by the author. You'll get an email the moment it's ready.", "लेखक PDF अपलोड करत आहेत. ते तयार होताच तुम्हाला ईमेल येईल.", "लेखक PDF अपलोड कर रहे हैं। तैयार होते ही आपको ईमेल मिलेगा।"],
  limit: ["Download limit reached. WhatsApp 86248 60808 and we'll reset it.", "डाउनलोड मर्यादा संपली. 86248 60808 वर व्हॉट्सॲप करा, आम्ही पुन्हा सुरू करू.", "डाउनलोड सीमा पूरी हुई। 86248 60808 पर व्हाट्सऐप करें, हम फिर से चालू करेंगे।"],
  test_badge: ["Test mode — no real money", "टेस्ट मोड — खरे पैसे नाहीत", "टेस्ट मोड — असली पैसा नहीं"]
};
function useST() { const { t } = useL(); return (k, v) => { let s = ST[k] ? ST[k][t.i] : k; if (v && typeof s === "string") Object.keys(v).forEach((x) => (s = s.replace("{" + x + "}", v[x]))); return s; }; }

const PAYCFG = () => Object.assign({ live: false, keyId: "", api: "/.netlify/functions", mode: "test" }, window.VMP_PAY || {});
const bookTitle = (b) => b.titleLatin || b.title;
const listPrice = (b) => b.type === "bundle" ? b.price : b.price;
const bundleValue = (b) => (b.items || []).reduce((s, id) => { const x = window.CMS_ALL_EBOOKS.find((y) => y.id === id); return s + (x ? x.price : 0); }, 0);
function ratingsFor(id) { return (window.VMPStore.load().ratings || []).filter((r) => r.product === id && !r.hidden); }
function Stars({ n, size }) { return <span className="stars-s" style={{ fontSize: size || 16 }} aria-label={n + " of 5"}>{[1, 2, 3, 4, 5].map((i) => <i key={i} className={i <= Math.round(n) ? "on" : ""}>★</i>)}</span>; }

function findCoupon(code, productId) {
  const c = (window.VMPStore.load().coupons || []).find((x) => x.code.toUpperCase() === String(code).trim().toUpperCase());
  if (!c || !c.active) return null;
  if (c.expires && c.expires < new Date().toISOString().slice(0, 10)) return null;
  if (c.maxUses && (c.used || 0) >= c.maxUses) return null;
  if (c.products !== "all" && !(c.products || []).includes(productId)) return null;
  return c;
}
const discountOf = (c, base) => (!c ? 0 : Math.min(base, c.type === "pct" ? Math.round((base * c.value) / 100) : c.value));

/* -------- cards -------- */
function ProductCard({ b }) {
  const st = useST(); const { t } = useL();
  const r = ratingsFor(b.id); const avg = r.length ? r.reduce((s, x) => s + x.stars, 0) / r.length : 0;
  return (
    <A to={"store/" + b.id} className="pcard">
      <div className="pcard-cover">{b.type === "bundle" ? <BundleCover b={b} /> : <BookCover b={b} small />}</div>
      <div className="pcard-b">
        <b lang={b.lang}>{b.title}</b>
        <small>{st("by")}</small>
        <div className="pcard-f">
          <span className="ptag">{b.pwyw ? "₹" + b.minPrice + "+" : "₹" + b.price}</span>
          {b.compareAt > b.price && <s className="muted">₹{b.compareAt}</s>}
          {r.length > 0 && <span className="pcard-r"><Stars n={avg} size={13} /> {r.length}</span>}
          <span className="lang-pill" style={{ marginLeft: "auto" }}>{b.type === "bundle" ? st("bundle") : t("lang_" + b.lang)}</span>
        </div>
      </div>
    </A>
  );
}
function BundleCover({ b }) {
  const items = (b.items || []).map((id) => window.CMS_ALL_EBOOKS.find((x) => x.id === id)).filter(Boolean).slice(0, 4);
  return <div className="bundle-cover" style={{ background: b.hue || "#14365c" }}>{items.map((x, i) => <div key={x.id} className="bc-item" style={{ background: x.hue, color: x.accent, transform: `translateX(${(i - (items.length - 1) / 2) * 34}px) rotate(${(i - (items.length - 1) / 2) * 6}deg)`, zIndex: i }}><small>Dard E Body Care</small><b lang={x.lang}>{x.title}</b></div>)}</div>;
}

/* -------- storefront -------- */
function StorePage() {
  const { t } = useL(); const st = useST();
  useSeo(st("creator") + " — Ebooks by Dr. Vipul Ahire", st("bio"));
  useStoreTick();
  const [lang, setLang] = useState("all"); const [sort, setSort] = useState("feat");
  let list = window.EBOOKS.filter((b) => lang === "all" || b.lang === lang || (b.type === "bundle" && lang === "all"));
  if (sort === "low") list = [...list].sort((a, b) => a.price - b.price);
  if (sort === "high") list = [...list].sort((a, b) => b.price - a.price);
  const langs = [...new Set(window.EBOOKS.filter((b) => b.type !== "bundle").map((b) => b.lang))];
  return (
    <main>
      <section className="sf-head">
        <div className="wrap sf-head-in">
          <img src="assets/logo-256.png" alt="" className="sf-avatar" />
          <div style={{ flex: 1, minWidth: 240 }}>
            <h1>{st("creator")}</h1>
            <p className="sf-by">{st("by")}</p>
            <p className="sf-bio">{st("bio")}</p>
          </div>
          <div className="sf-links">
            <A to="library" className="btn btn-light btn-sm">{st("library")}</A>
            <a className="btn btn-sm sf-ghost" href={window.BUSINESS.youtube} target="_blank" rel="noopener">YouTube</a>
            <a className="btn btn-sm sf-ghost" href={window.BUSINESS.instagram} target="_blank" rel="noopener">Instagram</a>
          </div>
        </div>
      </section>
      <section className="sec" style={{ paddingTop: 34 }}>
        <div className="wrap">
          <div className="sf-bar">
            <div className="tabs" style={{ margin: 0 }}>
              <button className={lang === "all" ? "on" : ""} onClick={() => setLang("all")}>{st("all")}</button>
              {langs.map((l) => <button key={l} className={lang === l ? "on" : ""} onClick={() => setLang(l)}>{t("lang_" + l)}</button>)}
            </div>
            <div className="row" style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <span className="muted" style={{ fontSize: 15 }}>{list.length} {st("products")}</span>
              <select className="sf-sort" value={sort} onChange={(e) => setSort(e.target.value)}><option value="feat">{st("sort_feat")}</option><option value="low">{st("sort_low")}</option><option value="high">{st("sort_high")}</option></select>
            </div>
          </div>
          <div className="pgrid">{list.map((b) => <ProductCard key={b.id} b={b} />)}</div>
          <div className="sf-trust"><span>🔒 {st("secure")}</span><span>⚡ {t("instant")}</span><span>₹ {st("powered")}</span></div>
        </div>
      </section>
    </main>
  );
}

/* -------- product -------- */
function ProductPage({ id }) {
  const { t, lang } = useL(); const st = useST();
  useStoreTick();
  const b = window.EBOOKS.find((x) => x.id === id);
  const tx = (window.EBOOK_TEXT[id]) || {};
  const [open, setOpen] = useState(false);
  const [pw, setPw] = useState(b ? (b.pwyw ? b.suggested || b.minPrice : b.price) : 0);
  const [code, setCode] = useState(""); const [coupon, setCoupon] = useState(null); const [cErr, setCErr] = useState(""); const [showC, setShowC] = useState(false);
  const [copied, setCopied] = useState(false);
  useSeo((b ? bookTitle(b) : "Ebook") + " — " + st("creator"), b ? t.pick(tx.blurb) : "");
  useEffect(() => {
    if (!b) return;
    const ld = { "@context": "https://schema.org", "@type": b.type === "bundle" ? "Product" : "Book", name: b.title, author: { "@type": "Person", name: "Dr. Vipul Ahire" }, inLanguage: b.lang, bookFormat: "EBook", image: "https://vipmagicalphysio.com/assets/logo-512.png", offers: { "@type": "Offer", price: b.price, priceCurrency: "INR", availability: "https://schema.org/InStock", url: "https://vipmagicalphysio.com/" + lang + "/store/" + b.id } };
    const r = ratingsFor(b.id); if (r.length) ld.aggregateRating = { "@type": "AggregateRating", ratingValue: (r.reduce((s, x) => s + x.stars, 0) / r.length).toFixed(1), reviewCount: r.length };
    let el = document.getElementById("ld-book"); if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = "ld-book"; document.head.appendChild(el); }
    el.textContent = JSON.stringify(ld); return () => el.remove();
  }, [id, lang]);
  if (!b) return <main className="sec"><div className="wrap"><h2>404</h2><A to="store">← {t("nav_store")}</A></div></main>;
  const base = b.pwyw ? Math.max(b.minPrice, +pw || 0) : b.price;
  const disc = discountOf(coupon, base);
  const total = Math.max(0, base - disc);
  const feats = (b.features && b.features[lang] && b.features[lang].length) ? b.features[lang] : ST.feats[t.i];
  const r = ratingsFor(b.id); const avg = r.length ? r.reduce((s, x) => s + x.stars, 0) / r.length : 0;
  const url = location.href;
  const applyCoupon = () => { const c = findCoupon(code, b.id); if (c) { setCoupon(c); setCErr(""); } else { setCoupon(null); setCErr(st("coupon_bad")); } };
  const more = window.EBOOKS.filter((x) => x.id !== b.id).slice(0, 3);
  const bundleItems = b.type === "bundle" ? (b.items || []).map((i) => window.CMS_ALL_EBOOKS.find((x) => x.id === i)).filter(Boolean) : [];
  return (
    <main className="sec" style={{ paddingTop: 30 }}>
      <div className="wrap">
        <div className="crumbs"><A to="store">{st("creator")}</A> / {bookTitle(b)}</div>
        <div className="pp">
          <div className="pp-media">
            <div className="pp-stage">{b.type === "bundle" ? <BundleCover b={b} /> : <div style={{ width: "min(340px,70%)" }}><BookCover b={b} /></div>}</div>
            <div className="pp-thumbs">
              <Slot id={"ebook-" + b.id + "-p1"} ph="photo_treat" className="pp-thumb" />
              <Slot id={"ebook-" + b.id + "-p2"} ph="photo_treat" className="pp-thumb" />
              <Slot id={"ebook-" + b.id + "-p3"} ph="photo_treat" className="pp-thumb" />
            </div>
          </div>

          <aside className="pp-buy">
            <div className="buybox">
              <span className="lang-pill">{b.type === "bundle" ? st("bundle") : t("lang_" + b.lang)}</span>
              <h1 lang={b.lang}>{b.title}</h1>
              <div className="pp-author"><img src="assets/logo-256.png" alt="" />{st("by")}</div>
              {r.length > 0 && <a href="#ratings" className="pp-rating" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: document.getElementById("ratings").offsetTop - 90, behavior: "smooth" }); }}><Stars n={avg} /> {avg.toFixed(1)} · {r.length}</a>}
              <div className="pp-price">
                {b.pwyw ? (
                  <label className="pwyw"><span>{st("pwyw")} <em>{st("pwyw_min", { n: b.minPrice })}</em></span>
                    <div className="pwyw-in"><b>₹</b><input type="number" inputMode="numeric" min={b.minPrice} value={pw} onChange={(e) => setPw(e.target.value)} onBlur={() => setPw(Math.max(b.minPrice, +pw || 0))} /></div></label>
                ) : (<><b className="ptag big">₹{b.price}</b>{b.compareAt > b.price && <><s className="muted">₹{b.compareAt}</s><span className="save">{st("save", { n: b.compareAt - b.price })}</span></>}</>)}
                {b.type === "bundle" && bundleValue(b) > b.price && <span className="save">{st("save", { n: bundleValue(b) - b.price })}</span>}
              </div>
              {!showC && !coupon && <button className="linkish" onClick={() => setShowC(true)}>{st("coupon")}</button>}
              {(showC || coupon) && <div className="coupon-row"><input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="CODE" aria-label="Coupon" /><button className="btn btn-sm btn-ghost" onClick={applyCoupon}>{st("apply")}</button></div>}
              {coupon && <div className="ok-line">✓ {st("coupon_ok", { c: coupon.code })} · −₹{disc}</div>}
              {cErr && <div className="err">{cErr}</div>}
              <button className="btn btn-primary buy-btn" onClick={() => setOpen(true)}>{total === 0 ? st("get_free") : st("get") + " · ₹" + total}</button>
              <ul className="buy-points"><li>⚡ {t("instant")}</li><li>🔒 {st("secure")}</li></ul>
              <div className="share-row">
                <span className="muted">{st("share")}:</span>
                <a href={"https://wa.me/?text=" + encodeURIComponent(bookTitle(b) + " — " + url)} target="_blank" rel="noopener" className="sh-btn" style={{ background: "#1f9d55" }}>{WA_ICON}</a>
                <button className="sh-btn" style={{ background: "var(--navy)" }} onClick={() => { navigator.clipboard && navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1800); }}>{copied ? "✓" : "🔗"}</button>
                {copied && <small className="muted">{st("copied")}</small>}
              </div>
              <A to="library" className="linkish" style={{ display: "block", marginTop: 12 }}>{st("bought")} →</A>
            </div>
          </aside>

          <div className="pp-desc">
            <p className="lead" style={{ color: "var(--ink)" }}>{t.pick(tx.blurb)}</p>
            {bundleItems.length > 0 && <><h3>{st("includes")}</h3><div className="incl">{bundleItems.map((x) => <A to={"store/" + x.id} key={x.id} className="incl-i"><span style={{ background: x.hue }}></span><b lang={x.lang}>{x.title}</b><small>₹{x.price}</small></A>)}</div></>}
            <h3>{st("youget")}</h3>
            <ul className="ticks">{feats.map((f) => <li key={f}>{f}</li>)}</ul>
            {tx.for && <><h3>{t("bk_for")}</h3><p>{t.pick(tx.for)}</p></>}
            <h3>{st("details")}</h3>
            <table className="dtable"><tbody>
              <tr><td>{t("bk_language")}</td><td>{b.type === "bundle" ? [...new Set(bundleItems.map((x) => t("lang_" + x.lang)))].join(", ") : t("lang_" + b.lang)}</td></tr>
              <tr><td>{t("bk_format")}</td><td>PDF</td></tr>
              {b.pages && <tr><td>{st("pages")}</td><td>{b.pages}</td></tr>}
              {b.size && <tr><td>{st("size")}</td><td>{b.size}</td></tr>}
              <tr><td>{t("refund")}</td><td><A to="legal/refund">{t("refund")} →</A></td></tr>
            </tbody></table>

            <h3 id="ratings">{st("ratings")}</h3>
            {r.length ? (
              <div className="rlist">
                <div className="rsum"><b>{avg.toFixed(1)}</b><Stars n={avg} size={20} /><span className="muted">{r.length}</span></div>
                {r.slice(0, 8).map((x) => <div className="ritem" key={x.id}><div className="row" style={{ display: "flex", gap: 10, alignItems: "center" }}><Stars n={x.stars} /><b>{x.name.split(" ")[0]}</b><span className="vbadge">✓ {st("verified")}</span></div>{x.text && <p>{x.text}</p>}</div>)}
              </div>
            ) : <p className="muted">{st("no_ratings")}</p>}
          </div>
        </div>

        {more.length > 0 && <><h2 style={{ marginTop: 64, fontSize: 32 }}>{st("more")}</h2><div className="pgrid">{more.map((x) => <ProductCard key={x.id} b={x} />)}</div></>}
      </div>
      {open && <CheckoutSheet b={b} base={base} coupon={coupon} disc={disc} total={total} onClose={() => setOpen(false)} />}
    </main>
  );
}

/* -------- checkout sheet -------- */
function CheckoutSheet({ b, base, coupon, disc, total, onClose }) {
  const { t, lang } = useL(); const st = useST();
  const saved = JSON.parse(localStorage.getItem("vmp_buyer") || "{}");
  const [f, setF] = useState({ email: saved.email || "", name: saved.name || "", mobile: saved.mobile || "", agree: false, optin: false });
  const [errs, setErrs] = useState({}); const [stage, setStage] = useState("form"); const [msg, setMsg] = useState(""); const [order, setOrder] = useState(null); const [sim, setSim] = useState(false);
  const cfg = PAYCFG();
  useEffect(() => { const k = (e) => e.key === "Escape" && stage !== "processing" && onClose(); window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, [stage]);

  const finishPaid = (o, gatewayId, token) => {
    const S = window.VMPStore;
    const items = b.type === "bundle" ? b.items : [b.id];
    const paid = S.update("orders", o.id, { status: "paid", paymentId: gatewayId, downloads: {}, maxDownloads: 5, items, downloadToken: token || "", expiresAt: new Date(Date.now() + 365 * 86400000).toISOString() }, "Payment verified (Razorpay)", "razorpay");
    if (total > 0) S.add("payments", { kind: "ebook", ref: o.id, name: o.name, mobile: o.mobile, email: o.email, purpose: "Ebook: " + bookTitle(b), amount: total, method: "Razorpay", gatewayId, status: "paid", receipt: "RCPT-" + Date.now().toString().slice(-6), lang, silent: true }, "Payment recorded (ebook)");
    if (coupon) { const db = S.load(); const c = (db.coupons || []).find((x) => x.code === coupon.code); if (c) { c.used = (c.used || 0) + 1; S.save(db); } }
    if (f.optin) S.add("subscribers", { email: f.email, lang, source: "ebook", consent: true }, "Subscriber via ebook");
    localStorage.setItem("vmp_lib_email", f.email.toLowerCase());
    setOrder(paid); setStage("done");
  };

  const pay = async () => {
    const er = {};
    if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = t("err_email");
    if (!f.name.trim()) er.name = t("err_name");
    if (f.mobile && !/^[6-9]\d{9}$/.test(f.mobile.replace(/\D/g, "").slice(-10))) er.mobile = t("err_mobile");
    if (!f.agree) er.agree = t("err_consent");
    setErrs(er); if (Object.keys(er).length) return;
    localStorage.setItem("vmp_buyer", JSON.stringify({ email: f.email, name: f.name, mobile: f.mobile }));
    setMsg("");
    const o = window.VMPStore.add("orders", { product: b.id, title: bookTitle(b), base, discount: disc, coupon: coupon ? coupon.code : "", amount: total, name: f.name.trim(), email: f.email.trim().toLowerCase(), mobile: f.mobile.replace(/\D/g, "").slice(-10), status: "created", lang }, "Order created");
    if (total === 0) { finishPaid(o, "free"); return; }

    if (cfg.live && cfg.keyId && window.Razorpay) {
      setStage("processing");
      try {
        const r = await fetch(cfg.api + "/create-order", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId: b.id, coupon: coupon ? coupon.code : "", amount: base, customer: { name: f.name, email: f.email, mobile: f.mobile }, lang, localOrderId: o.id }) }).then((x) => x.json());
        if (!r.razorpayOrderId) throw new Error(r.error || "order");
        await new Promise((res, rej) => {
          const rz = new window.Razorpay({
            key: cfg.keyId, order_id: r.razorpayOrderId, amount: r.amount, currency: "INR",
            name: "VIP MAGICAL PHYSIO", description: bookTitle(b), image: location.origin + "/assets/logo-256.png",
            prefill: { name: f.name, email: f.email, contact: f.mobile }, notes: { orderId: r.orderId, product: b.id },
            theme: { color: "#0d7f7a" },
            handler: async (resp) => {
              const v = await fetch(cfg.api + "/verify-payment", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...resp, orderId: r.orderId }) }).then((x) => x.json());
              v.ok ? res(v) : rej(new Error("verify"));
            },
            modal: { ondismiss: () => rej(new Error("dismissed")) }
          });
          rz.on("payment.failed", () => rej(new Error("failed")));
          rz.open();
        }).then((v) => { finishPaid(o, v.paymentId, v.downloadToken); });
      } catch (e) {
        window.VMPStore.update("orders", o.id, { status: e.message === "dismissed" ? "abandoned" : "failed" }, "Payment " + e.message, "razorpay");
        setMsg(e.message === "dismissed" ? st("dismissed") : st("failed")); setStage("form");
      }
      return;
    }
    // prototype gateway
    setOrder(o); setSim(true);
  };
  const simResult = (ok) => {
    setSim(false); setStage("processing");
    setTimeout(() => {
      if (ok) finishPaid(order, "pay_" + Math.random().toString(36).slice(2, 12));
      else { window.VMPStore.update("orders", order.id, { status: "failed" }, "Payment failed", "razorpay"); setMsg(st("failed")); setStage("form"); }
    }, 1400);
  };
  const dl = () => downloadItem(order, b.type === "bundle" ? b.items[0] : b.id, st);

  return (
    <div className="sheet-bg" onClick={() => stage === "form" && onClose()}>
      <aside className="sheet" onClick={(e) => e.stopPropagation()} role="dialog" aria-label={st("ck_title")}>
        <div className="sheet-h"><b>{st("ck_title")}</b>{!cfg.live && <span className="testb">{st("test_badge")}</span>}<button className="x" onClick={onClose} disabled={stage === "processing"} aria-label={t("close")}>×</button></div>
        <div className="sheet-sum">
          <div className="mini-c" style={{ background: b.hue, color: b.accent }}><b lang={b.lang}>{b.title}</b></div>
          <div style={{ flex: 1 }}><b lang={b.lang}>{b.title}</b><small>{st("by")}</small></div>
          <b>₹{base}</b>
        </div>
        {stage === "form" && (
          <div className="sheet-b">
            {msg && <div className="note warn" style={{ marginBottom: 14 }}>{msg}</div>}
            <div className="field"><label htmlFor="se">{st("email")}</label><input id="se" type="email" autoComplete="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />{errs.email && <span className="err">{errs.email}</span>}</div>
            <div className="field"><label htmlFor="sn">{st("name")}</label><input id="sn" autoComplete="name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />{errs.name && <span className="err">{errs.name}</span>}</div>
            <div className="field"><label htmlFor="sm">{st("mobile")}</label><input id="sm" inputMode="numeric" autoComplete="tel" value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} />{errs.mobile && <span className="err">{errs.mobile}</span>}</div>
            <div className="totals">
              <div><span>{st("subtotal")}</span><span>₹{base}</span></div>
              {disc > 0 && <div className="ok-line"><span>{st("discount")} ({coupon.code})</span><span>−₹{disc}</span></div>}
              <div className="tot"><span>{st("total")}</span><span>₹{total}</span></div>
              <small className="muted">{t("incl_tax")}</small>
            </div>
            <label className="check"><input type="checkbox" checked={f.agree} onChange={(e) => setF({ ...f, agree: e.target.checked })} />{st("agree")}</label>
            {errs.agree && <div className="err" style={{ marginTop: -6 }}>{errs.agree}</div>}
            <label className="check"><input type="checkbox" checked={f.optin} onChange={(e) => setF({ ...f, optin: e.target.checked })} />{st("optin")}</label>
            <button className="btn btn-primary" style={{ width: "100%", marginTop: 8 }} onClick={pay}>{total === 0 ? st("get_free") : st("pay", { n: total })}</button>
            <div className="rz-foot"><span>🔒 {st("secure")}</span><span>{st("powered")}</span></div>
          </div>
        )}
        {stage === "processing" && <div className="sheet-b center" style={{ paddingTop: 50 }}><div className="spinner"></div><p>{st("processing")}</p></div>}
        {stage === "done" && order && (
          <div className="sheet-b center">
            <div className="success"><div className="tick"></div></div>
            <h2 style={{ fontSize: 28 }}>{st("ready")}</h2>
            <p>{st("ready_p", { e: order.email })}</p>
            <div className="ref" style={{ justifyContent: "center" }}><div><small>{t("order_no")}</small><b>{order.id}</b></div><div><small>{st("total")}</small><b>₹{order.amount}</b></div></div>
            <button className="btn btn-primary" style={{ width: "100%" }} onClick={dl}>↓ {st("download")}</button>
            <A to="library" className="btn btn-ghost" style={{ width: "100%", marginTop: 10 }} onClick={onClose}>{st("open_lib")}</A>
          </div>
        )}
        {sim && (
          <div className="rz-sim">
            <div className="modal">
              <div className="rz-head"><b>Razorpay · {st("test_badge")}</b><span>₹{total}</span></div>
              <div className="rz-body">
                <div style={{ fontSize: 15 }}><b>VIP MAGICAL PHYSIO</b><br /><span className="muted">{bookTitle(b)} · {order.id}</span></div>
                <div className="chips"><span className="chip">UPI</span><span className="chip">Cards</span><span className="chip">Net-banking</span><span className="chip">Wallets</span></div>
                <button className="btn btn-primary" onClick={() => simResult(true)}>{t("rz_pay_ok")}</button>
                <button className="btn btn-ghost" onClick={() => simResult(false)}>{t("rz_pay_fail")}</button>
                <small className="muted">{t("rz_demo")}</small>
              </div>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}

function downloadItem(order, productId, st) {
  const S = window.VMPStore; const db = S.load();
  const o = db.orders.find((x) => x.id === order.id); if (!o) return;
  const dls = typeof o.downloads === "object" && o.downloads ? o.downloads : {};
  const used = dls[productId] || 0; const max = o.maxDownloads || 5;
  if (used >= max) { alert(st("limit")); return; }
  const cfg = PAYCFG();
  if (cfg.live && o.downloadToken) { window.open(cfg.api + "/download?token=" + encodeURIComponent(o.downloadToken) + "&product=" + productId, "_blank"); }
  const book = (window.CMS_ALL_EBOOKS || []).find((x) => x.id === productId);
  dls[productId] = used + 1; S.update("orders", o.id, { downloads: dls }, "Download " + productId, "customer");
  if (!cfg.live) { if (book && book.fileUrl) window.open(book.fileUrl, "_blank"); else alert(st("no_file")); }
}

/* -------- library -------- */
function LibraryPage() {
  const { t, lang } = useL(); const st = useST();
  useSeo(st("lib_h"), st("lib_p"));
  useStoreTick();
  const [email, setEmail] = useState(localStorage.getItem("vmp_lib_email") || "");
  const [authed, setAuthed] = useState(!!localStorage.getItem("vmp_lib_email"));
  const [sent, setSent] = useState(null); const [code, setCode] = useState(""); const [err, setErr] = useState("");
  const [rateFor, setRateFor] = useState(null);
  const send = () => { if (!/^\S+@\S+\.\S+$/.test(email)) return setErr(t("err_email")); setErr(""); setSent(String(Math.floor(100000 + Math.random() * 900000))); };
  const verify = () => { if (code.trim() === sent) { localStorage.setItem("vmp_lib_email", email.trim().toLowerCase()); setAuthed(true); setErr(""); } else setErr(st("code_bad")); };
  if (!authed) return (
    <main className="sec"><div className="wrap" style={{ maxWidth: 560 }}>
      <span className="kicker">{st("creator")}</span><h1 style={{ fontSize: "clamp(34px,4.6vw,52px)" }}>{st("lib_h")}</h1><p className="lead">{st("lib_p")}</p>
      <div className="form-card" style={{ marginTop: 20 }}>
        <div className="field"><label htmlFor="le">Email</label><input id="le" type="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={!!sent} /></div>
        {!sent ? <button className="btn btn-primary" onClick={send}>{st("send_code")}</button> : (<>
          <div className="note sun" style={{ marginBottom: 12 }}>{st("code_demo", { c: sent })}</div>
          <div className="field"><label htmlFor="lc">{st("code")}</label><input id="lc" inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} /></div>
          <button className="btn btn-primary" onClick={verify}>{st("verify")}</button>
        </>)}
        {err && <div className="err" style={{ marginTop: 10 }}>{err}</div>}
      </div>
    </div></main>
  );
  const me = (localStorage.getItem("vmp_lib_email") || "").toLowerCase();
  const db = window.VMPStore.load();
  const orders = db.orders.filter((o) => o.email === me && o.status === "paid");
  const rows = orders.flatMap((o) => (o.items && o.items.length ? o.items : [o.product]).map((pid) => ({ o, pid, book: (window.CMS_ALL_EBOOKS || []).find((x) => x.id === pid) }))).filter((r) => r.book);
  const myRatings = db.ratings || [];
  return (
    <main className="sec"><div className="wrap">
      <div className="sec-head"><div><span className="kicker">{st("creator")}</span><h1 style={{ fontSize: "clamp(34px,4.6vw,52px)" }}>{st("lib_h")}</h1><p className="muted mb0">{me}</p></div>
        <div className="btn-row"><A to="store" className="btn btn-ghost btn-sm">← {t("nav_store")}</A><button className="btn btn-ghost btn-sm" onClick={() => { localStorage.removeItem("vmp_lib_email"); setAuthed(false); setSent(null); setCode(""); }}>{st("signout")}</button></div></div>
      {!rows.length && <div className="form-card center"><p className="lead" style={{ margin: "0 auto 16px" }}>{st("none")}</p><A to="store" className="btn btn-primary">{t("nav_store")}</A></div>}
      <div className="lib">{rows.map(({ o, pid, book }) => {
        const used = (o.downloads && o.downloads[pid]) || 0; const left = Math.max(0, (o.maxDownloads || 5) - used);
        const rated = myRatings.find((r) => r.orderId === o.id && r.product === pid);
        return <div className="lib-i" key={o.id + pid}>
          <div className="lib-c"><BookCover b={book} small /></div>
          <div className="lib-b">
            <b lang={book.lang}>{book.title}</b>
            <small className="muted">{st("bought_on")} {new Date(o.createdAt).toLocaleDateString("en-IN")} · {o.id} · ₹{o.amount}</small>
            <div className="btn-row" style={{ marginTop: 12 }}>
              <button className="btn btn-primary btn-sm" disabled={!left} onClick={() => downloadItem(o, pid, st)}>↓ {st("download")}</button>
              <button className="btn btn-ghost btn-sm" onClick={() => printReceipt(o, st, t)}>{st("receipt")}</button>
              {!rated && <button className="btn btn-ghost btn-sm" onClick={() => setRateFor({ o, pid })}>★ {st("rate")}</button>}
              {rated && <span className="muted" style={{ alignSelf: "center" }}><Stars n={rated.stars} size={14} /></span>}
            </div>
            <small className="muted" style={{ marginTop: 6 }}>{st("left", { n: left })}</small>
          </div>
        </div>;
      })}</div>
      {rateFor && <RateModal o={rateFor.o} pid={rateFor.pid} onClose={() => setRateFor(null)} />}
    </div></main>
  );
}
function RateModal({ o, pid, onClose }) {
  const st = useST(); const [n, setN] = useState(5); const [txt, setTxt] = useState(""); const [done, setDone] = useState(false);
  const post = () => { const db = window.VMPStore.load(); db.ratings = db.ratings || []; db.ratings.unshift({ id: "RT-" + Date.now().toString(36), createdAt: new Date().toISOString(), product: pid, orderId: o.id, name: o.name, stars: n, text: txt.trim().slice(0, 400), hidden: false }); db.log.unshift({ at: new Date().toISOString(), who: "customer", action: "Rating " + n + "★", ref: pid }); window.VMPStore.save(db); setDone(true); setTimeout(onClose, 1200); };
  return <div className="modal-bg" onClick={onClose}><div className="modal" onClick={(e) => e.stopPropagation()}><div className="rz-body" style={{ padding: 26 }}>
    {done ? <h3 className="center">{st("thanks")}</h3> : <>
      <h3>{st("rate")}</h3>
      <div className="star-pick">{[1, 2, 3, 4, 5].map((i) => <button key={i} className={i <= n ? "on" : ""} onClick={() => setN(i)} aria-label={i + " stars"}>★</button>)}</div>
      <textarea rows="3" placeholder={st("rate_ph")} value={txt} onChange={(e) => setTxt(e.target.value)} style={{ font: "inherit", padding: 12, borderRadius: 12, border: "1.5px solid var(--line)" }} />
      <button className="btn btn-primary" onClick={post}>{st("rate_send")}</button>
    </>}
  </div></div></div>;
}
function printReceipt(o, st, t) {
  const p = (window.VMPStore.load().payments || []).find((x) => x.ref === o.id) || {};
  const w = window.open("", "_blank", "width=640,height=760");
  w.document.write(`<html><head><title>${st("receipt")} ${o.id}</title><style>body{font-family:Mukta,Arial,sans-serif;padding:40px;color:#1d2733}h1{color:#14365c;margin:0}table{width:100%;border-collapse:collapse;margin-top:24px}td{padding:10px 0;border-bottom:1px solid #eee}td:last-child{text-align:right}.tot td{font-weight:700;font-size:18px;border:0}.m{color:#5b6673;font-size:14px}</style></head><body>
  <div style="display:flex;gap:14px;align-items:center"><img src="${location.href.replace(/[^/]*(#.*)?$/, "")}assets/logo-256.png" width="64"><div><h1>VIP MAGICAL PHYSIO</h1><div class="m">Dard E Body Care · Pabal Phata, Shirur, Maharashtra · ${window.BUSINESS.phone}</div></div></div>
  <h2 style="margin-top:30px">${st("receipt")} ${p.receipt || ""}</h2><div class="m">${t("order_no")}: ${o.id} · ${new Date(o.createdAt).toLocaleString("en-IN")} · ${p.gatewayId || o.paymentId || ""}</div>
  <div class="m" style="margin-top:6px">${o.name} · ${o.email}</div>
  <table><tr><td>${o.title}</td><td>₹${o.base != null ? o.base : o.amount}</td></tr>${o.discount ? `<tr><td>${st("discount")} (${o.coupon})</td><td>−₹${o.discount}</td></tr>` : ""}<tr class="tot"><td>${st("total")}</td><td>₹${o.amount}</td></tr></table>
  <p class="m">${t("incl_tax")}. ${st("powered")}.</p><script>print()<\/script></body></html>`);
}

Object.assign(window, { StorePage, ProductPage, LibraryPage, ProductCard, ST });
