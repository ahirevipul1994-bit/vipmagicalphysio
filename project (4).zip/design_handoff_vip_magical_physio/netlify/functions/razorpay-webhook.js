// Razorpay Dashboard → Settings → Webhooks → URL: https://vipmagicalphysio.com/.netlify/functions/razorpay-webhook
// Events: payment.captured, payment.failed, refund.processed · Secret = RAZORPAY_WEBHOOK_SECRET
// The webhook is the source of truth: even if the buyer closes the browser, the order is fulfilled here.
const { json, sb, env, hmac, safeEq, fulfil } = require("./_lib");

exports.handler = async (event) => {
  const sig = event.headers["x-razorpay-signature"];
  if (!safeEq(hmac(env("RAZORPAY_WEBHOOK_SECRET"), event.body), sig)) return json(400, { error: "bad signature" });
  const evt = JSON.parse(event.body);
  const eventId = event.headers["x-razorpay-event-id"] || evt.created_at + ":" + evt.event;
  try {
    // Idempotency: unique key on payment_events.id → duplicate deliveries are ignored.
    const ins = await sb("payment_events", { method: "POST", headers: { Prefer: "return=representation,resolution=ignore-duplicates" }, body: JSON.stringify({ id: eventId, type: evt.event, payload: evt }) });
    if (!ins || !ins.length) return json(200, { duplicate: true });

    const pay = evt.payload.payment && evt.payload.payment.entity;
    if (evt.event === "payment.captured" && pay) {
      const [order] = await sb("orders?razorpay_order_id=eq." + pay.order_id + "&select=id");
      if (order) await fulfil(order.id, pay.id);
    }
    if (evt.event === "payment.failed" && pay) {
      await sb("orders?razorpay_order_id=eq." + pay.order_id + "&status=eq.created", { method: "PATCH", body: JSON.stringify({ status: "failed" }) });
    }
    if (evt.event === "refund.processed") {
      const ref = evt.payload.refund.entity;
      await sb("orders?razorpay_payment_id=eq." + ref.payment_id, { method: "PATCH", body: JSON.stringify({ status: "refunded", refunded_at: new Date().toISOString() }) });
      await sb("payments?gateway_id=eq." + ref.payment_id, { method: "PATCH", body: JSON.stringify({ status: "refunded" }) });
    }
    return json(200, { ok: true });
  } catch (e) { console.error(e); return json(500, { error: "server" }); } // Razorpay retries on 5xx
};
