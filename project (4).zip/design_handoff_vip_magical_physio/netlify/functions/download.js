// GET ?token=… — checks signature, expiry, paid status and the 5-download limit,
// then redirects to a 60-second signed URL from the PRIVATE Supabase Storage bucket "ebooks".
const { sb, env, readDownload } = require("./_lib");

exports.handler = async (event) => {
  const d = readDownload((event.queryStringParameters || {}).token);
  if (!d) return { statusCode: 403, body: "This download link is invalid or expired. WhatsApp 86248 60808 for help." };
  const [order] = await sb("orders?id=eq." + d.o + "&select=*");
  if (!order || order.status !== "paid") return { statusCode: 403, body: "Order not paid." };
  const counts = order.download_counts || {};
  if ((counts[d.p] || 0) >= (order.max_downloads || 5)) return { statusCode: 429, body: "Download limit reached. WhatsApp 86248 60808 and we will reset it." };
  const [p] = await sb("products?id=eq." + d.p + "&select=file_path,title");
  if (!p || !p.file_path) return { statusCode: 404, body: "File is being uploaded by the author — you will get an email when it is ready." };
  counts[d.p] = (counts[d.p] || 0) + 1;
  await sb("orders?id=eq." + d.o, { method: "PATCH", body: JSON.stringify({ download_counts: counts }) });
  const r = await fetch(env("SUPABASE_URL") + "/storage/v1/object/sign/ebooks/" + p.file_path, { method: "POST", headers: { Authorization: "Bearer " + env("SUPABASE_SERVICE_ROLE_KEY"), "Content-Type": "application/json" }, body: JSON.stringify({ expiresIn: 60 }) });
  const j = await r.json();
  return { statusCode: 302, headers: { Location: env("SUPABASE_URL") + "/storage/v1" + j.signedURL + "&download=" + encodeURIComponent(p.title + ".pdf") } };
};
