// POST {productId, coupon, amount (only used for pay-what-you-want), customer:{name,email,mobile}, lang}
// Price is ALWAYS read from the database — the browser cannot change it.
const { json, sb, razorpay, env } = require("./_lib");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "POST only" });
  try {
    const { productId, coupon, amount, customer = {}, lang } = JSON.parse(event.body || "{}");
    if (!/^\S+@\S+\.\S+$/.test(customer.email || "")) return json(400, { error: "email" });
    const [p] = await sb("products?id=eq." + encodeURIComponent(productId) + "&active=is.true&select=*");
    if (!p) return json(404, { error: "product" });

    let base = p.price_paise;
    if (p.pwyw) base = Math.max(p.min_price_paise, Math.round(Number(amount || 0) * 100));
    let discount = 0, couponCode = null;
    if (coupon) {
      const [c] = await sb("coupons?code=eq." + encodeURIComponent(String(coupon).toUpperCase()) + "&active=is.true&select=*");
      const ok = c && (!c.expires_on || c.expires_on >= new Date().toISOString().slice(0, 10)) && (!c.max_uses || c.used < c.max_uses) && (c.product_ids === null || c.product_ids.includes(p.id));
      if (ok) { discount = Math.min(base, c.kind === "pct" ? Math.round((base * c.value) / 100) : c.value * 100); couponCode = c.code; }
    }
    const total = base - discount;
    const [order] = await sb("orders", { method: "POST", body: JSON.stringify({
      product_id: p.id, items: p.bundle_items || null, amount_paise: total, base_paise: base, discount_paise: discount, coupon_code: couponCode,
      customer_name: String(customer.name || "").slice(0, 120), customer_email: customer.email.toLowerCase(), customer_mobile: String(customer.mobile || "").replace(/\D/g, "").slice(-10) || null,
      lang: ["en", "mr", "hi"].includes(lang) ? lang : "en", status: total === 0 ? "created" : "created"
    }) });
    if (total === 0) return json(200, { free: true, orderId: order.id });
    const rz = await razorpay("orders", { amount: total, currency: "INR", receipt: order.id, notes: { order_id: order.id, product: p.id, email: customer.email } });
    await sb("orders?id=eq." + order.id, { method: "PATCH", body: JSON.stringify({ razorpay_order_id: rz.id }) });
    return json(200, { orderId: order.id, razorpayOrderId: rz.id, amount: total, keyId: env("RAZORPAY_KEY_ID") });
  } catch (e) { console.error(e); return json(500, { error: "server" }); }
};
