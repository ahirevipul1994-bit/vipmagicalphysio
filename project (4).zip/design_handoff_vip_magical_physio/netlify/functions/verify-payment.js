// POST {razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId}
// Verifies the Checkout signature server-side, then fulfils (idempotent).
const { json, sb, env, hmac, safeEq, fulfil, signDownload } = require("./_lib");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "POST only" });
  try {
    const b = JSON.parse(event.body || "{}");
    const expected = hmac(env("RAZORPAY_KEY_SECRET"), b.razorpay_order_id + "|" + b.razorpay_payment_id);
    if (!safeEq(expected, b.razorpay_signature)) return json(400, { ok: false, error: "signature" });
    const [order] = await sb("orders?id=eq." + b.orderId + "&razorpay_order_id=eq." + b.razorpay_order_id + "&select=*");
    if (!order) return json(404, { ok: false });
    const paid = await fulfil(order.id, b.razorpay_payment_id);
    const exp = new Date(paid.download_expires_at || Date.now() + 365 * 86400000).getTime();
    return json(200, { ok: true, orderId: order.id, paymentId: b.razorpay_payment_id, downloadToken: signDownload(order.id, order.product_id, exp) });
  } catch (e) { console.error(e); return json(500, { ok: false }); }
};
