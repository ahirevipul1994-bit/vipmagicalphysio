// Shared helpers for VIP MAGICAL PHYSIO payment functions (Netlify Functions, Node 18+).
// Env vars (Netlify → Site settings → Environment variables):
//   RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, RAZORPAY_WEBHOOK_SECRET   (Razorpay account: ahirevipul1994@gmail.com)
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY                          (server-only, never in browser)
//   BREVO_API_KEY, MAIL_FROM=books@vipmagicalphysio.com, MAIL_ADMIN=ahirevipul1994@gmail.com
//   SITE_URL=https://vipmagicalphysio.com, DOWNLOAD_SECRET=<long random string>
const crypto = require("crypto");

const env = (k) => { const v = process.env[k]; if (!v) throw new Error("Missing env " + k); return v; };
const json = (status, body) => ({ statusCode: status, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": process.env.SITE_URL || "*" }, body: JSON.stringify(body) });

async function sb(path, opts = {}) {
  const r = await fetch(env("SUPABASE_URL") + "/rest/v1/" + path, {
    ...opts,
    headers: { apikey: env("SUPABASE_SERVICE_ROLE_KEY"), Authorization: "Bearer " + env("SUPABASE_SERVICE_ROLE_KEY"), "Content-Type": "application/json", Prefer: "return=representation", ...(opts.headers || {}) }
  });
  const text = await r.text();
  if (!r.ok) throw new Error("Supabase " + r.status + ": " + text);
  return text ? JSON.parse(text) : null;
}

async function razorpay(path, body) {
  const auth = Buffer.from(env("RAZORPAY_KEY_ID") + ":" + env("RAZORPAY_KEY_SECRET")).toString("base64");
  const r = await fetch("https://api.razorpay.com/v1/" + path, { method: body ? "POST" : "GET", headers: { Authorization: "Basic " + auth, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json();
  if (!r.ok) throw new Error("Razorpay: " + (j.error && j.error.description));
  return j;
}

const hmac = (secret, data) => crypto.createHmac("sha256", secret).update(data).digest("hex");
const safeEq = (a, b) => { const A = Buffer.from(a || ""), B = Buffer.from(b || ""); return A.length === B.length && crypto.timingSafeEqual(A, B); };

function signDownload(orderId, productId, exp) { return Buffer.from(JSON.stringify({ o: orderId, p: productId, e: exp })).toString("base64url") + "." + hmac(env("DOWNLOAD_SECRET"), orderId + "|" + productId + "|" + exp); }
function readDownload(token) {
  const [b, sig] = String(token).split("."); if (!b || !sig) return null;
  const d = JSON.parse(Buffer.from(b, "base64url").toString());
  if (!safeEq(sig, hmac(env("DOWNLOAD_SECRET"), d.o + "|" + d.p + "|" + d.e))) return null;
  if (Date.now() > d.e) return null;
  return d;
}

async function sendEmail({ to, name, subject, html }) {
  if (!process.env.BREVO_API_KEY) return;
  await fetch("https://api.brevo.com/v3/smtp/email", {
    method: "POST", headers: { "api-key": process.env.BREVO_API_KEY, "Content-Type": "application/json" },
    body: JSON.stringify({ sender: { email: process.env.MAIL_FROM || "books@vipmagicalphysio.com", name: "VIP MAGICAL PHYSIO" }, to: [{ email: to, name }], subject, htmlContent: html })
  });
}

/* Called from BOTH verify-payment and the webhook — idempotent. */
async function fulfil(orderId, paymentId) {
  const [order] = await sb("orders?id=eq." + orderId + "&select=*");
  if (!order) throw new Error("order not found");
  if (order.status === "paid") return order; // already fulfilled (duplicate webhook / double call)
  const exp = Date.now() + 365 * 86400000;
  const [paid] = await sb("orders?id=eq." + orderId + "&status=neq.paid", { method: "PATCH", body: JSON.stringify({ status: "paid", razorpay_payment_id: paymentId, paid_at: new Date().toISOString(), download_expires_at: new Date(exp).toISOString() }) });
  if (!paid) return order; // lost the race to another call — already paid
  if (order.coupon_code) await sb("rpc/increment_coupon", { method: "POST", body: JSON.stringify({ p_code: order.coupon_code }) }).catch(() => {});
  await sb("payments", { method: "POST", body: JSON.stringify({ order_id: orderId, kind: "ebook", amount_paise: order.amount_paise, method: "razorpay", gateway_id: paymentId, status: "paid", customer_email: order.customer_email, customer_name: order.customer_name }) });
  const items = order.items && order.items.length ? order.items : [order.product_id];
  const site = process.env.SITE_URL || "https://vipmagicalphysio.com";
  const links = items.map((p) => `<li><a href="${site}/.netlify/functions/download?token=${encodeURIComponent(signDownload(orderId, p, exp))}">${p}</a></li>`).join("");
  await sendEmail({ to: order.customer_email, name: order.customer_name, subject: "Your ebook from VIP MAGICAL PHYSIO — order " + orderId,
    html: `<p>Thank you ${order.customer_name}!</p><p>Your payment of ₹${order.amount_paise / 100} is verified.</p><ul>${links}</ul><p>Each link works 5 times. You can also open your library anytime: ${site}/en/library</p><p>— Dr. Vipul Ahire, VIP MAGICAL PHYSIO · 86248 60808</p>` });
  if (process.env.MAIL_ADMIN) await sendEmail({ to: process.env.MAIL_ADMIN, name: "Clinic", subject: "New ebook sale ₹" + order.amount_paise / 100, html: `<p>${order.customer_name} (${order.customer_email}) bought ${items.join(", ")} — order ${orderId}</p>` });
  return paid;
}

module.exports = { env, json, sb, razorpay, hmac, safeEq, signDownload, readDownload, sendEmail, fulfil };
