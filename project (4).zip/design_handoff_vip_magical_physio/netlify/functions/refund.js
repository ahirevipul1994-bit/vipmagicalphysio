// POST {orderId, reason} with header Authorization: Bearer <Supabase admin user JWT>
// Only users with role=admin in `profiles` can refund. Final status arrives via the refund.processed webhook.
const { json, sb, razorpay, env } = require("./_lib");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, {});
  try {
    const jwt = (event.headers.authorization || "").replace("Bearer ", "");
    const u = await fetch(env("SUPABASE_URL") + "/auth/v1/user", { headers: { apikey: env("SUPABASE_SERVICE_ROLE_KEY"), Authorization: "Bearer " + jwt } }).then((r) => r.json());
    const [prof] = await sb("profiles?user_id=eq." + u.id + "&select=role");
    if (!prof || prof.role !== "admin") return json(403, { error: "admin only" });
    const { orderId, reason } = JSON.parse(event.body || "{}");
    const [o] = await sb("orders?id=eq." + orderId + "&status=eq.paid&select=*");
    if (!o) return json(404, { error: "not refundable" });
    const rf = await razorpay("payments/" + o.razorpay_payment_id + "/refund", { amount: o.amount_paise, notes: { reason: reason || "", order: orderId } });
    await sb("admin_logs", { method: "POST", body: JSON.stringify({ actor: u.email, action: "Refund requested ₹" + o.amount_paise / 100, ref: orderId }) });
    return json(200, { ok: true, refundId: rf.id });
  } catch (e) { console.error(e); return json(500, { error: "server" }); }
};
