/* Payment configuration (public values only — NEVER put the Razorpay key SECRET here).
   Razorpay account: ahirevipul1994@gmail.com · Website: vipmagicalphysio.com
   1. Razorpay Dashboard → Account & Settings → API Keys → generate. Copy the Key ID (rzp_test_… or rzp_live_…) below.
   2. Put RAZORPAY_KEY_SECRET + RAZORPAY_WEBHOOK_SECRET in Netlify → Site settings → Environment variables.
   3. Set live: true after testing. Admin → Store & payments → Razorpay setup can also override these for the prototype. */
window.VMP_PAY = Object.assign({
  live: false,                 // false = prototype/simulated gateway
  keyId: "",                   // e.g. "rzp_test_XXXXXXXXXXXX"
  mode: "test",                // "test" | "live"
  api: "/.netlify/functions",  // serverless endpoints (see /netlify/functions)
  account: "ahirevipul1994@gmail.com",
  site: "https://vipmagicalphysio.com"
}, JSON.parse(localStorage.getItem("vmp_pay_cfg") || "{}"));
