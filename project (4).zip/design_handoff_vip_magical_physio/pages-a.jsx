/* Home, About, Services, Service detail, Videos */
const SVC_ORDER = window.SERVICE_META.map((m) => m.slug);
const vById = (id) => window.VIDEOS.find((v) => v.id === id);

function ServiceCard({ slug, n }) {
  const { t } = useL();
  const s = window.SERVICES[slug];
  return (
    <A to={"services/" + slug} className="card">
      <span className="svc-num">{String(n).padStart(2, "0")}</span>
      <h3>{t.pick(s.title)}</h3>
      <p>{t.pick(s.short)}</p>
      <div className="who"><b>{t("who_helps")}:</b> {t.pick(s.who)}</div>
      <span className="link-arrow">{t("learn_more")} →</span>
    </A>
  );
}

function Modes({ compact }) {
  const { t } = useL();
  const items = [["opd", "mode_opd", "mode_opd_p", "fee_opd", "photo_clinic"], ["home", "mode_home", "mode_home_p", "fee_home", "photo_treat"], ["online", "mode_online", "mode_online_p", "fee_online", null]];
  return (
    <div className="grid g3">
      {items.map(([m, h, p, f, ph]) => (
        <div className="mode" key={m}>
          {!compact && (ph ? <Slot id={"mode-" + m} ph={ph} /> : (
            <div style={{ aspectRatio: "16/10", background: "var(--navy)", display: "grid", placeItems: "center", color: "#fff", padding: 24 }}>
              <div style={{ border: "2px solid rgba(255,255,255,.3)", borderRadius: 18, padding: "18px 26px", textAlign: "center" }}>
                <div style={{ fontFamily: "var(--f-head)", fontSize: 26 }}>● {t("mode_online")}</div>
                <div style={{ opacity: .75, fontSize: 15 }}>WhatsApp / Google Meet</div>
              </div>
            </div>
          ))}
          <div className="mode-body">
            <span className="mode-tag">{m === "online" ? t("min30") : m === "home" ? t("min60") : t("min30")}</span>
            <h3 style={{ marginTop: 6 }}>{t(h)}</h3>
            <p className="muted" style={{ margin: 0 }}>{t(p)}</p>
            <div className="fee">{t(f)}</div>
            <A to={"book/" + m} className="btn btn-primary btn-sm">{t("book_this")}</A>
          </div>
        </div>
      ))}
    </div>
  );
}

function MapBlock() {
  const { t } = useL();
  const B = window.BUSINESS;
  return (
    <div className="map-grid">
      <div className="card" style={{ padding: "26px 30px" }}>
        <div className="info-row"><div><small>{t("address_label")}</small><b>{t("address")}</b></div></div>
        <div className="info-row"><div><small>{t("hours_label")}</small><b>{t("hours_short")}</b><div className="muted" style={{ fontSize: 16 }}>{t("sunday_closed")}</div></div></div>
        <div className="info-row"><div><small>{t("phone_label")}</small><b><a href={"tel:" + B.tel} style={{ color: "var(--navy)" }}>{B.phone}</a></b></div></div>
        <div className="note sun" style={{ margin: "8px 0 18px" }}>{t("call_before")}</div>
        <div className="btn-row">
          <a className="btn btn-primary" href={B.mapsUrl} target="_blank" rel="noopener">{t("directions")}</a>
          <a className="btn btn-ghost" href={"tel:" + B.tel}>{PHONE_ICON} {t("call")}</a>
        </div>
      </div>
      <div className="map-frame"><iframe title="VIP MAGICAL PHYSIO map" src={B.mapsEmbed} loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe></div>
    </div>
  );
}

function HomePage() {
  const { t } = useL();
  useSeo("Physiotherapist in Shirur — Dr. Vipul Ahire", t("hero_intro"));
  const [play, setPlay] = useState(null);
  const featured = ["jB5r0Cn6u7c", "D1VKyVsDl_Q", "xct3GbLimc0", "xCIPuu5_-No"].map(vById);
  return (
    <main>
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <span className="kicker">{t("hero_kicker")}</span>
            <h1>{t("tagline_a")}<span className="b">{t("tagline_b")}</span></h1>
            <p className="lead">{t("hero_intro")}</p>
            <div className="btn-row">
              <A to="book" className="btn btn-primary">{t("nav_book")}</A>
              <A to="book/home" className="btn btn-ghost">{t("hero_home")}</A>
              <A to="book/online" className="btn btn-ghost">{t("hero_online")}</A>
            </div>
            <div className="hero-meta">
              <span><i className={"dot" + (isOpenNow() ? "" : " off")}></i>{t("hours_short")}</span>
              <a href={"tel:" + window.BUSINESS.tel} style={{ color: "inherit", display: "flex", gap: 8, alignItems: "center", fontWeight: 600 }}>{PHONE_ICON}{window.BUSINESS.phone}</a>
            </div>
          </div>
          <div className="hero-photo">
            <div className="hero-sun"></div>
            <Slot id="hero-dr" ph="photo_dr" />
            <div className="hero-card"><b>{t("dr_name")}</b><span>{t("dr_title")}</span><span>{t("years")}</span></div>
          </div>
        </div>
      </section>

      <section style={{ paddingBottom: 20 }}><div className="wrap"><ReviewStrip /></div></section>

      <section className="sec">
        <div className="wrap">
          <div className="sec-head">
            <div><span className="kicker">{t("sec_services_k")}</span><h2>{t("sec_services_h")}</h2><p className="lead mb0">{t("sec_services_p")}</p></div>
            <A to="services" className="btn btn-ghost btn-sm">{t("all_services")} →</A>
          </div>
          <div className="grid g3">{SVC_ORDER.slice(0, 6).map((s, i) => <ServiceCard key={s} slug={s} n={i + 1} />)}</div>
        </div>
      </section>

      <section className="sec alt">
        <div className="wrap about-grid">
          <Slot id="about-dr" ph="photo_dr" />
          <div>
            <span className="kicker">{t("sec_about_k")}</span>
            <h2>{t("sec_about_h")}</h2>
            <p className="lead">{t("sec_about_p")}</p>
            <div className="facts">
              <div className="fact"><small>{t("ab_qual")}</small><b>{t("ab_qual_v")}</b></div>
              <div className="fact"><small>{t("ab_exp")}</small><b>{t("ab_exp_v")}</b></div>
            </div>
            <A to="about" className="btn btn-navy">{t("about_more")}</A>
          </div>
        </div>
      </section>

      <section className="sec">
        <div className="wrap">
          <div className="sec-head"><div><span className="kicker">{t("sec_why_k")}</span><h2>{t("sec_why_h")}</h2></div></div>
          <div className="grid g3" style={{ rowGap: 34 }}>
            {t.row("why").map(([h, p], i) => (
              <div className="why-item" key={i}><span className="why-ico">{i + 1}</span><div><h3>{h}</h3><p>{p}</p></div></div>
            ))}
          </div>
        </div>
      </section>

      <section className="sec sand">
        <div className="wrap">
          <div className="sec-head"><div><span className="kicker">{t("sec_how_k")}</span><h2>{t("sec_how_h")}</h2></div></div>
          <div className="steps">{t.row("how").map(([h, p], i) => <div className="step" key={i}><b>{i + 1}</b><h4>{h}</h4><p>{p}</p></div>)}</div>
        </div>
      </section>

      <section className="sec">
        <div className="wrap">
          <div className="sec-head"><div><span className="kicker">{t("sec_modes_k")}</span><h2>{t("sec_modes_h")}</h2></div></div>
          <Modes />
          <div style={{ marginTop: 26, display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap" }}>
            <b style={{ color: "var(--navy)" }}>{t("coverage")}:</b>
            <div className="chips">{window.UI.areas[t.i].map((a) => <span className="chip teal" key={a}>{a}</span>)}</div>
          </div>
          <div className="note warn" style={{ marginTop: 20 }}>{t("online_limit")}</div>
        </div>
      </section>

      <section className="sec alt">
        <div className="wrap">
          <div className="sec-head">
            <div><span className="kicker">{t("sec_edu_k")}</span><h2>{t("sec_edu_h")}</h2><p className="lead mb0">{t("sec_edu_p")}</p></div>
            <div className="btn-row"><a className="btn btn-sm" style={{ background: "#c4302b", color: "#fff" }} href={window.BUSINESS.youtubeSub} target="_blank" rel="noopener">▶ {t("subscribe")}</a><A to="videos" className="btn btn-ghost btn-sm">{t("all_videos")} →</A></div>
          </div>
          <div className="grid g4">{featured.map((v) => <VideoCard key={v.id} v={v} onPlay={setPlay} />)}</div>
        </div>
      </section>

      <section className="sec">
        <div className="wrap">
          <div className="sec-head">
            <div><span className="kicker">{t("sec_store_k")}</span><h2>{t("sec_store_h")}</h2><p className="lead mb0">{t("sec_store_p")}</p></div>
            <A to="store" className="btn btn-ghost btn-sm">{t("all_books")} →</A>
          </div>
          <BookGrid />
        </div>
      </section>

      <section className="sec sand">
        <div className="wrap">
          <div className="sec-head"><div><span className="kicker">{t("rvp_k")}</span><h2>{t("rvp_h")}</h2><p className="lead mb0">{t("rvp_p")}</p></div></div>
          <div className="btn-row">
            <a className="btn btn-sun" href={window.BUSINESS.reviewUrl} target="_blank" rel="noopener">★ {t("rv_button")}</a>
            <a className="btn btn-ghost" href={window.BUSINESS.mapsUrl} target="_blank" rel="noopener">{t("rv_read")}</a>
          </div>
        </div>
      </section>

      <section className="sec">
        <div className="wrap">
          <div className="sec-head"><div><span className="kicker">{t("sec_map_k")}</span><h2>{t("sec_map_h")}</h2></div></div>
          <MapBlock />
        </div>
      </section>
      <VideoModal v={play} onClose={() => setPlay(null)} />
    </main>
  );
}

function BookGrid() {
  const { t } = useL();
  return (
    <div className="grid g4">
      {window.EBOOKS.map((b) => (
        <A to={"store/" + b.id} className="book" key={b.id}>
          <BookCover b={b} small />
          <div className="book-info">
            <span className="lang-pill">{t("lang_" + b.lang)}</span>
            <b style={{ marginTop: 8 }}>{b.titleLatin || b.title}</b>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
              <span className="price">₹{b.price}</span>
              <span className="link-arrow">{t("buy_now")} →</span>
            </div>
          </div>
        </A>
      ))}
    </div>
  );
}

function AboutPage() {
  const { t } = useL();
  useSeo(t("dr_name") + " — " + t("dr_title"), t("sec_about_p"));
  return (
    <main>
      <section className="sec">
        <div className="wrap about-grid">
          <Slot id="about-page-dr" ph="photo_dr" />
          <div>
            <span className="kicker">{t("nav_about")}</span>
            <h1 style={{ fontSize: "clamp(36px,5vw,60px)" }}>{t("dr_name")}</h1>
            <p className="lead">{t("sec_about_p")}</p>
            <div className="facts">
              <div className="fact"><small>{t("ab_qual")}</small><b>{t("ab_qual_v")}</b></div>
              <div className="fact"><small>{t("ab_exp")}</small><b>{t("ab_exp_v")}</b></div>
              <div className="fact"><small>{t("ab_areas")}</small><b style={{ fontSize: 17 }}>{t("ab_areas_v")}</b></div>
              <div className="fact"><small>{t("ab_edu")}</small><b style={{ fontSize: 17 }}>{t("ab_edu_v")}</b></div>
            </div>
          </div>
        </div>
      </section>
      <section className="sec alt">
        <div className="wrap grid g2" style={{ gap: 48, alignItems: "start" }}>
          <div><h2>{t("ab_h")}</h2><p className="lead">{t("ab_p1")}</p><p className="lead">{t("ab_p2")}</p></div>
          <div className="card" style={{ background: "var(--cream)" }}>
            <h3>{t("ab_ethics_h")}</h3>
            <ul className="ticks">{window.UI.ab_ethics[t.i].map((x) => <li key={x}>{x}</li>)}</ul>
          </div>
        </div>
      </section>
      <section className="sec"><div className="wrap"><Modes compact /></div></section>
    </main>
  );
}

function ServicesPage() {
  const { t } = useL();
  useSeo(t("sec_services_k") + " — Shirur", t("sec_services_p"));
  return (
    <main className="sec">
      <div className="wrap">
        <span className="kicker">{t("sec_services_k")}</span>
        <h1 style={{ fontSize: "clamp(36px,5vw,60px)" }}>{t("sec_services_h")}</h1>
        <p className="lead" style={{ marginBottom: 36 }}>{t("sec_services_p")}</p>
        <div className="grid g3">{SVC_ORDER.map((s, i) => <ServiceCard key={s} slug={s} n={i + 1} />)}</div>
      </div>
    </main>
  );
}

function ServiceDetail({ slug }) {
  const { t } = useL();
  const s = window.SERVICES[slug];
  const meta = window.SERVICE_META.find((m) => m.slug === slug);
  const [play, setPlay] = useState(null);
  useSeo(t.pick(s.title) + " in Shirur", t.pick(s.short));
  useEffect(() => {
    const ld = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: s.faq[t.lang].map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) };
    let el = document.getElementById("ld-faq"); if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = "ld-faq"; document.head.appendChild(el); }
    el.textContent = JSON.stringify(ld);
    return () => el.remove();
  }, [slug, t.lang]);
  const idx = SVC_ORDER.indexOf(slug);
  const related = [SVC_ORDER[(idx + 1) % 12], SVC_ORDER[(idx + 2) % 12], SVC_ORDER[(idx + 9) % 12]];
  const bookTo = slug === "home-visit" ? "book/home" : slug === "online-consultation" ? "book/online" : "book/opd/" + slug;
  return (
    <main>
      <section className="sec" style={{ paddingBottom: 40 }}>
        <div className="wrap">
          <div className="crumbs"><A>{t("nav_home")}</A> / <A to="services">{t("nav_services")}</A> / {t.pick(s.title)}</div>
          <div className="svc-hero">
            <div>
              <span className="kicker">{t("sv_k")}</span>
              <h1 style={{ fontSize: "clamp(36px,5vw,62px)" }}>{t.pick(s.title)}</h1>
              <p className="lead">{t.pick(s.intro)}</p>
              <div className="btn-row" style={{ marginTop: 22 }}>
                <A to={bookTo} className="btn btn-primary">{t("nav_book")}</A>
                <a className="btn btn-wa" href={waLink(t.pick(s.title) + " — " + t("nav_book"))} target="_blank" rel="noopener">{WA_ICON}{t("whatsapp")}</a>
              </div>
            </div>
            <Slot id={"svc-" + slug} ph="photo_treat" />
          </div>
        </div>
      </section>
      <section className="sec alt" style={{ paddingTop: 56 }}>
        <div className="wrap grid g2" style={{ gap: 40 }}>
          <div><h2 style={{ fontSize: 32 }}>{t("sv_symptoms")}</h2><ul className="ticks">{t.pick(s.symptoms).map((x) => <li key={x}>{x}</li>)}</ul></div>
          <div><h2 style={{ fontSize: 32 }}>{t("sv_who")}</h2><p className="lead">{t.pick(s.who)}</p>
            <h2 style={{ fontSize: 32, marginTop: 28 }}>{t("sv_assess")}</h2><ul className="ticks">{window.UI.sv_assess_list[t.i].map((x) => <li key={x}>{x}</li>)}</ul></div>
        </div>
      </section>
      <section className="sec">
        <div className="wrap grid g2" style={{ gap: 40, alignItems: "start" }}>
          <div><h2 style={{ fontSize: 32 }}>{t("sv_approach")}</h2><ul className="ticks">{t.pick(s.approach).map((x) => <li key={x}>{x}</li>)}</ul></div>
          <div className="red-box"><h3>{t("sv_red")}</h3><ul className="ticks red">{t.pick(s.red).map((x) => <li key={x}>{x}</li>)}</ul><p style={{ margin: "14px 0 0", fontWeight: 600, color: "#7d2a19" }}>{t("sv_red_note")}</p></div>
        </div>
      </section>
      {meta.videos.length > 0 && (
        <section className="sec sand">
          <div className="wrap">
            <div className="sec-head"><div><span className="kicker">YouTube · Dr. Vipul Ahire</span><h2>{t("sv_videos")}</h2></div>
              <a className="btn btn-sm" style={{ background: "#c4302b", color: "#fff" }} href={window.BUSINESS.youtubeSub} target="_blank" rel="noopener">▶ {t("subscribe")}</a></div>
            <div className="grid g3">{meta.videos.map(vById).filter(Boolean).map((v) => <VideoCard key={v.id} v={v} onPlay={setPlay} />)}</div>
          </div>
        </section>
      )}
      <section className="sec">
        <div className="wrap" style={{ maxWidth: 860 }}>
          <h2>{t("sv_faq")}</h2>
          {t.pick(s.faq).map(([q, a]) => <details className="faq" key={q}><summary>{q}</summary><p>{a}</p></details>)}
          <p className="muted" style={{ fontSize: 15, marginTop: 20 }}>{t("sv_reviewed")}</p>
        </div>
      </section>
      <section style={{ paddingBottom: 72 }}>
        <div className="wrap">
          <div className="cta-band">
            <div><h2>{t("sv_cta_h")}</h2><p>{t("sv_cta_p")}</p></div>
            <div className="btn-row"><A to={bookTo} className="btn btn-light">{t("nav_book")}</A><a className="btn btn-sun" href={"tel:" + window.BUSINESS.tel}>{PHONE_ICON}{window.BUSINESS.phone}</a></div>
          </div>
          <h3 style={{ marginTop: 56 }}>{t("sv_related")}</h3>
          <div className="grid g3">{related.map((r) => <ServiceCard key={r} slug={r} n={SVC_ORDER.indexOf(r) + 1} />)}</div>
        </div>
      </section>
      <VideoModal v={play} onClose={() => setPlay(null)} />
    </main>
  );
}

function VideosPage() {
  const { t } = useL();
  useSeo(t("nav_videos") + " — Dard E Body Care", t("vid_p"));
  const [tab, setTab] = useState("all");
  const [play, setPlay] = useState(null);
  const topics = ["all", "back", "neck", "knee", "shoulder", "stroke", "ortho", "general"];
  const list = window.VIDEOS.filter((v) => tab === "all" || v.topic === tab).sort((a, b) => b.v - a.v);
  return (
    <main className="sec">
      <div className="wrap">
        <div className="sec-head">
          <div><span className="kicker">YouTube · @drvipulahireofficial</span><h1 style={{ fontSize: "clamp(36px,5vw,60px)" }}>{t("vid_h")}</h1><p className="lead mb0">{t("vid_p")}</p></div>
          <a className="btn" style={{ background: "#c4302b", color: "#fff" }} href={window.BUSINESS.youtubeSub} target="_blank" rel="noopener">▶ {t("subscribe")}</a>
        </div>
        <div className="tabs">{topics.map((x) => <button key={x} className={tab === x ? "on" : ""} onClick={() => setTab(x)}>{t("t_" + x)}</button>)}</div>
        <div className="grid g3">{list.map((v) => <VideoCard key={v.id} v={v} onPlay={setPlay} />)}</div>
        <div style={{ marginTop: 56 }}><Newsletter /></div>
      </div>
      <VideoModal v={play} onClose={() => setPlay(null)} />
    </main>
  );
}

function Newsletter() {
  const { t, lang } = useL();
  const [email, setEmail] = useState(""); const [ok, setOk] = useState(false); const [c, setC] = useState(false); const [err, setErr] = useState("");
  const submit = (e) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr(t("err_email"));
    if (!c) return setErr(t("err_consent"));
    window.VMPStore.add("subscribers", { email, lang, source: "website", consent: true }, "Newsletter signup");
    setOk(true); setErr("");
  };
  return (
    <div className="card" style={{ background: "var(--navy)", border: 0, color: "#dbe6f2", padding: "32px clamp(22px,4vw,40px)" }}>
      <div className="grid g2" style={{ alignItems: "center", gap: 28 }}>
        <div><h2 style={{ color: "#fff", fontSize: 32 }}>{t("guide_h")}</h2><p style={{ margin: 0 }}>{t("guide_p")}</p></div>
        {ok ? <div className="note" style={{ fontWeight: 600 }}>{t("guide_ok")}</div> : (
          <form onSubmit={submit} noValidate>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <input aria-label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@email.com" style={{ flex: 1, minWidth: 200, minHeight: 54, borderRadius: 999, border: 0, padding: "0 20px", font: "inherit" }} />
              <button className="btn btn-sun">{t("guide_btn")}</button>
            </div>
            <label className="check" style={{ marginTop: 12, color: "#dbe6f2" }}><input type="checkbox" checked={c} onChange={(e) => setC(e.target.checked)} />{t("guide_consent")}</label>
            {err && <div className="err" style={{ color: "#ffb9a8" }}>{err}</div>}
          </form>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { HomePage, AboutPage, ServicesPage, ServiceDetail, VideosPage, BookGrid, MapBlock, Modes, Newsletter, ServiceCard, SVC_ORDER });
