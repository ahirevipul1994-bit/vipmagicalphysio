/* UI strings — [English, मराठी, हिंदी]. Every visible word on the site comes from here or services-*.js */
window.LANGS = [
  { code: "en", label: "English", short: "EN" },
  { code: "mr", label: "मराठी", short: "मरा" },
  { code: "hi", label: "हिंदी", short: "हिं" }
];
window.UI = {
  // nav
  nav_home: ["Home", "मुख्यपृष्ठ", "होम"],
  nav_about: ["About", "आमच्याबद्दल", "हमारे बारे में"],
  nav_services: ["Services", "सेवा", "सेवाएँ"],
  nav_store: ["Ebooks", "ई-पुस्तके", "ई-बुक्स"],
  nav_videos: ["Videos", "व्हिडिओ", "वीडियो"],
  nav_reviews: ["Reviews", "रिव्ह्यू", "रिव्यू"],
  nav_faq: ["FAQ", "प्रश्नोत्तरे", "सवाल-जवाब"],
  nav_contact: ["Contact", "संपर्क", "संपर्क"],
  nav_book: ["Book Appointment", "अपॉइंटमेंट बुक करा", "अपॉइंटमेंट बुक करें"],
  menu: ["Menu", "मेनू", "मेनू"],
  close: ["Close", "बंद करा", "बंद करें"],
  call: ["Call", "कॉल करा", "कॉल करें"],
  whatsapp: ["WhatsApp", "व्हॉट्सॲप", "व्हाट्सऐप"],
  language: ["Language", "भाषा", "भाषा"],
  open_now: ["Open now", "आता सुरू आहे", "अभी खुला है"],
  closed_now: ["Closed now", "आता बंद आहे", "अभी बंद है"],
  hours_short: ["Mon–Sat · 9 AM – 5 PM", "सोम–शनि · सकाळी ९ – सायं ५", "सोम–शनि · सुबह 9 – शाम 5"],
  sunday_closed: ["Sunday closed", "रविवार बंद", "रविवार बंद"],

  // hero
  hero_kicker: ["Physiotherapy clinic · Pabal Phata, Shirur", "फिजिओथेरपी क्लिनिक · पाबळ फाटा, शिरूर", "फिजियोथेरेपी क्लिनिक · पाबल फाटा, शिरूर"],
  tagline_a: ["Move better.", "चांगली हालचाल.", "बेहतर चलें।"],
  tagline_b: ["Live better.", "चांगले जीवन.", "बेहतर जिएँ।"],
  hero_intro: [
    "Dr. Vipul Ahire (BPTh) assesses your pain properly, explains it in simple words, and builds an exercise plan that fits your daily life — at the clinic, at your home, or online.",
    "डॉ. विपुल अहिरे (BPTh) तुमच्या दुखण्याची नीट तपासणी करतात, सोप्या शब्दांत समजावून सांगतात आणि तुमच्या रोजच्या जीवनाला साजेसा व्यायाम आराखडा तयार करतात — क्लिनिकमध्ये, तुमच्या घरी किंवा ऑनलाइन.",
    "डॉ. विपुल अहिरे (BPTh) आपके दर्द की ठीक से जाँच करते हैं, आसान शब्दों में समझाते हैं और आपकी रोज़मर्रा की ज़िंदगी के अनुसार व्यायाम योजना बनाते हैं — क्लिनिक में, आपके घर पर या ऑनलाइन।"
  ],
  hero_home: ["Home Visit", "घरी भेट", "होम विज़िट"],
  hero_online: ["Online Consultation", "ऑनलाइन सल्ला", "ऑनलाइन परामर्श"],
  photo_dr: ["Drop Dr. Vipul's portrait here", "डॉ. विपुल यांचा फोटो येथे टाका", "डॉ. विपुल की फ़ोटो यहाँ डालें"],
  photo_clinic: ["Drop a clinic photo here", "क्लिनिकचा फोटो येथे टाका", "क्लिनिक की फ़ोटो यहाँ डालें"],
  photo_treat: ["Drop a treatment photo here", "उपचाराचा फोटो येथे टाका", "उपचार की फ़ोटो यहाँ डालें"],
  dr_name: ["Dr. Vipul Ahire", "डॉ. विपुल अहिरे", "डॉ. विपुल अहिरे"],
  dr_title: ["Physiotherapist · BPTh", "फिजिओथेरपिस्ट · BPTh", "फिजियोथेरेपिस्ट · BPTh"],
  years: ["~6 years clinical experience", "सुमारे ६ वर्षांचा क्लिनिकल अनुभव", "लगभग 6 वर्षों का क्लिनिकल अनुभव"],

  // review strip
  rv_strip_title: ["Treated at VIP MAGICAL PHYSIO?", "VIP MAGICAL PHYSIO मध्ये उपचार घेतले आहेत?", "VIP MAGICAL PHYSIO में इलाज करवाया है?"],
  rv_strip_body: [
    "Your honest Google review helps another family in Shirur find the right care. It takes one minute.",
    "तुमचा प्रामाणिक Google रिव्ह्यू शिरूरमधील दुसऱ्या कुटुंबाला योग्य उपचार शोधायला मदत करतो. फक्त एक मिनिट लागतो.",
    "आपका ईमानदार Google रिव्यू शिरूर के किसी और परिवार को सही इलाज ढूँढने में मदद करता है। बस एक मिनट लगता है।"
  ],
  rv_button: ["Write a Google Review", "Google रिव्ह्यू लिहा", "Google रिव्यू लिखें"],
  rv_read: ["Read our reviews on Google", "आमचे रिव्ह्यू Google वर वाचा", "हमारे रिव्यू Google पर पढ़ें"],

  // home sections
  sec_services_k: ["Physiotherapy services", "फिजिओथेरपी सेवा", "फिजियोथेरेपी सेवाएँ"],
  sec_services_h: ["What brings you here today?", "आज तुम्हाला कशाचा त्रास आहे?", "आज आपको किस बात की तकलीफ़ है?"],
  sec_services_p: [
    "Choose your problem. Each page explains it simply, shows a video from Dr. Vipul, and tells you when to see a doctor instead.",
    "तुमचा त्रास निवडा. प्रत्येक पानावर तो सोप्या भाषेत समजावला आहे, डॉ. विपुल यांचा व्हिडिओ आहे, आणि डॉक्टरांकडे कधी जावे हेही सांगितले आहे.",
    "अपनी समस्या चुनें। हर पेज पर उसे आसान भाषा में समझाया गया है, डॉ. विपुल का वीडियो है, और यह भी बताया गया है कि डॉक्टर के पास कब जाना चाहिए।"
  ],
  all_services: ["All 12 services", "सर्व १२ सेवा", "सभी 12 सेवाएँ"],
  learn_more: ["Read more", "अधिक वाचा", "और पढ़ें"],
  who_helps: ["Who it may help", "कोणाला उपयोगी", "किसके लिए उपयोगी"],

  sec_about_k: ["Who you'll be seeing", "तुम्हाला कोण तपासणार", "आपको कौन देखेगा"],
  sec_about_h: ["Care that starts with listening.", "ऐकून घेण्यापासून सुरू होणारे उपचार.", "सुनने से शुरू होने वाला इलाज।"],
  sec_about_p: [
    "Dr. Vipul Ahire is a physiotherapist (BPTh) practising in Shirur with about six years of clinical experience in back and neck pain, knee and shoulder problems, stroke recovery, post-operative care and older-adult mobility. He also teaches patients and families through his YouTube channel, Dard E Body Care.",
    "डॉ. विपुल अहिरे हे शिरूरमध्ये प्रॅक्टिस करणारे फिजिओथेरपिस्ट (BPTh) आहेत. कंबर व मानदुखी, गुडघा व खांद्याचे त्रास, स्ट्रोकनंतरचे पुनर्वसन, ऑपरेशननंतरची काळजी आणि वृद्धांची हालचाल यांचा त्यांना सुमारे सहा वर्षांचा क्लिनिकल अनुभव आहे. ते त्यांच्या 'दर्द ए बॉडी केअर' या YouTube चॅनलद्वारे रुग्ण व कुटुंबांना माहितीही देतात.",
    "डॉ. विपुल अहिरे शिरूर में प्रैक्टिस करने वाले फिजियोथेरेपिस्ट (BPTh) हैं। कमर और गर्दन दर्द, घुटने और कंधे की समस्याएँ, स्ट्रोक के बाद पुनर्वास, ऑपरेशन के बाद की देखभाल और बुज़ुर्गों की गतिशीलता में उन्हें लगभग छह वर्षों का क्लिनिकल अनुभव है। वे अपने 'दर्द ए बॉडी केयर' YouTube चैनल के ज़रिए मरीज़ों और परिवारों को जानकारी भी देते हैं।"
  ],
  about_more: ["About Dr. Vipul", "डॉ. विपुल यांच्याबद्दल", "डॉ. विपुल के बारे में"],

  sec_why_k: ["Why patients choose us", "रुग्ण आम्हाला का निवडतात", "मरीज़ हमें क्यों चुनते हैं"],
  sec_why_h: ["Honest, personal, practical.", "प्रामाणिक, वैयक्तिक, व्यावहारिक.", "ईमानदार, व्यक्तिगत, व्यावहारिक।"],
  why: [
    [["Individual assessment", "Every patient is examined first. The plan follows what we find."], ["वैयक्तिक तपासणी", "प्रत्येक रुग्णाची आधी तपासणी होते. आराखडा तपासणीनुसार ठरतो."], ["व्यक्तिगत जाँच", "हर मरीज़ की पहले जाँच होती है। योजना जाँच के अनुसार बनती है।"]],
    [["Your own exercise plan", "Exercises chosen for your body and taught until you can do them alone."], ["तुमचा स्वतःचा व्यायाम आराखडा", "तुमच्या शरीरासाठी निवडलेले व्यायाम, जे तुम्ही स्वतः करू शकेपर्यंत शिकवले जातात."], ["आपकी अपनी व्यायाम योजना", "आपके शरीर के लिए चुने गए व्यायाम, जो तब तक सिखाए जाते हैं जब तक आप खुद न कर सकें।"]],
    [["Explained in your language", "Marathi, Hindi or English — you understand why, not just what."], ["तुमच्या भाषेत समजावणे", "मराठी, हिंदी किंवा इंग्रजी — काय करायचे इतकेच नाही, तर का करायचे तेही समजते."], ["आपकी भाषा में समझाना", "मराठी, हिंदी या अंग्रेज़ी — सिर्फ़ क्या नहीं, बल्कि क्यों भी समझ आता है।"]],
    [["Care at home", "Home visits for elders, stroke and post-surgery patients."], ["घरी उपचार", "वृद्ध, स्ट्रोक आणि ऑपरेशननंतरच्या रुग्णांसाठी घरी भेट."], ["घर पर इलाज", "बुज़ुर्गों, स्ट्रोक और ऑपरेशन के बाद के मरीज़ों के लिए होम विज़िट।"]],
    [["Function is the goal", "Stairs, walking, work, sleep — progress measured by what you can do."], ["काम करता येणे हेच ध्येय", "जिना, चालणे, काम, झोप — प्रगती तुम्ही काय करू शकता यावरून मोजली जाते."], ["काम कर पाना ही मंज़िल", "सीढ़ियाँ, चलना, काम, नींद — प्रगति इस बात से मापी जाती है कि आप क्या कर पाते हैं।"]],
    [["Honest about limits", "If you need a doctor, scan or surgery, we tell you and refer."], ["मर्यादांबद्दल प्रामाणिक", "डॉक्टर, स्कॅन किंवा ऑपरेशनची गरज असल्यास आम्ही स्पष्ट सांगतो आणि पाठवतो."], ["सीमाओं के बारे में ईमानदार", "अगर डॉक्टर, स्कैन या ऑपरेशन की ज़रूरत है, तो हम साफ़ बताते हैं और रेफ़र करते हैं।"]]
  ],

  sec_how_k: ["How it works", "प्रक्रिया कशी असते", "प्रक्रिया कैसे होती है"],
  sec_how_h: ["Six simple steps.", "सहा सोप्या पायऱ्या.", "छह आसान कदम।"],
  how: [
    [["Contact us", "Call, WhatsApp or fill the form."], ["संपर्क करा", "कॉल, व्हॉट्सॲप किंवा फॉर्म भरा."], ["संपर्क करें", "कॉल, व्हाट्सऐप या फ़ॉर्म भरें।"]],
    [["Book a time", "Pick clinic, home or online and a free slot."], ["वेळ बुक करा", "क्लिनिक, घर किंवा ऑनलाइन आणि रिकामी वेळ निवडा."], ["समय बुक करें", "क्लिनिक, घर या ऑनलाइन और खाली समय चुनें।"]],
    [["Assessment", "History, movement, strength and daily needs."], ["तपासणी", "इतिहास, हालचाल, ताकद आणि रोजच्या गरजा."], ["जाँच", "इतिहास, हरकत, ताकत और रोज़ की ज़रूरतें।"]],
    [["Your plan", "Clear goals and exercises, explained."], ["तुमचा आराखडा", "स्पष्ट ध्येये आणि व्यायाम, समजावून."], ["आपकी योजना", "स्पष्ट लक्ष्य और व्यायाम, समझाकर।"]],
    [["Progress check", "We review real tasks and adjust."], ["प्रगती तपासणी", "खऱ्या कामांवरून आढावा घेऊन बदल करतो."], ["प्रगति जाँच", "असली कामों से समीक्षा करके बदलाव करते हैं।"]],
    [["Follow-up", "A home programme to stay well."], ["पाठपुरावा", "बरे राहण्यासाठी घरचा व्यायाम कार्यक्रम."], ["फ़ॉलो-अप", "ठीक रहने के लिए घर का व्यायाम कार्यक्रम।"]]
  ],

  sec_modes_k: ["Three ways to be seen", "उपचाराचे तीन मार्ग", "इलाज के तीन तरीके"],
  sec_modes_h: ["Clinic, home or online.", "क्लिनिक, घरी किंवा ऑनलाइन.", "क्लिनिक, घर या ऑनलाइन।"],
  mode_opd: ["Clinic OPD", "क्लिनिक OPD", "क्लिनिक OPD"],
  mode_home: ["Home Visit", "घरी भेट", "होम विज़िट"],
  mode_online: ["Online Consultation", "ऑनलाइन सल्ला", "ऑनलाइन परामर्श"],
  mode_opd_p: [
    "In-person assessment and treatment at VIP MAGICAL PHYSIO CLINIC, Pabal Phata, Shirur.",
    "VIP MAGICAL PHYSIO क्लिनिक, पाबळ फाटा, शिरूर येथे प्रत्यक्ष तपासणी आणि उपचार.",
    "VIP MAGICAL PHYSIO क्लिनिक, पाबल फाटा, शिरूर में प्रत्यक्ष जाँच और इलाज।"
  ],
  mode_home_p: [
    "For patients who cannot travel easily. Available in Shirur city, Ramling, Baburaonagar, Sharadwadi and Annapur.",
    "प्रवास करणे कठीण असलेल्या रुग्णांसाठी. शिरूर शहर, रामलिंग, बाबुरावनगर, शरदवाडी आणि अन्नापूर येथे उपलब्ध.",
    "जिन मरीज़ों के लिए आना-जाना मुश्किल है, उनके लिए। शिरूर शहर, रामलिंग, बाबुरावनगर, शरदवाड़ी और अन्नापूर में उपलब्ध।"
  ],
  mode_online_p: [
    "Video consultation across India for advice, exercise guidance and follow-up — where remote assessment is suitable.",
    "सल्ला, व्यायाम मार्गदर्शन आणि पाठपुराव्यासाठी संपूर्ण भारतात व्हिडिओ सल्ला — जिथे ऑनलाइन तपासणी योग्य असेल तिथे.",
    "सलाह, व्यायाम मार्गदर्शन और फ़ॉलो-अप के लिए पूरे भारत में वीडियो परामर्श — जहाँ ऑनलाइन जाँच उपयुक्त हो।"
  ],
  fee_opd: ["Fee depends on your condition — explained before treatment.", "शुल्क तुमच्या त्रासानुसार — उपचारापूर्वी सांगितले जाते.", "फ़ीस आपकी समस्या के अनुसार — इलाज से पहले बताई जाती है।"],
  fee_home: ["Fee depends on distance — confirmed on the phone.", "शुल्क अंतरानुसार — फोनवर निश्चित केले जाते.", "फ़ीस दूरी के अनुसार — फ़ोन पर तय की जाती है।"],
  fee_online: ["Fee depends on session duration — shared before booking.", "शुल्क सत्राच्या कालावधीनुसार — बुकिंगपूर्वी सांगितले जाते.", "फ़ीस सत्र की अवधि के अनुसार — बुकिंग से पहले बताई जाती है।"],
  book_this: ["Book this", "हे बुक करा", "यह बुक करें"],
  coverage: ["Home-visit area", "घरी भेटीचा परिसर", "होम विज़िट क्षेत्र"],
  areas: [["Shirur city", "Ramling", "Baburaonagar", "Sharadwadi", "Annapur"], ["शिरूर शहर", "रामलिंग", "बाबुरावनगर", "शरदवाडी", "अन्नापूर"], ["शिरूर शहर", "रामलिंग", "बाबुरावनगर", "शरदवाड़ी", "अन्नापूर"]],

  sec_edu_k: ["Free patient education", "मोफत रुग्ण माहिती", "मुफ़्त मरीज़ शिक्षा"],
  sec_edu_h: ["Watch Dr. Vipul explain it.", "डॉ. विपुल यांच्याकडून समजून घ्या.", "डॉ. विपुल से समझिए।"],
  sec_edu_p: [
    "Short videos on back pain, neck pain, knee pain, frozen shoulder and stroke recovery — from the Dard E Body Care YouTube channel.",
    "कंबरदुखी, मानदुखी, गुडघेदुखी, फ्रोझन शोल्डर आणि स्ट्रोकनंतरचे पुनर्वसन यावर छोटे व्हिडिओ — 'दर्द ए बॉडी केअर' YouTube चॅनलवरून.",
    "कमर दर्द, गर्दन दर्द, घुटने का दर्द, फ्रोज़न शोल्डर और स्ट्रोक के बाद पुनर्वास पर छोटे वीडियो — 'दर्द ए बॉडी केयर' YouTube चैनल से।"
  ],
  subscribe: ["Subscribe on YouTube", "YouTube वर सबस्क्राइब करा", "YouTube पर सब्सक्राइब करें"],
  all_videos: ["All videos", "सर्व व्हिडिओ", "सभी वीडियो"],
  views: ["views", "व्ह्यूज", "व्यूज़"],
  watch: ["Watch", "पहा", "देखें"],
  most_watched: ["Most watched", "सर्वाधिक पाहिलेले", "सबसे ज़्यादा देखे गए"],

  sec_store_k: ["Dard E Body Care ebooks", "दर्द ए बॉडी केअर ई-पुस्तके", "दर्द ए बॉडी केयर ई-बुक्स"],
  sec_store_h: ["Health guides you can keep.", "जपून ठेवता येतील असे आरोग्य मार्गदर्शक.", "हमेशा साथ रखने लायक स्वास्थ्य गाइड।"],
  sec_store_p: [
    "Plain-language ebooks by Dr. Vipul Ahire. Pay securely with UPI, card or net-banking and download instantly.",
    "डॉ. विपुल अहिरे यांची सोप्या भाषेतील ई-पुस्तके. UPI, कार्ड किंवा नेट-बँकिंगने सुरक्षित पेमेंट करा आणि लगेच डाउनलोड करा.",
    "डॉ. विपुल अहिरे की आसान भाषा में ई-बुक्स। UPI, कार्ड या नेट-बैंकिंग से सुरक्षित भुगतान करें और तुरंत डाउनलोड करें।"
  ],
  buy_now: ["Buy now", "आत्ता खरेदी करा", "अभी खरीदें"],
  view_book: ["View details", "तपशील पहा", "विवरण देखें"],
  lang_en: ["English", "इंग्रजी", "अंग्रेज़ी"],
  lang_hi: ["Hindi", "हिंदी", "हिंदी"],
  lang_mr: ["Marathi", "मराठी", "मराठी"],
  instant: ["Instant PDF download", "लगेच PDF डाउनलोड", "तुरंत PDF डाउनलोड"],
  by_author: ["by Dr. Vipul Ahire (Physio)", "लेखक: डॉ. विपुल अहिरे (फिजिओ)", "लेखक: डॉ. विपुल अहिरे (फिजियो)"],
  all_books: ["See all ebooks", "सर्व ई-पुस्तके पहा", "सभी ई-बुक्स देखें"],

  sec_map_k: ["Visit the clinic", "क्लिनिकला भेट द्या", "क्लिनिक आएँ"],
  sec_map_h: ["Find us at Pabal Phata.", "पाबळ फाटा येथे भेटा.", "पाबल फाटा पर मिलें।"],
  address: ["VIP MAGICAL PHYSIO CLINIC, Pabal Phata, Shirur, Pune District, Maharashtra", "VIP MAGICAL PHYSIO क्लिनिक, पाबळ फाटा, शिरूर, जि. पुणे, महाराष्ट्र", "VIP MAGICAL PHYSIO क्लिनिक, पाबल फाटा, शिरूर, ज़िला पुणे, महाराष्ट्र"],
  directions: ["Get directions", "दिशा मिळवा", "रास्ता देखें"],
  call_before: ["Please call before visiting — appointments are confirmed by phone.", "भेटीपूर्वी कृपया कॉल करा — अपॉइंटमेंट फोनवर निश्चित केली जाते.", "आने से पहले कृपया कॉल करें — अपॉइंटमेंट फ़ोन पर पक्की की जाती है।"],
  hours_label: ["Working hours", "कामाची वेळ", "काम का समय"],
  phone_label: ["Phone", "फोन", "फ़ोन"],
  address_label: ["Address", "पत्ता", "पता"],

  // footer
  ft_about: [
    "Physiotherapy, rehabilitation and patient education in Shirur. Educational brand: Dard E Body Care.",
    "शिरूरमध्ये फिजिओथेरपी, पुनर्वसन आणि रुग्ण-शिक्षण. शैक्षणिक ब्रँड: दर्द ए बॉडी केअर.",
    "शिरूर में फिजियोथेरेपी, पुनर्वास और मरीज़ शिक्षा। शैक्षणिक ब्रांड: दर्द ए बॉडी केयर।"
  ],
  ft_pages: ["Pages", "पाने", "पेज"],
  ft_legal: ["Legal", "कायदेशीर", "कानूनी"],
  ft_follow: ["Follow", "फॉलो करा", "फ़ॉलो करें"],
  privacy: ["Privacy Policy", "गोपनीयता धोरण", "गोपनीयता नीति"],
  terms: ["Terms & Conditions", "नियम व अटी", "नियम और शर्तें"],
  refund: ["Refund & Cancellation", "परतावा व रद्द करणे", "रिफ़ंड और रद्दीकरण"],
  disclaimer: ["Medical Disclaimer", "वैद्यकीय अस्वीकरण", "चिकित्सा अस्वीकरण"],
  emergency: [
    "Emergency? Chest pain, sudden weakness on one side, slurred speech, or loss of bladder/bowel control — call 108 or go to the nearest hospital now. Do not wait for a physiotherapy appointment.",
    "आपत्कालीन स्थिती? छातीत दुखणे, अचानक एका बाजूला कमजोरी, बोलण्यात अडखळणे किंवा लघवी/शौचावरील नियंत्रण जाणे — आत्ताच १०८ वर कॉल करा किंवा जवळच्या रुग्णालयात जा. फिजिओथेरपी अपॉइंटमेंटची वाट पाहू नका.",
    "आपातकाल? सीने में दर्द, अचानक एक तरफ़ कमज़ोरी, बोलने में लड़खड़ाहट, या पेशाब/मल पर नियंत्रण खोना — अभी 108 पर कॉल करें या नज़दीकी अस्पताल जाएँ। फिजियोथेरेपी अपॉइंटमेंट का इंतज़ार न करें।"
  ],
  rights: ["All rights reserved.", "सर्व हक्क राखीव.", "सर्वाधिकार सुरक्षित।"],

  // booking
  bk_k: ["Book an appointment", "अपॉइंटमेंट बुक करा", "अपॉइंटमेंट बुक करें"],
  bk_h: ["Request your time.", "तुमची वेळ मागवा.", "अपना समय माँगें।"],
  bk_p: [
    "Choose how you want to be seen, pick a free time, and send your request. The clinic will call or WhatsApp you to confirm. Your booking is confirmed only after that call.",
    "उपचार कसा हवा ते निवडा, रिकामी वेळ निवडा आणि विनंती पाठवा. क्लिनिक तुम्हाला कॉल किंवा व्हॉट्सॲप करून निश्चित करेल. त्या कॉलनंतरच बुकिंग निश्चित होते.",
    "इलाज कैसे चाहिए वह चुनें, खाली समय चुनें और अनुरोध भेजें। क्लिनिक आपको कॉल या व्हाट्सऐप करके पक्का करेगा। उस कॉल के बाद ही बुकिंग पक्की होती है।"
  ],
  step: ["Step", "पायरी", "चरण"],
  bk_s1: ["How would you like to be seen?", "उपचार कसा हवा आहे?", "इलाज कैसे चाहिए?"],
  bk_s2: ["Choose a date and time", "तारीख आणि वेळ निवडा", "तारीख और समय चुनें"],
  bk_s3: ["Your details", "तुमची माहिती", "आपकी जानकारी"],
  f_name: ["Patient name", "रुग्णाचे नाव", "मरीज़ का नाम"],
  f_mobile: ["Mobile number", "मोबाइल नंबर", "मोबाइल नंबर"],
  f_email: ["Email (optional)", "ईमेल (ऐच्छिक)", "ईमेल (वैकल्पिक)"],
  f_email_req: ["Email (for your download link)", "ईमेल (डाउनलोड लिंकसाठी)", "ईमेल (डाउनलोड लिंक के लिए)"],
  f_lang: ["Preferred language", "पसंतीची भाषा", "पसंदीदा भाषा"],
  f_service: ["Problem / service", "त्रास / सेवा", "समस्या / सेवा"],
  f_service_ph: ["Select your problem", "तुमचा त्रास निवडा", "अपनी समस्या चुनें"],
  f_other: ["Other / not sure", "इतर / खात्री नाही", "अन्य / पक्का नहीं"],
  f_location: ["Home address for visit", "भेटीसाठी घरचा पत्ता", "विज़िट के लिए घर का पता"],
  f_area: ["Area", "परिसर", "क्षेत्र"],
  f_msg: ["Brief message (no reports or detailed history)", "थोडक्यात संदेश (रिपोर्ट्स किंवा सविस्तर इतिहास नको)", "संक्षिप्त संदेश (रिपोर्ट या विस्तृत इतिहास नहीं)"],
  f_consent: [
    "I agree that VIP MAGICAL PHYSIO may store these details and contact me by phone, SMS or WhatsApp about this appointment. (Required)",
    "या अपॉइंटमेंटसंदर्भात VIP MAGICAL PHYSIO ने ही माहिती जतन करून माझ्याशी फोन, SMS किंवा व्हॉट्सॲपवर संपर्क साधण्यास माझी संमती आहे. (आवश्यक)",
    "मैं सहमत हूँ कि इस अपॉइंटमेंट के संबंध में VIP MAGICAL PHYSIO यह जानकारी सुरक्षित रखे और मुझसे फ़ोन, SMS या व्हाट्सऐप पर संपर्क करे। (आवश्यक)"
  ],
  f_marketing: [
    "Also send me occasional free health tips by email/WhatsApp. (Optional — you can stop anytime)",
    "मला अधूनमधून मोफत आरोग्य टिप्स ईमेल/व्हॉट्सॲपवर पाठवा. (ऐच्छिक — कधीही बंद करता येईल)",
    "मुझे कभी-कभी मुफ़्त स्वास्थ्य टिप्स ईमेल/व्हाट्सऐप पर भेजें। (वैकल्पिक — कभी भी बंद कर सकते हैं)"
  ],
  closed_day: ["The clinic is closed on Sundays. Please choose another day.", "रविवारी क्लिनिक बंद असते. कृपया दुसरा दिवस निवडा.", "रविवार को क्लिनिक बंद रहता है। कृपया दूसरा दिन चुनें।"],
  no_slots: ["No free times left on this day. Please try another date.", "या दिवशी रिकामी वेळ नाही. कृपया दुसरी तारीख पहा.", "इस दिन कोई खाली समय नहीं है। कृपया दूसरी तारीख देखें।"],
  booked: ["Booked", "बुक", "बुक"],
  choose_time: ["Available times", "उपलब्ध वेळा", "उपलब्ध समय"],
  bk_submit: ["Send appointment request", "अपॉइंटमेंट विनंती पाठवा", "अपॉइंटमेंट अनुरोध भेजें"],
  bk_wa: ["Or book on WhatsApp", "किंवा व्हॉट्सॲपवर बुक करा", "या व्हाट्सऐप पर बुक करें"],
  err_name: ["Please enter the patient's name.", "कृपया रुग्णाचे नाव लिहा.", "कृपया मरीज़ का नाम लिखें।"],
  err_mobile: ["Please enter a valid 10-digit mobile number.", "कृपया योग्य १० अंकी मोबाइल नंबर लिहा.", "कृपया सही 10 अंकों का मोबाइल नंबर लिखें।"],
  err_email: ["Please enter a valid email address.", "कृपया योग्य ईमेल पत्ता लिहा.", "कृपया सही ईमेल पता लिखें।"],
  err_slot: ["Please choose a date and time.", "कृपया तारीख आणि वेळ निवडा.", "कृपया तारीख और समय चुनें।"],
  err_consent: ["Please tick the consent box to continue.", "पुढे जाण्यासाठी कृपया संमतीच्या चौकटीत खूण करा.", "आगे बढ़ने के लिए कृपया सहमति वाले बॉक्स पर टिक करें।"],
  err_loc: ["Please enter the home address and area.", "कृपया घरचा पत्ता आणि परिसर लिहा.", "कृपया घर का पता और क्षेत्र लिखें।"],
  err_taken: ["Sorry, that time was just taken. Please choose another.", "क्षमस्व, ती वेळ आत्ताच बुक झाली. कृपया दुसरी निवडा.", "क्षमा करें, वह समय अभी-अभी बुक हो गया। कृपया दूसरा चुनें।"],
  ok_h: ["Request received — not yet confirmed", "विनंती मिळाली — अजून निश्चित नाही", "अनुरोध मिल गया — अभी पक्का नहीं"],
  ok_p: [
    "Thank you. Your time is held for you. The clinic will call or WhatsApp you on {m} to confirm. Please keep your phone nearby.",
    "धन्यवाद. तुमची वेळ राखून ठेवली आहे. निश्चित करण्यासाठी क्लिनिक तुम्हाला {m} वर कॉल किंवा व्हॉट्सॲप करेल. कृपया फोन जवळ ठेवा.",
    "धन्यवाद। आपका समय आपके लिए रोका गया है। पक्का करने के लिए क्लिनिक आपको {m} पर कॉल या व्हाट्सऐप करेगा। कृपया फ़ोन पास रखें।"
  ],
  ref_no: ["Reference number", "संदर्भ क्रमांक", "संदर्भ संख्या"],
  status: ["Status", "स्थिती", "स्थिति"],
  st_requested: ["Requested", "विनंती केली", "अनुरोधित"],
  st_confirmed: ["Confirmed", "निश्चित", "पक्का"],
  st_completed: ["Completed", "पूर्ण", "पूरा"],
  st_cancelled: ["Cancelled", "रद्द", "रद्द"],
  st_declined: ["Declined", "नाकारले", "अस्वीकृत"],
  ok_change: ["Need to change or cancel? Message us on WhatsApp with your reference number.", "बदल किंवा रद्द करायचे आहे? संदर्भ क्रमांकासह व्हॉट्सॲपवर संदेश पाठवा.", "बदलना या रद्द करना है? संदर्भ संख्या के साथ व्हाट्सऐप पर संदेश भेजें।"],
  ok_reschedule: ["Reschedule / cancel on WhatsApp", "व्हॉट्सॲपवर वेळ बदला / रद्द करा", "व्हाट्सऐप पर समय बदलें / रद्द करें"],
  book_another: ["Book another", "आणखी एक बुक करा", "एक और बुक करें"],
  online_limit: [
    "Online consultation cannot replace a hands-on examination. If your problem needs a physical check, we will tell you and suggest a clinic or home visit.",
    "ऑनलाइन सल्ला प्रत्यक्ष तपासणीची जागा घेऊ शकत नाही. तुमच्या त्रासाला प्रत्यक्ष तपासणीची गरज असल्यास आम्ही तसे सांगू आणि क्लिनिक किंवा घरी भेट सुचवू.",
    "ऑनलाइन परामर्श प्रत्यक्ष जाँच की जगह नहीं ले सकता। अगर आपकी समस्या में शारीरिक जाँच ज़रूरी है, तो हम बताएँगे और क्लिनिक या होम विज़िट का सुझाव देंगे।"
  ],
  home_limit: [
    "Home visits are available in Shirur city, Ramling, Baburaonagar, Sharadwadi and Annapur. Other areas: please call to check.",
    "घरी भेट शिरूर शहर, रामलिंग, बाबुरावनगर, शरदवाडी आणि अन्नापूर येथे उपलब्ध आहे. इतर भागांसाठी कृपया कॉल करून विचारा.",
    "होम विज़िट शिरूर शहर, रामलिंग, बाबुरावनगर, शरदवाड़ी और अन्नापूर में उपलब्ध है। अन्य क्षेत्रों के लिए कृपया कॉल करके पूछें।"
  ],
  min30: ["30 min", "३० मिनिटे", "30 मिनट"],
  min60: ["~60 min incl. travel", "प्रवासासह ~६० मिनिटे", "यात्रा सहित ~60 मिनट"],
  online_how: [
    ["Request a time below", "The clinic confirms and shares the fee", "Pay by UPI and get a video link", "Join from your phone at the time"],
    ["खाली वेळ मागवा", "क्लिनिक निश्चित करून शुल्क सांगते", "UPI ने पेमेंट करा व व्हिडिओ लिंक मिळवा", "ठरलेल्या वेळी फोनवरून सामील व्हा"],
    ["नीचे समय माँगें", "क्लिनिक पक्का करके फ़ीस बताता है", "UPI से भुगतान करें और वीडियो लिंक पाएँ", "तय समय पर फ़ोन से जुड़ें"]
  ],

  // store / checkout
  store_h: ["Ebooks by Dr. Vipul Ahire", "डॉ. विपुल अहिरे यांची ई-पुस्तके", "डॉ. विपुल अहिरे की ई-बुक्स"],
  bk_language: ["Language", "भाषा", "भाषा"],
  bk_format: ["Format", "स्वरूप", "फ़ॉर्मेट"],
  bk_pdf: ["PDF ebook — read on phone, tablet or computer", "PDF ई-पुस्तक — फोन, टॅबलेट किंवा संगणकावर वाचा", "PDF ई-बुक — फ़ोन, टैबलेट या कंप्यूटर पर पढ़ें"],
  bk_for: ["Who it is for", "कोणासाठी", "किसके लिए"],
  bk_inside: ["What's inside", "पुस्तकात काय आहे", "इसमें क्या है"],
  bk_inside_note: ["Chapter list to be confirmed by the author before launch.", "प्रकरणांची यादी प्रकाशनापूर्वी लेखकाकडून निश्चित केली जाईल.", "अध्यायों की सूची प्रकाशन से पहले लेखक द्वारा तय की जाएगी।"],
  secure_pay: ["Secure payment by Razorpay · UPI · Cards · Net-banking", "Razorpay द्वारे सुरक्षित पेमेंट · UPI · कार्ड · नेट-बँकिंग", "Razorpay द्वारा सुरक्षित भुगतान · UPI · कार्ड · नेट-बैंकिंग"],
  incl_tax: ["Inclusive of applicable taxes", "लागू करांसह", "लागू करों सहित"],
  ck_h: ["Checkout", "चेकआउट", "चेकआउट"],
  ck_summary: ["Order summary", "ऑर्डरचा सारांश", "ऑर्डर सारांश"],
  ck_total: ["Total", "एकूण", "कुल"],
  ck_pay: ["Pay ₹{p} securely", "₹{p} सुरक्षितपणे भरा", "₹{p} सुरक्षित भुगतान करें"],
  ck_note: [
    "Your download link is released only after our server confirms the payment with Razorpay.",
    "आमच्या सर्व्हरने Razorpay कडून पेमेंटची खात्री केल्यानंतरच डाउनलोड लिंक दिली जाते.",
    "हमारे सर्वर द्वारा Razorpay से भुगतान की पुष्टि होने के बाद ही डाउनलोड लिंक दिया जाता है।"
  ],
  ck_verifying: ["Verifying payment with Razorpay…", "Razorpay कडून पेमेंट तपासत आहोत…", "Razorpay से भुगतान की जाँच हो रही है…"],
  ck_success: ["Payment verified. Thank you!", "पेमेंट निश्चित झाले. धन्यवाद!", "भुगतान की पुष्टि हुई। धन्यवाद!"],
  ck_success_p: ["A copy of your download link has been sent to {e}. The link works 5 times within 7 days.", "तुमच्या डाउनलोड लिंकची प्रत {e} वर पाठवली आहे. ही लिंक ७ दिवसांत ५ वेळा वापरता येते.", "आपके डाउनलोड लिंक की प्रति {e} पर भेजी गई है। यह लिंक 7 दिनों में 5 बार काम करता है।"],
  ck_download: ["Download your ebook", "तुमचे ई-पुस्तक डाउनलोड करा", "अपनी ई-बुक डाउनलोड करें"],
  ck_failed: ["Payment was not completed", "पेमेंट पूर्ण झाले नाही", "भुगतान पूरा नहीं हुआ"],
  ck_failed_p: ["No money has been taken. If money was deducted, it is auto-refunded by your bank in 5–7 working days. You can try again.", "कोणतेही पैसे घेतले गेले नाहीत. पैसे कापले गेले असल्यास बँकेकडून ५–७ कामकाजाच्या दिवसांत आपोआप परत होतात. पुन्हा प्रयत्न करू शकता.", "कोई पैसा नहीं लिया गया है। अगर पैसा कटा है, तो बैंक 5–7 कार्य दिवसों में अपने आप लौटा देता है। आप दोबारा कोशिश कर सकते हैं।"],
  try_again: ["Try again", "पुन्हा प्रयत्न करा", "फिर से कोशिश करें"],
  order_no: ["Order number", "ऑर्डर क्रमांक", "ऑर्डर संख्या"],
  rz_title: ["Razorpay · Test mode", "Razorpay · टेस्ट मोड", "Razorpay · टेस्ट मोड"],
  rz_pay_ok: ["Simulate successful payment", "यशस्वी पेमेंटचे अनुकरण", "सफल भुगतान का अनुकरण"],
  rz_pay_fail: ["Simulate failed payment", "अयशस्वी पेमेंटचे अनुकरण", "असफल भुगतान का अनुकरण"],
  rz_demo: ["Prototype: connects to live Razorpay once your keys are added.", "प्रोटोटाइप: तुमच्या की जोडल्यावर लाइव्ह Razorpay शी जोडले जाईल.", "प्रोटोटाइप: आपकी की जोड़ने पर लाइव Razorpay से जुड़ जाएगा।"],
  support: ["Problem with your order? WhatsApp 86248 60808 with your order number.", "ऑर्डरमध्ये अडचण? ऑर्डर क्रमांकासह 86248 60808 वर व्हॉट्सॲप करा.", "ऑर्डर में समस्या? ऑर्डर संख्या के साथ 86248 60808 पर व्हाट्सऐप करें।"],
  back: ["Back", "मागे", "वापस"],

  // reviews page
  rvp_k: ["Google reviews", "Google रिव्ह्यू", "Google रिव्यू"],
  rvp_h: ["Your experience helps others choose well.", "तुमचा अनुभव इतरांना योग्य निवड करायला मदत करतो.", "आपका अनुभव दूसरों को सही चुनाव करने में मदद करता है।"],
  rvp_p: [
    "We never write reviews ourselves or offer gifts for them. Whatever your experience — good or needing improvement — please share it honestly on Google.",
    "आम्ही स्वतः कधीही रिव्ह्यू लिहीत नाही किंवा त्यासाठी भेटवस्तू देत नाही. तुमचा अनुभव कसाही असो — चांगला किंवा सुधारणेची गरज असलेला — कृपया तो Google वर प्रामाणिकपणे लिहा.",
    "हम खुद कभी रिव्यू नहीं लिखते और न ही उसके लिए कोई उपहार देते हैं। आपका अनुभव जैसा भी हो — अच्छा या सुधार की ज़रूरत वाला — कृपया उसे Google पर ईमानदारी से लिखें।"
  ],
  rvp_steps_h: ["How to write a review — 3 steps", "रिव्ह्यू कसा लिहावा — ३ पायऱ्या", "रिव्यू कैसे लिखें — 3 कदम"],
  rvp_steps: [
    ["Tap the button or scan the QR code", "Choose stars and write a few words about your visit", "Tap Post. That's it — thank you!"],
    ["बटण दाबा किंवा QR कोड स्कॅन करा", "स्टार निवडा आणि भेटीबद्दल काही शब्द लिहा", "पोस्ट दाबा. झाले — धन्यवाद!"],
    ["बटन दबाएँ या QR कोड स्कैन करें", "स्टार चुनें और अपनी विज़िट के बारे में कुछ शब्द लिखें", "पोस्ट दबाएँ। हो गया — धन्यवाद!"]
  ],
  rvp_ideas_h: ["Not sure what to write? You could mention:", "काय लिहावे सुचत नाही? तुम्ही हे लिहू शकता:", "क्या लिखें समझ नहीं आ रहा? आप ये लिख सकते हैं:"],
  rvp_ideas: [
    ["What problem you came with", "Clinic, home visit or online", "How things were explained", "What you can do now"],
    ["कोणत्या त्रासासाठी आलात", "क्लिनिक, घरी भेट की ऑनलाइन", "माहिती कशी समजावली गेली", "आता तुम्ही काय करू शकता"],
    ["आप किस समस्या के साथ आए थे", "क्लिनिक, होम विज़िट या ऑनलाइन", "बातें कैसे समझाई गईं", "अब आप क्या कर पाते हैं"]
  ],
  rvp_qr: ["Scan to review", "रिव्ह्यूसाठी स्कॅन करा", "रिव्यू के लिए स्कैन करें"],
  rvp_print: ["Print clinic QR poster", "क्लिनिक QR पोस्टर प्रिंट करा", "क्लिनिक QR पोस्टर प्रिंट करें"],
  rvp_share: ["Share this review link", "ही रिव्ह्यू लिंक शेअर करा", "यह रिव्यू लिंक शेयर करें"],
  rvp_privacy: ["Please don't include personal medical details in public reviews.", "कृपया सार्वजनिक रिव्ह्यूमध्ये वैयक्तिक वैद्यकीय तपशील लिहू नका.", "कृपया सार्वजनिक रिव्यू में निजी चिकित्सा विवरण न लिखें।"],
  rvp_feedback_h: ["Something we should improve?", "आम्ही काही सुधारावे का?", "क्या हमें कुछ सुधारना चाहिए?"],
  rvp_feedback_p: ["You can also tell Dr. Vipul directly on WhatsApp. This does not replace your Google review.", "तुम्ही डॉ. विपुल यांना थेट व्हॉट्सॲपवरही सांगू शकता. हे Google रिव्ह्यूची जागा घेत नाही.", "आप डॉ. विपुल को सीधे व्हाट्सऐप पर भी बता सकते हैं। यह Google रिव्यू की जगह नहीं लेता।"],
  copied: ["Link copied", "लिंक कॉपी झाली", "लिंक कॉपी हो गया"],

  // videos page
  vid_h: ["Physiotherapy, explained out loud.", "फिजिओथेरपी, सोप्या भाषेत.", "फिजियोथेरेपी, आसान भाषा में।"],
  vid_p: ["Real videos from Dr. Vipul's YouTube channel, sorted by problem. General education only — not a substitute for assessment.", "डॉ. विपुल यांच्या YouTube चॅनलवरील खरे व्हिडिओ, त्रासानुसार. केवळ सामान्य माहिती — तपासणीचा पर्याय नाही.", "डॉ. विपुल के YouTube चैनल के असली वीडियो, समस्या के अनुसार। सिर्फ़ सामान्य जानकारी — जाँच का विकल्प नहीं।"],
  t_all: ["All", "सर्व", "सभी"],
  t_back: ["Back pain", "कंबरदुखी", "कमर दर्द"],
  t_neck: ["Neck pain", "मानदुखी", "गर्दन दर्द"],
  t_knee: ["Knee pain", "गुडघेदुखी", "घुटने का दर्द"],
  t_shoulder: ["Shoulder", "खांदा", "कंधा"],
  t_stroke: ["Stroke", "स्ट्रोक", "स्ट्रोक"],
  t_ortho: ["Injury & surgery", "दुखापत व ऑपरेशन", "चोट और ऑपरेशन"],
  t_general: ["General pain", "सामान्य वेदना", "सामान्य दर्द"],
  guide_h: ["Free health tips by email", "ईमेलद्वारे मोफत आरोग्य टिप्स", "ईमेल से मुफ़्त स्वास्थ्य टिप्स"],
  guide_p: ["One short, useful tip a fortnight in your language. No spam. Unsubscribe anytime.", "दर पंधरा दिवसांनी तुमच्या भाषेत एक छोटी, उपयुक्त टीप. स्पॅम नाही. कधीही बंद करा.", "हर पंद्रह दिन में आपकी भाषा में एक छोटी, उपयोगी टिप। कोई स्पैम नहीं। कभी भी बंद करें।"],
  guide_btn: ["Subscribe", "सबस्क्राइब करा", "सब्सक्राइब करें"],
  guide_ok: ["Subscribed — a welcome email is on its way.", "सबस्क्राइब झाले — स्वागत ईमेल येत आहे.", "सब्सक्राइब हो गया — स्वागत ईमेल आ रहा है।"],
  guide_consent: ["I agree to receive educational emails. I can unsubscribe anytime.", "मला शैक्षणिक ईमेल मिळण्यास संमती आहे. मी कधीही बंद करू शकतो/शकते.", "मैं शैक्षणिक ईमेल पाने के लिए सहमत हूँ। मैं कभी भी बंद कर सकता/सकती हूँ।"],

  // service page
  sv_k: ["Physiotherapy service", "फिजिओथेरपी सेवा", "फिजियोथेरेपी सेवा"],
  sv_symptoms: ["Common problems", "सामान्य त्रास", "आम समस्याएँ"],
  sv_who: ["Who may benefit", "कोणाला फायदा होऊ शकतो", "किसे फ़ायदा हो सकता है"],
  sv_assess: ["What the assessment includes", "तपासणीत काय असते", "जाँच में क्या होता है"],
  sv_assess_list: [
    ["A conversation about your history, pain and daily demands", "Observing how you sit, stand, walk and move", "Movement, strength and flexibility checks", "A clear explanation and a written plan"],
    ["तुमचा इतिहास, दुखणे आणि रोजच्या गरजांविषयी चर्चा", "तुम्ही कसे बसता, उभे राहता, चालता व हालचाल करता याचे निरीक्षण", "हालचाल, ताकद आणि लवचिकता तपासणी", "स्पष्ट स्पष्टीकरण आणि लेखी आराखडा"],
    ["आपके इतिहास, दर्द और रोज़ की ज़रूरतों पर बातचीत", "आप कैसे बैठते, खड़े होते, चलते और हिलते हैं — इसका निरीक्षण", "हरकत, ताकत और लचीलेपन की जाँच", "साफ़ समझाना और लिखित योजना"]
  ],
  sv_approach: ["Treatment & exercise approach", "उपचार व व्यायाम पद्धत", "इलाज और व्यायाम का तरीका"],
  sv_red: ["See a doctor first if", "आधी डॉक्टरांना भेटा जर", "पहले डॉक्टर को दिखाएँ अगर"],
  sv_red_note: ["These need medical assessment, not a routine physiotherapy visit.", "यासाठी वैद्यकीय तपासणी हवी, नियमित फिजिओथेरपी भेट नाही.", "इसके लिए चिकित्सा जाँच ज़रूरी है, सामान्य फिजियोथेरेपी विज़िट नहीं।"],
  sv_videos: ["Watch Dr. Vipul on this", "याबद्दल डॉ. विपुल यांचा व्हिडिओ पहा", "इस पर डॉ. विपुल का वीडियो देखें"],
  sv_faq: ["Questions people ask", "लोक विचारत असलेले प्रश्न", "लोग जो सवाल पूछते हैं"],
  sv_cta_h: ["Ready to be assessed properly?", "योग्य तपासणीसाठी तयार आहात?", "सही जाँच के लिए तैयार हैं?"],
  sv_cta_p: ["Call, WhatsApp or request a time online.", "कॉल, व्हॉट्सॲप करा किंवा ऑनलाइन वेळ मागवा.", "कॉल, व्हाट्सऐप करें या ऑनलाइन समय माँगें।"],
  sv_related: ["Related services", "संबंधित सेवा", "संबंधित सेवाएँ"],
  sv_reviewed: ["General health education. Does not replace individual assessment. Reviewed by Dr. Vipul Ahire (BPTh).", "सामान्य आरोग्य माहिती. वैयक्तिक तपासणीची जागा घेत नाही. डॉ. विपुल अहिरे (BPTh) यांनी तपासलेले.", "सामान्य स्वास्थ्य जानकारी। व्यक्तिगत जाँच की जगह नहीं लेती। डॉ. विपुल अहिरे (BPTh) द्वारा समीक्षित।"],

  // about page
  ab_h: ["Rehabilitation is teaching, not just treating.", "पुनर्वसन म्हणजे फक्त उपचार नव्हे, शिकवणे.", "पुनर्वास सिर्फ़ इलाज नहीं, सिखाना है।"],
  ab_p1: [
    "Most recovery happens between appointments — at home, at work, while sleeping. That only works when patients understand why they are doing each exercise. So every visit here is partly education.",
    "बहुतेक सुधारणा अपॉइंटमेंटच्या मधल्या काळात होते — घरी, कामावर, झोपेत. रुग्णाला प्रत्येक व्यायाम का करायचा हे समजले तरच ते शक्य होते. म्हणून इथली प्रत्येक भेट थोडी शिकवणीही असते.",
    "ज़्यादातर सुधार अपॉइंटमेंट के बीच के समय में होता है — घर पर, काम पर, सोते समय। यह तभी संभव है जब मरीज़ को समझ हो कि हर व्यायाम क्यों करना है। इसलिए यहाँ हर विज़िट थोड़ी सिखाई भी होती है।"
  ],
  ab_p2: [
    "Dr. Vipul assesses carefully, explains honestly, teaches you to do the work yourself, and changes the plan if it isn't working — rather than repeating the same thing.",
    "डॉ. विपुल काळजीपूर्वक तपासतात, प्रामाणिकपणे समजावतात, तुम्हाला स्वतः व्यायाम करायला शिकवतात आणि आराखडा उपयोगी पडत नसेल तर तोच तोच न करता बदलतात.",
    "डॉ. विपुल ध्यान से जाँचते हैं, ईमानदारी से समझाते हैं, आपको खुद व्यायाम करना सिखाते हैं, और योजना काम न करे तो वही दोहराने के बजाय उसे बदलते हैं।"
  ],
  ab_qual: ["Qualification", "शैक्षणिक पात्रता", "शैक्षणिक योग्यता"],
  ab_qual_v: ["Bachelor of Physiotherapy (BPTh)", "बॅचलर ऑफ फिजिओथेरपी (BPTh)", "बैचलर ऑफ फिजियोथेरेपी (BPTh)"],
  ab_exp: ["Experience", "अनुभव", "अनुभव"],
  ab_exp_v: ["About 6 years of clinical practice", "सुमारे ६ वर्षांचा क्लिनिकल सराव", "लगभग 6 वर्षों की क्लिनिकल प्रैक्टिस"],
  ab_areas: ["Clinical areas", "क्लिनिकल क्षेत्रे", "क्लिनिकल क्षेत्र"],
  ab_areas_v: ["Musculoskeletal, orthopaedic, neurological (stroke) and geriatric rehabilitation", "स्नायू-अस्थी, ऑर्थोपेडिक, न्यूरोलॉजिकल (स्ट्रोक) आणि वृद्धांचे पुनर्वसन", "मस्कुलोस्केलेटल, ऑर्थोपेडिक, न्यूरोलॉजिकल (स्ट्रोक) और बुज़ुर्गों का पुनर्वास"],
  ab_edu: ["Education brand", "शैक्षणिक ब्रँड", "शैक्षणिक ब्रांड"],
  ab_edu_v: ["Dard E Body Care — YouTube, Instagram and ebooks", "दर्द ए बॉडी केअर — YouTube, Instagram आणि ई-पुस्तके", "दर्द ए बॉडी केयर — YouTube, Instagram और ई-बुक्स"],
  ab_ethics_h: ["Our promise", "आमचे वचन", "हमारा वादा"],
  ab_ethics: [
    ["No guaranteed outcomes or fixed recovery timelines", "Clear referral when a doctor or surgeon is needed", "Fees explained before treatment begins", "No fake reviews, ratings or statistics", "Your data is never sold"],
    ["खात्रीशीर परिणाम किंवा ठरावीक कालावधीचे वचन नाही", "डॉक्टर किंवा सर्जनची गरज असल्यास स्पष्ट रेफरल", "उपचार सुरू करण्यापूर्वी शुल्क सांगितले जाते", "खोटे रिव्ह्यू, रेटिंग किंवा आकडे नाहीत", "तुमची माहिती कधीही विकली जात नाही"],
    ["कोई गारंटीड नतीजा या तय समय-सीमा का वादा नहीं", "डॉक्टर या सर्जन की ज़रूरत पर साफ़ रेफ़रल", "इलाज शुरू करने से पहले फ़ीस बताई जाती है", "कोई नकली रिव्यू, रेटिंग या आँकड़े नहीं", "आपकी जानकारी कभी बेची नहीं जाती"]
  ],

  // contact
  ct_h: ["Talk to the clinic.", "क्लिनिकशी बोला.", "क्लिनिक से बात करें।"],
  ct_p: ["The quickest way is a phone call or WhatsApp. You can also send a short enquiry below.", "सर्वात जलद मार्ग म्हणजे फोन किंवा व्हॉट्सॲप. तुम्ही खाली छोटी चौकशीही पाठवू शकता.", "सबसे तेज़ तरीका फ़ोन या व्हाट्सऐप है। आप नीचे छोटी पूछताछ भी भेज सकते हैं।"],
  enq_h: ["Send an enquiry", "चौकशी पाठवा", "पूछताछ भेजें"],
  enq_btn: ["Send enquiry", "चौकशी पाठवा", "पूछताछ भेजें"],
  enq_ok: ["Thank you — we'll reply within working hours.", "धन्यवाद — कामाच्या वेळेत आम्ही उत्तर देऊ.", "धन्यवाद — काम के समय में हम जवाब देंगे।"],

  // faq
  faq_h: ["Frequently asked questions", "वारंवार विचारले जाणारे प्रश्न", "अक्सर पूछे जाने वाले सवाल"],
  faq: [
    [["Do I need a doctor's referral?", "No. You can book directly. If we find something that needs a doctor, we will refer you."], ["डॉक्टरांची चिठ्ठी लागते का?", "नाही. तुम्ही थेट बुक करू शकता. डॉक्टरांची गरज वाटल्यास आम्ही तुम्हाला पाठवू."], ["क्या डॉक्टर की पर्ची चाहिए?", "नहीं। आप सीधे बुक कर सकते हैं। डॉक्टर की ज़रूरत लगी तो हम आपको रेफ़र करेंगे।"]],
    [["What are the fees?", "Clinic fees depend on your condition, home-visit fees on distance, and online fees on session length. The fee is always explained before treatment."], ["शुल्क किती आहे?", "क्लिनिकचे शुल्क त्रासानुसार, घरी भेटीचे अंतरानुसार आणि ऑनलाइनचे सत्राच्या वेळेनुसार असते. शुल्क नेहमी उपचारापूर्वी सांगितले जाते."], ["फ़ीस कितनी है?", "क्लिनिक की फ़ीस समस्या के अनुसार, होम विज़िट की दूरी के अनुसार और ऑनलाइन की सत्र की अवधि के अनुसार होती है। फ़ीस हमेशा इलाज से पहले बताई जाती है।"]],
    [["What should I bring to the first visit?", "Any recent reports or X-rays, a list of medicines, and loose comfortable clothing."], ["पहिल्या भेटीला काय आणावे?", "अलीकडील रिपोर्ट्स किंवा एक्स-रे, औषधांची यादी आणि सैल आरामदायक कपडे."], ["पहली विज़िट में क्या लाएँ?", "हाल की रिपोर्ट या एक्स-रे, दवाओं की सूची और ढीले आरामदायक कपड़े।"]],
    [["How many sessions will I need?", "It varies. We review progress regularly and never promise a fixed number of sessions."], ["किती सत्रे लागतील?", "हे व्यक्तीनुसार बदलते. आम्ही नियमित आढावा घेतो आणि ठरावीक सत्रांचे वचन देत नाही."], ["कितने सत्र लगेंगे?", "यह हर व्यक्ति में अलग होता है। हम नियमित समीक्षा करते हैं और तय सत्रों का वादा नहीं करते।"]],
    [["Do you come home?", "Yes — in Shirur city, Ramling, Baburaonagar, Sharadwadi and Annapur. Call to check other areas."], ["तुम्ही घरी येता का?", "हो — शिरूर शहर, रामलिंग, बाबुरावनगर, शरदवाडी आणि अन्नापूर येथे. इतर भागांसाठी कॉल करा."], ["क्या आप घर आते हैं?", "हाँ — शिरूर शहर, रामलिंग, बाबुरावनगर, शरदवाड़ी और अन्नापूर में। अन्य क्षेत्रों के लिए कॉल करें।"]],
    [["Is online physiotherapy useful?", "It works well for advice, exercise guidance and follow-ups. It cannot replace a hands-on examination for every problem."], ["ऑनलाइन फिजिओथेरपी उपयोगी आहे का?", "सल्ला, व्यायाम मार्गदर्शन आणि पाठपुराव्यासाठी उपयोगी आहे. पण प्रत्येक त्रासासाठी प्रत्यक्ष तपासणीची जागा घेऊ शकत नाही."], ["क्या ऑनलाइन फिजियोथेरेपी उपयोगी है?", "सलाह, व्यायाम मार्गदर्शन और फ़ॉलो-अप के लिए उपयोगी है। लेकिन हर समस्या में प्रत्यक्ष जाँच की जगह नहीं ले सकती।"]],
    [["How do I get my ebook after paying?", "Right after payment is verified, a download button appears and the link is emailed to you. WhatsApp us if you face any problem."], ["पेमेंटनंतर ई-पुस्तक कसे मिळेल?", "पेमेंट निश्चित होताच डाउनलोड बटण दिसते आणि लिंक ईमेलवर पाठवली जाते. अडचण आल्यास व्हॉट्सॲप करा."], ["भुगतान के बाद ई-बुक कैसे मिलेगी?", "भुगतान की पुष्टि होते ही डाउनलोड बटन दिखता है और लिंक ईमेल पर भेजा जाता है। कोई समस्या हो तो व्हाट्सऐप करें।"]],
    [["Can I cancel or change my appointment?", "Yes. Message us on WhatsApp with your reference number, ideally a few hours before."], ["अपॉइंटमेंट रद्द किंवा बदलू शकतो का?", "हो. संदर्भ क्रमांकासह व्हॉट्सॲपवर संदेश पाठवा, शक्यतो काही तास आधी."], ["क्या अपॉइंटमेंट रद्द या बदल सकते हैं?", "हाँ। संदर्भ संख्या के साथ व्हाट्सऐप पर संदेश भेजें, हो सके तो कुछ घंटे पहले।"]]
  ],

  pay_k: ["Secure payment", "सुरक्षित पेमेंट", "सुरक्षित भुगतान"],
  pay_h: ["Payment request from VIP MAGICAL PHYSIO", "VIP MAGICAL PHYSIO कडून पेमेंट विनंती", "VIP MAGICAL PHYSIO से भुगतान अनुरोध"],
  pay_for: ["For", "कशासाठी", "किसके लिए"],
  pay_to: ["Patient", "रुग्ण", "मरीज़"],
  pay_amount: ["Amount", "रक्कम", "राशि"],
  pay_due: ["Due by", "भरण्याची अंतिम तारीख", "भुगतान की अंतिम तारीख"],
  pay_btn: ["Pay ₹{p} now", "आत्ता ₹{p} भरा", "अभी ₹{p} भरें"],
  pay_done_h: ["Payment received — thank you!", "पेमेंट मिळाले — धन्यवाद!", "भुगतान मिल गया — धन्यवाद!"],
  pay_done_p: ["Your receipt number is {r}. A copy has been sent to you on WhatsApp.", "तुमचा पावती क्रमांक {r} आहे. प्रत व्हॉट्सॲपवर पाठवली आहे.", "आपकी रसीद संख्या {r} है। इसकी प्रति व्हाट्सऐप पर भेजी गई है।"],
  pay_already: ["This payment link has already been paid.", "या लिंकचे पेमेंट आधीच झाले आहे.", "इस लिंक का भुगतान पहले ही हो चुका है।"],
  pay_missing: ["This payment link is not valid or has expired. Please contact the clinic.", "ही पेमेंट लिंक वैध नाही किंवा कालबाह्य झाली आहे. कृपया क्लिनिकशी संपर्क साधा.", "यह भुगतान लिंक मान्य नहीं है या समाप्त हो गया है। कृपया क्लिनिक से संपर्क करें।"],
  pay_cancelled: ["This payment request was cancelled by the clinic.", "ही पेमेंट विनंती क्लिनिकने रद्द केली आहे.", "यह भुगतान अनुरोध क्लिनिक ने रद्द कर दिया है।"],
  receipt: ["Receipt", "पावती", "रसीद"],
  print_receipt: ["Print receipt", "पावती प्रिंट करा", "रसीद प्रिंट करें"],
  updated: ["Last updated: November 2026", "शेवटचे अद्यतन: नोव्हेंबर २०२६", "अंतिम अपडेट: नवंबर 2026"]
};

/* Legal pages — [en, mr, hi] arrays of [heading, body] */
window.LEGAL = {
  privacy: [
    [["What we collect", "Only what we need: name, mobile number, optional email, preferred language, the service you need, appointment time and, for home visits, your address. We do not ask for medical reports online."], ["आम्ही काय गोळा करतो", "फक्त आवश्यक माहिती: नाव, मोबाइल नंबर, ऐच्छिक ईमेल, पसंतीची भाषा, आवश्यक सेवा, अपॉइंटमेंटची वेळ आणि घरी भेटीसाठी पत्ता. आम्ही ऑनलाइन वैद्यकीय रिपोर्ट्स मागत नाही."], ["हम क्या इकट्ठा करते हैं", "सिर्फ़ ज़रूरी जानकारी: नाम, मोबाइल नंबर, वैकल्पिक ईमेल, पसंदीदा भाषा, ज़रूरी सेवा, अपॉइंटमेंट का समय और होम विज़िट के लिए पता। हम ऑनलाइन चिकित्सा रिपोर्ट नहीं माँगते।"]],
    [["Why we use it", "To arrange and confirm appointments, deliver ebooks you buy, and — only if you agree separately — send educational tips. Treatment messages and marketing messages are kept separate."], ["आम्ही ती का वापरतो", "अपॉइंटमेंट ठरवण्यासाठी व निश्चित करण्यासाठी, खरेदी केलेली ई-पुस्तके देण्यासाठी आणि — तुम्ही वेगळी संमती दिल्यासच — शैक्षणिक टिप्स पाठवण्यासाठी. उपचाराचे संदेश आणि मार्केटिंग संदेश वेगळे ठेवले जातात."], ["हम इसका उपयोग क्यों करते हैं", "अपॉइंटमेंट तय और पक्का करने, खरीदी गई ई-बुक्स देने और — सिर्फ़ आपकी अलग सहमति पर — शैक्षणिक टिप्स भेजने के लिए। इलाज के संदेश और मार्केटिंग संदेश अलग रखे जाते हैं।"]],
    [["Who can see it", "Only Dr. Vipul Ahire and authorised clinic staff. Payments are processed by Razorpay; we never see or store your card or UPI PIN. We never sell your data."], ["ती कोण पाहू शकते", "फक्त डॉ. विपुल अहिरे आणि अधिकृत क्लिनिक कर्मचारी. पेमेंट Razorpay द्वारे होते; आम्ही तुमचे कार्ड किंवा UPI PIN कधीही पाहत किंवा साठवत नाही. आम्ही तुमची माहिती कधीही विकत नाही."], ["इसे कौन देख सकता है", "सिर्फ़ डॉ. विपुल अहिरे और अधिकृत क्लिनिक स्टाफ़। भुगतान Razorpay द्वारा होता है; हम आपका कार्ड या UPI PIN कभी नहीं देखते या रखते। हम आपकी जानकारी कभी नहीं बेचते।"]],
    [["Your rights", "Under India's Digital Personal Data Protection Act, you may ask to see, correct or delete your data, or withdraw consent, by WhatsApp or call on 86248 60808."], ["तुमचे हक्क", "भारताच्या डिजिटल वैयक्तिक डेटा संरक्षण कायद्यानुसार तुम्ही तुमची माहिती पाहणे, दुरुस्त करणे किंवा हटवणे, किंवा संमती मागे घेणे यासाठी 86248 60808 वर व्हॉट्सॲप किंवा कॉल करू शकता."], ["आपके अधिकार", "भारत के डिजिटल व्यक्तिगत डेटा संरक्षण अधिनियम के तहत आप अपनी जानकारी देखने, सुधारने या हटाने, या सहमति वापस लेने के लिए 86248 60808 पर व्हाट्सऐप या कॉल कर सकते हैं।"]]
  ],
  terms: [
    [["Appointments", "A request submitted on this website is not a confirmed appointment. It is confirmed only when the clinic calls or messages you."], ["अपॉइंटमेंट", "या वेबसाइटवर पाठवलेली विनंती म्हणजे निश्चित अपॉइंटमेंट नाही. क्लिनिकने कॉल किंवा संदेश केल्यावरच ती निश्चित होते."], ["अपॉइंटमेंट", "इस वेबसाइट पर भेजा गया अनुरोध पक्का अपॉइंटमेंट नहीं है। क्लिनिक के कॉल या संदेश के बाद ही वह पक्का होता है।"]],
    [["Fees", "Clinic fees depend on the condition, home-visit fees on distance and online fees on duration. The fee is explained before treatment begins."], ["शुल्क", "क्लिनिकचे शुल्क त्रासानुसार, घरी भेटीचे अंतरानुसार आणि ऑनलाइनचे कालावधीनुसार असते. उपचार सुरू होण्यापूर्वी शुल्क सांगितले जाते."], ["फ़ीस", "क्लिनिक की फ़ीस समस्या के अनुसार, होम विज़िट की दूरी के अनुसार और ऑनलाइन की अवधि के अनुसार होती है। इलाज शुरू होने से पहले फ़ीस बताई जाती है।"]],
    [["Ebooks", "Ebooks are for personal use only. Sharing, copying or reselling them is not allowed."], ["ई-पुस्तके", "ई-पुस्तके फक्त वैयक्तिक वापरासाठी आहेत. ती शेअर करणे, कॉपी करणे किंवा पुन्हा विकणे यास परवानगी नाही."], ["ई-बुक्स", "ई-बुक्स सिर्फ़ निजी उपयोग के लिए हैं। इन्हें शेयर करना, कॉपी करना या दोबारा बेचना मना है।"]]
  ],
  refund: [
    [["Appointments", "Please cancel or reschedule at least 3 hours before by WhatsApp. Any advance paid for a cancelled online consultation is refunded or moved to a new time."], ["अपॉइंटमेंट", "कृपया किमान ३ तास आधी व्हॉट्सॲपवर रद्द करा किंवा वेळ बदला. रद्द केलेल्या ऑनलाइन सल्ल्यासाठी भरलेली आगाऊ रक्कम परत केली जाते किंवा नव्या वेळेसाठी वापरली जाते."], ["अपॉइंटमेंट", "कृपया कम से कम 3 घंटे पहले व्हाट्सऐप पर रद्द करें या समय बदलें। रद्द किए गए ऑनलाइन परामर्श का अग्रिम भुगतान लौटाया जाता है या नए समय पर लगाया जाता है।"]],
    [["Ebooks", "Because ebooks are delivered instantly, they are not normally refundable. If your download fails or the file is damaged, we will resend it or refund you in full."], ["ई-पुस्तके", "ई-पुस्तके लगेच दिली जात असल्याने साधारणपणे परतावा नसतो. डाउनलोड अयशस्वी झाल्यास किंवा फाइल खराब असल्यास आम्ही ती पुन्हा पाठवू किंवा पूर्ण परतावा देऊ."], ["ई-बुक्स", "ई-बुक्स तुरंत दी जाती हैं, इसलिए सामान्यतः रिफ़ंड नहीं होता। अगर डाउनलोड विफल हो या फ़ाइल खराब हो, तो हम दोबारा भेजेंगे या पूरा रिफ़ंड देंगे।"]],
    [["Failed payments", "If money is deducted but payment fails, your bank or Razorpay returns it automatically within 5–7 working days."], ["अयशस्वी पेमेंट", "पैसे कापले गेले पण पेमेंट अयशस्वी झाल्यास, तुमची बँक किंवा Razorpay ५–७ कामकाजाच्या दिवसांत आपोआप परत करते."], ["असफल भुगतान", "अगर पैसा कट गया पर भुगतान असफल हुआ, तो आपका बैंक या Razorpay 5–7 कार्य दिवसों में अपने आप लौटा देता है।"]]
  ],
  disclaimer: [
    [["Education, not diagnosis", "Information, videos and ebooks on this website are general health education. They do not replace an individual assessment by a qualified professional."], ["माहिती, निदान नव्हे", "या वेबसाइटवरील माहिती, व्हिडिओ आणि ई-पुस्तके सामान्य आरोग्य माहिती आहेत. ती पात्र तज्ज्ञाच्या वैयक्तिक तपासणीची जागा घेत नाहीत."], ["जानकारी, निदान नहीं", "इस वेबसाइट की जानकारी, वीडियो और ई-बुक्स सामान्य स्वास्थ्य शिक्षा हैं। ये योग्य विशेषज्ञ की व्यक्तिगत जाँच की जगह नहीं लेतीं।"]],
    [["No guarantees", "Every body responds differently. Physiotherapy does not guarantee a specific result or timeline."], ["कोणतीही खात्री नाही", "प्रत्येक शरीर वेगळा प्रतिसाद देते. फिजिओथेरपी ठरावीक परिणाम किंवा कालावधीची खात्री देत नाही."], ["कोई गारंटी नहीं", "हर शरीर अलग तरह से प्रतिक्रिया देता है। फिजियोथेरेपी किसी निश्चित नतीजे या समय-सीमा की गारंटी नहीं देती।"]],
    [["Emergencies", "For chest pain, stroke signs, severe injury or loss of bladder/bowel control, call 108 or go to the nearest hospital immediately."], ["आपत्कालीन स्थिती", "छातीत दुखणे, स्ट्रोकची लक्षणे, गंभीर दुखापत किंवा लघवी/शौचावरील नियंत्रण गेल्यास त्वरित १०८ वर कॉल करा किंवा जवळच्या रुग्णालयात जा."], ["आपातकाल", "सीने में दर्द, स्ट्रोक के लक्षण, गंभीर चोट या पेशाब/मल पर नियंत्रण खोने पर तुरंत 108 पर कॉल करें या नज़दीकी अस्पताल जाएँ।"]]
  ]
};
