# Handoff: VIP MAGICAL PHYSIO — Trilingual Clinic Website, Creator Ebook Store (Razorpay), Admin CRM, Automations & Editable CMS

## Overview
This is a full upgrade of **https://vipmagicalphysio.com** for VIP MAGICAL PHYSIO (Dr. Vipul Ahire, BPTh — Pabal Phata, Shirur, Pune District, Maharashtra). It has five goals:

1. **Get more genuine Google Business Profile reviews.** Review buttons appear across the site, there is a dedicated review page with a QR code, a printable A4 poster, and an automated WhatsApp review request after each visit.
2. **Sell ebooks like Gumroad / creator platforms** under the Dard E Body Care brand, with Razorpay payments (account **ahirevipul1994@gmail.com**). The flow is: storefront → product page → slide-in checkout → payment verified on the server → secure download → customer library → verified-buyer ratings. It also supports coupons, bundles and pay-what-you-want pricing.
3. **Local SEO and mobile-first design** in **English, Marathi and Hindi**, with every visible string translated.
4. **Three appointment flows** (Clinic OPD / Home Visit / Online) with real availability and no double-booking.
5. **An admin dashboard** covering CRM (contacts, pipeline, tasks, calendar), payments (orders, payment links, ledger, coupons, refunds), an automation engine (16 trilingual rules plus an outbox), and an **editable website CMS** that publishes changes to the live site.

Tagline: **Move better. Live better.**

## About the Design Files
The HTML/JSX files in this bundle are **design references**: working prototypes that run React through in-browser Babel and store data in `localStorage`. They show the intended look, copy, states and flows. **They are not production code to ship as-is.**

Recreate them in a production stack. If no codebase exists yet, use:
- **Next.js (App Router) or Astro** on **Netlify**. The site is currently on Netlify, with GitHub, and the domain is at Hostinger. Use real locale routes `/en/…`, `/mr/…`, `/hi/…` with SSR/SSG for SEO. The prototype uses hash routes like `#/mr/store/<id>`.
- **Supabase**: Postgres, Auth with roles, Row Level Security, and a private Storage bucket for PDFs.
- **Razorpay**: Orders API, Checkout.js, signature verification, webhooks and the Refund API.
- **Brevo**: transactional email and newsletter lists.
- WhatsApp stays on **click-to-chat** (`wa.me`). The WhatsApp Business API is not required.

**Some backend code is already production-ready and can be used close to as-is:**
- `netlify/functions/*`: create-order, verify-payment, razorpay-webhook, download, refund, plus a shared `_lib.js`.
- `supabase/schema.sql`: tables, RLS policies, the private `ebooks` bucket and the product seed data.
- `RAZORPAY SETUP.md`: step-by-step go-live guide for the owner.

The prototype's `window.VMPStore` (`data.js`) and `window.VMPAuto` (`automation.js`) are stand-ins for Supabase tables and DB triggers / cron. Their names map 1:1.

## Fidelity
**High-fidelity.** Colours, typography, spacing, radii, copy in all three languages, states and flows are final.

The exceptions are:
- `<image-slot>` photo placeholders, which need real photos.
- The simulated Razorpay modal, which is shown when `VMP_PAY.live=false`.
- The PIN login (`1234`), which must be replaced by Supabase Auth.

---

## Verified Business Facts (do not invent others)
| Field | Value |
|---|---|
| Name | VIP MAGICAL PHYSIO (clinic: VIP MAGICAL PHYSIO CLINIC) · education brand **Dard E Body Care** |
| Practitioner | Dr. Vipul Ahire — BPTh — ~6 years experience |
| Address | Pabal Phata, Shirur, Pune District, Maharashtra (no street number or PIN confirmed — don't add one) |
| Phone / WhatsApp | 86248 60808 → `tel:+918624860808`, `https://wa.me/918624860808` |
| Hours | Mon–Sat 09:00–17:00, Sunday closed |
| Google review link | `https://g.page/r/CVNq5MC_yrQaECE/review` |
| Home-visit area | Shirur city, Ramling, Baburaonagar, Sharadwadi, Annapur |
| YouTube | `https://www.youtube.com/@drvipulahireofficial` (23 real videos mapped by condition in `data.js`) |
| Instagram | `https://www.instagram.com/dr.vipul.dardebody/` |
| Razorpay account | ahirevipul1994@gmail.com · site vipmagicalphysio.com |
| Public fees | Not shown as numbers. OPD depends on condition, home visit on distance, online on duration. |

**Catalogue** (INR, prices include tax):
| id | Title | Lang | Price |
|---|---|---|---|
| stronger-after-40 | Stronger After 40 | EN | 399 |
| new-beginning-35 | A New Beginning for Health After 35 | EN | 299 |
| aap-ab-bhi-anmol | आप अब भी अनमोल हैं | HI | 499 |
| chhoti-aadatein | छोटी आदतें, लंबा उजाला | HI | 499 |
| complete-health-bundle | Complete Health Bundle — all 4 (bundle) | EN | 1299 (compare-at 1696) |

**Ethics rules (non-negotiable):**
- No fake reviews, ratings or statistics.
- No incentives for reviews.
- Review requests go to *every* completed patient, with no filtering.
- Marketing consent is collected separately from treatment-communication consent.
- Never promise guaranteed outcomes.
- Emergency guidance ("call 108") stays visible at all times.
- Ratings come from verified buyers only. Honest low ratings must not be hidden.

---

## Screens / Views — Public Website (`index.html`)

### Shell (`app-shell.jsx`, `site.css`)
- **Announcement bar.** Optional; edited in the CMS. Tones: sun `#f2b33d` with navy text, teal with white text, or red with white text. Centered, 16px, weight 600, padding 10×18.
- **Top bar.**
  - Background `#0e2742`, 15px text in `#cfe0f0`, min-height 42px.
  - Left: open/closed dot (9px; `#5bd28a` when open, `#e98b72` when closed) followed by "Mon–Sat · 9 AM – 5 PM".
  - Right: "Call: 86248 60808".
- **Header.**
  - Sticky. Background `rgba(251,247,240,.94)` with `backdrop-filter: blur(10px)`, 1px bottom border `#e6dccb`, min-height 78px, gap 14px.
  - Brand: **logo** `assets/logo-256.png` (54px circle with a `drop-shadow(0 3px 8px rgba(14,39,66,.22))`), then "VIP MAGICAL PHYSIO" (Baloo 2, 20px) with the tagline underneath (13px, muted).
  - Nav links: 17px Mukta 500, padding 10×13, radius 12. Hover background `#f3ebdd`. Active state: text `#0a6662`, background `#dff1ee`.
  - Language switch: a pill containing EN / मरा / हिं. The active option is navy with white text.
  - CTA: "Book Appointment" teal pill.
- **Header responsive behaviour.**
  - ≤1320px: nav link padding 10×9 at 16px.
  - ≤1240px: nav and CTA are hidden; a "Menu" button opens a full-screen cream overlay.
  - ≤560px: logo 42px, wordmark 15px (wraps, max-width 96px), tagline hidden.
- **Footer.**
  - Background `#0e2742`. Four columns (1.4fr 1fr 1fr 1fr) collapsing to two columns ≤860px.
  - Columns: brand (64px logo) / Pages / Legal / Follow + language switch.
  - Below: an emergency box (`rgba(179,64,42,.18)` background, `#ffd9cf` text) and the © line.
- **Mobile action bar (≤860px).** Fixed to the bottom. Three columns: Call (sand), WhatsApp (`#1f9d55`), Book (teal). Height 52px.
- **Desktop WhatsApp button (>860px).** 62px green circle, bottom-right.

### Home, About, Services (×12), Booking, Videos, Reviews, FAQ, Contact, Legal
These are unchanged from the previous handoff and fully specified in code:
- **Home** sections in order: hero (arched 4:5 portrait slot with the doctor card *beside* it in a 170px column), review strip, services grid, about, why us, how it works, three care modes plus coverage chips, videos, ebooks, review CTA, map and contact.
- **Service detail**: hero, symptoms, who it's for, assessment, approach, a **red-flag box** (`#fbe9e4`), mapped YouTube videos, FAQ (with `FAQPage` JSON-LD), CTA band, related services.
- **Booking**: three-step form. (1) Mode cards. (2) 14-day date scroller plus slot grid; Sundays are closed. (3) Details with separate treatment and marketing consent checkboxes and a honeypot field. Success screen reads "Request received — not yet confirmed" and shows the reference `VMP-…`.
- **Reviews page**: large sun-coloured "Write a Google Review" button, a 220px QR code, Web Share button, 3-step guide, and a WhatsApp feedback card. The feedback card does **not** gate or replace the Google review.
- **Pay page** `#/<lang>/pay/<PL-id>`: patient-facing payment link page. Shows Patient / For / Due / Amount (40px), then Pay → Razorpay → receipt. Handles three special states: already paid, cancelled, and invalid link.
- **Legal**: Privacy (DPDP Act), Terms, Refund, Disclaimer — all three languages, in `i18n-ui.js` → `LEGAL`.

### NEW — Creator Ebook Store (`store.jsx` + store section of `site.css`)
All store strings live in the `ST` object as `[en, mr, hi]` arrays.

**1. Storefront `/store`**
- **Creator header.**
  - Navy `#14365c` background, padding 42px top / 38px bottom. A sun-coloured circle decoration (opacity .14) sits at the top-right.
  - 104px round logo, then H1 "Dard E Body Care" (Baloo 2, clamp(32px, 4.4vw, 48px), white).
  - "by Dr. Vipul Ahire (BPTh)" in sun colour, weight 600, followed by a bio line in `#c3d3e4`.
  - Buttons: **My library** (white pill), YouTube and Instagram (ghost pills with a `rgba(255,255,255,.35)` border).
- **Filter bar.**
  - Language tabs (All / English / Hindi), pill buttons with min-height 44px; the active tab is navy.
  - Product count, plus a sort select (Featured / Price low→high / Price high→low).
- **Product grid.** `repeat(auto-fill, minmax(250px, 1fr))`, gap 22px.
- **Product card.**
  - White, 1px border `#e6dccb`, radius 18. Hover: translateY(-4px) plus shadow.
  - Cover area: sand `#f3ebdd`, aspect 1:1, padding 26×34, containing a CSS-drawn cover (max 190px).
  - Body, padding 14×16:
    - Title: Baloo 2, 19px, navy.
    - "by …": 14px, muted.
    - Footer row: **price tag** (sun background, navy-2 text, Baloo 17px/700, arrow-shaped via `clip-path: polygon(10px 0,100% 0,100% 100%,10px 100%,0 50%)`), compare-at price struck through, stars with a count, and a language or "Bundle" pill aligned right.
- **Bundle cover.** A square showing up to 4 mini covers fanned out, each offset `translateX((i-mid)*34px) rotate((i-mid)*6deg)`.
- **Trust row.** 🔒 secure checkout · ⚡ instant PDF · ₹ powered by Razorpay.

**2. Product page `/store/:id`**
- **Layout.**
  - Grid `minmax(0,1.15fr) minmax(320px,.85fr)`, gap 22px × 44px.
  - Desktop areas: `"media buy" "desc buy"`. The **buy box is sticky** at top: 100px.
  - ≤900px it stacks as media → buy → desc, and the buy box is no longer sticky.
- **Media.** Sand stage (radius 28, padding 46, min-height 420) holding the cover (340px), plus three 4:3 preview `<image-slot>`s for page previews.
- **Buy box.**
  - White, radius 28, padding 26, with shadow.
  - Language pill, then H1 (clamp(28px, 3vw, 38px)), then the author row (30px logo + "by …"), then the star rating, which scrolls to the ratings section.
  - **Price:** large tag at 30px. When a compare-at price exists, show it struck through plus a green "Save ₹X" pill (`#e5efe8` / `#2f7d4f`).
  - **Pay what you want:** label "Name a fair price · ₹min or more". The input has a 2px navy border with a "₹" prefix block and a 26px Baloo number; it is clamped to the minimum on blur.
  - **Coupon:** a "Have a coupon code?" link reveals an uppercase code input + Apply. Success: "✓ Coupon X applied · −₹Y" in green. Error: "This code is not valid for this book."
  - **Buy button:** full width, 62px tall — "Buy now · ₹total", or "Get it free" when the total is 0.
  - Then the points list (instant / secure), a share row (WhatsApp 40px green circle, copy link → "Link copied"), and "Already bought? Open your library →".
- **Description column.**
  - Blurb, "Includes" (bundle items as rows with colour swatch, title and price), and "What you get" (4 default features per language).
  - "Who it is for", then a details table (language, format PDF, pages, file size, refund link).
  - **Ratings from verified buyers:** average (36px), stars, a list with "✓ Verified buyer" badges, and an empty state.
- **"More from Dr. Vipul".** Three product cards.
- **JSON-LD.** `Book` (or `Product` for bundles) with an `Offer`, plus `aggregateRating` when ratings exist.

**3. Checkout sheet** (slides in from the right; it is not a page)
- **Container.** Backdrop `rgba(14,39,66,.5)`. Sheet `width: min(460px,100%)`, full height, cream background. Animation `slideIn` .25s ease-out (from translateX(40px) with opacity 0). Esc or a backdrop click closes it, except while a payment is processing.
- **Header.** "Checkout" (Baloo 22px), a "Test mode — no real money" badge when not live, and a × button (40px circle).
- **Summary row.** 46×62 mini cover, title, "by …", base price.
- **Form.**
  - Email\* (labelled as where the download link is sent), Name\*, Mobile (optional, Indian 10-digit `^[6-9]\d{9}$`).
  - Totals card: Subtotal / Discount (code) / **Total** (20px, bold), then "Inclusive of applicable taxes".
  - Required "I agree to the Terms and Refund policy…" checkbox, plus an optional health-tips opt-in.
  - "Pay ₹N" button.
- **Remember the buyer.** Email, name and mobile are saved to `localStorage.vmp_buyer` and prefilled next time.
- **States.**
  - `form` → `processing`: spinner + "Confirming your payment with Razorpay…".
  - → `done`: tick, "Your ebook is ready!", "Receipt and download link sent to {email}", order number + total, **Download PDF**, Open my library.
  - Errors return to `form` with a red note: either "Payment didn't go through. No money was taken" or "Payment window closed".
- **Live mode** (`VMP_PAY.live && keyId && window.Razorpay`):
  1. `POST /create-order` returns `{orderId, razorpayOrderId, amount}`.
  2. `new Razorpay({key, order_id, name:"VIP MAGICAL PHYSIO", image: logo, prefill, theme:{color:"#0d7f7a"}})`.
  3. The handler calls `POST /verify-payment`, which returns `{ok, paymentId, downloadToken}`.
  4. `payment.failed` and `ondismiss` are handled.
- **Prototype mode.** An in-sheet Razorpay mock with "Simulate successful / failed payment" buttons.

**4. Library `/library`**
- **Sign-in.** Email, then "Send code" (a 6-digit code emailed by Brevo in production; shown on screen in the prototype), then "Open library". The email is stored in `localStorage.vmp_lib_email`.
- **Grid.** `repeat(auto-fill, minmax(360px, 1fr))`.
- **Item.** 96px cover, title, "Bought {date} · {order} · ₹{amount}". Buttons: **Download PDF** (disabled at the limit), **Receipt** (opens a printable receipt with logo, items, discount and total), and **★ Rate this book**. Below: "{n} downloads left" (5 per item).
- **Rate modal.** 5 large stars (38px) plus an optional 400-character text, then "Post rating". One rating per order + product.

---

## Screens / Views — Admin Dashboard (`Admin Dashboard.html` + `admin2-*.jsx`, `admin2.css`)
- **Layout.**
  - 248px navy-2 sidebar (logo, grouped nav: **Today / CRM / Business / Website**, count badges in sun) plus a main area (padding 20×26).
  - Top bar: page title (28px) and a global search that finds patients by name, mobile or email and opens their profile.
  - ≤820px the sidebar becomes an off-canvas drawer (☰ button).
- **Login.** Prototype PIN 1234. Production uses Supabase Auth with `profiles.role` set to admin, clinician or staff.

| Section | What it does |
|---|---|
| **Overview** | 10 clickable KPIs (to confirm, WhatsApp to send, open tasks, revenue this month, outstanding dues, contacts, upcoming, completed, ebooks sold, conversion %). Stacked revenue bars for the last 6 months (services teal / ebooks sun) counting **paid only**. Today's schedule. "Needs attention" list (tasks + overdue payment links). |
| **Tasks** | Add task + due date. Open/Done toggle. Automation-created call-back tasks link to Call / Profile. Overdue tasks are highlighted red-soft. |
| **Contacts** | Auto-built from bookings, enquiries, orders, payments, payment links and subscribers, keyed by mobile (or email). Search plus stage and tag filters, CSV export, and "+ Add contact" for walk-ins. Columns: name/sources, mobile/lang, stage, tags, visits, paid (LTV), due, last activity. |
| **Contact drawer** (760px) | Avatar initials, phone/email/lang, stage select (auto stage marked), editable tags, 4 KPIs (visits/upcoming/lifetime paid/due). Actions: WhatsApp, Call, + Book, + Payment link, + Task. Private notes. A unified **timeline** of appointments, enquiries, orders, payments, links, messages and notes. |
| **Pipeline** | Kanban across 6 stages: New lead / Booked / In treatment / Completed · follow-up / Ebook customer / Inactive. Cards can be dragged between columns, which overrides the auto stage. |
| **Appointments** | **Week calendar**: Mon–Sat × opening hours. Colour-coded events (OPD navy, Home teal, Online sun); requested = dashed outline, completed = 55% opacity. Plus a list view with filters and an "Awaiting confirmation" panel. Actions: Confirm / Decline / Completed / Cancel / Collect payment (pre-fills a payment link). Confirming opens the prepared WhatsApp message. "+ New appointment" modal for phone/walk-in bookings with a live slot picker. |
| **Availability** | Single clinician calendar. Toggle individual slots or close a whole day. |
| **Enquiries** | Status select (new / contacted / converted / closed) plus WhatsApp reply. |
| **Google reviews** | Completed patients with Send on WhatsApp / "asked" badge, the review link + QR + poster, counters. |
| **Store & payments** | Seven tabs, listed in the next table. |
| **Automations** | **Outbox**: KPIs ready / scheduled / sent / skipped; messages shown as chat bubbles with channel chips (WA / @ / ! / TASK); Send (opens wa.me prefilled), Send now, Skip; "Send next WhatsApp" for working through the queue. **Rules**: 16 default rules with toggles, a "When → wait → channel" flow and sent counts; the editor drawer has trigger, channel, delay, audience (treatment / marketing / internal), a trilingual template with variable chips and a WhatsApp-bubble preview per language. **Subscribers**: MR/HI/EN segments, Brevo CSV export, unsubscribe. **Activity log**: last 300 audit entries. |
| **Website content (CMS)** | Sticky bar: section tabs, "● Unpublished changes", Preview site, Discard, **Publish to website**. Sections are listed in the CMS table below. Publishing writes only the differences from the defaults and updates the live site immediately via a `storage` event. "Reset everything to original" is available. |

**Store & payments tabs**
| Tab | Contents |
|---|---|
| Sales dashboard | Range 7/30/90/365 days. KPIs: revenue, estimated Razorpay fees (≈2.36%), net, checkout conversion, coupon discounts/refunds. Daily bars and sales by product. |
| Ebook orders | Filter, search, CSV export. Download count n/5. Actions: Resend link (resets the count), **Refund** (confirm dialog → Razorpay Refund API), **Recover** (email abandoned or failed buyers). |
| Payment links | Create from presets (OPD / Home / Online / 10-session package) or a custom amount and due date, in MR/HI/EN. The link is created and WhatsApp opens with a trilingual message. Actions: copy, open, paid by cash/UPI, cancel. Overdue links trigger an automatic reminder. |
| All payments | Monthly ledger with collected / services / ebooks / refunded totals and a by-method breakdown. "+ Record cash/UPI". "Export for accountant" (CSV). |
| Coupons | Code, % or ₹ off, all products or one product, max uses, expiry. Active toggle, usage count, delete. |
| Ratings | Moderate (hide/show abusive ratings only). |
| Razorpay setup | Account card (ahirevipul1994@gmail.com · vipmagicalphysio.com · status). Public Key ID field, validated as `rzp_(test|live)_…`; pasting a secret is rejected. Live toggle. Internal default fees. Receipt name + GSTIN. 5-step go-live checklist with links. Webhook URL with a copy button. |

**CMS sections**
| Section | What can be edited |
|---|---|
| Clinic details | Phone, review URL, Maps URL/embed, YouTube, Instagram, open/close time, working days. These also drive booking slots. |
| Announcement bar | On/off, tone, trilingual text, preview. |
| Homepage & page text | Grouped trilingual fields. **"✦ AI translate EN → मराठी/हिंदी"** via `window.genspark.complete`; the output must be reviewed. |
| Service pages | All 12 pages: title, short, who, intro, symptoms, approach, red flags, FAQ add/remove, attached videos. |
| Ebooks & prices | Title, Latin title, price, compare-at, **pay-what-you-want + minimum**, pages, size, language, cover palette (6 options), PDF drop zone, description, audience, on-sale toggle, delete. Add ebook / **Add bundle** (pick included books). |
| YouTube videos | Add by URL (ID parsed), edit title/topic/views, remove. |
| FAQ | Add, edit, reorder, remove. |
| All text | Search every UI string in all three languages. |

---

## Interactions & Behavior
- **Language.** On first visit, read `localStorage.vmp_lang`, then `navigator.languages` (mr → hi → en), falling back to en. Switching keeps the current path. Production must emit `hreflang` alternates (en/mr/hi/x-default), a canonical URL, and translated titles and descriptions.
- **Slots.**
  - Mon–Sat, open → the last slot that *ends* by closing time.
  - OPD and online: 30-minute duration and step. Home visit: 60 minutes including travel, 60-minute step.
  - A slot is blocked by any requested/confirmed appointment in any mode, or by a manual block.
  - Same-day slots within the next 60 minutes are hidden.
  - **Production:** enforce with a Postgres exclusion constraint and a booking RPC.
- **Payment state machine (orders).** `created → paid | failed | abandoned`, and `paid → refunded`.
  - **A download is unlocked only when the server marks the order paid.** That happens in verify-payment *or* in the `payment.captured` webhook, whichever arrives first.
  - Fulfilment is idempotent: a conditional update on `status ≠ paid`, plus a unique `payment_events.id`.
- **Download rules.**
  - The token is HMAC-signed with order, product and expiry (365 days).
  - 5 downloads per product per order.
  - The file is served through a 60-second signed URL from the private Supabase bucket `ebooks`.
- **Coupons.** Checked on the client for display and **re-validated on the server** in create-order: active, not expired, under max uses, product scope. The `used` count is incremented on fulfilment.
- **Revenue.** Paid transactions only; refunded and unpaid are excluded. Fees are an estimate.
- **Automation engine (`automation.js`).**
  - Store events map to rules, which produce outbox messages or tasks in the patient's language.
  - Email, SMS and admin alerts send automatically (Brevo in production). WhatsApp messages wait as "ready" for one-tap sending.
  - Time-based items:
    - reminder 24 hours before a confirmed appointment
    - review request 2 hours after completion
    - follow-up 7 days later
    - overdue payment-link reminder
  - Cancelling or declining an appointment skips its scheduled messages.
  - Marketing messages require consent.
  - The prototype processes the schedule every 30 s. **Production:** a Supabase cron / scheduled Netlify function every 5 min.
- **Toasts.** Bottom-center pill: navy, teal = ok, red = warn. They disappear after 2.6 s.
- **Animations.**
  - Checkout sheet slides in over .25s.
  - Cards lift 3–4px over .18s.
  - Book cover hover: translateY(-4px) rotate(-.6deg).
  - Buttons press down 1px when active.

## State / Data Model (Supabase — see `supabase/schema.sql`)
**Commerce tables:**
- `products`: id, type (ebook/bundle), title, title_latin, lang, price_paise, compare_at_paise, pwyw, min_price_paise, bundle_items[], file_path, pages, size_label, active, description/audience/features/cover jsonb.
- `coupons`: code, kind (pct/flat), value, product_ids[], max_uses, used, expires_on, active.
- `orders`: `ORD-…`; base, discount and amount in paise; coupon; customer fields; lang; status; razorpay_order_id and razorpay_payment_id (unique); download_counts jsonb; max_downloads; download_expires_at; paid_at; refunded_at.
- `payments`: order_id, kind, amount_paise, method, gateway_id, status, receipt_no.
- `payment_events`: Razorpay event id as primary key, for idempotency.
- `ratings`: unique on (order_id, product_id).
- `subscribers`, `admin_logs`, `profiles(role)`.

**Clinic/CRM tables to add in the same style** (they mirror the prototype store):
`appointments`, `availability_blocks`, `enquiries`, `payment_links`, `outbox`, `automation_rules`, `tasks`, `contact_meta(tags, notes, stage)`, `site_content` (CMS overrides as jsonb per key — `cms-apply.js` shows the merge logic).

**RLS rules:**
- The public can read only active products and non-hidden ratings.
- Orders and payments are written **only** by Netlify Functions using the service-role key.
- All admin reads require `is_admin()`.

## Environment (Netlify)
`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `DOWNLOAD_SECRET`, `SITE_URL=https://vipmagicalphysio.com`, `BREVO_API_KEY`, `MAIL_FROM=books@vipmagicalphysio.com`, `MAIL_ADMIN=ahirevipul1994@gmail.com`.

- Webhook URL: `https://vipmagicalphysio.com/.netlify/functions/razorpay-webhook`.
- Webhook events: `payment.captured`, `payment.failed`, `refund.processed`.
- The public Key ID goes in `pay-config.js`. **The secret never goes in the frontend.**

## SEO
- **Site-wide JSON-LD:** `MedicalClinic` + `LocalBusiness` with logo `/assets/logo-512.png`, phone, address (no PIN), hours Mo–Sa 09–17, areaServed, availableLanguage, founder (BPTh), sameAs.
- **Per-page JSON-LD:** `FAQPage` on service/FAQ pages; `Book`/`Product` + `Offer` + `aggregateRating` on store pages.
- **Head tags:** favicon and apple-touch icon set; og:image = the logo.
- **Target keywords:** physiotherapist in Shirur, home visit physiotherapy Shirur, stroke rehabilitation Shirur, knee/back pain physiotherapy Shirur, online physiotherapy consultation India.
- **Technical:** sitemap with locale alternates; `robots.txt` disallowing `/admin`.

## Design Tokens
**Colours**
| Token | Hex | Token | Hex |
|---|---|---|---|
| navy | `#14365c` | sand | `#f3ebdd` |
| navy-2 | `#0e2742` | line | `#e6dccb` |
| teal | `#0d7f7a` | ink | `#1d2733` |
| teal-2 | `#0a6662` | muted | `#5b6673` |
| teal-soft | `#dff1ee` | sun | `#f2b33d` (hover `#e6a52a`) |
| cream (site bg) | `#fbf7f0` | sun-soft | `#fff3d6` |
| admin bg | `#f6f2ea` | red / red-soft | `#b3402a` / `#fbe9e4` |
| green | `#2f7d4f` (bg `#e5efe8`) | WhatsApp | `#1f9d55` |
| YouTube | `#c4302b` | Razorpay header | `#0c2451` |

The logo itself uses navy `#0b1a33`, teal `#2fb5b0` and gold `#d8a64a`, which sit harmoniously with these tokens.

**Ebook cover palettes (bg / accent):** `#14365c/#f2b33d`, `#0d7f7a/#ffe7b8`, `#8a3b1e/#ffd28a`, `#3d2a6b/#f6c453`, `#1f5e3a/#e9f3c6`, `#9b2c4a/#ffd6c9`. Bundle: `#0e2742/#f2b33d`.

**Typography**
- Fonts: **Baloo 2** (headings, 500–700) and **Mukta** (body, 400–700). Both cover Devanagari.
- Body: 19px, line-height 1.6 (admin 15.5px).
- H1: clamp(40px, 6.2vw, 76px) on home, clamp(36px, 5vw, 60px) on inner pages.
- H2: clamp(30px, 4vw, 46px). H3: clamp(22px, 2.2vw, 26px).
- Price tag: Baloo 700, 17px in cards, 30px on the product page.
- Headings use `text-wrap: balance`; body text uses `pretty`.

**Radius:** 12 / 14 / 18 (`--r`) / 28 (`--r-lg`) / 999 (pills).

**Shadow:** `0 1px 2px rgba(20,54,92,.06), 0 8px 28px rgba(20,54,92,.08)`.
- Primary button: `0 6px 18px rgba(13,127,122,.28)`.
- Sun button: `0 6px 18px rgba(242,179,61,.35)`.

**Buttons:** min-height 54px (44px small; buy button 62px), padding 0 24px, pill shape, weight 600. Admin buttons: 40px.

**Breakpoints (site):** 1320, 1240 (nav collapse), 1000, 980, 900 (hero / product stack), 860 (action bar), 700, 620, 560.

**Breakpoints (admin):** 1200, 900, 820 (off-canvas sidebar).

**Accessibility:**
- Tap targets ≥44px.
- 19px body text for older users.
- `lang` attribute on Devanagari titles.
- `aria-pressed` on toggles; labelled inputs.
- The checkout sheet has `role="dialog"` and closes on Esc.

## Assets
- `assets/logo-256.png`, `assets/logo-512.png`: official logo (gold/teal "V" figure in a navy circle, transparent background), supplied by the client. The 1024px original is in the project root at `assets/logo.png`.
- Photos: none supplied yet. Every `<image-slot>` is a placeholder (portrait 4:5 and 1:1, clinic 16:10, treatment 4:3, ebook page previews 4:3).
- Ebook covers: drawn in CSS (`BookCover`, `BundleCover`). Replace with real cover art when available.
- Ebook PDFs: to be uploaded to the private Supabase bucket `ebooks/<product-id>.pdf`.
- Icons: inline SVG (WhatsApp, phone). Stars and arrows are text glyphs.
- QR codes: `qrcode-generator@1.4.4` (pre-render as SVG in production).
- YouTube thumbnails: `i.ytimg.com`. Embeds use `youtube-nocookie.com`.

## Files
| File | Purpose |
|---|---|
| `index.html` | Public site entry, JSON-LD, script order, router (incl. `/store`, `/store/:id`, `/library`, `/pay/:id`) |
| `site.css` | All public styles incl. the creator store section |
| `app-shell.jsx` | i18n context, routing, SEO hook, Header/Footer/ActionBar, VideoCard/Modal, BookCover, ReviewStrip |
| `pages-a.jsx` | Home, About, Services, Service detail, Videos, Newsletter, Map, Modes |
| `pages-b.jsx` | Booking, Reviews, FAQ, Contact, Legal, **PayPage**, AnnouncementBar (old store kept as `Old*`) |
| `store.jsx` | **Creator store**: StorePage, ProductPage, CheckoutSheet (live Razorpay + simulated), LibraryPage, ratings, receipts, `ST` strings |
| `i18n-ui.js` | All UI strings `[en, mr, hi]` + legal pages |
| `services-a.js`, `services-b.js` | 12 service pages + ebook descriptions (trilingual) |
| `data.js` | Business facts, videos, ebooks, prototype store `VMPStore` (slots, CRUD, audit log) |
| `cms-apply.js` | Editable-content layer: defaults snapshot, merge, publish, bundle seed |
| `automation.js` | Automation engine: 16 trilingual rules, events, outbox, scheduler |
| `pay-config.js` | Public Razorpay config (Key ID, live flag); **no secrets** |
| `Admin Dashboard.html` + `admin2.css` + `admin2-core/cms/crm/pay/auto.jsx` | Admin v2 (CRM, payments, automations, CMS) |
| `Review QR Poster.html` | A4 printable Google-review poster with logo |
| `netlify/functions/*.js` | **Production** payment backend: create-order, verify-payment, razorpay-webhook, download, refund, `_lib` |
| `supabase/schema.sql` | **Production** schema + RLS + bucket + seed |
| `RAZORPAY SETUP.md` | Owner's go-live guide (KYC, keys, env, webhook, test with `success@razorpay`) |

## Open Items
1. Real ebook PDFs, cover art, chapter lists and page counts.
2. Real clinic and doctor photos.
3. Exact Google Business Profile place ID for the map embed.
4. Native-speaker review of the Marathi and Hindi medical copy.
5. Razorpay KYC + keys, Supabase project, Brevo sender domain verification, GSTIN (if any).
6. Replace the PIN login with Supabase Auth and roles.
7. Move the CRM/automation tables from the prototype store into Supabase (schema pattern provided).
