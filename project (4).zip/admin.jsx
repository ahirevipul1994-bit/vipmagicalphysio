/* VIP MAGICAL PHYSIO — Admin CRM (prototype on localStorage; production = Supabase + RLS) */
const { useState, useEffect, useMemo } = React;
const S = window.VMPStore;
const SVC_NAME = (s) => (window.SERVICES[s] ? window.SERVICES[s].title.en : s === "other" ? "Other" : "—");
const MODE = { opd: "Clinic OPD", home: "Home visit", online: "Online" };
const STATUS_B = { requested: "b-req", confirmed: "b-conf", completed: "b-done", cancelled: "b-can", declined: "b-can", new: "b-req", contacted: "b-conf", converted: "b-done", closed: "b-can", created: "b-req", paid: "b-paid", failed: "b-fail", refunded: "b-can" };
const fmtD = (s) => s ? new Date(s).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
const wa = (m, txt) => "https://wa.me/91" + m + "?text=" + encodeURIComponent(txt);
const REVIEW = window.BUSINESS.reviewUrl;

const MSG = {
  confirm: {
    en: (a) => `Hello ${a.name}, your ${MODE[a.mode]} appointment at VIP MAGICAL PHYSIO is CONFIRMED for ${a.date.split("-").reverse().join("/")} at ${S.fmtTime(a.time)}. Ref ${a.id}. Pabal Phata, Shirur · 86248 60808`,
    mr: (a) => `नमस्कार ${a.name}, VIP MAGICAL PHYSIO येथे तुमची अपॉइंटमेंट ${a.date.split("-").reverse().join("/")} रोजी ${S.fmtTime(a.time)} वाजता निश्चित झाली आहे. संदर्भ ${a.id}. पाबळ फाटा, शिरूर · 86248 60808`,
    hi: (a) => `नमस्ते ${a.name}, VIP MAGICAL PHYSIO में आपकी अपॉइंटमेंट ${a.date.split("-").reverse().join("/")} को ${S.fmtTime(a.time)} बजे पक्की हो गई है। संदर्भ ${a.id}. पाबल फाटा, शिरूर · 86248 60808`
  },
  remind: {
    en: (a) => `Reminder: your appointment at VIP MAGICAL PHYSIO is tomorrow at ${S.fmtTime(a.time)}. Reply here to reschedule. Ref ${a.id}`,
    mr: (a) => `आठवण: VIP MAGICAL PHYSIO येथे तुमची अपॉइंटमेंट उद्या ${S.fmtTime(a.time)} वाजता आहे. वेळ बदलायची असल्यास येथे कळवा. संदर्भ ${a.id}`,
    hi: (a) => `याद दिलाना: VIP MAGICAL PHYSIO में आपकी अपॉइंटमेंट कल ${S.fmtTime(a.time)} बजे है। समय बदलना हो तो यहाँ बताएँ। संदर्भ ${a.id}`
  },
  review: {
    en: (a) => `Thank you for visiting VIP MAGICAL PHYSIO, ${a.name}. If you have a minute, please share your honest experience on Google — it helps other families in Shirur: ${REVIEW}`,
    mr: (a) => `${a.name}, VIP MAGICAL PHYSIO ला भेट दिल्याबद्दल धन्यवाद. एक मिनिट असल्यास कृपया तुमचा प्रामाणिक अनुभव Google वर लिहा — शिरूरमधील इतर कुटुंबांना मदत होईल: ${REVIEW}`,
    hi: (a) => `${a.name}, VIP MAGICAL PHYSIO आने के लिए धन्यवाद। एक मिनट हो तो कृपया अपना ईमानदार अनुभव Google पर लिखें — इससे शिरूर के दूसरे परिवारों को मदद मिलती है: ${REVIEW}`
  },
  decline: {
    en: (a) => `Hello ${a.name}, sorry — the ${S.fmtTime(a.time)} slot on ${a.date.split("-").reverse().join("/")} is not available. Please call 86248 60808 or reply here for another time.`,
    mr: (a) => `नमस्कार ${a.name}, क्षमस्व — ${a.date.split("-").reverse().join("/")} रोजी ${S.fmtTime(a.time)} ची वेळ उपलब्ध नाही. कृपया 86248 60808 वर कॉल करा किंवा दुसऱ्या वेळेसाठी येथे कळवा.`,
    hi: (a) => `नमस्ते ${a.name}, क्षमा करें — ${a.date.split("-").reverse().join("/")} को ${S.fmtTime(a.time)} का समय उपलब्ध नहीं है। कृपया 86248 60808 पर कॉल करें या दूसरे समय के लिए यहाँ बताएँ।`
  }
};
const msgFor = (type, a) => (MSG[type][a.plang] || MSG[type].en)(a);

function useDB() {
  const [db, setDb] = useState(S.load());
  useEffect(() => { const f = () => setDb(S.load()); window.addEventListener("vmp-store", f); window.addEventListener("storage", f); return () => { window.removeEventListener("vmp-store", f); window.removeEventListener("storage", f); }; }, []);
  return db;
}

function seed() {
  const names = [["Sunita Pawar", "mr"], ["Ramesh Gaikwad", "mr"], ["Anil Shinde", "mr"], ["Priya Kulkarni", "en"], ["Rajesh Yadav", "hi"], ["Meena Bhosale", "mr"], ["Vikas Sharma", "hi"], ["Asha Jadhav", "mr"], ["Kiran Thorat", "en"], ["Savita More", "mr"]];
  const svcs = ["knee-pain", "back-pain", "stroke-rehab", "neck-pain", "post-op-rehab", "shoulder-pain", "geriatric", "balance-falls"];
  const db = { enquiries: [], appointments: [], orders: [], subscribers: [], reviewRequests: [], blocked: [], log: [] };
  const today = new Date(); const ymd = (d) => d.toISOString().slice(0, 10);
  const used = {};
  for (let i = 0; i < 26; i++) {
    const d = new Date(today); d.setDate(d.getDate() + (i < 14 ? -Math.floor(i * 2.5) - 1 : i - 14));
    if (d.getDay() === 0) d.setDate(d.getDate() + 1);
    const mode = ["opd", "opd", "home", "online", "opd"][i % 5];
    let h = 9 + (i % 7); const key = ymd(d) + h; if (used[key]) h = (h + 3) % 8 + 9; used[ymd(d) + h] = 1;
    const [nm, pl] = names[i % names.length];
    const past = i < 14;
    const status = past ? ["completed", "completed", "completed", "cancelled", "completed", "declined"][i % 6] : ["requested", "confirmed", "requested", "confirmed"][i % 4];
    db.appointments.push({ id: "VMP-" + (1000 + i), createdAt: new Date(d.getTime() - 86400000 * 2).toISOString(), mode, date: ymd(d), time: String(h).padStart(2, "0") + ":00", name: nm, mobile: "98" + String(22000000 + i * 137).slice(0, 8), email: "", plang: pl, service: svcs[i % svcs.length], area: mode === "home" ? ["Shirur city", "Ramling", "Baburaonagar", "Sharadwadi", "Annapur"][i % 5] : "", address: mode === "home" ? "Near main road" : "", msg: "", consent: true, marketing: i % 3 === 0, status });
  }
  const books = window.EBOOKS;
  for (let i = 0; i < 18; i++) {
    const b = books[i % 4]; const d = new Date(today); d.setDate(d.getDate() - Math.floor(i * 4.3));
    const st = i % 7 === 3 ? "failed" : i === 9 ? "refunded" : "paid";
    db.orders.push({ id: "ORD-" + (5000 + i), createdAt: d.toISOString(), product: b.id, title: b.titleLatin || b.title, amount: b.price, name: names[i % 10][0], email: "reader" + i + "@gmail.com", mobile: "97" + String(30000000 + i * 91).slice(0, 8), status: st, paymentId: st === "paid" ? "pay_demo" + i : "", downloads: st === "paid" ? 1 + (i % 3) : 0 });
  }
  ["Is home visit available in Ramling?", "Fees for knee pain?", "Online consult from Pune possible?", "Mother has stroke, need home physio", "Do you treat sciatica?"].forEach((m, i) => {
    const d = new Date(today); d.setDate(d.getDate() - i * 3);
    db.enquiries.push({ id: "REC-E" + i, createdAt: d.toISOString(), name: names[i + 3][0], mobile: "99" + String(41000000 + i * 77).slice(0, 8), msg: m, lang: names[i + 3][1], status: ["new", "contacted", "converted", "new", "closed"][i] });
  });
  for (let i = 0; i < 9; i++) db.subscribers.push({ id: "REC-S" + i, createdAt: new Date(today.getTime() - i * 5 * 86400000).toISOString(), email: "sub" + i + "@gmail.com", lang: ["mr", "en", "hi"][i % 3], source: ["website", "ebook", "booking"][i % 3], consent: true });
  db.log.push({ at: new Date().toISOString(), who: "admin", action: "Demo data loaded", ref: "—" });
  S.save(db);
}

/* ------------------- UI pieces ------------------- */
function Badge({ s }) { return <span className={"badge " + (STATUS_B[s] || "b-can")}>{s}</span>; }
function KPI({ label, value, sub, tone }) {
  return <div className="kpi" style={tone ? { background: tone, color: "#fff" } : null}><small style={tone ? { color: "rgba(255,255,255,.75)" } : null}>{label}</small><b style={tone ? { color: "#fff" } : null}>{value}</b>{sub && <span style={tone ? { color: "rgba(255,255,255,.8)" } : null}>{sub}</span>}</div>;
}
function Bars({ data }) {
  const max = Math.max(1, ...data.map((d) => d.v));
  return (
    <div className="bars">
      {data.map((d) => <div key={d.k} className="bar-col"><span className="bar-v">{d.v ? "₹" + d.v.toLocaleString("en-IN") : ""}</span><div className="bar" style={{ height: (d.v / max) * 150 + 4 }}></div><small>{d.k}</small></div>)}
    </div>
  );
}

function Overview({ db, go }) {
  const A = db.appointments, O = db.orders;
  const paid = O.filter((o) => o.status === "paid");
  const revenue = paid.reduce((s, o) => s + o.amount, 0);
  const refunds = O.filter((o) => o.status === "refunded").reduce((s, o) => s + o.amount, 0);
  const pending = A.filter((a) => a.status === "requested");
  const conv = db.enquiries.length + A.length ? Math.round((A.filter((a) => ["confirmed", "completed"].includes(a.status)).length / (A.length || 1)) * 100) : 0;
  const months = Array.from({ length: 6 }, (_, i) => { const d = new Date(); d.setMonth(d.getMonth() - 5 + i); return { k: d.toLocaleString("en-IN", { month: "short" }), m: d.getMonth(), y: d.getFullYear() }; });
  const trend = months.map((mo) => ({ k: mo.k, v: paid.filter((o) => { const d = new Date(o.createdAt); return d.getMonth() === mo.m && d.getFullYear() === mo.y; }).reduce((s, o) => s + o.amount, 0) }));
  const today = new Date().toISOString().slice(0, 10);
  const todays = A.filter((a) => a.date === today && ["requested", "confirmed"].includes(a.status)).sort((a, b) => a.time.localeCompare(b.time));
  const reviewDue = A.filter((a) => a.status === "completed" && !db.reviewRequests.some((r) => r.appt === a.id));
  return (
    <>
      <div className="kpis">
        <KPI label="Pending confirmations" value={pending.length} sub="need a call / WhatsApp" tone={pending.length ? "#b3402a" : null} />
        <KPI label="Confirmed upcoming" value={A.filter((a) => a.status === "confirmed" && a.date >= today).length} />
        <KPI label="Completed" value={A.filter((a) => a.status === "completed").length} />
        <KPI label="Cancelled / declined" value={A.filter((a) => ["cancelled", "declined"].includes(a.status)).length} />
        <KPI label="Home visits" value={A.filter((a) => a.mode === "home").length} />
        <KPI label="Online consults" value={A.filter((a) => a.mode === "online").length} />
        <KPI label="Ebook sales (paid)" value={paid.length} />
        <KPI label="Gross ebook revenue" value={"₹" + revenue.toLocaleString("en-IN")} sub={refunds ? "₹" + refunds + " refunded" : "unpaid orders excluded"} tone="#0d7f7a" />
        <KPI label="Enquiries" value={db.enquiries.length} sub={db.enquiries.filter((e) => e.status === "new").length + " new"} />
        <KPI label="Request → confirmed" value={conv + "%"} />
      </div>
      <div className="two">
        <div className="panel"><h3>Ebook revenue · last 6 months</h3><Bars data={trend} /></div>
        <div className="panel">
          <h3>Today</h3>
          {todays.length ? todays.map((a) => <div className="row-mini" key={a.id}><b>{S.fmtTime(a.time)}</b><span>{a.name} · {MODE[a.mode]}</span><Badge s={a.status} /></div>) : <p className="muted">No appointments today.</p>}
          <h3 style={{ marginTop: 22 }}>Follow-up tasks</h3>
          <button className="task" onClick={() => go("appointments")}>{pending.length} appointment requests to confirm →</button>
          <button className="task" onClick={() => go("reviews")}>{reviewDue.length} completed patients not yet asked for a review →</button>
          <button className="task" onClick={() => go("enquiries")}>{db.enquiries.filter((e) => e.status === "new").length} new enquiries to reply →</button>
        </div>
      </div>
    </>
  );
}

function Appointments({ db }) {
  const [mode, setMode] = useState("all"); const [st, setSt] = useState("all"); const [q, setQ] = useState("");
  const list = db.appointments.filter((a) => (mode === "all" || a.mode === mode) && (st === "all" || a.status === st) && (!q || (a.name + a.mobile + a.id).toLowerCase().includes(q.toLowerCase()))).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  const act = (a, status, msgType) => {
    S.update("appointments", a.id, { status }, "Appointment " + status);
    if (msgType) window.open(wa(a.mobile, msgFor(msgType, a)), "_blank");
  };
  return (
    <div className="panel">
      <div className="filters">
        <select value={mode} onChange={(e) => setMode(e.target.value)}><option value="all">All types</option><option value="opd">Clinic OPD</option><option value="home">Home visit</option><option value="online">Online</option></select>
        <select value={st} onChange={(e) => setSt(e.target.value)}><option value="all">All status</option>{["requested", "confirmed", "completed", "cancelled", "declined"].map((s) => <option key={s}>{s}</option>)}</select>
        <input placeholder="Search name, mobile, ref…" value={q} onChange={(e) => setQ(e.target.value)} />
        <span className="muted">{list.length} records</span>
      </div>
      <div className="tbl-wrap"><table className="tbl">
        <thead><tr><th>Ref</th><th>When</th><th>Patient</th><th>Type</th><th>Problem</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>{list.map((a) => (
          <tr key={a.id}>
            <td className="mono">{a.id}</td>
            <td><b>{a.date.split("-").reverse().join("/")}</b><br /><span className="muted">{S.fmtTime(a.time)}</span></td>
            <td><b>{a.name}</b><br /><a href={"tel:+91" + a.mobile}>{a.mobile}</a> · <span className="muted">{(a.plang || "en").toUpperCase()}</span></td>
            <td>{MODE[a.mode]}{a.area && <><br /><span className="muted">{a.area}</span></>}</td>
            <td>{SVC_NAME(a.service)}{a.msg && <div className="muted small">"{a.msg}"</div>}</td>
            <td><Badge s={a.status} /></td>
            <td className="acts">
              {a.status === "requested" && <><button className="b-ok" onClick={() => act(a, "confirmed", "confirm")}>Confirm + WhatsApp</button><button onClick={() => act(a, "declined", "decline")}>Decline</button></>}
              {a.status === "confirmed" && <><button onClick={() => window.open(wa(a.mobile, msgFor("remind", a)), "_blank")}>Send reminder</button><button className="b-ok" onClick={() => act(a, "completed")}>Mark completed</button><button onClick={() => act(a, "cancelled")}>Cancel</button></>}
              {a.status === "completed" && <button onClick={() => { S.add("reviewRequests", { appt: a.id, name: a.name, mobile: a.mobile, lang: a.plang, by: "admin" }, "Review request sent"); window.open(wa(a.mobile, msgFor("review", a)), "_blank"); }}>Ask for review</button>}
            </td>
          </tr>))}
          {!list.length && <tr><td colSpan="7" className="muted center" style={{ padding: 40 }}>No appointments yet. Book one from the website, or load demo data.</td></tr>}
        </tbody>
      </table></div>
    </div>
  );
}

function Availability({ db }) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const slots = S.slots(date, "opd");
  const blockedDay = db.blocked.some((b) => b.date === date && !b.time);
  const toggle = (t) => {
    const ex = db.blocked.find((b) => b.date === date && b.time === t);
    const d = S.load();
    d.blocked = ex ? d.blocked.filter((b) => !(b.date === date && b.time === t)) : d.blocked.concat({ date, time: t });
    d.log.unshift({ at: new Date().toISOString(), who: "admin", action: (ex ? "Unblocked " : "Blocked ") + date + " " + t, ref: "slot" }); S.save(d);
  };
  const toggleDay = () => {
    const d = S.load();
    d.blocked = blockedDay ? d.blocked.filter((b) => !(b.date === date && !b.time)) : d.blocked.concat({ date, time: null });
    d.log.unshift({ at: new Date().toISOString(), who: "admin", action: (blockedDay ? "Opened " : "Closed full day ") + date, ref: "slot" }); S.save(d);
  };
  return (
    <div className="panel">
      <div className="filters"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /><button className={blockedDay ? "b-ok" : ""} onClick={toggleDay}>{blockedDay ? "Re-open this day" : "Close whole day (leave / holiday)"}</button></div>
      <p className="muted">One clinician calendar — OPD, home and online share these slots, so double-booking is impossible. Tap a free slot to block it.</p>
      {slots.closed ? <p>Sunday — clinic closed.</p> : (
        <div className="slotgrid">{slots.list.map((s) => {
          const manual = db.blocked.some((b) => b.date === date && b.time === s.t);
          const appt = db.appointments.find((a) => a.date === date && a.time === s.t && ["requested", "confirmed"].includes(a.status));
          return <button key={s.t} className={"sl " + (appt ? "booked" : manual ? "blocked" : s.free ? "free" : "busy")} onClick={() => !appt && toggle(s.t)} disabled={!!appt}>
            <b>{S.fmtTime(s.t)}</b><small>{appt ? appt.name.split(" ")[0] + " · " + MODE[appt.mode] : manual ? "Blocked" : s.free ? "Free" : blockedDay ? "Closed" : "Unavailable"}</small></button>;
        })}</div>
      )}
    </div>
  );
}

function Enquiries({ db }) {
  return (
    <div className="panel"><div className="tbl-wrap"><table className="tbl">
      <thead><tr><th>Received</th><th>Name</th><th>Message</th><th>Lang</th><th>Status</th><th></th></tr></thead>
      <tbody>{db.enquiries.map((e) => (
        <tr key={e.id}><td>{fmtD(e.createdAt)}</td><td><b>{e.name}</b><br /><a href={"tel:+91" + e.mobile}>{e.mobile}</a></td><td>{e.msg || <span className="muted">—</span>}</td><td>{(e.lang || "").toUpperCase()}</td><td><Badge s={e.status} /></td>
          <td className="acts"><select value={e.status} onChange={(x) => S.update("enquiries", e.id, { status: x.target.value }, "Enquiry → " + x.target.value)}>{["new", "contacted", "converted", "closed"].map((s) => <option key={s}>{s}</option>)}</select>
            <button onClick={() => window.open(wa(e.mobile, "Hello " + e.name + ", thank you for contacting VIP MAGICAL PHYSIO. "), "_blank")}>WhatsApp</button></td></tr>))}
        {!db.enquiries.length && <tr><td colSpan="6" className="muted center" style={{ padding: 40 }}>No enquiries yet.</td></tr>}
      </tbody></table></div></div>
  );
}

function Orders({ db }) {
  const byBook = window.EBOOKS.map((b) => ({ b, n: db.orders.filter((o) => o.product === b.id && o.status === "paid").length }));
  return (
    <>
      <div className="kpis" style={{ gridTemplateColumns: "repeat(4,1fr)" }}>{byBook.map(({ b, n }) => <KPI key={b.id} label={b.titleLatin || b.title} value={n + " sold"} sub={"₹" + (n * b.price).toLocaleString("en-IN")} />)}</div>
      <div className="panel"><div className="tbl-wrap"><table className="tbl">
        <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Ebook</th><th>Amount</th><th>Status</th><th>Downloads</th><th></th></tr></thead>
        <tbody>{db.orders.map((o) => (
          <tr key={o.id}><td className="mono">{o.id}</td><td>{fmtD(o.createdAt)}</td><td><b>{o.name}</b><br /><span className="muted small">{o.email}</span></td><td>{o.title}</td><td>₹{o.amount}</td><td><Badge s={o.status} /></td><td>{o.status === "paid" ? (o.downloads || 0) + " / 5" : "—"}</td>
            <td className="acts">{o.status === "paid" && <><button onClick={() => S.update("orders", o.id, { downloads: 0 }, "Download link re-issued")}>Resend link</button><button onClick={() => confirm("Refund ₹" + o.amount + " via Razorpay?") && S.update("orders", o.id, { status: "refunded" }, "Refund issued")}>Refund</button></>}</td></tr>))}
          {!db.orders.length && <tr><td colSpan="8" className="muted center" style={{ padding: 40 }}>No orders yet.</td></tr>}
        </tbody></table></div></div>
    </>
  );
}

function Reviews({ db }) {
  const done = db.appointments.filter((a) => a.status === "completed");
  const asked = (id) => db.reviewRequests.find((r) => r.appt === id);
  return (
    <div className="two">
      <div className="panel">
        <h3>Completed patients</h3>
        <p className="muted">Every completed patient is asked the same way — no filtering by satisfaction, no incentives (Google policy).</p>
        {done.map((a) => { const r = asked(a.id); return (
          <div className="row-mini" key={a.id}><b>{a.name}</b><span className="muted">{SVC_NAME(a.service)} · {a.date.split("-").reverse().join("/")} · {(a.plang || "en").toUpperCase()}</span>
            {r ? <span className="badge b-done">Asked {fmtD(r.createdAt)}</span> : <button className="b-ok" onClick={() => { S.add("reviewRequests", { appt: a.id, name: a.name, mobile: a.mobile, lang: a.plang, by: "admin" }, "Review request sent"); window.open(wa(a.mobile, msgFor("review", a)), "_blank"); }}>Send on WhatsApp</button>}
          </div>); })}
        {!done.length && <p className="muted">Mark appointments "completed" to see them here.</p>}
      </div>
      <div className="panel">
        <h3>Review link & QR</h3>
        <div style={{ display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap" }}>
          <QRImg />
          <div><div className="mono small" style={{ wordBreak: "break-all" }}>{REVIEW}</div>
            <div className="acts" style={{ marginTop: 10 }}><a className="btnlink" href={REVIEW} target="_blank">Open</a><a className="btnlink" href="Review QR Poster.html" target="_blank">Print poster</a></div></div>
        </div>
        <h3 style={{ marginTop: 22 }}>Message templates</h3>
        {["mr", "hi", "en"].map((l) => <div className="tpl" key={l}><b>{l.toUpperCase()}</b><p>{MSG.review[l]({ name: "{name}" })}</p></div>)}
        <div className="kpis" style={{ gridTemplateColumns: "1fr 1fr", marginTop: 16 }}><KPI label="Requests sent" value={db.reviewRequests.length} /><KPI label="Not yet asked" value={done.filter((a) => !asked(a.id)).length} /></div>
      </div>
    </div>
  );
}
function QRImg() { const q = window.qrcode(0, "M"); q.addData(REVIEW); q.make(); return <img src={q.createDataURL(4, 1)} width="120" height="120" alt="QR" style={{ imageRendering: "pixelated", border: "1px solid #eee", borderRadius: 10 }} />; }

function Subscribers({ db }) {
  const exportCsv = () => {
    const rows = [["email", "language", "source", "consent", "date"]].concat(db.subscribers.map((s) => [s.email, s.lang, s.source, "yes", s.createdAt]));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map((r) => r.join(",")).join("\n")], { type: "text/csv" })); a.download = "subscribers-brevo.csv"; a.click();
  };
  const seg = (l) => db.subscribers.filter((s) => s.lang === l).length;
  return (
    <div className="panel">
      <div className="filters"><span className="muted">Marketing list (consent only) — kept separate from patient records.</span><button onClick={exportCsv}>Export CSV for Brevo</button></div>
      <div className="kpis" style={{ gridTemplateColumns: "repeat(3,1fr)" }}><KPI label="Marathi list" value={seg("mr")} /><KPI label="Hindi list" value={seg("hi")} /><KPI label="English list" value={seg("en")} /></div>
      <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Email</th><th>Language</th><th>Source</th><th>Joined</th><th></th></tr></thead>
        <tbody>{db.subscribers.map((s) => <tr key={s.id}><td>{s.email}</td><td>{s.lang.toUpperCase()}</td><td>{s.source}</td><td>{fmtD(s.createdAt)}</td><td className="acts"><button onClick={() => S.remove("subscribers", s.id)}>Unsubscribe</button></td></tr>)}
          {!db.subscribers.length && <tr><td colSpan="5" className="muted center" style={{ padding: 40 }}>No subscribers yet.</td></tr>}</tbody></table></div>
    </div>
  );
}

function Automations({ db }) {
  const pend = db.appointments.filter((a) => a.status === "requested").length;
  const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1); const tm = tomorrow.toISOString().slice(0, 10);
  const rem = db.appointments.filter((a) => a.status === "confirmed" && a.date === tm).length;
  const rows = [
    ["New enquiry acknowledgement", "Email (Brevo)", "On form submit", "ready"],
    ["Appointment request received", "Email + screen", "On booking", "live"],
    ["Appointment confirmed", "WhatsApp (1-tap) + email", "When you click Confirm", "live"],
    ["Reminder 24 h before", "WhatsApp (1-tap) + email", rem + " due for tomorrow", rem ? "pending" : "live"],
    ["Cancellation / reschedule notice", "WhatsApp + email", "On status change", "live"],
    ["Ebook purchase confirmation", "Email (Brevo)", "After Razorpay webhook", "ready"],
    ["Secure ebook download link", "Email + screen", "Signed link · 5 uses / 7 days", "ready"],
    ["Newsletter welcome", "Email (Brevo)", "On consented signup", "ready"],
    ["Fortnightly education email", "Email (Brevo) · per language", "Consented list only", "ready"],
    ["Review request", "WhatsApp (1-tap)", "After visit marked completed", "live"],
    ["Admin alert — new booking", "Email to clinic", pend + " awaiting confirmation", pend ? "pending" : "live"]
  ];
  const B = { live: "b-done", ready: "b-conf", pending: "b-req" };
  const L = { live: "Working in prototype", ready: "Needs Brevo / Razorpay keys", pending: "Action needed" };
  return (
    <div className="panel">
      <p className="muted">"Working in prototype" runs in this demo now. "Needs keys" switches on once your Brevo and Razorpay accounts are connected.</p>
      <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Automation</th><th>Channel</th><th>Trigger</th><th>Status</th></tr></thead>
        <tbody>{rows.map((r) => <tr key={r[0]}><td><b>{r[0]}</b></td><td>{r[1]}</td><td>{r[2]}</td><td><span className={"badge " + B[r[3]]}>{L[r[3]]}</span></td></tr>)}</tbody></table></div>
    </div>
  );
}

function Log({ db }) {
  return <div className="panel"><div className="tbl-wrap"><table className="tbl"><thead><tr><th>When</th><th>By</th><th>Action</th><th>Ref</th></tr></thead>
    <tbody>{db.log.slice(0, 200).map((l, i) => <tr key={i}><td>{fmtD(l.at)}</td><td>{l.who}</td><td>{l.action}</td><td className="mono">{l.ref}</td></tr>)}</tbody></table></div></div>;
}

const TABS = [["overview", "Overview"], ["appointments", "Appointments"], ["availability", "Availability"], ["enquiries", "Enquiries"], ["orders", "Ebook orders"], ["reviews", "Google reviews"], ["subscribers", "Subscribers"], ["automations", "Automations"], ["log", "Activity log"]];

function Admin() {
  const db = useDB();
  const [tab, setTab] = useState(localStorage.getItem("vmp_admin_tab") || "overview");
  const [authed, setAuthed] = useState(sessionStorage.getItem("vmp_admin") === "1");
  const [pin, setPin] = useState("");
  useEffect(() => localStorage.setItem("vmp_admin_tab", tab), [tab]);
  if (!authed) return (
    <div className="login"><form onSubmit={(e) => { e.preventDefault(); if (pin === "1234") { sessionStorage.setItem("vmp_admin", "1"); setAuthed(true); } else alert("Wrong PIN"); }}>
      <img className="lm" src="assets/logo-256.png" alt="VIP MAGICAL PHYSIO" style={{ width: 84, height: 84, margin: "0 auto" }} /><h2>VIP MAGICAL PHYSIO · Admin</h2><p className="muted">Prototype PIN: <b>1234</b><br />Production uses Supabase email login + role-based access.</p>
      <input type="password" inputMode="numeric" placeholder="PIN" value={pin} onChange={(e) => setPin(e.target.value)} autoFocus /><button className="b-ok">Sign in</button></form></div>
  );
  const pending = db.appointments.filter((a) => a.status === "requested").length;
  return (
    <div className="adm">
      <aside>
        <div className="side-brand"><img className="lm" src="assets/logo-256.png" alt="" /><div><b>VIP MAGICAL PHYSIO</b><small>CRM · Dr. Vipul Ahire</small></div></div>
        {TABS.map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}{k === "appointments" && pending > 0 && <i>{pending}</i>}</button>)}
        <div className="side-foot">
          <a href="index.html" target="_blank">Open website ↗</a>
          <button onClick={() => { seed(); }}>Load demo data</button>
          <button onClick={() => confirm("Clear all prototype data?") && S.reset()}>Clear data</button>
          <button onClick={() => { sessionStorage.removeItem("vmp_admin"); setAuthed(false); }}>Sign out</button>
        </div>
      </aside>
      <main>
        <header><h1>{TABS.find((x) => x[0] === tab)[1]}</h1><span className="muted">{new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</span></header>
        {tab === "overview" && <Overview db={db} go={setTab} />}
        {tab === "appointments" && <Appointments db={db} />}
        {tab === "availability" && <Availability db={db} />}
        {tab === "enquiries" && <Enquiries db={db} />}
        {tab === "orders" && <Orders db={db} />}
        {tab === "reviews" && <Reviews db={db} />}
        {tab === "subscribers" && <Subscribers db={db} />}
        {tab === "automations" && <Automations db={db} />}
        {tab === "log" && <Log db={db} />}
      </main>
    </div>
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(<Admin />);
