/* VIP MAGICAL PHYSIO — shared data + demo CRM store (localStorage).
   In production this store is replaced by Supabase tables with Row Level Security. */
window.BUSINESS = {
  name: "VIP MAGICAL PHYSIO",
  phone: "86248 60808",
  tel: "+918624860808",
  wa: "918624860808",
  reviewUrl: "https://g.page/r/CVNq5MC_yrQaECE/review",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=VIP+MAGICAL+PHYSIO+CLINIC+Pabal+Phata+Shirur",
  mapsEmbed: "https://www.google.com/maps?q=VIP+MAGICAL+PHYSIO+CLINIC,+Pabal+Phata,+Shirur,+Maharashtra&output=embed",
  youtube: "https://www.youtube.com/@drvipulahireofficial",
  youtubeSub: "https://www.youtube.com/@drvipulahireofficial?sub_confirmation=1",
  instagram: "https://www.instagram.com/dr.vipul.dardebody/",
  open: { days: [1, 2, 3, 4, 5, 6], start: 9, end: 17 }
};

/* Real uploads from @drvipulahireofficial, mapped to conditions. */
window.VIDEOS = [
  { id: "D1VKyVsDl_Q", t: "Neck pain exercises in Marathi | मानेची नस दबल्यावर उपाय", v: 917, topic: "neck" },
  { id: "q-9m2Dpr00g", t: "शरिरातील वेदना जिवघेण्या बनु शकतात | Treat your pain by physio", v: 940, topic: "general" },
  { id: "19kU0aB86FI", t: "No Pain, Only Gain | त्रासदायक वेदनांचा नायनाट", v: 810, topic: "general" },
  { id: "XrqEgMsP1Cw", t: "Spine pain treated without surgery | मणक्याचा त्रास", v: 735, topic: "back" },
  { id: "jB5r0Cn6u7c", t: "Low back pain recovery | कंबरदुखी पासुन सुटका", v: 732, topic: "back" },
  { id: "xct3GbLimc0", t: "Stroke recovery | मेंदुविकार — पुनर्वसन", v: 698, topic: "stroke" },
  { id: "aC4PkW8p-Ts", t: "Avoiding pain: the key to relief | वेदनांपासुन आराम", v: 693, topic: "general" },
  { id: "6yeS8T-uivc", t: "Painfree life | शारिरीक वेदनांवर उपाय", v: 680, topic: "general" },
  { id: "0YWl1C15e78", t: "Recovery after brain stroke | पॅरेलिसीस पुनर्वसन", v: 646, topic: "stroke" },
  { id: "VGTHCCj3Pxc", t: "Dr. Ahire physio treatment | गुडघ्यांची ताकद वाढवा", v: 614, topic: "knee" },
  { id: "bOTMbPRLh0M", t: "उपचारासाठी दुरुन रुग्ण शिरुरमध्ये | Low back pain recovery", v: 387, topic: "back" },
  { id: "NoOMSIubJsw", t: "Pain relief yoga | दुखण्यापासुन आराम", v: 364, topic: "general" },
  { id: "xCIPuu5_-No", t: "Frozen shoulder exercises | खांदा दुखी", v: 336, topic: "shoulder" },
  { id: "XFVfVC42Qxs", t: "मानेचे दुखणे उपाय | Neck pain recovery", v: 302, topic: "neck" },
  { id: "xp5hHObBlCM", t: "Post-operative physiotherapy | ऑपरेशन नंतरचा उपचार", v: 204, topic: "ortho" },
  { id: "F-QcEggZh8g", t: "Painfree life | औषधे-गोळ्यांचा कंटाळा", v: 192, topic: "general" },
  { id: "nfXAMieB9Hw", t: "Health issues in gym | जिममुळे त्रास वाढतो का?", v: 161, topic: "general" },
  { id: "adKClhAwMcU", t: "Ankle sprain recovery | नसांचे त्रास", v: 127, topic: "ortho" },
  { id: "1U3m9DmDebc", t: "फिजिओथेरपीनंतर गुडघेदुखी कमी, ताकद वाढली", v: 113, topic: "knee" },
  { id: "mwOKhXXuWA4", t: "Driver's low back pain | कंबरदुखी", v: 81, topic: "back" },
  { id: "tllVRXeA5jg", t: "कंबर-मान दुखी | Pain free life secret", v: 72, topic: "back" },
  { id: "ckpCNELK3HM", t: "Instant neck pain relief | व्यायामाने मानदुखी", v: 64, topic: "neck" },
  { id: "PRCjF3vPDZI", t: "गुडघ्यांना आराम | Knee pain", v: 0, topic: "knee" }
];

window.SERVICE_META = [
  { slug: "back-pain", videos: ["jB5r0Cn6u7c", "XrqEgMsP1Cw", "mwOKhXXuWA4"] },
  { slug: "neck-pain", videos: ["D1VKyVsDl_Q", "XFVfVC42Qxs", "ckpCNELK3HM"] },
  { slug: "knee-pain", videos: ["VGTHCCj3Pxc", "1U3m9DmDebc", "PRCjF3vPDZI"] },
  { slug: "shoulder-pain", videos: ["xCIPuu5_-No"] },
  { slug: "stroke-rehab", videos: ["xct3GbLimc0", "0YWl1C15e78"] },
  { slug: "ortho-rehab", videos: ["adKClhAwMcU", "xp5hHObBlCM"] },
  { slug: "post-op-rehab", videos: ["xp5hHObBlCM"] },
  { slug: "geriatric", videos: ["NoOMSIubJsw", "19kU0aB86FI"] },
  { slug: "balance-falls", videos: ["NoOMSIubJsw", "6yeS8T-uivc"] },
  { slug: "home-visit", videos: ["q-9m2Dpr00g", "1U3m9DmDebc"] },
  { slug: "online-consultation", videos: ["aC4PkW8p-Ts"] },
  { slug: "posture-ergonomics", videos: ["tllVRXeA5jg", "nfXAMieB9Hw"] }
];

window.EBOOKS = [
  { id: "stronger-after-40", title: "Stronger After 40", lang: "en", price: 399, hue: "#14365c", accent: "#f2b33d" },
  { id: "new-beginning-35", title: "A New Beginning for Health After 35", lang: "en", price: 299, hue: "#0d7f7a", accent: "#ffe7b8" },
  { id: "aap-ab-bhi-anmol", title: "आप अब भी अनमोल हैं", titleLatin: "Aap Ab Bhi Anmol Hain", lang: "hi", price: 499, hue: "#8a3b1e", accent: "#ffd28a" },
  { id: "chhoti-aadatein", title: "छोटी आदतें, लंबा उजाला", titleLatin: "Chhoti Aadatein, Lamba Ujala", lang: "hi", price: 499, hue: "#3d2a6b", accent: "#f6c453" }
];

/* ---------- demo CRM store ---------- */
(function () {
  const KEY = "vmp_crm_v1";
  const empty = () => ({ enquiries: [], appointments: [], orders: [], subscribers: [], reviewRequests: [], blocked: [], log: [], payments: [], paylinks: [], outbox: [], tasks: [], notes: [], contactsMeta: {}, rules: null, settings: {} });
  function load() { try { return Object.assign(empty(), JSON.parse(localStorage.getItem(KEY) || "{}")); } catch (e) { return empty(); } }
  function save(db) { localStorage.setItem(KEY, JSON.stringify(db)); window.dispatchEvent(new Event("vmp-store")); }
  function uid(p) { return p + "-" + Math.random().toString(36).slice(2, 6).toUpperCase() + Date.now().toString(36).slice(-3).toUpperCase(); }
  const DUR = { opd: 30, online: 30, home: 60 };
  const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
  const pad = (n) => String(n).padStart(2, "0");

  const Store = {
    load, save, uid, DUR,
    add(type, rec, action) {
      const db = load();
      const r = Object.assign({ id: uid(type === "orders" ? "ORD" : type === "appointments" ? "VMP" : "REC"), createdAt: new Date().toISOString() }, rec);
      db[type].unshift(r);
      db.log.unshift({ at: r.createdAt, who: rec.by || "website", action: action || ("New " + type.slice(0, -1)), ref: r.id });
      save(db);
      if (window.VMPAuto) window.VMPAuto.handle(type, null, r);
      return r;
    },
    update(type, id, patch, action, who) {
      const db = load();
      const r = db[type].find((x) => x.id === id); if (!r) return null;
      const before = Object.assign({}, r);
      Object.assign(r, patch, { updatedAt: new Date().toISOString() });
      if (action) db.log.unshift({ at: new Date().toISOString(), who: who || "admin", action, ref: id });
      save(db);
      if (window.VMPAuto) window.VMPAuto.handle(type, before, r);
      return r;
    },
    remove(type, id) { const db = load(); db[type] = db[type].filter((x) => x.id !== id); save(db); },
    /* All slots share one clinician — so OPD, home and online can never overlap. */
    slots(dateStr, mode) {
      const d = new Date(dateStr + "T00:00:00");
      if (!window.BUSINESS.open.days.includes(d.getDay())) return { closed: true, list: [] };
      const db = load();
      const busy = db.appointments
        .filter((a) => a.date === dateStr && (a.status === "requested" || a.status === "confirmed"))
        .map((a) => [toMin(a.time), toMin(a.time) + DUR[a.mode]]);
      db.blocked.filter((b) => b.date === dateStr).forEach((b) => busy.push(b.time ? [toMin(b.time), toMin(b.time) + 30] : [0, 24 * 60]));
      const now = new Date(); const isToday = now.toDateString() === d.toDateString();
      const dur = DUR[mode]; const step = mode === "home" ? 60 : 30;
      const list = [];
      for (let m = window.BUSINESS.open.start * 60; m + dur <= window.BUSINESS.open.end * 60; m += step) {
        const t = pad(Math.floor(m / 60)) + ":" + pad(m % 60);
        const clash = busy.some(([s, e]) => m < e && m + dur > s);
        const past = isToday && m <= now.getHours() * 60 + now.getMinutes() + 60;
        list.push({ t, free: !clash && !past });
      }
      return { closed: false, list };
    },
    isFree(dateStr, time, mode) { const s = Store.slots(dateStr, mode); const x = s.list.find((l) => l.t === time); return !!(x && x.free); },
    fmtTime(t) { const [h, m] = t.split(":").map(Number); const ap = h >= 12 ? "PM" : "AM"; return ((h + 11) % 12 + 1) + ":" + pad(m) + " " + ap; },
    reset() { save(empty()); },
    empty
  };
  window.VMPStore = Store;
})();
