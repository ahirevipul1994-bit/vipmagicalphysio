/* Admin v2 — Website content editor (publishes to the live site via VMPCMS) */
const arr2o = (a) => ({ en: (a || [])[0] || "", mr: (a || [])[1] || "", hi: (a || [])[2] || "" });
const o2arr = (o) => [o.en || "", o.mr || "", o.hi || ""];
const lines = (s) => String(s || "").split("\n").map((x) => x.trim()).filter(Boolean);
const ytId = (u) => { const m = String(u).match(/(?:v=|youtu\.be\/|shorts\/|embed\/)([\w-]{11})/); return m ? m[1] : /^[\w-]{11}$/.test(u) ? u : null; };

const HOME_KEYS = [
  ["Hero", ["hero_kicker", "tagline_a", "tagline_b", "hero_intro", "years"]],
  ["Google review strip", ["rv_strip_title", "rv_strip_body", "rv_button"]],
  ["Section headings", ["sec_services_h", "sec_services_p", "sec_about_h", "sec_about_p", "sec_why_h", "sec_how_h", "sec_modes_h", "sec_edu_h", "sec_edu_p", "sec_store_h", "sec_store_p", "sec_map_h"]],
  ["Clinic, fees & visits", ["address", "hours_short", "sunday_closed", "call_before", "mode_opd_p", "mode_home_p", "mode_online_p", "fee_opd", "fee_home", "fee_online", "online_limit", "home_limit"]],
  ["About Dr. Vipul", ["ab_qual_v", "ab_exp_v", "ab_areas_v", "ab_edu_v", "ab_h", "ab_p1", "ab_p2"]],
  ["Safety & footer", ["emergency", "ft_about"]]
];

function ContentEditor() {
  const [draft, setDraft] = useState(() => CMS.effective());
  const [dirty, setDirty] = useState(false);
  const [sec, setSec] = useState("business");
  const D = window.CMS_DEFAULTS;
  const set = (fn) => { setDraft((d) => { const n = JSON.parse(JSON.stringify(d)); fn(n); return n; }); setDirty(true); };

  const publish = () => {
    const ui = {}; Object.keys(draft.ui).forEach((k) => { if (JSON.stringify(draft.ui[k]) !== JSON.stringify(D.ui[k])) ui[k] = draft.ui[k]; });
    const services = {}; Object.keys(draft.services).forEach((k) => { if (JSON.stringify(draft.services[k]) !== JSON.stringify(D.services[k])) services[k] = draft.services[k]; });
    CMS.save({ business: draft.business, ui, services, serviceMeta: draft.serviceMeta, ebooks: draft.ebooks, ebookText: draft.ebookText, videos: draft.videos, announcement: draft.announcement });
    CMS.apply();
    mutate(() => {}, "Website content published", Object.keys(ui).length + " text · " + Object.keys(services).length + " services");
    setDirty(false); toast("Published — the live website is updated", "ok");
  };
  const discard = () => { setDraft(CMS.effective()); setDirty(false); };
  const resetAll = () => { if (confirm("Reset ALL website content to the original version?")) { CMS.reset(); CMS.apply(); setDraft(CMS.effective()); setDirty(false); toast("Content reset to original"); } };

  const SECS = [["business", "Clinic details"], ["announce", "Announcement bar"], ["home", "Homepage & page text"], ["services", "Service pages"], ["ebooks", "Ebooks & prices"], ["videos", "YouTube videos"], ["faq", "FAQ"], ["alltext", "All text (search)"]];
  return (
    <div className="cms">
      <div className="cms-bar">
        <Seg value={sec} options={SECS} onChange={setSec} />
        <div className="row">
          {dirty && <span className="dirty">● Unpublished changes</span>}
          <a className="btn-s ghost" href="index.html" target="_blank">Preview site ↗</a>
          <button className="btn-s ghost" onClick={discard} disabled={!dirty}>Discard</button>
          <button className="btn-s" onClick={publish} disabled={!dirty}>Publish to website</button>
        </div>
      </div>
      {sec === "business" && <BusinessEd d={draft} set={set} />}
      {sec === "announce" && <AnnounceEd d={draft} set={set} />}
      {sec === "home" && <HomeEd d={draft} set={set} />}
      {sec === "services" && <ServiceEd d={draft} set={set} />}
      {sec === "ebooks" && <EbookEd d={draft} set={set} />}
      {sec === "videos" && <VideoEd d={draft} set={set} />}
      {sec === "faq" && <FaqEd d={draft} set={set} />}
      {sec === "alltext" && <AllTextEd d={draft} set={set} />}
      <p className="muted small" style={{ marginTop: 18 }}>Last published: {draft.updatedAt ? fmtD(draft.updatedAt) : "never (original content)"} · <button className="linkbtn" onClick={resetAll}>Reset everything to original</button></p>
    </div>
  );
}

function BusinessEd({ d, set }) {
  const b = d.business;
  const DAYN = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return (
    <Panel title="Clinic details" right={<span className="muted small">Used in header, footer, map, booking slots, WhatsApp and Google links</span>}>
      <div className="fg">
        <F label="Phone / WhatsApp (10 digits)"><input value={b.phone} onChange={(e) => set((n) => (n.business.phone = e.target.value))} /></F>
        <F label="Google review link" hint="From Google Business Profile → Ask for reviews"><input value={b.reviewUrl} onChange={(e) => set((n) => (n.business.reviewUrl = e.target.value))} /></F>
        <F label="Google Maps directions link"><input value={b.mapsUrl} onChange={(e) => set((n) => (n.business.mapsUrl = e.target.value))} /></F>
        <F label="Google Maps embed URL" hint="Use your Business Profile place for an exact pin"><input value={b.mapsEmbed} onChange={(e) => set((n) => (n.business.mapsEmbed = e.target.value))} /></F>
        <F label="YouTube channel"><input value={b.youtube} onChange={(e) => set((n) => { n.business.youtube = e.target.value; n.business.youtubeSub = e.target.value + "?sub_confirmation=1"; })} /></F>
        <F label="Instagram"><input value={b.instagram} onChange={(e) => set((n) => (n.business.instagram = e.target.value))} /></F>
        <F label="Opening time"><select value={b.open.start} onChange={(e) => set((n) => (n.business.open.start = +e.target.value))}>{[6, 7, 8, 9, 10, 11].map((h) => <option key={h} value={h}>{h}:00 AM</option>)}</select></F>
        <F label="Closing time"><select value={b.open.end} onChange={(e) => set((n) => (n.business.open.end = +e.target.value))}>{[13, 14, 15, 16, 17, 18, 19, 20, 21].map((h) => <option key={h} value={h}>{h - 12}:00 PM</option>)}</select></F>
        <F label="Working days" span>
          <div className="row">{DAYN.map((dn, i) => <button key={i} className={"daybtn" + (b.open.days.includes(i) ? " on" : "")} onClick={() => set((n) => { const s = new Set(n.business.open.days); s.has(i) ? s.delete(i) : s.add(i); n.business.open.days = [...s].sort(); })}>{dn}</button>)}</div>
        </F>
      </div>
      <div className="note" style={{ marginTop: 14 }}>Changing hours also changes the bookable slots on the website. Remember to update the visible hours text ("Homepage & page text → Clinic") and your Google Business Profile too, so they all match.</div>
    </Panel>
  );
}

function AnnounceEd({ d, set }) {
  const a = d.announcement;
  return (
    <Panel title="Announcement bar" right={<Toggle on={a.active} onChange={(v) => set((n) => (n.announcement.active = v))} label={a.active ? "Showing on website" : "Hidden"} />}>
      <p className="muted">A thin bar above the header — for holidays, new ebook launches or camp dates.</p>
      <div className="row" style={{ marginBottom: 12 }}><span className="muted small">Colour</span><Seg value={a.tone} options={[["sun", "Yellow"], ["teal", "Teal"], ["red", "Red"]]} onChange={(v) => set((n) => (n.announcement.tone = v))} /></div>
      <Tri label="Message" value={a.text} onChange={(v) => set((n) => (n.announcement.text = v))} />
      {a.active && a.text.en && <div className="ann-prev" data-tone={a.tone}>{a.text.en}</div>}
    </Panel>
  );
}

function UIField({ d, set, k }) {
  const v = d.ui[k]; if (!Array.isArray(v) || typeof v[0] !== "string") return null;
  const long = (v[0] || "").length > 70;
  const changed = JSON.stringify(v) !== JSON.stringify(window.CMS_DEFAULTS.ui[k]);
  return <div className="uif"><Tri label={<>{k.replace(/_/g, " ")} {changed && <span className="chg">edited</span>}</>} rows={long ? 3 : 1} value={arr2o(v)} onChange={(o) => set((n) => (n.ui[k] = o2arr(o)))} /></div>;
}
function HomeEd({ d, set }) {
  const [g, setG] = useState(0);
  return (
    <div className="split">
      <nav className="subnav">{HOME_KEYS.map(([t], i) => <button key={t} className={g === i ? "on" : ""} onClick={() => setG(i)}>{t}</button>)}</nav>
      <Panel title={HOME_KEYS[g][0]}>{HOME_KEYS[g][1].map((k) => <UIField key={k} d={d} set={set} k={k} />)}</Panel>
    </div>
  );
}

function ListTri({ label, value, onChange }) {
  const v = value || { en: [], mr: [], hi: [] };
  return (
    <div className="tri"><div className="tri-h"><b>{label}</b><span className="muted small">one item per line</span></div>
      <div className="tri-g">{LANGS3.map(([k, l]) => <label key={k}><small>{l}</small><textarea rows={4} lang={k} value={(v[k] || []).join("\n")} onChange={(e) => onChange({ ...v, [k]: lines(e.target.value) })} /></label>)}</div>
    </div>
  );
}
function ServiceEd({ d, set }) {
  const slugs = d.serviceMeta.map((m) => m.slug);
  const [slug, setSlug] = useState(slugs[0]);
  const s = d.services[slug]; const meta = d.serviceMeta.find((m) => m.slug === slug);
  const up = (field, val) => set((n) => (n.services[slug][field] = val));
  const faqRows = (s.faq.en || []).map((_, i) => ({ q: { en: s.faq.en[i][0], mr: (s.faq.mr[i] || [])[0] || "", hi: (s.faq.hi[i] || [])[0] || "" }, a: { en: s.faq.en[i][1], mr: (s.faq.mr[i] || [])[1] || "", hi: (s.faq.hi[i] || [])[1] || "" } }));
  const saveFaq = (rows) => up("faq", { en: rows.map((r) => [r.q.en, r.a.en]), mr: rows.map((r) => [r.q.mr, r.a.mr]), hi: rows.map((r) => [r.q.hi, r.a.hi]) });
  const [addV, setAddV] = useState("");
  return (
    <div className="split">
      <nav className="subnav">{slugs.map((x) => <button key={x} className={slug === x ? "on" : ""} onClick={() => setSlug(x)}>{d.services[x].title.en}{JSON.stringify(d.services[x]) !== JSON.stringify(window.CMS_DEFAULTS.services[x]) && <i className="dotc"></i>}</button>)}</nav>
      <div>
        <Panel title={s.title.en} right={<a className="btn-s ghost" href={"index.html#/en/services/" + slug} target="_blank">View page ↗</a>}>
          <Tri label="Page title" value={s.title} onChange={(v) => up("title", v)} />
          <Tri label="Short description (cards)" rows={2} value={s.short} onChange={(v) => up("short", v)} />
          <Tri label="Who it may help" rows={2} value={s.who} onChange={(v) => up("who", v)} />
          <Tri label="Introduction" rows={3} value={s.intro} onChange={(v) => up("intro", v)} />
          <ListTri label="Common problems" value={s.symptoms} onChange={(v) => up("symptoms", v)} />
          <ListTri label="Treatment & exercise approach" value={s.approach} onChange={(v) => up("approach", v)} />
          <ListTri label="See a doctor first if (red flags)" value={s.red} onChange={(v) => up("red", v)} />
        </Panel>
        <Panel title="FAQ on this page" right={<button className="btn-s ghost" onClick={() => saveFaq([...faqRows, { q: { en: "", mr: "", hi: "" }, a: { en: "", mr: "", hi: "" } }])}>+ Add question</button>}>
          {faqRows.map((r, i) => <div className="faq-ed" key={i}>
            <Tri label={"Question " + (i + 1)} value={r.q} onChange={(v) => { const rows = [...faqRows]; rows[i] = { ...r, q: v }; saveFaq(rows); }} />
            <Tri label="Answer" rows={2} value={r.a} onChange={(v) => { const rows = [...faqRows]; rows[i] = { ...r, a: v }; saveFaq(rows); }} />
            <button className="linkbtn danger" onClick={() => saveFaq(faqRows.filter((_, j) => j !== i))}>Remove question</button>
          </div>)}
        </Panel>
        <Panel title="Videos shown on this page">
          <div className="vchips">{meta.videos.map((id) => { const v = d.videos.find((x) => x.id === id); return <span className="vchip" key={id}><img src={"https://i.ytimg.com/vi/" + id + "/default.jpg"} alt="" />{v ? v.t.slice(0, 40) : id}<button onClick={() => set((n) => { const m = n.serviceMeta.find((x) => x.slug === slug); m.videos = m.videos.filter((x) => x !== id); })}>×</button></span>; })}</div>
          <div className="row" style={{ marginTop: 10 }}>
            <select value={addV} onChange={(e) => setAddV(e.target.value)}><option value="">Add a video from your library…</option>{d.videos.filter((v) => !meta.videos.includes(v.id)).map((v) => <option key={v.id} value={v.id}>{v.t}</option>)}</select>
            <button className="btn-s" disabled={!addV} onClick={() => { set((n) => n.serviceMeta.find((x) => x.slug === slug).videos.push(addV)); setAddV(""); }}>Add</button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function EbookEd({ d, set }) {
  const [sel, setSel] = useState(d.ebooks[0] && d.ebooks[0].id);
  const b = d.ebooks.find((x) => x.id === sel);
  const tx = b && (d.ebookText[b.id] || { blurb: { en: "", mr: "", hi: "" }, for: { en: "", mr: "", hi: "" } });
  const upB = (k, v) => set((n) => (n.ebooks.find((x) => x.id === sel)[k] = v));
  const addBook = () => {
    const id = "ebook-" + Date.now().toString(36);
    set((n) => { n.ebooks.push({ id, title: "New ebook", lang: "mr", price: 199, hue: "#14365c", accent: "#f2b33d", active: false }); n.ebookText[id] = { blurb: { en: "", mr: "", hi: "" }, for: { en: "", mr: "", hi: "" } }; });
    setSel(id);
  };
  const PALETTES = [["#14365c", "#f2b33d"], ["#0d7f7a", "#ffe7b8"], ["#8a3b1e", "#ffd28a"], ["#3d2a6b", "#f6c453"], ["#1f5e3a", "#e9f3c6"], ["#9b2c4a", "#ffd6c9"]];
  return (
    <div className="split">
      <nav className="subnav">
        {d.ebooks.map((x) => <button key={x.id} className={sel === x.id ? "on" : ""} onClick={() => setSel(x.id)}>{x.titleLatin || x.title}<small>₹{x.price} · {x.active === false ? "hidden" : "on sale"}</small></button>)}
        <button className="add" onClick={addBook}>+ Add new ebook</button>
        <button className="add" style={{ borderTop: 0, marginTop: 0 }} onClick={() => { const id = "bundle-" + Date.now().toString(36); set((n) => { n.ebooks.push({ id, type: "bundle", title: "New bundle", lang: "en", price: 999, items: [], hue: "#0e2742", accent: "#f2b33d", active: false }); n.ebookText[id] = { blurb: { en: "", mr: "", hi: "" }, for: { en: "", mr: "", hi: "" } }; }); setSel(id); }}>+ Add bundle</button>
      </nav>
      {b && <Panel title={b.titleLatin || b.title} right={<Toggle on={b.active !== false} onChange={(v) => upB("active", v)} label={b.active !== false ? "On sale" : "Hidden from store"} />}>
        <div className="ebook-ed">
          <div className="mini-cover" style={{ background: b.hue, color: b.accent }} title={b.type === "bundle" ? "Bundle" : ""}><small>Dard E Body Care</small><b lang={b.lang}>{b.title}</b><i style={{ background: b.accent }}></i><span>Dr. Vipul Ahire</span></div>
          <div className="fg">
            <F label="Title (as printed)"><input value={b.title} lang={b.lang} onChange={(e) => upB("title", e.target.value)} /></F>
            <F label="Title in English letters (optional)"><input value={b.titleLatin || ""} onChange={(e) => upB("titleLatin", e.target.value)} /></F>
            <F label="Price (₹, incl. tax)"><input type="number" min="0" value={b.price} onChange={(e) => upB("price", Math.max(0, +e.target.value))} /></F>
            <F label="Compare-at price (₹, optional strike-through)"><input type="number" min="0" value={b.compareAt || ""} onChange={(e) => upB("compareAt", +e.target.value || 0)} /></F>
            <F label="Pay what you want"><Toggle on={!!b.pwyw} onChange={(v) => set((n) => { const x = n.ebooks.find((y) => y.id === sel); x.pwyw = v; x.minPrice = x.minPrice || Math.round(x.price * 0.6); x.suggested = x.suggested || x.price; })} label={b.pwyw ? "Buyer chooses ≥ minimum" : "Fixed price"} /></F>
            {b.pwyw && <F label="Minimum price (₹)"><input type="number" min="0" value={b.minPrice || 0} onChange={(e) => upB("minPrice", Math.max(0, +e.target.value))} /></F>}
            <F label="Pages"><input type="number" value={b.pages || ""} onChange={(e) => upB("pages", +e.target.value || "")} /></F>
            <F label="File size label"><input value={b.size || ""} placeholder="e.g. 4.2 MB" onChange={(e) => upB("size", e.target.value)} /></F>
            {b.type === "bundle" && <F label="Books in this bundle" span><div className="row">{d.ebooks.filter((x) => x.type !== "bundle").map((x) => <label key={x.id} className="tag" style={{ cursor: "pointer" }}><input type="checkbox" style={{ minHeight: "auto" }} checked={(b.items || []).includes(x.id)} onChange={(e) => set((n) => { const y = n.ebooks.find((z) => z.id === sel); const s = new Set(y.items || []); e.target.checked ? s.add(x.id) : s.delete(x.id); y.items = [...s]; })} />{x.titleLatin || x.title}</label>)}</div></F>}
            <F label="Book language"><select value={b.lang} onChange={(e) => upB("lang", e.target.value)}>{LANGS3.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
            <F label="Cover colours" span><div className="row">{PALETTES.map(([h, a]) => <button key={h} className={"pal" + (b.hue === h ? " on" : "")} style={{ background: h }} onClick={() => set((n) => { const x = n.ebooks.find((y) => y.id === sel); x.hue = h; x.accent = a; })}><i style={{ background: a }}></i></button>)}</div></F>
            <F label="PDF file" span hint="Production: uploaded to a private Supabase Storage bucket; buyers get a signed link."><div className="drop">Drop PDF here · {b.file || "no file yet"}<input type="file" accept="application/pdf" onChange={(e) => e.target.files[0] && upB("file", e.target.files[0].name)} /></div></F>
          </div>
        </div>
        <Tri label="Description" rows={3} value={tx.blurb} onChange={(v) => set((n) => { n.ebookText[sel] = n.ebookText[sel] || {}; n.ebookText[sel].blurb = v; n.ebookText[sel].for = n.ebookText[sel].for || tx.for; })} />
        <Tri label="Who it is for" rows={2} value={tx.for} onChange={(v) => set((n) => { n.ebookText[sel] = n.ebookText[sel] || {}; n.ebookText[sel].for = v; n.ebookText[sel].blurb = n.ebookText[sel].blurb || tx.blurb; })} />
        <div className="row" style={{ justifyContent: "space-between", marginTop: 8 }}>
          <a className="btn-s ghost" href={"index.html#/en/store/" + b.id} target="_blank">View product page ↗</a>
          <button className="linkbtn danger" onClick={() => { if (confirm("Delete this ebook from the store?")) { set((n) => { n.ebooks = n.ebooks.filter((x) => x.id !== sel); }); setSel(d.ebooks[0].id); } }}>Delete ebook</button>
        </div>
      </Panel>}
    </div>
  );
}

function VideoEd({ d, set }) {
  const [url, setUrl] = useState(""); const [title, setTitle] = useState(""); const [topic, setTopic] = useState("general");
  const TOPICS = ["back", "neck", "knee", "shoulder", "stroke", "ortho", "general"];
  const add = () => {
    const id = ytId(url); if (!id) return toast("Paste a valid YouTube link", "warn");
    if (d.videos.some((v) => v.id === id)) return toast("Already in library", "warn");
    set((n) => n.videos.unshift({ id, t: title || "New video", v: 0, topic })); setUrl(""); setTitle(""); toast("Video added");
  };
  return (
    <>
      <Panel title="Add a YouTube video">
        <div className="fg" style={{ gridTemplateColumns: "2fr 2fr 1fr auto" }}>
          <F label="YouTube link"><input value={url} placeholder="https://youtu.be/…" onChange={(e) => setUrl(e.target.value)} /></F>
          <F label="Title"><input value={title} onChange={(e) => setTitle(e.target.value)} /></F>
          <F label="Topic"><select value={topic} onChange={(e) => setTopic(e.target.value)}>{TOPICS.map((t) => <option key={t}>{t}</option>)}</select></F>
          <F label=" "><button className="btn-s" onClick={add}>Add</button></F>
        </div>
      </Panel>
      <Panel title={"Video library (" + d.videos.length + ")"} right={<span className="muted small">Shown on Videos page, sorted by views</span>}>
        <div className="vlist">{d.videos.map((v, i) => <div className="vrow" key={v.id}>
          <img src={"https://i.ytimg.com/vi/" + v.id + "/mqdefault.jpg"} alt="" />
          <input value={v.t} onChange={(e) => set((n) => (n.videos[i].t = e.target.value))} />
          <select value={v.topic} onChange={(e) => set((n) => (n.videos[i].topic = e.target.value))}>{TOPICS.map((t) => <option key={t}>{t}</option>)}</select>
          <input type="number" className="w80" value={v.v} title="Views" onChange={(e) => set((n) => (n.videos[i].v = +e.target.value))} />
          <button className="linkbtn danger" onClick={() => set((n) => { n.videos.splice(i, 1); n.serviceMeta.forEach((m) => (m.videos = m.videos.filter((x) => x !== v.id))); })}>Remove</button>
        </div>)}</div>
      </Panel>
    </>
  );
}

function FaqEd({ d, set }) {
  const rows = d.ui.faq.map((r) => ({ q: { en: r[0][0], mr: r[1][0], hi: r[2][0] }, a: { en: r[0][1], mr: r[1][1], hi: r[2][1] } }));
  const save = (rs) => set((n) => (n.ui.faq = rs.map((r) => [[r.q.en, r.a.en], [r.q.mr, r.a.mr], [r.q.hi, r.a.hi]])));
  return (
    <Panel title="FAQ page" right={<button className="btn-s ghost" onClick={() => save([...rows, { q: { en: "", mr: "", hi: "" }, a: { en: "", mr: "", hi: "" } }])}>+ Add question</button>}>
      {rows.map((r, i) => <div className="faq-ed" key={i}>
        <Tri label={"Question " + (i + 1)} value={r.q} onChange={(v) => { const x = [...rows]; x[i] = { ...r, q: v }; save(x); }} />
        <Tri label="Answer" rows={2} value={r.a} onChange={(v) => { const x = [...rows]; x[i] = { ...r, a: v }; save(x); }} />
        <div className="row"><button className="linkbtn" disabled={!i} onClick={() => { const x = [...rows]; [x[i - 1], x[i]] = [x[i], x[i - 1]]; save(x); }}>↑ Move up</button><button className="linkbtn danger" onClick={() => save(rows.filter((_, j) => j !== i))}>Remove</button></div>
      </div>)}
    </Panel>
  );
}

function AllTextEd({ d, set }) {
  const [q, setQ] = useState("");
  const keys = Object.keys(d.ui).filter((k) => Array.isArray(d.ui[k]) && typeof d.ui[k][0] === "string");
  const hits = keys.filter((k) => !q || (k + " " + d.ui[k].join(" ")).toLowerCase().includes(q.toLowerCase())).slice(0, 40);
  return (
    <Panel title="Every word on the website" right={<span className="muted small">{keys.length} text items × 3 languages</span>}>
      <input className="search" placeholder="Search any word in English, मराठी or हिंदी… (e.g. 'fee', 'Sunday', 'शुल्क')" value={q} onChange={(e) => setQ(e.target.value)} />
      {hits.map((k) => <UIField key={k} d={d} set={set} k={k} />)}
      {hits.length === 40 && <p className="muted small">Showing first 40 — refine your search.</p>}
    </Panel>
  );
}

Object.assign(window, { ContentEditor });
