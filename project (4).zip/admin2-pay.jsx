/* Admin v2 — Store & payments: sales, orders, coupons, ratings, payment links, ledger, Razorpay setup */
function Payments({ db, openContact, plSeed, clearPlSeed }) {
  const [tab, setTab] = useState(plSeed ? "links" : "sales");
  useEffect(() => { if (plSeed) setTab("links"); }, [plSeed]);
  const T = [["sales", "Sales dashboard"], ["orders", "Ebook orders"], ["links", "Payment links"], ["ledger", "All payments"], ["coupons", "Coupons"], ["ratings", "Ratings"], ["setup", "Razorpay setup"]];
  return (
    <>
      <div className="toolbar"><Seg value={tab} options={T} onChange={setTab} /></div>
      {tab === "sales" && <Sales db={db} />}
      {tab === "orders" && <Orders db={db} openContact={openContact} />}
      {tab === "links" && <PayLinks db={db} seed={plSeed} clearSeed={clearPlSeed} openContact={openContact} />}
      {tab === "ledger" && <Ledger db={db} openContact={openContact} />}
      {tab === "coupons" && <Coupons db={db} />}
      {tab === "ratings" && <Ratings db={db} />}
      {tab === "setup" && <RzSetup db={db} />}
    </>
  );
}

function Sales({ db }) {
  const [range, setRange] = useState(30);
  const since = new Date(Date.now() - range * 86400000).toISOString();
  const orders = db.orders.filter((o) => (o.createdAt || "") >= since);
  const paid = orders.filter((o) => o.status === "paid");
  const created = orders.length;
  const gross = paid.reduce((s, o) => s + (o.amount || 0), 0);
  const disc = paid.reduce((s, o) => s + (o.discount || 0), 0);
  const refunded = orders.filter((o) => o.status === "refunded").reduce((s, o) => s + o.amount, 0);
  const fees = Math.round(gross * 0.0236);
  const days = Array.from({ length: Math.min(range, 30) }, (_, i) => { const d = new Date(Date.now() - (Math.min(range, 30) - 1 - i) * 86400000); const k = d.toISOString().slice(0, 10); return { k, l: d.getDate(), v: paid.filter((o) => (o.createdAt || "").slice(0, 10) === k).reduce((s, o) => s + o.amount, 0) }; });
  const max = Math.max(1, ...days.map((d) => d.v));
  const byP = (window.CMS_ALL_EBOOKS || window.EBOOKS).map((b) => { const ps = paid.filter((o) => o.product === b.id); return { b, n: ps.length, v: ps.reduce((s, o) => s + o.amount, 0) }; }).sort((a, b) => b.v - a.v);
  return (
    <>
      <div className="row" style={{ marginBottom: 12 }}><Seg value={range} options={[[7, "7 days"], [30, "30 days"], [90, "90 days"], [365, "12 months"]]} onChange={setRange} /></div>
      <div className="kpis">
        <KPI label="Ebook revenue" value={inr(gross)} sub={paid.length + " sales"} tone="#0d7f7a" />
        <KPI label="Est. Razorpay fees" value={inr(fees)} sub="≈2% + GST" />
        <KPI label="Net to bank (est.)" value={inr(gross - fees - refunded)} />
        <KPI label="Checkout conversion" value={created ? Math.round((paid.length / created) * 100) + "%" : "—"} sub={created + " checkouts started"} />
        <KPI label="Coupon discounts" value={inr(disc)} sub={"Refunded " + inr(refunded)} />
      </div>
      <div className="two">
        <Panel title="Daily sales">
          <div className="bars thin">{days.map((d) => <div className="bar-col" key={d.k} title={d.k + " · " + inr(d.v)}><div className="bar" style={{ height: (d.v / max) * 150 + 2 }}></div><small>{d.l}</small></div>)}</div>
        </Panel>
        <Panel title="By product">
          {byP.map(({ b, n, v }) => <div className="row-mini" key={b.id}><span className="swatch" style={{ background: b.hue }}></span><span><b>{b.titleLatin || b.title}</b><div className="muted small">₹{b.price} · {b.active === false ? "hidden" : "on sale"}</div></span><b>{n}</b><b style={{ minWidth: 80, textAlign: "right" }}>{inr(v)}</b></div>)}
          <p className="muted small">Edit titles, prices, files and bundles in Website content → Ebooks & prices.</p>
        </Panel>
      </div>
    </>
  );
}

function Orders({ db, openContact }) {
  const [st, setSt] = useState("all"); const [q, setQ] = useState("");
  const list = db.orders.filter((o) => (st === "all" || o.status === st) && (!q || (o.id + o.name + o.email + o.title).toLowerCase().includes(q.toLowerCase())));
  const refund = (o) => {
    if (!confirm(`Refund ${inr(o.amount)} to ${o.name}? Money returns to their account in 5–7 days via Razorpay.`)) return;
    S.update("orders", o.id, { status: "refunded" }, "Refund issued " + inr(o.amount));
    mutate((d) => { const p = (d.payments || []).find((x) => x.ref === o.id); if (p) p.status = "refunded"; });
    toast("Refund recorded (live: sent via Razorpay API)", "ok");
  };
  const resend = (o) => { S.update("orders", o.id, { downloads: {} }, "Download links reset & resent"); toast("Download count reset · email resent", "ok"); };
  const exportCsv = () => { const rows = [["order", "date", "name", "email", "mobile", "product", "base", "discount", "coupon", "amount", "status", "payment_id"]].concat(list.map((o) => [o.id, o.createdAt, o.name, o.email, o.mobile, o.title, o.base ?? o.amount, o.discount || 0, o.coupon || "", o.amount, o.status, o.paymentId || ""])); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map((r) => r.map((x) => '"' + String(x ?? "").replace(/"/g, '""') + '"').join(",")).join("\n")], { type: "text/csv" })); a.download = "ebook-orders.csv"; a.click(); };
  return (
    <Panel title="Ebook orders" right={<><select value={st} onChange={(e) => setSt(e.target.value)}><option value="all">All</option>{["paid", "created", "abandoned", "failed", "refunded"].map((s) => <option key={s}>{s}</option>)}</select><input className="search" placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} /><button className="btn-s ghost" onClick={exportCsv}>Export CSV</button></>}>
      <div className="tbl-wrap"><table className="tbl">
        <thead><tr><th>Order</th><th>Date</th><th>Buyer</th><th>Product</th><th>Amount</th><th>Status</th><th>Downloads</th><th></th></tr></thead>
        <tbody>{list.map((o) => { const dl = typeof o.downloads === "object" && o.downloads ? Object.values(o.downloads).reduce((a, b) => a + b, 0) : o.downloads || 0;
          return <tr key={o.id}><td className="mono">{o.id}</td><td>{fmtD(o.createdAt)}</td><td><button className="linkbtn" onClick={() => openContact(o.mobile || o.email)}><b>{o.name}</b></button><div className="muted small">{o.email}</div></td>
            <td>{o.title}{o.coupon && <div className="muted small">coupon {o.coupon} −₹{o.discount}</div>}</td><td>{inr(o.amount)}</td><td><Badge s={o.status === "abandoned" ? "skipped" : o.status}>{o.status}</Badge></td><td>{o.status === "paid" ? dl + " / " + (o.maxDownloads || 5) : "—"}</td>
            <td className="acts">{o.status === "paid" && <><button onClick={() => resend(o)}>Resend link</button><button onClick={() => refund(o)}>Refund</button></>}{["failed", "abandoned"].includes(o.status) && <a className="mini" href={"mailto:" + o.email + "?subject=Complete your order&body=" + encodeURIComponent("Hello " + o.name + ", your order for " + o.title + " was not completed. You can finish it here: " + AU.siteBase() + "#/en/store/" + o.product)}>Recover</a>}</td></tr>; })}
          {!list.length && <tr><td colSpan="8"><Empty>No orders.</Empty></td></tr>}</tbody></table></div>
    </Panel>
  );
}

function PayLinks({ db, seed, clearSeed, openContact }) {
  const fees = (db.settings && db.settings.fees) || { opd: 500, home: 800, online: 400 };
  const blank = () => ({ name: "", mobile: "", email: "", lang: "mr", purpose: "", amount: "", due: new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10), kind: "service" });
  const [f, setF] = useState(blank());
  const [open, setOpen] = useState(false);
  useEffect(() => { if (seed) { setF({ ...blank(), name: seed.name || "", mobile: seed.mobile || "", email: seed.email || "", lang: seed.lang || "mr", purpose: seed.purpose || "", amount: seed.amount || "" }); setOpen(true); clearSeed && clearSeed(); } }, [seed]);
  const create = () => {
    if (!f.name || normMobile(f.mobile).length !== 10 || !(+f.amount > 0) || !f.purpose) return toast("Name, mobile, purpose and amount are required", "warn");
    S.add("paylinks", { ...f, mobile: normMobile(f.mobile), amount: +f.amount, status: "unpaid", by: "admin" }, "Payment link created " + inr(f.amount));
    const pl = S.load().paylinks[0];
    const m = S.load().outbox.find((x) => x.ref === pl.id && x.status === "ready");
    if (m) { window.open(AU.waUrl(m), "_blank"); AU.markSent(m.id); }
    toast("Link created · WhatsApp opened", "ok"); setOpen(false); setF(blank());
  };
  const link = (p) => AU.siteBase() + "#/" + (p.lang || "en") + "/pay/" + p.id;
  const markPaid = (p, method) => {
    S.add("payments", { kind: p.kind, ref: p.id, name: p.name, mobile: p.mobile, purpose: p.purpose, amount: p.amount, method, status: "paid", receipt: "RCPT-" + Date.now().toString().slice(-6), lang: p.lang, by: "admin" }, "Payment recorded (" + method + ")");
    S.update("paylinks", p.id, { status: "paid", paidAt: new Date().toISOString(), paidBy: method }, "Payment link marked paid");
    toast("Marked paid · receipt queued");
  };
  const presets = [["Clinic OPD session", fees.opd, "opd"], ["Home visit session", fees.home, "home"], ["Online consultation", fees.online, "online"], ["10-session package", fees.opd * 9, "package"]];
  const list = (db.paylinks || []);
  return (
    <>
      <Panel title="Payment links" right={<button className="btn-s" onClick={() => setOpen(true)}>+ New payment link</button>}>
        <p className="muted">Send a secure Razorpay link by WhatsApp for sessions, home visits, online consultations or packages. The patient pays by UPI or card; it is recorded here automatically and a receipt is sent. Overdue links get an automatic gentle reminder.</p>
        <div className="tbl-wrap"><table className="tbl">
          <thead><tr><th>Link</th><th>Patient</th><th>For</th><th>Amount</th><th>Due</th><th>Status</th><th></th></tr></thead>
          <tbody>{list.map((p) => { const overdue = p.status === "unpaid" && p.due && p.due < today();
            return <tr key={p.id}><td className="mono">{p.id}</td><td><button className="linkbtn" onClick={() => openContact(p.mobile)}><b>{p.name}</b></button><div className="muted small">{p.mobile}</div></td><td>{p.purpose}</td><td><b>{inr(p.amount)}</b></td><td>{dmy(p.due)}</td>
              <td><Badge s={overdue ? "overdue" : p.status}>{overdue ? "overdue" : p.status}</Badge>{p.paidBy && <div className="muted small">{p.paidBy}</div>}</td>
              <td className="acts">{p.status === "unpaid" && <>
                <button onClick={() => { navigator.clipboard && navigator.clipboard.writeText(link(p)); toast("Link copied"); }}>Copy link</button>
                <a className="mini" href={waTo(p.mobile, AU.fill(AU.rules(db).find((r) => r.id === "r14").tpl[p.lang] || "", { name: p.name, product: p.purpose, amount: p.amount, link: link(p) }))} target="_blank">WhatsApp</a>
                <a className="mini" href={link(p)} target="_blank">Open</a>
                <button onClick={() => markPaid(p, "Cash")}>Paid cash</button><button onClick={() => markPaid(p, "UPI (direct)")}>Paid UPI</button>
                <button onClick={() => S.update("paylinks", p.id, { status: "cancelled" }, "Payment link cancelled")}>Cancel</button></>}</td></tr>; })}
            {!list.length && <tr><td colSpan="7"><Empty>No payment links yet.</Empty></td></tr>}</tbody></table></div>
      </Panel>
      <Modal open={open} onClose={() => setOpen(false)} title="New payment link" width={620}>
        <div className="row" style={{ marginBottom: 12, flexWrap: "wrap" }}>{presets.map(([l, a, k]) => <button key={l} className="mini" onClick={() => setF({ ...f, purpose: l, amount: a, kind: k })}>{l} · {inr(a)}</button>)}</div>
        <div className="fg">
          <F label="Patient name"><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></F>
          <F label="Mobile (WhatsApp)"><input value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} /></F>
          <F label="For (shown to patient)" span><input value={f.purpose} onChange={(e) => setF({ ...f, purpose: e.target.value })} placeholder="e.g. Stroke rehab — 10 home sessions" /></F>
          <F label="Amount (₹)"><input type="number" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} /></F>
          <F label="Due date"><input type="date" value={f.due} onChange={(e) => setF({ ...f, due: e.target.value })} /></F>
          <F label="Message language"><select value={f.lang} onChange={(e) => setF({ ...f, lang: e.target.value })}>{LANGS3.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
          <F label="Email (optional)"><input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></F>
        </div>
        <div className="row end"><button className="btn-s" onClick={create}>Create & send on WhatsApp</button></div>
      </Modal>
    </>
  );
}

function Ledger({ db, openContact }) {
  const [m, setM] = useState(new Date().toISOString().slice(0, 7));
  const [add, setAdd] = useState(false); const [f, setF] = useState({ name: "", mobile: "", purpose: "Clinic OPD session", amount: "", method: "Cash" });
  const list = (db.payments || []).filter((p) => (p.createdAt || "").slice(0, 7) === m);
  const sum = (fn) => list.filter(fn).reduce((s, p) => s + p.amount, 0);
  const byMethod = ["Cash", "UPI", "UPI (direct)", "Razorpay", "Card"].map((k) => [k, sum((p) => p.status === "paid" && p.method === k)]).filter((x) => x[1]);
  const save = () => { if (!f.name || !(+f.amount > 0)) return toast("Name and amount needed", "warn"); S.add("payments", { ...f, mobile: normMobile(f.mobile), amount: +f.amount, kind: "service", status: "paid", receipt: "RCPT-" + Date.now().toString().slice(-6), by: "admin" }, "Manual payment " + inr(f.amount)); setAdd(false); setF({ ...f, name: "", mobile: "", amount: "" }); toast("Payment recorded"); };
  const csv = () => { const rows = [["receipt", "date", "name", "mobile", "for", "kind", "method", "amount", "status", "gateway_id"]].concat(list.map((p) => [p.receipt, p.createdAt, p.name, p.mobile, p.purpose, p.kind, p.method, p.amount, p.status, p.gatewayId || ""])); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map((r) => r.map((x) => '"' + String(x ?? "").replace(/"/g, '""') + '"').join(",")).join("\n")], { type: "text/csv" })); a.download = "payments-" + m + ".csv"; a.click(); };
  return (
    <>
      <div className="kpis" style={{ gridTemplateColumns: "repeat(4,1fr)" }}>
        <KPI label="Collected" value={inr(sum((p) => p.status === "paid"))} tone="#0d7f7a" />
        <KPI label="Services" value={inr(sum((p) => p.status === "paid" && p.kind !== "ebook"))} />
        <KPI label="Ebooks" value={inr(sum((p) => p.status === "paid" && p.kind === "ebook"))} />
        <KPI label="Refunded" value={inr(sum((p) => p.status === "refunded"))} />
      </div>
      <Panel title="All payments" right={<><input type="month" value={m} onChange={(e) => setM(e.target.value)} /><button className="btn-s ghost" onClick={csv}>Export for accountant</button><button className="btn-s" onClick={() => setAdd(true)}>+ Record cash/UPI</button></>}>
        <div className="row small muted" style={{ marginBottom: 8 }}>{byMethod.map(([k, v]) => <span key={k} className="tag">{k}: {inr(v)}</span>)}</div>
        <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Receipt</th><th>Date</th><th>From</th><th>For</th><th>Method</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>{list.map((p) => <tr key={p.id}><td className="mono">{p.receipt}</td><td>{fmtD(p.createdAt)}</td><td><button className="linkbtn" onClick={() => openContact(p.mobile || p.email)}><b>{p.name}</b></button></td><td>{p.purpose}</td><td>{p.method}</td><td><b>{inr(p.amount)}</b></td><td><Badge s={p.status} /></td></tr>)}
            {!list.length && <tr><td colSpan="7"><Empty>No payments this month.</Empty></td></tr>}</tbody></table></div>
      </Panel>
      <Modal open={add} onClose={() => setAdd(false)} title="Record a payment received at the clinic">
        <div className="fg"><F label="Name"><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></F><F label="Mobile"><input value={f.mobile} onChange={(e) => setF({ ...f, mobile: e.target.value })} /></F>
          <F label="For" span><input value={f.purpose} onChange={(e) => setF({ ...f, purpose: e.target.value })} /></F><F label="Amount (₹)"><input type="number" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} /></F>
          <F label="Method"><select value={f.method} onChange={(e) => setF({ ...f, method: e.target.value })}>{["Cash", "UPI (direct)", "Card"].map((x) => <option key={x}>{x}</option>)}</select></F></div>
        <div className="row end"><button className="btn-s" onClick={save}>Save & send receipt</button></div>
      </Modal>
    </>
  );
}

function Coupons({ db }) {
  const [f, setF] = useState({ code: "", type: "pct", value: 20, products: "all", maxUses: "", expires: "" });
  const list = db.coupons || [];
  const add = () => {
    const code = f.code.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (!code || !(+f.value > 0)) return toast("Code and value required", "warn");
    if (list.some((c) => c.code === code)) return toast("Code already exists", "warn");
    mutate((d) => { d.coupons = d.coupons || []; d.coupons.unshift({ code, type: f.type, value: +f.value, products: f.products === "all" ? "all" : [f.products], maxUses: +f.maxUses || 0, expires: f.expires, used: 0, active: true, createdAt: new Date().toISOString() }); }, "Coupon created " + code);
    setF({ ...f, code: "" }); toast("Coupon " + code + " created");
  };
  const books = window.CMS_ALL_EBOOKS || window.EBOOKS;
  return (
    <>
      <Panel title="Create coupon">
        <div className="fg" style={{ gridTemplateColumns: "1.2fr .9fr .7fr 1.3fr .7fr 1fr auto" }}>
          <F label="Code"><input value={f.code} placeholder="DIWALI20" onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} /></F>
          <F label="Type"><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="pct">% off</option><option value="flat">₹ off</option></select></F>
          <F label="Value"><input type="number" value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} /></F>
          <F label="Applies to"><select value={f.products} onChange={(e) => setF({ ...f, products: e.target.value })}><option value="all">All products</option>{books.map((b) => <option key={b.id} value={b.id}>{b.titleLatin || b.title}</option>)}</select></F>
          <F label="Max uses"><input type="number" placeholder="∞" value={f.maxUses} onChange={(e) => setF({ ...f, maxUses: e.target.value })} /></F>
          <F label="Expires"><input type="date" value={f.expires} onChange={(e) => setF({ ...f, expires: e.target.value })} /></F>
          <F label=" "><button className="btn-s" onClick={add}>Create</button></F>
        </div>
        <p className="muted small">Tip: share links like <span className="mono">…/store/stronger-after-40</span> with the code in your YouTube description or Instagram bio.</p>
      </Panel>
      <Panel title="Coupons"><div className="tbl-wrap"><table className="tbl"><thead><tr><th>Code</th><th>Discount</th><th>Applies to</th><th>Used</th><th>Expires</th><th>Active</th><th></th></tr></thead>
        <tbody>{list.map((c) => <tr key={c.code}><td className="mono"><b>{c.code}</b></td><td>{c.type === "pct" ? c.value + "%" : inr(c.value)}</td><td>{c.products === "all" ? "All" : (c.products || []).map((id) => (books.find((b) => b.id === id) || {}).titleLatin || id).join(", ")}</td><td>{c.used || 0}{c.maxUses ? " / " + c.maxUses : ""}</td><td>{c.expires ? dmy(c.expires) : "—"}</td>
          <td><Toggle on={c.active} onChange={(v) => mutate((d) => { d.coupons.find((x) => x.code === c.code).active = v; }, "Coupon " + c.code + (v ? " on" : " off"))} /></td>
          <td><button className="linkbtn danger" onClick={() => mutate((d) => (d.coupons = d.coupons.filter((x) => x.code !== c.code)), "Coupon deleted " + c.code)}>Delete</button></td></tr>)}
          {!list.length && <tr><td colSpan="7"><Empty>No coupons yet.</Empty></td></tr>}</tbody></table></div></Panel>
    </>
  );
}

function Ratings({ db }) {
  const list = db.ratings || [];
  const books = window.CMS_ALL_EBOOKS || window.EBOOKS;
  return <Panel title="Ratings from verified buyers" right={<span className="muted small">Only buyers can rate (from their library). Hide anything abusive — do not hide honest low ratings.</span>}>
    {list.map((r) => <div className="row-mini" key={r.id}><span className="stars-a">{"★".repeat(r.stars)}<i>{"★".repeat(5 - r.stars)}</i></span><span><b>{(books.find((b) => b.id === r.product) || {}).titleLatin || r.product}</b> · {r.name}<div className="muted small">{r.text || "—"} · {fmtD(r.createdAt)}</div></span>
      <button className="mini" onClick={() => mutate((d) => { d.ratings.find((x) => x.id === r.id).hidden = !r.hidden; }, "Rating " + (r.hidden ? "shown" : "hidden"))}>{r.hidden ? "Show" : "Hide"}</button></div>)}
    {!list.length && <Empty>No ratings yet.</Empty>}
  </Panel>;
}

function RzSetup({ db }) {
  const cfg = window.VMP_PAY || {};
  const [f, setF] = useState({ keyId: cfg.keyId || "", mode: cfg.mode || "test", live: !!cfg.live });
  const [fees, setFees] = useState((db.settings && db.settings.fees) || { opd: 500, home: 800, online: 400 });
  const [biz, setBiz] = useState({ legalName: (db.settings || {}).legalName || "VIP MAGICAL PHYSIO", gstin: (db.settings || {}).gstin || "", gstRate: (db.settings || {}).gstRate || 0 });
  const save = () => {
    if (f.live && !/^rzp_(test|live)_\w+$/.test(f.keyId)) return toast("Enter a valid Razorpay Key ID (rzp_test_… or rzp_live_…)", "warn");
    if (f.keyId && /secret/i.test(f.keyId)) return toast("Never paste the Key Secret here", "warn");
    localStorage.setItem("vmp_pay_cfg", JSON.stringify({ keyId: f.keyId, mode: f.keyId.startsWith("rzp_live") ? "live" : "test", live: f.live }));
    mutate((d) => { d.settings = { ...(d.settings || {}), fees: { opd: +fees.opd, home: +fees.home, online: +fees.online }, ...biz }; }, "Payment settings saved");
    toast("Saved — reload the website to apply", "ok");
  };
  const wh = "https://vipmagicalphysio.com/.netlify/functions/razorpay-webhook";
  const steps = [
    ["Razorpay account", "ahirevipul1994@gmail.com — complete KYC & website verification", "https://dashboard.razorpay.com"],
    ["API keys", "Settings → API Keys → Generate. Key ID below; Key Secret only in Netlify env", "https://dashboard.razorpay.com/app/website-app-settings/api-keys"],
    ["Webhook", wh + " · events: payment.captured, payment.failed, refund.processed", "https://dashboard.razorpay.com/app/webhooks"],
    ["Netlify env vars", "RAZORPAY_KEY_ID · RAZORPAY_KEY_SECRET · RAZORPAY_WEBHOOK_SECRET · SUPABASE_URL · SUPABASE_SERVICE_ROLE_KEY · DOWNLOAD_SECRET · BREVO_API_KEY", "https://app.netlify.com"],
    ["Supabase", "Run supabase/schema.sql · upload PDFs to private bucket 'ebooks'", "https://supabase.com/dashboard"]
  ];
  return (
    <div className="two">
      <Panel title="Connect Razorpay">
        <div className="rz-acc"><b>Account</b><span>ahirevipul1994@gmail.com</span><b>Website</b><span>vipmagicalphysio.com</span><b>Status</b><span>{cfg.live ? <Badge s="paid">{(cfg.mode || "test").toUpperCase()} · connected</Badge> : <Badge s="requested">Prototype (simulated)</Badge>}</span></div>
        <div className="fg" style={{ marginTop: 14 }}>
          <F label="Razorpay Key ID (public)" span hint="Starts with rzp_test_ or rzp_live_. The Key SECRET never goes here."><input value={f.keyId} onChange={(e) => setF({ ...f, keyId: e.target.value.trim() })} placeholder="rzp_test_XXXXXXXXXXXX" /></F>
          <F label="Use real Razorpay checkout" span><Toggle on={f.live} onChange={(v) => setF({ ...f, live: v })} label={f.live ? "On — needs the Netlify functions deployed" : "Off — simulated gateway for testing the design"} /></F>
        </div>
        <h3 style={{ marginTop: 16 }}>Default service fees (for payment-link presets)</h3>
        <div className="fg" style={{ gridTemplateColumns: "1fr 1fr 1fr" }}><F label="Clinic OPD ₹"><input type="number" value={fees.opd} onChange={(e) => setFees({ ...fees, opd: e.target.value })} /></F><F label="Home visit ₹"><input type="number" value={fees.home} onChange={(e) => setFees({ ...fees, home: e.target.value })} /></F><F label="Online ₹"><input type="number" value={fees.online} onChange={(e) => setFees({ ...fees, online: e.target.value })} /></F></div>
        <p className="muted small">These are internal defaults only — the website still says fees depend on condition, distance and duration.</p>
        <h3 style={{ marginTop: 16 }}>Receipts & tax</h3>
        <div className="fg"><F label="Name on receipts"><input value={biz.legalName} onChange={(e) => setBiz({ ...biz, legalName: e.target.value })} /></F><F label="GSTIN (if registered)"><input value={biz.gstin} onChange={(e) => setBiz({ ...biz, gstin: e.target.value.toUpperCase() })} /></F></div>
        <div className="row end"><button className="btn-s" onClick={save}>Save settings</button></div>
      </Panel>
      <Panel title="Go-live checklist" right={<a className="btn-s ghost" href="RAZORPAY SETUP.md" target="_blank">Full guide ↗</a>}>
        {steps.map(([h, d, u], i) => <div className="chk" key={h}><span className="chk-n">{i + 1}</span><div><b>{h}</b><div className="muted small" style={{ wordBreak: "break-word" }}>{d}</div></div><a className="mini" href={u} target="_blank">Open</a></div>)}
        <div className="row" style={{ marginTop: 10 }}><span className="mono small" style={{ flex: 1, wordBreak: "break-all" }}>{wh}</span><button className="mini" onClick={() => { navigator.clipboard && navigator.clipboard.writeText(wh); toast("Webhook URL copied"); }}>Copy</button></div>
        <div className="note" style={{ marginTop: 14 }}>Test with Razorpay test UPI <b className="mono">success@razorpay</b> before switching to live keys. Razorpay fee ≈ 2% per transaction + GST, no monthly charge.</div>
      </Panel>
    </div>
  );
}

Object.assign(window, { Payments });
