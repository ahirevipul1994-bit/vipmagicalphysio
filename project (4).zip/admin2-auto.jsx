/* Admin v2 — Automations: rules editor, outbox, activity log, subscribers */
function Automations({ db, openContact }) {
  const [tab, setTab] = useState("outbox");
  const ready = (db.outbox || []).filter((m) => m.status === "ready" && m.channel === "whatsapp").length;
  return (
    <>
      <div className="toolbar"><Seg value={tab} options={[["outbox", "Outbox" + (ready ? " (" + ready + ")" : "")], ["rules", "Automation rules"], ["subs", "Subscribers"], ["log", "Activity log"]]} onChange={setTab} /></div>
      {tab === "outbox" && <Outbox db={db} openContact={openContact} />}
      {tab === "rules" && <Rules db={db} />}
      {tab === "subs" && <Subscribers db={db} />}
      {tab === "log" && <Log db={db} />}
    </>
  );
}

function Outbox({ db, openContact }) {
  const [f, setF] = useState("ready");
  const all = db.outbox || [];
  const list = all.filter((m) => f === "all" || m.status === f);
  const cnt = (s) => all.filter((m) => m.status === s).length;
  const sendAll = () => { const r = list.filter((m) => m.channel === "whatsapp" && m.status === "ready"); if (!r.length) return; window.open(AU.waUrl(r[0]), "_blank"); AU.markSent(r[0].id); toast((r.length - 1) + " more to send", "ok"); };
  return (
    <>
      <div className="kpis" style={{ gridTemplateColumns: "repeat(4,1fr)" }}>
        <KPI label="Ready to send (WhatsApp)" value={cnt("ready")} tone={cnt("ready") ? "#c98a12" : null} onClick={() => setF("ready")} />
        <KPI label="Scheduled" value={cnt("scheduled")} sub="reminders, follow-ups" onClick={() => setF("scheduled")} />
        <KPI label="Sent" value={cnt("sent")} onClick={() => setF("sent")} />
        <KPI label="Skipped" value={cnt("skipped")} sub="no consent / no contact" onClick={() => setF("skipped")} />
      </div>
      <Panel title="Message outbox" right={<><Seg value={f} options={[["ready", "Ready"], ["scheduled", "Scheduled"], ["sent", "Sent"], ["skipped", "Skipped"], ["all", "All"]]} onChange={setF} />{f === "ready" && <button className="btn-s wa" onClick={sendAll}>Send next WhatsApp</button>}</>}>
        <p className="muted small">Email & SMS go out automatically through Brevo. WhatsApp uses free click-to-chat: tap Send, WhatsApp opens with the message written in the patient's language — just press send.</p>
        {list.map((m) => <div className="msg" key={m.id}>
          <span className={"ch ch-" + m.channel}>{m.channel === "whatsapp" ? "WA" : m.channel === "email" ? "@" : m.channel === "admin" ? "!" : m.channel.toUpperCase()}</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="row"><b>{m.rule}</b><span className="muted small">→ <button className="linkbtn" onClick={() => openContact(m.to)}>{m.name || m.to}</button> · {m.lang.toUpperCase()}</span><Badge s={m.status} />{m.status === "scheduled" && <span className="muted small">at {fmtD(m.dueAt)}</span>}</div>
            <div className="msg-t">{m.text}</div>
            {m.note && <div className="muted small">{m.note}</div>}
          </div>
          <div className="acts">
            {m.status === "ready" && m.channel === "whatsapp" && <a className="mini ok" href={AU.waUrl(m)} target="_blank" onClick={() => AU.markSent(m.id)}>Send</a>}
            {m.status === "scheduled" && <button className="mini" onClick={() => mutate((d) => { const x = d.outbox.find((y) => y.id === m.id); x.status = "ready"; x.dueAt = new Date().toISOString(); })}>Send now</button>}
            {["ready", "scheduled"].includes(m.status) && <button className="mini" onClick={() => mutate((d) => { const x = d.outbox.find((y) => y.id === m.id); x.status = "skipped"; x.note = "Skipped by staff"; })}>Skip</button>}
          </div>
        </div>)}
        {!list.length && <Empty>Nothing here.</Empty>}
      </Panel>
    </>
  );
}

function Rules({ db }) {
  const rules = AU.rules(db);
  const [edit, setEdit] = useState(null);
  const save = (rs, msg) => mutate((d) => (d.rules = rs), msg || "Automation rules updated");
  const stat = (id) => (db.outbox || []).filter((m) => m.ruleId === id && m.status === "sent").length;
  return (
    <>
      <Panel title="Automation rules" right={<><button className="btn-s ghost" onClick={() => confirm("Restore the original 16 automations?") && save(null, "Rules restored")}>Restore defaults</button><button className="btn-s" onClick={() => setEdit({ id: "r" + Date.now().toString(36), name: "New automation", on: "appointment.completed", channel: "whatsapp", delayMin: 0, active: true, audience: "treatment", tpl: { en: "", mr: "", hi: "" }, isNew: true })}>+ New rule</button></>}>
        <div className="rules">{rules.map((r) => <div className={"rule" + (r.active ? "" : " off")} key={r.id}>
          <Toggle on={r.active} onChange={(v) => save(rules.map((x) => (x.id === r.id ? { ...x, active: v } : x)), "Rule " + r.name + (v ? " on" : " off"))} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <b>{r.name}</b>
            <div className="rule-flow"><span className="when">When: {AU.EVENTS[r.on]}</span>{r.delayMin > 0 && <span>wait {r.delayMin >= 60 ? r.delayMin / 60 + " h" : r.delayMin + " min"}</span>}<span className={"ch-l ch-" + r.channel}>{AU.CHANNELS[r.channel]}</span>{r.audience === "marketing" && <span className="tag">consent only</span>}</div>
          </div>
          <span className="muted small">{stat(r.id)} sent</span>
          <button className="mini" onClick={() => setEdit(JSON.parse(JSON.stringify(r)))}>Edit</button>
        </div>)}</div>
      </Panel>
      {edit && <RuleEditor r={edit} onClose={() => setEdit(null)} onSave={(n) => { const { isNew, ...clean } = n; save(isNew ? [...rules, clean] : rules.map((x) => (x.id === n.id ? clean : x)), "Rule saved: " + n.name); setEdit(null); toast("Automation saved", "ok"); }} onDelete={() => { save(rules.filter((x) => x.id !== edit.id), "Rule deleted"); setEdit(null); }} />}
    </>
  );
}
function RuleEditor({ r, onClose, onSave, onDelete }) {
  const [n, setN] = useState(r); const [pl, setPl] = useState("mr");
  const VARS = ["name", "date", "time", "mode", "service", "ref", "amount", "product", "link", "review", "phone"];
  return (
    <Drawer open onClose={onClose} title={r.isNew ? "New automation" : "Edit automation"} wide>
      <div className="fg">
        <F label="Name" span><input value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} /></F>
        <F label="When this happens"><select value={n.on} onChange={(e) => setN({ ...n, on: e.target.value })}>{Object.entries(AU.EVENTS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
        <F label="Do this"><select value={n.channel} onChange={(e) => setN({ ...n, channel: e.target.value })}>{Object.entries(AU.CHANNELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></F>
        <F label="Wait before sending"><select value={n.delayMin} onChange={(e) => setN({ ...n, delayMin: +e.target.value })}>{[[0, "Immediately"], [30, "30 minutes"], [120, "2 hours"], [1440, "1 day"], [4320, "3 days"], [10080, "7 days"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></F>
        <F label="Message type" hint="Marketing messages are only sent to people who ticked consent"><select value={n.audience} onChange={(e) => setN({ ...n, audience: e.target.value })}><option value="treatment">Service / treatment message</option><option value="marketing">Marketing / newsletter</option><option value="internal">Internal (staff only)</option></select></F>
      </div>
      <Tri label="Message (sent in the patient's language)" rows={4} value={n.tpl} onChange={(v) => setN({ ...n, tpl: v })} />
      <div className="row small" style={{ flexWrap: "wrap", margin: "-4px 0 12px" }}><span className="muted">Insert:</span>{VARS.map((v) => <button key={v} className="mini" onClick={() => setN({ ...n, tpl: { ...n.tpl, en: (n.tpl.en || "") + " {" + v + "}" } })}>{"{" + v + "}"}</button>)}</div>
      <Panel title="Preview" right={<Seg value={pl} options={LANGS3} onChange={setPl} />}><div className="wa-bubble" lang={pl}>{AU.test(n, pl) || <span className="muted">Write a message above</span>}</div></Panel>
      <div className="row" style={{ justifyContent: "space-between" }}>{!r.isNew ? <button className="linkbtn danger" onClick={() => confirm("Delete this automation?") && onDelete()}>Delete rule</button> : <span></span>}<button className="btn-s" onClick={() => onSave(n)}>Save automation</button></div>
    </Drawer>
  );
}

function Subscribers({ db }) {
  const csv = () => { const rows = [["EMAIL", "LANGUAGE", "SOURCE", "OPT_IN_DATE"]].concat(db.subscribers.map((s) => [s.email, s.lang, s.source, s.createdAt])); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map((r) => r.join(",")).join("\n")], { type: "text/csv" })); a.download = "brevo-subscribers.csv"; a.click(); };
  const seg = (l) => db.subscribers.filter((s) => s.lang === l).length;
  return <Panel title="Newsletter subscribers (consent given)" right={<button className="btn-s ghost" onClick={csv}>Export CSV for Brevo</button>}>
    <div className="kpis" style={{ gridTemplateColumns: "repeat(3,1fr)" }}><KPI label="Marathi list" value={seg("mr")} /><KPI label="Hindi list" value={seg("hi")} /><KPI label="English list" value={seg("en")} /></div>
    <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Email</th><th>Language</th><th>Source</th><th>Joined</th><th></th></tr></thead>
      <tbody>{db.subscribers.map((s) => <tr key={s.id}><td>{s.email}</td><td>{(s.lang || "").toUpperCase()}</td><td>{s.source}</td><td>{fmtDay(s.createdAt)}</td><td><button className="linkbtn danger" onClick={() => S.remove("subscribers", s.id)}>Unsubscribe</button></td></tr>)}
        {!db.subscribers.length && <tr><td colSpan="5"><Empty>No subscribers yet.</Empty></td></tr>}</tbody></table></div>
  </Panel>;
}
function Log({ db }) {
  return <Panel title="Activity log (audit trail)"><div className="tbl-wrap"><table className="tbl"><thead><tr><th>When</th><th>By</th><th>Action</th><th>Ref</th></tr></thead>
    <tbody>{db.log.slice(0, 300).map((l, i) => <tr key={i}><td>{fmtD(l.at)}</td><td>{l.who}</td><td>{l.action}</td><td className="mono">{l.ref}</td></tr>)}</tbody></table></div></Panel>;
}

Object.assign(window, { Automations });
