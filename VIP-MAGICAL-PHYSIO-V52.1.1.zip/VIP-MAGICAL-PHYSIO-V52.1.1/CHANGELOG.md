# Changelog

## 52.1.1 — 2026-11-26

Replaced the placeholder website mark and browser icons with the owner-supplied
logo. Added an optimized portrait crop from the supplied owner banner to the
homepage and About page, with translated name captions and accessible image
descriptions. The face itself was not retouched or regenerated.

## 52.1.0 — 2026-11-26

Added the owner's Google Business, YouTube and Instagram profiles and WhatsApp
Business contact links with language-specific appointment messages. Added a
video library and service-matched public channel playlists, with click-to-load
YouTube privacy-enhanced embeds and an updated CSP.

Completed authored Hindi and Marathi copy across public content and owner UI
labels. The translation layer preserves IDs, form enum values and handlers.
Added six localization/profile tests and a public-settings migration.
Medical/legal translations still require professional human review. No account
management API, rating synchronization, message sending or video dubbing is claimed.

## 52.0.0 — 2026-11-26

Initial source release: public physiotherapy site, multilingual core experience,
owner administrative workspace, Supabase migration and public request function,
Netlify setup, static route summaries, CSV tests and owner documentation.

Live integrations require configuration; production gates and deferred scope are
listed in docs/RELEASE.md. No earlier VIP Magical Physio release was accessible.
