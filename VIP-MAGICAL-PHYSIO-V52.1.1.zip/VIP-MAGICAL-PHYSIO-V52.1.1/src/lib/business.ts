import { createClient } from '@supabase/supabase-js';
import { toCsv } from './csv';
import { profiles } from './profiles';
export { toCsv } from './csv';

export type Language = 'en' | 'hi' | 'mr';
export type EnquiryKind = 'GENERAL' | 'CLINIC' | 'HOME_VISIT' | 'ONLINE';
export type EnquiryStatus = 'NEW' | 'CONTACTED' | 'APPOINTMENT_REQUESTED' | 'CLOSED';
export type AppointmentStatus = 'REQUESTED' | 'PENDING_CONFIRMATION' | 'CONFIRMED' | 'RESCHEDULED' | 'CANCELLED' | 'COMPLETED' | 'NO_SHOW';
export interface BusinessSettings {
  name: string; founder: string; location: string; phone: string; whatsapp: string; email: string;
  hours: string; announcement: string; languages: string[]; address: string;
  google?: string; youtube?: string; instagram?: string;
}
export const defaultSettings: BusinessSettings = {
  name: 'VIP MAGICAL PHYSIO', founder: 'Dr. Vipul Ahire (Physio)', location: 'Shirur, Pune District, Maharashtra',
  phone: '+91 8624860808', whatsapp: profiles.whatsapp, email: '', hours: 'By appointment', announcement: '',
  languages: ['English', 'हिन्दी', 'मराठी'], address: '',
  google: profiles.google, youtube: profiles.youtube, instagram: profiles.instagram,
};
export interface EnquiryInput {
  name: string; phone: string; email?: string; kind: EnquiryKind; service: string;
  preferred_date?: string; locality?: string; message?: string; consent: boolean; language: Language;
  idempotency_key: string; website?: string; source?: string; captcha_token?: string;
}
export interface Enquiry extends EnquiryInput {
  id: string; created_at: string; status: EnquiryStatus; next_action: string; follow_up_at: string | null;
}
export interface Appointment {
  id: string; enquiry_id: string; starts_at: string; ends_at: string; kind: EnquiryKind;
  status: AppointmentStatus; created_at: string; notes: string;
}
export interface ContentPage { slug: string; language: Language; title: string; body: string; published: boolean; }
export interface FinanceRecord { id: string; kind: 'PAYMENT' | 'EXPENSE'; amount_paise: number; description: string; occurred_at: string; created_at: string; }
export interface AuditRecord { id: string; action: string; entity: string; created_at: string; }
export const services = [
  { slug: 'orthopaedic-physiotherapy', name: 'Orthopaedic physiotherapy', description: 'Individual assessment and movement-focused support for joint, muscle and back concerns.' },
  { slug: 'neurological-rehabilitation', name: 'Neurological rehabilitation', description: 'Goal-led rehabilitation for movement, balance and everyday independence.' },
  { slug: 'post-operative-rehabilitation', name: 'Post-operative rehabilitation', description: 'A gradual return to everyday movement, in coordination with your surgical advice.' },
  { slug: 'geriatric-physiotherapy', name: 'Geriatric physiotherapy', description: 'Support for strength, balance and confident movement as you age.' },
  { slug: 'home-visit-physiotherapy', name: 'Home visit physiotherapy', description: 'Request physiotherapy in the comfort of your home in Shirur. Availability is confirmed personally.' },
  { slug: 'online-consultation', name: 'Online consultation', description: 'Discuss your goals and receive professional guidance remotely, where clinically appropriate.' },
];

const env = import.meta.env;
export const isConfigured = Boolean(env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY);
export const supabase = isConfigured ? createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY, {
  auth: { persistSession: false, autoRefreshToken: true, detectSessionInUrl: true },
}) : null;
function client() {
  if (!supabase) throw new Error('Online requests are not available yet. The owner must connect Supabase before this feature can be used. Nothing has been submitted.');
  return supabase;
}
function check(error: {message: string} | null) { if (error) throw new Error(error.message); }
export async function getSettings(): Promise<BusinessSettings> {
  if (!supabase) return defaultSettings;
  const { data, error } = await supabase.from('business_settings').select('value').eq('id', 1).single();
  check(error);
  return { ...defaultSettings, ...data?.value };
}
export async function saveSettings(value: BusinessSettings) {
  const { error } = await client().from('business_settings').update({ value }).eq('id', 1);
  check(error);
}
export async function submitEnquiry(input: EnquiryInput): Promise<string> {
  const { data, error } = await client().functions.invoke('submit-enquiry', { body: input });
  check(error);
  if (data?.error) throw new Error(data.error);
  if (!data?.reference) throw new Error('Your request could not be verified. Please try again using the same form.');
  return data.reference;
}
export async function signIn(email: string, password: string) {
  const { data, error } = await client().auth.signInWithPassword({ email, password });
  check(error); return data;
}
export async function signOut() { const { error } = await client().auth.signOut(); check(error); }
export async function isOwner(): Promise<boolean> {
  if (!supabase) return false;
  const { data, error } = await supabase.rpc('is_owner');
  check(error); return data === true;
}
export async function requestPasswordReset(email: string) {
  const { error } = await client().auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}${import.meta.env.BASE_URL}admin/reset` });
  check(error);
}
export async function changePassword(password: string) {
  if (password.length < 12) throw new Error('Use at least 12 characters.');
  const { error } = await client().auth.updateUser({ password }); check(error);
}
export async function listEnquiries(): Promise<Enquiry[]> {
  const { data, error } = await client().from('enquiries').select('*').order('created_at', { ascending: false }).limit(1000);
  check(error); return data ?? [];
}
export async function updateEnquiry(id: string, patch: Partial<Pick<Enquiry, 'status' | 'next_action' | 'follow_up_at'>>) {
  const { error } = await client().from('enquiries').update(patch).eq('id', id); check(error);
}
export async function listAppointments(): Promise<Appointment[]> {
  const { data, error } = await client().from('appointments').select('*').order('starts_at').limit(1000);
  check(error); return data ?? [];
}
export async function saveAppointment(input: Omit<Appointment, 'id' | 'created_at'>, id?: string) {
  const result = id ? await client().from('appointments').update(input).eq('id', id) : await client().from('appointments').insert(input);
  check(result.error);
}
export async function listContent(language?: Language): Promise<ContentPage[]> {
  let query = client().from('content_pages').select('*');
  if (language) query = query.eq('language', language).eq('published', true);
  const { data, error } = await query; check(error); return data ?? [];
}
export async function saveContent(page: ContentPage) {
  const { error } = await client().from('content_pages').upsert(page, { onConflict: 'slug,language' }); check(error);
}
export async function listFinance(): Promise<FinanceRecord[]> {
  const { data, error } = await client().from('finance_records').select('*').order('occurred_at', {ascending: false}).limit(1000);
  check(error); return data ?? [];
}
export async function addFinance(input: Omit<FinanceRecord, 'id' | 'created_at'>) {
  const { error } = await client().from('finance_records').insert(input); check(error);
}
export async function listAudit(): Promise<AuditRecord[]> {
  const { data, error } = await client().from('audit_logs').select('id,action,entity,created_at').order('created_at', {ascending:false}).limit(100);
  check(error); return data ?? [];
}
export function downloadCsv(rows: object[], filename: string) {
  const url = URL.createObjectURL(new Blob([toCsv(rows as Record<string, unknown>[])], {type:'text/csv;charset=utf-8;'}));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}
