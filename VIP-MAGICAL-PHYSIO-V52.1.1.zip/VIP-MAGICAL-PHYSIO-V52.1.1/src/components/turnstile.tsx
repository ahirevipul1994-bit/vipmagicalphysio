import { useEffect, useRef } from 'react';

declare global {
  interface Window {
    turnstile?: {
      render: (el: HTMLElement, opts: Record<string, unknown>) => string;
      reset: (id?: string) => void;
      remove: (id?: string) => void;
    };
  }
}

export const turnstileSiteKey: string = import.meta.env.VITE_TURNSTILE_SITE_KEY ?? '';
const SRC = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
let loader: Promise<void> | null = null;
function load() {
  if (window.turnstile) return Promise.resolve();
  if (!loader) loader = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = SRC; s.async = true; s.defer = true;
    s.onload = () => res(); s.onerror = () => { loader = null; rej(new Error('Verification could not load.')); };
    document.head.appendChild(s);
  });
  return loader;
}

/** Cloudflare Turnstile widget. Changing resetKey resets the challenge (token cleared). */
export function Turnstile({ onToken, resetKey, language }: { onToken: (t: string) => void; resetKey: number; language: string }) {
  const box = useRef<HTMLDivElement>(null);
  const id = useRef<string | null>(null);
  const cb = useRef(onToken); cb.current = onToken;

  useEffect(() => {
    if (!turnstileSiteKey) return;
    let cancelled = false;
    load().then(() => {
      if (cancelled || !box.current || !window.turnstile) return;
      id.current = window.turnstile.render(box.current, {
        sitekey: turnstileSiteKey, language,
        callback: (t: string) => cb.current(t),
        'expired-callback': () => cb.current(''),
        'error-callback': () => cb.current(''),
      });
    }).catch(() => cb.current(''));
    return () => { cancelled = true; if (id.current && window.turnstile) window.turnstile.remove(id.current); id.current = null; };
  }, [language]);

  useEffect(() => {
    if (resetKey && id.current && window.turnstile) { window.turnstile.reset(id.current); cb.current(''); }
  }, [resetKey]);

  return <div ref={box} data-testid="widget-turnstile" className="min-h-[65px]" />;
}
