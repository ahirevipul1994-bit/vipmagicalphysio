# VIP MAGICAL PHYSIO — 52.1.1

Website and administrative owner workspace for **vipmagicalphysio.com**.
This is a **source-code release, not a verified production operating system**.
The public site runs without a backend. Submitting enquiries and using owner
records require your own Supabase and Cloudflare Turnstile configuration.
Nothing is stored in local storage as a substitute for the database.

## Start the downloaded standalone ZIP

1. Install Node.js 24 and pnpm 10.
2. Extract the ZIP into a new folder.
3. Run `pnpm install --frozen-lockfile`.
4. Run `pnpm dev` and open the URL printed by Vite.
5. Run `pnpm typecheck`, `pnpm test`, and `pnpm build`.

The source inside the Replit repository is a pnpm workspace: use
`pnpm --filter @workspace/vip-magical-physio run dev` through its managed workflow.
The exported ZIP is transformed into a standalone project and uses the commands above.
Only the exported ZIP's manifest/configuration are transformed; application code is the same.

## Before accepting real enquiries

Follow **docs/DEPLOYMENT.md**. Create a Supabase project, apply the migration,
provision the owner privately, configure Turnstile, deploy the Edge Function,
and set the three public build variables. Test privacy and access controls
in staging before using any real personal information.

No service-role keys, payment secrets, passwords or patient records belong
in this ZIP, frontend settings, GitHub or chat.

## Included

- Public responsive website, six service pages, education, FAQs and policy drafts.
- English/Hindi/Marathi authored public pages, service details, education, articles,
  FAQs, policy drafts, forms and owner-interface labels.
- Owner-supplied Google Business, Instagram and YouTube profile links; manual
  WhatsApp appointment requests to the owner-provided business number.
- Verified service-matched YouTube playlists and click-to-load privacy-enhanced embeds.
- Request form with consent, idempotency, Turnstile and server validation.
- Supabase Auth owner sign-in and password recovery, no public signup UI.
- Owner enquiries, follow-ups, scheduling, manual finance, content and settings.
- CSV exports with formula-injection mitigation; read-only audit history.
- PostgreSQL migration with RLS, restricted grants, audit triggers and overlap exclusion.
- Supabase Edge Function for public enquiries; Netlify configuration.
- Static public route summaries and metadata generated at build time.
- Tests, owner instructions, security/release limitations and staging checklist.

## Important limitations

The source must not be described as fully verified or production-ready.
Live database, RLS, concurrent booking, CAPTCHA, auth, recovery and migration
tests have **not** been executed against an owner Supabase project.
Private signed-in pages have not been visually verified.
Professional human sign-off of clinical/legal translations, payment processing, digital downloads,
AI, email/WhatsApp automation, advanced availability/travel buffers, imports,
clinical records and verified backup restoration are **not implemented**.

Language selection persists between pages. Share a page with `?lang=en`,
`?lang=mr` or `?lang=hi` to open it in a specific language. Video audio and
third-party interfaces keep their original language; videos are not dubbed.
Google review links invite honest feedback, without incentives, fabricated
reviews or any guarantee of higher ratings.

See docs/RELEASE.md for evidence and the feature register. The project includes
manual financial records only, not gateway-verified payments, accounting or GST software.

## Documentation

- docs/DEPLOYMENT.md — setup, owner provisioning, Netlify and staging gates.
- docs/OWNER-MANUAL.md — day-to-day use.
- docs/ARCHITECTURE.md — decisions, database and boundaries.
- docs/SECURITY.md — threat review, governance and scan findings.
- docs/OPERATIONS.md — continuity, recovery, costs and future work.
- docs/RELEASE.md — implementation register, verification and acceptance.
- CHANGELOG.md — release history.
