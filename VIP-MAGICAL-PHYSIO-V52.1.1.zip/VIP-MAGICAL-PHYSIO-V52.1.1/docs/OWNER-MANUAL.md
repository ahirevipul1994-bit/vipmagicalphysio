# Owner operating manual

## First use

Ask the person configuring Supabase to follow DEPLOYMENT.md. Until connected,
the website is readable but online requests and private records are unavailable.
Do not invite patients to use a form that still shows configuration required.

## Sign in and recovery

Open `/admin`. Use the privately provisioned email and password. There is no
public registration. A reload signs you out because the session is kept in memory.
Use Forgot password for a reset email; open it in the same browser and set a
new password of at least 12 characters. Reset delivery must be configured and tested.
Use Sign out after work, particularly on shared devices.

## Publish your contact information

Open Settings. Add your real phone number, WhatsApp country-code number,
email, address and hours. Save. Do not put API secrets here.
The owner-provided phone/WhatsApp contact is included by default. Confirm it is
the right business number before publishing. Settings can change it later.
Setting WhatsApp enables a manual contact link, **not automated messaging**.
Verify your legal policies and qualifications before publishing them.

## Enquiries and administrative follow-ups

Open Enquiries. Search by name, phone or locality; filter status and request type.
Review the request, contact the person manually, update the status and add a
next action. Set a follow-up time in Indian Standard Time and Save.
Close resolved requests rather than deleting them.
Do not enter diagnoses, medical histories, scans or treatment notes.
Consent recorded by the form is for replying to that request, not marketing consent.

## Appointments and home visits

Open Appointments. Choose an existing enquiry. Select start/end, type and status.
All entered times are IST. A request is **not confirmed** until you choose CONFIRMED.
Home visits use HOME_VISIT and can be filtered. Use Edit/reschedule to change times.
Database restrictions reject overlapping confirmed or rescheduled appointments.
Requested/pending appointments do not reserve a confirmed slot.
Confirm availability, travel time, prices and location manually. Advanced automatic
availability, travel buffers, breaks and holiday rules are not included.
Cancel keeps the history; Restore returns a canceled entry to REQUESTED.

## Money

Finance records manual PAYMENT and EXPENSE entries in rupees, preserving paise.
Check descriptions and amounts carefully before adding them. These are
administrative records, not a bank feed, receipts, GST returns or verified
Razorpay transactions. There is no automatic refund or financial deletion.
If an entry is wrong, follow a reviewed correction procedure; do not enter
negative numbers to bypass validation.

## Website content and translations

Content allows a title, plain-text body, language and Published setting per page.
Unpublished entries do not replace public text. Keep clinical and legal changes
under professional human review. This release does not support HTML injection.
For the home entry, title/body replace the main headline/introduction only.
Built-in public content and owner-interface labels are available in all three
languages. Owner-authored content is selected by language; write/review each
version in the editor. New arbitrary text and external technical diagnostics
are not automatically translated.
The content editor covers the documented page slugs, not every navigation label,
service title, blog article or price. Price/catalog editing is future work.

## Export

Use CSV in Enquiries, Appointments or Finance. Each current list/export loads
at most 1,000 records. Secure the downloaded file: it contains personal data.
Do not send exports to marketing tools without separate verified permissions.
CSV exports are **not database backups** and cannot restore the whole system.

## Overview and audit

Overview counts NEW enquiries, due follow-ups and upcoming appointments from
the loaded database records. Net recorded equals manual payments minus expenses.
These are not complete lifetime metrics beyond the 1,000-record limit.
Audit shows the latest 100 change events, not copies of sensitive payloads.

## Unavailable features

E-books/checkout, Razorpay, AI, automated WhatsApp/email, advanced analytics,
patient/caregiver portals, clinical notes, imports and subscriptions are not enabled.
No purchase button should take money. Do not assume any integration or backup
is healthy simply because a public key is configured.

## Updates and recovery

Read RELEASE.md and OPERATIONS.md before updates. Review changes in staging.
Retain prior code release and provider recovery options. A code ZIP does not
contain business records. Do not delete a database to "restart" an update.
