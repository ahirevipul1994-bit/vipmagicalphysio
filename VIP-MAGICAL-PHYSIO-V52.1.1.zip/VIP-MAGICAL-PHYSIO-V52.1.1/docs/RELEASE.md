# Release notes, traceability and acceptance

## Current release: 52.1.1

Includes the owner-supplied website logo, browser icons and a portrait crop
from the supplied banner on the homepage and About page. Images are optimized
locally; no AI face modification or new identity/qualification claim is made.

Adds owner-authorized business profile links and WhatsApp appointment links,
complete authored Hindi/Marathi site copy, owner-interface localization,
service-matched public YouTube videos/playlists and a `/videos` route.
See `SOCIAL-AND-LANGUAGES.md` for sourcing, scope and limitations.
The source now includes 10 unit/coverage tests. Existing external Supabase,
production deployment, MFA and recovery verification limitations remain.
The historical 52.0.0 register below is superseded for localization and
manual social/WhatsApp links only, not for the deferred integration engines.

Version: 52.0.0. Source release date: 2026-11-26.
Current checkpoint: source built; package verification recorded separately.
This is a scoped first release, **not the complete four-phase master specification**.

## Requirement-to-implementation register

| ID | Requirement / feature | Source | Status and verification |
|---|---|---|---|
| MVP-01 | Public website/services/education/policy drafts | src/pages/public.tsx, src/lib/content.ts | IMPLEMENTED; build/visual evidence in verification report |
| MVP-02 | Responsive accessible interaction | src/index.css, components/site.tsx | IMPLEMENTED; not formally WCAG/usability tested |
| MVP-03 | English/Hindi/Marathi framework | src/lib/i18n.tsx | IMPLEMENTED; deeper content English fallback unless owner translated |
| MVP-04 | Enquiry/home/online/appointment request | components/request-form.tsx, supabase/functions/submit-enquiry | CONFIGURATION REQUIRED; no live submissions tested |
| MVP-05 | Consent/input validation/spam/idempotency | Edge Function, migration enquiries/RPC | IMPLEMENTED source; staging security/retry tests required |
| MVP-06 | Supabase owner authentication/recovery | src/lib/business.ts, pages/admin.tsx | CONFIGURATION REQUIRED; no public signup UI |
| MVP-07 | Public/private separation/RLS | migration policies, grants, is_owner | IMPLEMENTED source; no live RLS proof |
| MVP-08 | Unified overview/real metrics | pages/admin.tsx Overview | CONFIGURATION REQUIRED; no fake metrics; latest 1,000 cap |
| MVP-09 | Lead status/basic follow-ups | pages/admin.tsx Enquiries | CONFIGURATION REQUIRED; needs authenticated staging testing |
| MVP-10 | Appointment/home-visit management | pages/admin.tsx Appointments, exclusion constraint | CONFIGURATION REQUIRED; no automatic availability engine |
| MVP-11 | CSV exports | src/lib/csv.ts, pages/admin.tsx | IMPLEMENTED; pure CSV unit tests included, runtime export needs owner test |
| MVP-12 | Business settings/content edits | pages/admin.tsx, business_settings/content_pages | CONFIGURATION REQUIRED; plain text, limited slug coverage |
| MVP-13 | Manual financial administration | pages/admin.tsx Finance, finance_records | CONFIGURATION REQUIRED; not verified payments or accounting |
| MVP-14 | Audit history | migration triggers, pages/admin.tsx Audit | CONFIGURATION REQUIRED; database-admin tampering remains trusted boundary |
| MVP-15 | Deployment/release/source ZIP | scripts, netlify.toml, docs | See generated ZIP verification report |
| MVP-16 | Observability/continuity/recovery | docs/OPERATIONS.md | Basic error UI IMPLEMENTED; monitoring/restore verification NOT IMPLEMENTED |
| SEO-01 | Metadata/static route summaries/sitemap | scripts/prerender.mjs, components/site.tsx | IMPLEMENTED; not full visual SSR; intended domain not verified live |
| GOV-01 | Clinical/ethical boundaries | educational copy, form warnings, docs | IMPLEMENTED content; human clinical/legal review required |
| SEC-01 | Threat/security/dependency review | docs/SECURITY.md | Scan evidence supplied; production security NOT VERIFIED |
| FUT-01 | Payment/digital downloads | ebooks informational route | NOT IMPLEMENTED; no checkout |
| FUT-02 | AI/automation/messaging/integration health engine | none | NOT IMPLEMENTED |
| FUT-03 | Full CRM/contact entity/imports/advanced scheduling | none | NOT IMPLEMENTED |
| FUT-04 | MFA enforcement/security monitoring/full consent lifecycle | none | NOT IMPLEMENTED |
| FUT-05 | Verified restoration/production smoke tests | none | NOT IMPLEMENTED |

## Test cases and evidence

Automated tests exercise the real CSV implementation: empty data, quoted fields,
Unicode and spreadsheet formula mitigation. Production build and TypeScript
checks are listed with actual results in the generated verification report.
The app is not mocked into a signed-in state for screenshots.
No first-build browser-interaction/e2e suite was executed.

The staging checklist in DEPLOYMENT.md defines functional/security acceptance,
including concurrent appointments, unauthorized access, Turnstile, persistence
and password recovery. These tests are **not executed**, not silently passed.
Migration existence does not imply migration validity or successful application.

## Seven release gates

1. Functionality: BLOCKED for live administrative use pending configuration/testing.
2. Security: BLOCKED pending RLS/auth/MFA/abuse staging verification.
3. Database and integrity: BLOCKED pending fresh migration and concurrency tests.
4. Deployment: NOT IMPLEMENTED / no production deploy or smoke test.
5. Backup/recovery: NOT IMPLEMENTED / no verified restore.
6. Performance/observability: partial source only; no measured production targets.
7. Documentation/delivery: source package and evidence supplied once ZIP verification completes.

## Implementation scorecard

No numerical score is awarded before an operational staging environment exists.
The brief's weighted table also sums to **107**, despite labelling TOTAL as 100;
a valid numerical audit must first normalize or obtain corrected weights.
UI existence receives no operational functionality credit here.
Regardless of a future score, failed critical security or data-integrity gates
block classification as production-ready.

## Final acceptance report

Accepted for this delivery: downloadable source with a working public preview,
implemented configuration-dependent administrative code, migration, guides,
test sources and explicit limitations.
Not accepted/claimed: a verified functional Supabase deployment, complete master
scope, legal compliance, successful backups, payment processing, production
security or live domain operation.
Owner's next action: configure staging and run the acceptance checklist before launch.
