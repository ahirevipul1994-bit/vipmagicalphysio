# Architecture and database

## Existing-project audit

At inspection, the accessible repository contained a fresh pnpm scaffold:
shared API skeleton, empty database library, mockup sandbox and no existing
VIP Magical Physio application or ZIP. The supplied master brief was available.
No existing clinic website, Supabase project, GitHub repository, live deployment,
patient database or recoverable previous clinic release was accessible.
Existing scaffold packages were preserved, not replaced. The standalone export
includes only this product rather than unrelated scaffold applications.
No historical "working version" or business-data backup is claimed.

## ADR: preserve the requested portable stack

**Decision:** React + TypeScript + Vite + Tailwind, hosted as a static frontend,
with Supabase Auth, PostgreSQL/RLS and an Edge Function as one centralized backend.
**Why:** the supplied brief specifically requests Netlify and Supabase and a
downloadable maintainable source package. No replacement database or local
password authentication was introduced.
**Alternatives:** the scaffold's Express/Replit PostgreSQL setup would make a
quick live preview possible but change the owner's requested hosting/auth model.
It is not used for this product's business records.
**Consequences:** Supabase/Turnstile configuration is required for operational use;
the source preview is not a live patient-management system.

## ADR: modular monolith, administrative MVP only

**Decision:** one frontend application, one Supabase backend/project, one primary
business database; internal public/admin/business/security modules.
**Why:** minimum maintenance and the brief's explicit MVP-first instruction.
**Consequences:** no microservices, duplicate backend, clinical decision engine,
payment provider or optional AI dependency in the MVP.

## ADR: no unconfigured-success fallback

**Decision:** public content may render without configuration, but submissions
fail closed and owner auth/records are unavailable without Supabase.
**Why:** pretending a saved enquiry or private owner login works risks lost
patient requests and misleading the owner.
**Consequences:** no seeded private patients, placeholder metrics or localStorage CRM.

## Boundaries and data flow

```text
Public browser --> readable public content/settings (Supabase RLS)
              --> Turnstile --> submit-enquiry Edge Function
                                     |
                       validated service-role-only RPC
                                     |
                              enquiries + audit

Owner browser --> Supabase Auth --> is_owner check
                               --> RLS-enforced business tables
                               --> audit triggers
```

The browser never receives the service-role key. Frontend route hiding is a
convenience only; database policy and grants enforce authorization.
The public anon JWT identifies a public application, not a trusted owner.
Only privately allowlisted auth UUIDs are owners.
Direct Supabase SDK/PostgREST and RPC interfaces are the backend contract;
the unrelated scaffold Express/OpenAPI service is not an alternate business API.

## Database entities

| Entity | Purpose and important controls |
|---|---|
| owner_accounts | Controlled Auth UUID allowlist, no client access |
| business_settings | One public business-information object; owner updates |
| enquiries | Administrative request/contact snapshot, consent/version, source, separate UUID and idempotency UUID |
| appointments | Separate UUID linked to enquiry; UTC start/end, IST presentation; exclusion constraint |
| content_pages | Composite slug/language key; only published entries public |
| finance_records | Manual payment/expense; positive integer paise, append only |
| audit_logs | Minimal actor/action/entity/key metadata; owner read only |
| submission_limits | Salted fingerprint/hourly limit; no browser permissions |

The contact snapshot in an enquiry is intentionally not a normalized contact
master. Separate contact entities, consent history, communications and advanced
CRM are deferred and must not be falsely represented as implemented.

## Integrity and transaction reliability

Every private entity has identifiers, timestamps and validation constraints.
Appointment exclusion uses half-open intervals `[start,end)` for confirmed/
rescheduled bookings across this one-physiotherapist business; it allows adjacent
visits and blocks overlapping concurrent confirmations. Pending requests can overlap.
Audit writes occur in the same transaction as record writes.
Public enquiries use a unique caller-generated UUID and transactional upsert so
the same submission key does not create another record. Distinct-key duplicate
people are not automatically merged. Manual finance and appointment-create
idempotency beyond database constraints remain hardening gaps.

## Migration and releases

Migration is version-controlled and intended for a fresh external Supabase
staging project. It has **not** been applied to a live owner account.
Do not run it on a populated unrelated schema. Apply via controlled migration
tooling, never runtime startup DDL.
Code rollback does not undo database changes. No destructive down migration is
provided because dropping business records is not safe recovery.

## Public rendering

Build generates factual static route summaries and per-route metadata for
crawlers/no-JavaScript visitors. React enhances/replaces this content on mount.
This is **not full rendered-page SSR or complete UI prerendering**; owner-edited
content is fetched at runtime and build-time summaries require a rebuild to change.
Multilingual route-specific SEO, hreflang and richer local structured data await
complete owner-reviewed translations and verified business facts.
