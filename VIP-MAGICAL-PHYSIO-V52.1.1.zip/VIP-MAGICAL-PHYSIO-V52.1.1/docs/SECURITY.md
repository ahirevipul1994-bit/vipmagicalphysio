# Security and healthcare data governance

## Release classification

**Not production-security-verified.** Source controls exist; executing migration,
RLS, authentication, captcha and concurrency tests against staging remains a
release gate. No legal, regulatory, DPDP, healthcare or WCAG certification is claimed.

## Threat review and source controls

| Threat | Implemented source control | Remaining verification or gap |
|---|---|---|
| Public access to private records | RLS, restricted grants, owner UUID RPC | Execute anon/non-owner/owner staging tests |
| Public admin signup/privilege escalation | No signup UI, private owner allowlist | Disable provider public signups, verify grants |
| Session theft/stale cross-account data | SDK auth, in-memory tokens, cache cleared on identity change | Session expiry/revocation and CSP staging tests; MFA not implemented |
| Form spam/resource abuse | Turnstile verified server-side with hostname, origin allowlist, 16KB streaming cap, fingerprint rate limit | Provider ingress abuse protections, proxy-header trust review |
| Forged inputs/SQL injection | Edge validation, constrained RPC fields, SQL constraints | Full fuzz/negative integration tests |
| XSS | React text rendering, plain-text content, Netlify CSP | CSP/browser verification; no custom HTML allowed |
| Duplicate request delivery | Unique idempotency key and transactional RPC | Retry/concurrency integration test |
| Overlapping bookings | PostgreSQL exclusion constraint | Concurrent staging transactions; travel buffers not implemented |
| Secret exposure | Public-only VITE config; service key only in Edge runtime | Operational secret scanning/rotation |
| CSV formula execution | Escape cells and dangerous leading characters | Automated CSV tests supplied |
| Audit tampering | Client read only, trigger-generated append events | Supabase service/database administrators remain trusted |
| Payment fraud | Checkout not implemented | No money accepted by this application |

## Scanner findings at initial review

- Dependency audit: **0 critical, 0 high, 1 moderate**. The moderate finding was
  postcss-selector-parser 6.0.10 (GHSA-rj75-hqrm-r3gf), a build-time CSS parser
  complexity issue. Latest typography parent still pinned it; a targeted patched
  parser override was added. See the final verification report for the rerun.
- Static scanner returned **incomplete=true**, no findings returned. This is
  incomplete coverage, not a clean SAST pass.
- Privacy/dataflow scanner returned no findings. This is not proof of compliance.

Do not infer production security from scanner counts alone.

## Healthcare and privacy rules

The system is for business administration. Do not collect clinical records,
diagnoses, treatment plans, scans or detailed histories through these forms.
Free text cannot guarantee that a visitor never discloses sensitive information;
the owner must promptly handle accidental disclosure under a reviewed procedure.
Do not send identifiable data to external AI or marketing systems.

Collect only the name, contact, request category, locality when needed,
preferred date, administrative message, language, source and consent needed
to answer the request. Consent is mandatory for request processing and versioned
in the record. It is **not consent for promotional messages**.

The public policy texts are drafts, not legal advice. Before launch obtain
qualified review of applicable Indian law, including phased commencement of
DPDP provisions/rules in force at launch. Do not assume all provisions commenced
on the same date. Review third-party processing, region and cross-border transfer
implications and publish actual business contact details and retention terms.

## Data lifecycle policy requiring owner approval

1. Owner documents the purpose, legal basis and contact point before collection.
2. Owner approves a retention schedule before launch. No retention period is
   silently imposed here.
3. Owner responds to access/correction/export/deletion requests after verifying
   identity through a private channel.
4. Exports are authorized but capped at 1,000 records; a full vendor-exit export
   requires the provider's controlled tools.
5. In-app hard deletion and retention jobs are not implemented. Authorized
   disposal must consider appointment references, required financial retention,
   audit metadata and provider backups. No blanket SQL purge should be improvised.
6. Salted request-limit fingerprints need a reviewed expiry/maintenance procedure.
   No scheduled cleanup or automatic retention is claimed in this release.

## Incident response

If compromise or unintended disclosure is suspected: disable affected public
submissions/keys if necessary, preserve provider logs without copying patient
payloads, revoke compromised sessions, rotate secrets through provider controls,
investigate the affected records/time window, obtain professional notification
guidance, test the fix in staging, and record corrective action. Never paste
secrets or patient data into support chat or public issue trackers.
