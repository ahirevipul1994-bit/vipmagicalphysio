# Business profiles, videos and languages

## Public profiles

Profile URLs and the public business number were supplied by the owner.
`src/lib/profiles.ts` contains the canonical defaults without sharing/tracking
query parameters. Public settings can override the links. The second Supabase
migration updates stored settings in installations that already applied the
foundation migration; no migration has been run by this release.

Google opens the business profile; visitors can choose Google's review action
there. All honest experiences are welcome. There is no review gating,
incentive, fabricated star rating, live review feed or promise to increase ratings.
This release does not control or authenticate the external business accounts.

WhatsApp links open a prefilled appointment **request** in the selected website
language. The visitor decides whether to send it. It is not a confirmed booking,
automatic message, WhatsApp API integration or record in this site's database.
Do not send clinical records through this contact link.

## YouTube sourcing

Verified on 2026-11-26 from the owner's public channel:
https://www.youtube.com/@DrVipulAhireOfficial

Channel identifier: `UCNNg3Ly0HXsgpsACzPk8jWg`.

| Topic | Verified playlist | Featured video |
|---|---|---|
| Knee care / orthopaedic / older adults | PL2GdC5_xwrQLXxXpyLRABS8DSRnWVFBLB | PRCjF3vPDZI |
| Neurological / older adults | PL2GdC5_xwrQK0Iy_0UKaKUpzv6XIlMTB5 | 18X9gQ7PZhw |
| After surgery | PL2GdC5_xwrQLPUuiG6SREuOdb7fCzGris | kx2Bwj2v9Bo |
| Home physiotherapy | PL2GdC5_xwrQLPUuiG6SREuOdb7fCzGris | RGcuTvMIjHg |
| Online consultation | PL2GdC5_xwrQI5YiAaupyWmSuAm-UOHIFg | General exercise playlist only |

Selections prioritize service relevance and educational suitability, considering
publicly visible playlist/view information where available. They are curated,
not a live popularity ranking. Neutral website topic labels are not claims
about outcomes or literal copies of promotional video titles. No dedicated
online-consultation video was verified; the page states that limitation.

Players load only when requested by the visitor, using YouTube's
privacy-enhanced `youtube-nocookie.com` domain. No thumbnail or iframe is loaded
before that action. Following a YouTube link also contacts YouTube. Its privacy
and cookie policies then apply. Videos can later become unavailable or change.
Original audio, captions supplied by YouTube, branding and third-party pages
remain in their original language.

## Language coverage

English, Hindi and Marathi cover authored public page text, deep service
content, education, articles, FAQs, policy drafts, forms/validation and owner
interface labels. Proper brand names and user-supplied records retain their
original spelling. External diagnostics may retain technical English.

The `?lang=en`, `?lang=hi` and `?lang=mr` query values allow sharing a language
version. Subsequent pages use the saved language preference. The document
language is updated for assistive technology.

Translations are authored text, not a runtime machine-translation service.
They preserve form values, identifiers and event handlers. New content needs
corresponding translations. Owner-published language-specific content is
selected directly, not automatically translated.

The default legal policies remain drafts, and clinical/legal translations
require qualified human review before production use.
