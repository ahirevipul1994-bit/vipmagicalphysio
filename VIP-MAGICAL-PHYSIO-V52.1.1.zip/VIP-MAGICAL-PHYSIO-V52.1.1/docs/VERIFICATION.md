# Executed verification evidence

## 52.1.0 update

- TypeScript check passed after adding localization and profile/video components.
- All 10 automated CSV, translation-coverage, form-value-preservation and profile
  mapping tests passed.
- New external links and embeds use owner-provided/verified public destinations.
- No live account API access, review/rating synchronization, WhatsApp automation,
  video dubbing or production deployment is claimed.
- Marathi About page, Hindi video-library page and mobile Hindi appointment
  page were captured and inspected. The final Hindi captures had no browser
  errors; the public form correctly remained disabled without backend setup.
- Privacy-enhanced video loading was verified in source, not interactively
  played in a browser. Third-party availability can change.
- Full archive extraction/build results are supplied in the companion ZIP
  verification report. Existing backend-dependent tests below remain unexecuted.

## Source and standalone checks

Executed on 2026-11-26 with Node.js 24.22.3 and pnpm 10.26.1:

- Product TypeScript check: passed.
- Product automated CSV tests: 4 passed, 0 failed.
- Standalone exported source dependency installation: passed.
- Standalone TypeScript check: passed.
- Standalone automated CSV tests: 4 passed, 0 failed.
- Standalone production build: passed.
- Build generated 20 public static route summaries, sitemap and robots.txt.
- Build warnings: a non-fatal tooltip source-map location warning and a main
  JavaScript chunk over 500 kB (approximately 655 kB minified / 194 kB gzip).
  No measured mobile-performance claim is made.

## Visual checks

- Desktop homepage at 1440 × 1000: captured and inspected; rendered correctly,
  with no runtime error in capture browser output.
- Mobile appointment-request page at 390 × 844: captured and inspected; layout
  rendered and honestly displayed its configuration-required state.
- Screenshots are included in docs/screenshots in the delivered ZIP.
- No logged-in owner UI was visually verified because owner authentication is
  not configured. No auth bypass was created to take screenshots.
- Interactive/end-to-end tests, accessibility audit and usability study were
  not executed on this first build.

## Security scanners

- Final dependency audit after targeted parser update: 0 critical, 0 high,
  0 moderate, 0 low, 0 informational vulnerabilities reported.
- Static scanner: incomplete coverage, no findings returned.
- Privacy/dataflow scanner: no findings returned.
- These results do not certify security, healthcare privacy or legal compliance.

## ZIP-specific evidence

The separate archive verification report delivered with the ZIP records archive
integrity, essential-file checks, prohibited-file checks, literal-secret pattern
scan, extraction, frozen-lock installation, typechecking, tests and build.
That final report and archive SHA-256 cannot be embedded self-referentially in
the ZIP without changing the ZIP hash. The final report is delivered alongside it.

## Not executed / release blockers

External Supabase migration, database policies/grants, unauthorized-access tests,
owner login/reset/revocation, public request persistence, Turnstile provider
verification, rate limits, idempotency/concurrent submissions, concurrent booking
conflicts, manual finance persistence, production deployment/smoke tests, backup
execution/restoration and measured performance were not verified.

No Razorpay, AI, automated messaging or digital-download code was implemented.
This is a verified-build source package with configuration-dependent backend
code, **not a verified operational or production-ready MVP**.
