# Setup and deployment guide

## Status and prerequisites

Intended domain: `vipmagicalphysio.com`, provided by the owner. Domain ownership,
DNS, hosting accounts and a live production deployment have **not** been verified.
No paid service, DNS change, production migration or payment activation was performed.

Use separate staging and production Supabase projects. Obtain owner approval
before production changes. Do not put real personal or financial records into staging.

## 1. Supabase

1. Create your Supabase project and record its region and billing limits.
2. In staging, apply `supabase/migrations/202611260001_foundation.sql`,
   then `supabase/migrations/202611260002_public_profiles.sql`
   using the Supabase SQL editor or your controlled Supabase CLI migration flow.
   The foundation migration is for a fresh external Supabase project, not a Replit-managed database.
   The second migration updates public business profile/contact settings only;
   review those owner-authorized values before applying to an existing installation.
   It is not rerunnable SQL: migration tooling should apply it exactly once.
3. Review all tables and policies before exposing any public keys.
4. In Authentication settings, **disable public user signups**. There is no signup page.
   Configure a strong password policy of at least 12 characters and rate limits.
5. Create or invite the owner through Supabase's private administrative interface.
   The owner must verify the email/invitation.
6. Copy the UUID shown for that auth user. In the SQL editor, replace the marker
   below with that UUID, then run the statement privately:

   ```sql
   insert into public.owner_accounts(user_id) values ('OWNER_AUTH_USER_UUID');
   ```

   The marker deliberately is not a working UUID. Never grant owner access
   using email text, public app settings or browser code.
   The insertion is audited by the database trigger. There is no reusable bootstrap endpoint.
7. Add your exact staging and production `/admin/reset` URLs to the allowed
   Authentication redirect URLs. Configure the auth Site URL and a working email
   sender, then test invitation and reset delivery.
8. MFA enrollment, challenge UI and mandatory AAL2 policies are **not implemented**.
   This is a documented production hardening gate, not a completed MFA claim.
   Provider-side MFA support alone does not prove the app enforces MFA.

## 2. Cloudflare Turnstile and Edge Function

1. Create a Turnstile widget for your exact staging and production hostnames.
2. Public build variables (in `.env.local` for local work or the Netlify build settings):
   - `VITE_SUPABASE_URL` — project URL.
   - `VITE_SUPABASE_ANON_KEY` — **legacy public anon JWT**, not a service-role key.
     This release leaves gateway JWT verification enabled; new opaque publishable
     keys are not a tested substitute for the legacy anon JWT in Edge invocation.
   - `VITE_TURNSTILE_SITE_KEY` — public widget key.
   - Optional `VITE_SITE_URL` — intended canonical origin; defaults to the requested domain.
3. In **Supabase Edge Function secrets**, securely configure:
   - `TURNSTILE_SECRET_KEY`.
   - `RATE_LIMIT_SALT` — a high-entropy server-only random value.
   - `ALLOWED_ORIGINS` — exact comma-separated origins, no trailing slashes.
     For example add the actual Netlify staging origin and, once approved,
     `https://vipmagicalphysio.com`. Do not use `*`.
   Supabase supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to functions.
   Never use a `VITE_` prefix for those secrets.
4. Deploy `supabase/functions/submit-enquiry` through the Supabase CLI:
   `supabase functions deploy submit-enquiry --project-ref YOUR_PROJECT_REF`.
5. Keep JWT verification enabled as in `supabase/config.toml`.
6. Add development origins only in a staging project and only when needed.
7. Rebuild the frontend after changing public build variables.

The Edge Function validates origin, input, consent and Turnstile hostname,
then calls a service-role-only transactional RPC. The RPC stores the enquiry
and applies an hourly fingerprint limit. CAPTCHA and origin allowlisting are
not treated as authorization for private records.

## 3. Netlify

The downloaded standalone project includes a root `netlify.toml` with
`pnpm build` and publish directory `dist/public`.
The in-repository configuration uses workspace paths instead.

1. Import the extracted source into your private GitHub repository.
2. Connect it to your Netlify account and review the detected build settings.
3. Add only public build variables described above.
4. Build and review a staging URL first.
5. Publish only after the staging gates below pass and the owner approves.
6. Follow Netlify's current custom-domain instructions for Hostinger DNS;
   use the records Netlify actually supplies. Do not guess IP addresses.
7. Verify TLS, bare/www redirects, canonical URLs and Supabase redirect/origin allowlists.

Netlify security headers are supplied. Review CSP for any deliberately added
provider; do not remove it merely to make an integration work.

## Staging acceptance checklist — all require execution

- [ ] Migration applies cleanly on a fresh staging project.
- [ ] Anon cannot read any enquiry, appointment, finance or audit row.
- [ ] A signed-in non-owner cannot access private rows or change settings.
- [ ] Public cannot call the insertion RPC or change owner permissions.
- [ ] Owner sign-in, sign-out, reset, session expiry and revocation work.
- [ ] Turnstile accepts valid tokens and rejects invalid/replayed/wrong-host tokens.
- [ ] Enquiry stores once, returns a reference, and a retry does not duplicate it.
- [ ] Honeypot, invalid fields, missing consent and rate limits reject safely.
- [ ] Home visit and online requests appear with the correct type.
- [ ] Owner status/follow-up changes survive navigation and reload.
- [ ] Concurrent CONFIRMED/RESCHEDULED appointments cannot overlap.
- [ ] Adjacent appointment intervals are allowed, canceled intervals released.
- [ ] CSV exports contain only authorized records and do not execute spreadsheet formulas.
- [ ] Content drafts stay private; publishing changes the intended language/page.
- [ ] Manually recorded amounts preserve paise and are not presented as paid gateway transactions.
- [ ] Auth and error logs contain no unnecessary personal data.
- [ ] Mobile, keyboard, screen reader and older-reader usability checks pass.
- [ ] Backups and a separate-environment restoration are independently verified.

Do not mark any item complete based only on the existence of its source code.
