# Operations, continuity, recovery, cost and roadmap

## Integration health

| Integration | Release state |
|---|---|
| Supabase database/Auth/Edge | CONFIGURATION REQUIRED; source adapter and migration supplied |
| Turnstile | CONFIGURATION REQUIRED; public and private keys/hostnames needed |
| Netlify/Hostinger DNS | CONFIGURATION REQUIRED; setup guide supplied, no deployment made |
| GitHub | CONFIGURATION REQUIRED; no repository connection or CI execution claimed |
| Razorpay | NOT IMPLEMENTED; no order, webhook, checkout or refund handling |
| Email/WhatsApp automation | NOT IMPLEMENTED; manual contact links only when configured |
| AI | NOT IMPLEMENTED; essential functions have no AI dependency |
| Backup provider | CONFIGURATION REQUIRED; no executed/verified backup claimed |

Settings indicate presence of public build variables, not live provider health.
There is no production health-check/alert pipeline. SDK failures are shown to
the user; audit records capture business writes without copies of patient data.
Structured error aggregation, correlation IDs and external monitoring are future
hardening requirements. Do not log form bodies or auth headers when adding them.

## Manual continuity procedures

- AI and automated messaging are absent; their outage cannot block the MVP.
- If optional messaging fails, contact the person using authorized contact details.
- If Supabase is unavailable, the public content remains readable, but records/
  submissions are unavailable. The app must not falsely acknowledge receipt.
  Use an owner-approved offline minimal administrative log, then reconcile securely
  once restored. The software cannot promise full operation during database outage.
- If Netlify is unavailable, use previously published real business contact channels.
- Do not enable public request buttons until at least one real fallback contact
  method has been verified and published.

## Backup and disaster recovery procedure

Source ZIP is a code package, **not a business-data backup**.
Supabase owns external database recovery. Verify your actual project's current
plan, retention window, backups/PITR availability and restore limitations in its
controls before relying on them. The release has no scheduled dump job.

Owner must approve measurable recovery objectives. Proposed planning targets
(not guarantees): RPO no greater than 24 hours and RTO no greater than one working
day. Do not advertise these until the selected plan and restore drill demonstrate them.

1. Record the deployed code version, external project reference, migrations and
   provider backup configuration without storing secrets in documents.
2. Confirm provider backup status and retention, including separately stored assets
   if digital products are later added.
3. Restore a provider recovery point into a **separate** staging/recovery environment.
4. Apply only compatible source code. Verify row counts, owner authorization,
   enquiry/appointment relationships, financial totals and audit accessibility.
5. Submit a synthetic enquiry, confirm a booking and validate auth there.
6. Record evidence, elapsed time and data-loss window. Only then label RESTORE TESTED.
7. Obtain approval before switching a live domain/configuration to recovered data.

Current states: BACKUP CONFIGURED — not verified; BACKUP EXECUTED — not verified;
BACKUP VERIFIED — not verified; RESTORE TESTED — not executed.

## Release and rollback

Keep the previous source release and tested build. Review schema compatibility
before redeploying old code. A Netlify code rollback does not reverse a migration.
If data/schema recovery is needed, stop writes and use the provider recovery
procedure above; do not drop tables or run destructive inverse SQL as a shortcut.
Rebuild after changing any VITE public configuration. Secrets rotate server-side.

## Cost and resource register

No paid subscriptions were activated. Current provider prices were **not
verified** in this release, so the following are categories, not quoted prices.
All actual budgeting should be entered/reviewed in INR by the owner.

| Component | Classification | Cost factor/upgrade trigger |
|---|---|---|
| React/Vite source | FREE software | Development and maintenance work |
| Supabase | FREE WITH LIMITATIONS or PAID | Inactivity policy, capacity, backup/PITR, storage/egress, auth email |
| Netlify | FREE WITH LIMITATIONS or PAID | Traffic/build usage and current billing terms |
| Turnstile | CREDENTIALS REQUIRED | Verify current provider terms and widget limits |
| Domain | PAID | Owner's Hostinger renewal and DNS ownership |
| GitHub | CREDENTIALS REQUIRED | Repository/security/CI usage plan |
| AI/messaging/payments | FUTURE REQUIREMENT | Explicit owner approval before activation |

Minimum/expected monthly operating cost: **not established** until current plans,
usage and domain renewal are reviewed. Optional expansion cost: not established.
Do not interpret a free tier as zero ongoing cost or a production availability SLA.
Favor manual contact and reports before buying automation. Document a new ADR
before any change affecting recurring cost, hosting or ownership.

## Future roadmap — not included functionality

1. Configure staging Supabase/Turnstile and execute release gates.
2. Implement enforced MFA, owner recovery, full privacy/retention controls.
3. Complete human-reviewed Hindi/Marathi clinical/legal content and accessibility tests.
4. Add full contact/consent history, pagination/full export and advanced availability.
5. Add safe manual financial corrections and idempotent manual-create operations.
6. Test backups/restoration and privacy-conscious monitoring.
7. Only then consider verified Razorpay checkout/downloads, notifications,
   operational intelligence, cost tracking and optional server-side AI.
8. Clinical documentation and portals require separately approved governance.
