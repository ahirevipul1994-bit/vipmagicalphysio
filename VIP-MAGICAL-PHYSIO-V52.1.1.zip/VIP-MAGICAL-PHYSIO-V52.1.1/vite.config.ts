import path from 'node:path';
import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({
  base:'/',plugins:[react(),tailwindcss()],
  resolve:{alias:{'@':path.resolve(import.meta.dirname,'src')},dedupe:['react','react-dom']},
  build:{outDir:'dist/public',emptyOutDir:true},
  server:{host:'0.0.0.0',port:5173},
});
