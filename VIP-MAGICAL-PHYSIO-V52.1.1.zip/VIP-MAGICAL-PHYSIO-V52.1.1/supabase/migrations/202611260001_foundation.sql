-- VIP Magical Physio 52.0.0 / external Supabase PostgreSQL only.
-- Purpose: administrative MVP. No clinical records. Apply to a NEW staging project first.
-- Recovery: restore provider snapshot into a separate project; do not drop live tables.
begin;
create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create table public.owner_accounts (
  user_id uuid primary key references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
alter table public.owner_accounts enable row level security;
revoke all on public.owner_accounts from anon, authenticated;

create function public.is_owner() returns boolean
language sql stable security definer set search_path = ''
as $$ select exists(select 1 from public.owner_accounts where user_id = auth.uid()); $$;
revoke all on function public.is_owner() from public;
grant execute on function public.is_owner() to authenticated;

create table public.business_settings (
  id integer primary key check(id = 1),
  value jsonb not null check(jsonb_typeof(value) = 'object'),
  updated_at timestamptz not null default now()
);
insert into public.business_settings(id, value) values (1, '{
  "name":"VIP MAGICAL PHYSIO","founder":"Dr. Vipul Ahire (Physio)",
  "location":"Shirur, Pune District, Maharashtra","phone":"","whatsapp":"",
  "email":"","hours":"By appointment","announcement":"","address":"",
  "languages":["English","हिन्दी","मराठी"]
}');
alter table public.business_settings enable row level security;
create policy settings_read on public.business_settings for select to anon, authenticated using (true);
create policy settings_owner_update on public.business_settings for update to authenticated using(public.is_owner()) with check(public.is_owner());
grant select on public.business_settings to anon, authenticated;
grant update on public.business_settings to authenticated;

create table public.enquiries (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null check(char_length(name) between 2 and 100),
  phone text not null check(phone ~ '^\+?[0-9 ()-]{10,20}$'),
  email text not null default '' check(char_length(email) <= 254),
  kind text not null check(kind in ('GENERAL','CLINIC','HOME_VISIT','ONLINE')),
  service text not null check(char_length(service) between 1 and 100),
  preferred_date date,
  locality text not null default '' check(char_length(locality) <= 150),
  message text not null default '' check(char_length(message) <= 1000),
  consent boolean not null check(consent),
  consent_version text not null default 'administrative-request-1',
  language text not null check(language in ('en','hi','mr')),
  source text not null default '' check(char_length(source) <= 200),
  status text not null default 'NEW' check(status in ('NEW','CONTACTED','APPOINTMENT_REQUESTED','CLOSED')),
  next_action text not null default '' check(char_length(next_action) <= 1000),
  follow_up_at timestamptz,
  idempotency_key uuid not null unique
);
create index enquiries_created on public.enquiries(created_at desc);
create index enquiries_follow_up on public.enquiries(follow_up_at) where status <> 'CLOSED';
alter table public.enquiries enable row level security;
revoke all on public.enquiries from anon, authenticated;
grant select on public.enquiries to authenticated;
grant update(status,next_action,follow_up_at) on public.enquiries to authenticated;
create policy enquiries_owner_read on public.enquiries for select to authenticated using(public.is_owner());
create policy enquiries_owner_update on public.enquiries for update to authenticated using(public.is_owner()) with check(public.is_owner());

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  enquiry_id uuid not null references public.enquiries(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null check(ends_at > starts_at),
  kind text not null check(kind in ('GENERAL','CLINIC','HOME_VISIT','ONLINE')),
  status text not null default 'REQUESTED' check(status in (
    'REQUESTED','PENDING_CONFIRMATION','CONFIRMED','RESCHEDULED','CANCELLED','COMPLETED','NO_SHOW')),
  notes text not null default '' check(char_length(notes) <= 1000),
  created_at timestamptz not null default now(),
  constraint appointment_no_overlap exclude using gist (
    tstzrange(starts_at, ends_at, '[)') with &&
  ) where (status in ('CONFIRMED','RESCHEDULED'))
);
create index appointments_enquiry on public.appointments(enquiry_id);
alter table public.appointments enable row level security;
revoke all on public.appointments from anon, authenticated;
grant select, insert, update on public.appointments to authenticated;
create policy appointment_owner on public.appointments for all to authenticated using(public.is_owner()) with check(public.is_owner());

create table public.content_pages (
  slug text not null check(slug ~ '^[a-z0-9/-]{1,100}$'),
  language text not null check(language in ('en','hi','mr')),
  title text not null check(char_length(title) between 1 and 200),
  body text not null check(char_length(body) <= 50000),
  published boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key(slug, language)
);
alter table public.content_pages enable row level security;
revoke all on public.content_pages from anon, authenticated;
grant select on public.content_pages to anon;
grant select,insert,update on public.content_pages to authenticated;
create policy content_public on public.content_pages for select to anon, authenticated using(published);
create policy content_owner on public.content_pages for all to authenticated using(public.is_owner()) with check(public.is_owner());

create table public.finance_records (
  id uuid primary key default gen_random_uuid(),
  kind text not null check(kind in ('PAYMENT','EXPENSE')),
  amount_paise bigint not null check(amount_paise > 0 and amount_paise <= 10000000000),
  description text not null check(char_length(description) between 1 and 500),
  occurred_at timestamptz not null,
  created_at timestamptz not null default now()
);
alter table public.finance_records enable row level security;
revoke all on public.finance_records from anon, authenticated;
grant select,insert on public.finance_records to authenticated;
create policy finance_owner on public.finance_records for all to authenticated using(public.is_owner()) with check(public.is_owner());

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor uuid,
  action text not null,
  entity text not null,
  record_key text,
  created_at timestamptz not null default now()
);
alter table public.audit_logs enable row level security;
revoke all on public.audit_logs from anon, authenticated;
grant select on public.audit_logs to authenticated;
create policy audit_owner_read on public.audit_logs for select to authenticated using(public.is_owner());
create function public.audit_change() returns trigger
language plpgsql security definer set search_path = ''
as $$
begin
  if TG_OP = 'DELETE' then
    insert into public.audit_logs(actor, action, entity, record_key)
      values(auth.uid(), TG_OP, TG_TABLE_NAME, to_jsonb(OLD)->>'user_id');
    return OLD;
  end if;
  insert into public.audit_logs(actor, action, entity, record_key)
    values(auth.uid(), TG_OP, TG_TABLE_NAME,
      coalesce(to_jsonb(NEW)->>'id', to_jsonb(NEW)->>'slug', to_jsonb(NEW)->>'user_id'));
  if TG_TABLE_NAME in ('business_settings','content_pages') then NEW.updated_at = now(); end if;
  return NEW;
end; $$;
revoke all on function public.audit_change() from public;
create trigger audit_enquiries before insert or update on public.enquiries for each row execute function public.audit_change();
create trigger audit_appointments before insert or update on public.appointments for each row execute function public.audit_change();
create trigger audit_finance before insert on public.finance_records for each row execute function public.audit_change();
create trigger audit_settings before update on public.business_settings for each row execute function public.audit_change();
create trigger audit_content before insert or update on public.content_pages for each row execute function public.audit_change();
create trigger audit_owner before insert or update or delete on public.owner_accounts for each row execute function public.audit_change();

-- This table contains salted request fingerprints, not clinical data. No client grants.
create table public.submission_limits (
  fingerprint text primary key,
  window_start timestamptz not null,
  attempts integer not null
);
alter table public.submission_limits enable row level security;
revoke all on public.submission_limits from anon, authenticated;

-- Called ONLY by the validated Edge Function with service_role credentials.
create function public.submit_administrative_enquiry(payload jsonb, request_fingerprint text)
returns uuid language plpgsql security definer set search_path = ''
as $$
declare reference uuid; count_attempts integer;
begin
  perform pg_advisory_xact_lock(hashtextextended(request_fingerprint, 0));
  insert into public.submission_limits as limits(fingerprint,window_start,attempts)
  values(request_fingerprint,now(),1)
  on conflict on constraint submission_limits_pkey do update set
    attempts = case when limits.window_start < now()-interval '1 hour' then 1 else limits.attempts+1 end,
    window_start = case when limits.window_start < now()-interval '1 hour' then now() else limits.window_start end
  returning attempts into count_attempts;
  if count_attempts > 10 then raise exception 'Request limit reached. Please try later.'; end if;
  if payload->>'preferred_date' is not null and (payload->>'preferred_date')::date < (now() at time zone 'Asia/Kolkata')::date then
    raise exception 'Choose today or a future date.';
  end if;
  insert into public.enquiries(name,phone,email,kind,service,preferred_date,locality,message,consent,language,source,idempotency_key)
  values(
    payload->>'name',payload->>'phone',coalesce(payload->>'email',''),payload->>'kind',
    payload->>'service',(payload->>'preferred_date')::date,coalesce(payload->>'locality',''),
    coalesce(payload->>'message',''),(payload->>'consent')::boolean,payload->>'language',
    coalesce(payload->>'source',''),(payload->>'idempotency_key')::uuid
  )
  on conflict(idempotency_key) do update set idempotency_key=excluded.idempotency_key
  returning id into reference;
  return reference;
end; $$;
revoke all on function public.submit_administrative_enquiry(jsonb,text) from public, anon, authenticated;
grant execute on function public.submit_administrative_enquiry(jsonb,text) to service_role;
commit;
