-- Owner-authorized public business contact/profile update.
-- This updates public settings only, not contacts, requests or clinical data.
-- Apply after 202611260001_foundation.sql through the external Supabase migration flow.
-- Recovery: owner can edit these public settings in the owner workspace.
begin;
update public.business_settings
set value = value || '{
  "phone":"+91 8624860808",
  "whatsapp":"918624860808",
  "google":"https://share.google/0vZTRWXueTNG8861z",
  "youtube":"https://www.youtube.com/@DrVipulAhireOfficial",
  "instagram":"https://www.instagram.com/physiotherapist_shirur/"
}'::jsonb
where id=1;
commit;
