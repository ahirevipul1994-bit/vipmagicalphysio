import { createClient } from 'npm:@supabase/supabase-js@2';

// Supabase gateway JWT verification remains enabled. The public anon JWT is not
// authorization to read data; only this endpoint can perform a validated insert.
const origins = (Deno.env.get('ALLOWED_ORIGINS') ?? '').split(',').map(s => s.trim()).filter(Boolean);
const headersFor = (origin: string) => ({
  'Content-Type': 'application/json', 'Vary': 'Origin',
  ...(origins.includes(origin) ? { 'Access-Control-Allow-Origin': origin } : {}),
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
});
Deno.serve(async req => {
  const origin = req.headers.get('origin') ?? '';
  const headers = headersFor(origin);
  const reply = (status: number, value: unknown) => new Response(JSON.stringify(value), {status,headers});
  if (!origins.includes(origin)) return reply(403,{error:'This website origin has not been enabled.'});
  if (req.method === 'OPTIONS') return new Response(null,{status:204,headers});
  if (req.method !== 'POST') return reply(405,{error:'POST required.'});
  const secret = Deno.env.get('TURNSTILE_SECRET_KEY');
  const salt = Deno.env.get('RATE_LIMIT_SALT');
  const url = Deno.env.get('SUPABASE_URL');
  const role = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!secret || !salt || !url || !role) return reply(503,{error:'Online requests need owner configuration. Nothing has been submitted.'});
  try {
    // Stream with a strict size cap; do not allocate an unbounded attacker-controlled body.
    const reader = req.body?.getReader();
    if (!reader) return reply(400,{error:'Request body required.'});
    let total = 0; const chunks: Uint8Array[] = [];
    while(true) {
      const {done,value} = await reader.read(); if(done) break;
      total += value.byteLength;
      if(total > 16384) { await reader.cancel(); return reply(413,{error:'Request too large.'}); }
      chunks.push(value);
    }
    const bytes = new Uint8Array(total); let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk,offset); offset += chunk.length; }
    const body = JSON.parse(new TextDecoder().decode(bytes));
    if (body.website) return reply(400,{error:'Unable to accept request.'});
    const text = (key: string, min: number, max: number) => {
      const value = typeof body[key] === 'string' ? body[key].trim() : '';
      if(value.length < min || value.length > max || /[\u0000-\u0008]/.test(value)) throw new Error('invalid');
      return value;
    };
    const payload = {
      name:text('name',2,100), phone:text('phone',10,20), email:text('email',0,254),
      kind:text('kind',1,20),service:text('service',1,100),
      locality:text('locality',0,150), message:text('message',0,1000),
      language:text('language',2,2), source:text('source',0,200),consent:body.consent,
      idempotency_key:text('idempotency_key',36,36),
      preferred_date: body.preferred_date ? text('preferred_date',10,10) : null,
    };
    if(!/^\+?[0-9 ()-]{10,20}$/.test(payload.phone) ||
       (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) ||
       !['GENERAL','CLINIC','HOME_VISIT','ONLINE'].includes(payload.kind) ||
       !['en','hi','mr'].includes(payload.language) || payload.consent !== true ||
       !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(payload.idempotency_key) ||
       (payload.preferred_date && !/^\d{4}-\d{2}-\d{2}$/.test(payload.preferred_date)) ||
       (payload.kind === 'HOME_VISIT' && !payload.locality)) return reply(400,{error:'Please check the required fields and consent.'});
    const token = text('captcha_token',1,2048);
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';
    const verification = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{
      method:'POST', body:new URLSearchParams({secret,response:token,remoteip:ip}),
      signal:AbortSignal.timeout(10000),
    });
    if(!verification.ok) return reply(503,{error:'Spam protection unavailable. Please try later.'});
    const verdict = await verification.json();
    const allowedHostnames = origins.map(o => new URL(o).hostname);
    if(verdict.success !== true || !allowedHostnames.includes(verdict.hostname)) return reply(400,{error:'Please complete the security check again.'});
    const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(salt + ':' + ip));
    const fingerprint = Array.from(new Uint8Array(hash), b=>b.toString(16).padStart(2,'0')).join('');
    const db = createClient(url,role,{auth:{persistSession:false}});
    const {data,error} = await db.rpc('submit_administrative_enquiry',{payload,request_fingerprint:fingerprint});
    if(error) {
      if(error.message.includes('Request limit')) return reply(429,{error:'Too many requests. Please try later.'});
      if(error.message.includes('future date')) return reply(400,{error:'Choose today or a future date.'});
      return reply(503,{error:'Your request could not be stored. Please try again.'});
    }
    return reply(201,{reference:data, message:'Request received. This is not an appointment confirmation.'});
  } catch {
    return reply(400,{error:'The request could not be processed. Check your details and security check, then retry.'});
  }
});
