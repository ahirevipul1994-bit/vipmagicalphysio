-- =====================================================================
-- VIP MAGICAL PHYSIO CLINIC — Core schema (Supabase / PostgreSQL 15)
-- Migration 001 · Phase 2 foundation
-- Principles: minimal data, clinical notes separated from marketing CRM,
-- RLS on every table, double-booking prevented by the database itself.
-- =====================================================================

create extension if not exists btree_gist;
create extension if not exists pgcrypto;
create extension if not exists citext;

-- ---------- Enums ----------
create type appointment_type   as enum ('clinic_opd','home_visit','online','follow_up');
create type appointment_status as enum ('requested','pending_confirmation','confirmed','completed','cancelled','rescheduled','no_show');
create type lang_code          as enum ('en','mr','hi');
create type lead_source        as enum ('appointment','home_visit','online_consult','ebook','newsletter','free_guide','contact','walk_in','other');
create type order_status       as enum ('created','paid','failed','refunded');
create type staff_role         as enum ('owner','admin','reception');

-- ---------- Staff (maps to auth.users) ----------
create table staff (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  full_name  text not null,
  role       staff_role not null default 'reception',
  created_at timestamptz not null default now()
);

create or replace function is_staff(min_role staff_role default 'reception')
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from staff s where s.user_id = auth.uid()
    and (min_role = 'reception'
      or (min_role = 'admin' and s.role in ('admin','owner'))
      or (min_role = 'owner' and s.role = 'owner'))
  );
$$;

-- ---------- CRM: customers (marketing / admin data ONLY) ----------
create table customers (
  id                uuid primary key default gen_random_uuid(),
  full_name         text not null check (char_length(full_name) between 2 and 120),
  phone_e164        text not null unique check (phone_e164 ~ '^\+91[6-9][0-9]{9}$'),
  email             citext,
  preferred_lang    lang_code not null default 'en',
  first_source      lead_source not null,
  category          text,                       -- e.g. 'patient','ebook_buyer','subscriber'
  follow_up_status  text not null default 'none',
  follow_up_on      date,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

-- Consent is a ledger, never a single boolean (DPDP: provable, withdrawable)
create table consents (
  id           bigserial primary key,
  customer_id  uuid not null references customers(id) on delete cascade,
  purpose      text not null check (purpose in ('contact_for_request','marketing_email','marketing_whatsapp','privacy_ack')),
  granted      boolean not null,
  policy_ver   text not null,
  source_page  text,
  recorded_at  timestamptz not null default now()
);

create table crm_notes (
  id          bigserial primary key,
  customer_id uuid not null references customers(id) on delete cascade,
  author      uuid references staff(user_id),
  body        text not null check (char_length(body) <= 2000),
  created_at  timestamptz not null default now()
);

-- ---------- Scheduling ----------
create table working_hours (
  id          serial primary key,
  weekday     smallint not null check (weekday between 0 and 6),  -- 0 = Sunday
  opens       time not null,
  closes      time not null check (closes > opens),
  appt_type   appointment_type not null,
  slot_minutes smallint not null default 45 check (slot_minutes between 15 and 120)
);

create table blocked_periods (
  id      serial primary key,
  period  tstzrange not null,
  reason  text
);

create table service_areas (
  id            serial primary key,
  name          text not null unique,          -- e.g. 'Shirur city'
  active        boolean not null default true,
  visit_fee_inr integer not null check (visit_fee_inr >= 0),
  travel_fee_inr integer not null default 0 check (travel_fee_inr >= 0)
);

create table appointments (
  id               uuid primary key default gen_random_uuid(),
  customer_id      uuid not null references customers(id),
  appt_type        appointment_type not null,
  service_slug     text not null,
  status           appointment_status not null default 'requested',
  slot             tstzrange not null,
  service_area_id  int references service_areas(id),
  age_group        text check (age_group in ('<18','18-44','45-59','60-74','75+')),
  brief_enquiry    text check (char_length(brief_enquiry) <= 400),
  mobility_notes   text check (char_length(mobility_notes) <= 400),
  video_link       text,                       -- set only after payment + confirmation
  rescheduled_from uuid references appointments(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  -- Home visits must name an approved area
  constraint home_visit_needs_area check (appt_type <> 'home_visit' or service_area_id is not null),
  -- THE double-booking guard: no two live appointments may overlap
  constraint no_overlap exclude using gist (slot with &&)
    where (status in ('requested','pending_confirmation','confirmed'))
);
create index on appointments (customer_id);
create index on appointments using gist (slot);

create table appointment_events (            -- full status history / audit
  id             bigserial primary key,
  appointment_id uuid not null references appointments(id) on delete cascade,
  from_status    appointment_status,
  to_status      appointment_status not null,
  actor          uuid,
  at             timestamptz not null default now()
);

create or replace function log_appt_status() returns trigger language plpgsql as $$
begin
  if tg_op = 'INSERT' or new.status is distinct from old.status then
    insert into appointment_events(appointment_id, from_status, to_status, actor)
    values (new.id, case when tg_op='UPDATE' then old.status end, new.status, auth.uid());
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger trg_appt_status before insert or update on appointments
  for each row execute function log_appt_status();

-- ---------- Clinical records (separate, owner/admin only, never exported to CRM) ----------
create table clinical_notes (
  id             bigserial primary key,
  appointment_id uuid not null references appointments(id) on delete restrict,
  author         uuid not null references staff(user_id),
  body           text not null,
  created_at     timestamptz not null default now()
);

-- ---------- Dard E Body Care store ----------
create table ebooks (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique,
  title        text not null,
  lang         lang_code not null,
  category     text not null,
  price_paise  integer not null check (price_paise > 0),
  storage_path text not null,                 -- path inside PRIVATE bucket 'ebooks'
  published    boolean not null default false,
  clinically_reviewed boolean not null default false,
  created_at   timestamptz not null default now(),
  constraint publish_requires_review check (not published or clinically_reviewed)
);

create table orders (
  id                  uuid primary key default gen_random_uuid(),
  customer_id         uuid not null references customers(id),
  ebook_id            uuid not null references ebooks(id),
  amount_paise        integer not null,
  status              order_status not null default 'created',
  razorpay_order_id   text unique,
  razorpay_payment_id text unique,           -- unique = idempotency guard
  paid_at             timestamptz,
  created_at          timestamptz not null default now()
);

create table webhook_events (                 -- idempotent webhook processing
  event_id     text primary key,               -- Razorpay x-razorpay-event-id
  type         text not null,
  received_at  timestamptz not null default now()
);

create table download_tokens (
  token_hash   text primary key,               -- sha256 of token; raw token only emailed
  order_id     uuid not null references orders(id) on delete cascade,
  expires_at   timestamptz not null,
  uses_left    smallint not null default 5 check (uses_left >= 0),
  created_at   timestamptz not null default now()
);

-- ---------- Email log ----------
create table email_log (
  id          bigserial primary key,
  customer_id uuid references customers(id),
  template    text not null,
  lang        lang_code not null,
  provider_id text,
  status      text not null,                   -- queued | sent | bounced | failed
  error       text,
  at          timestamptz not null default now()
);

-- ---------- Admin audit log ----------
create table audit_log (
  id      bigserial primary key,
  actor   uuid,
  action  text not null,
  entity  text not null,
  entity_id text,
  at      timestamptz not null default now()
);

-- =====================================================================
-- ROW LEVEL SECURITY — public has NO direct table access.
-- All public writes go through server functions using the service role.
-- =====================================================================
alter table staff            enable row level security;
alter table customers        enable row level security;
alter table consents         enable row level security;
alter table crm_notes        enable row level security;
alter table working_hours    enable row level security;
alter table blocked_periods  enable row level security;
alter table service_areas    enable row level security;
alter table appointments     enable row level security;
alter table appointment_events enable row level security;
alter table clinical_notes   enable row level security;
alter table ebooks           enable row level security;
alter table orders           enable row level security;
alter table webhook_events   enable row level security;
alter table download_tokens  enable row level security;
alter table email_log        enable row level security;
alter table audit_log        enable row level security;

-- Public read of non-sensitive catalogue/config only
create policy pub_read_ebooks   on ebooks        for select using (published);
create policy pub_read_areas    on service_areas for select using (active);
create policy pub_read_hours    on working_hours for select using (true);

-- Staff policies
create policy staff_self        on staff for select using (user_id = auth.uid() or is_staff('owner'));
create policy staff_customers   on customers     for all using (is_staff()) with check (is_staff());
create policy staff_consents    on consents      for select using (is_staff());
create policy staff_notes       on crm_notes     for all using (is_staff()) with check (is_staff());
create policy staff_appts       on appointments  for all using (is_staff()) with check (is_staff());
create policy staff_appt_ev     on appointment_events for select using (is_staff());
create policy admin_hours       on working_hours for all using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_blocks      on blocked_periods for all using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_areas       on service_areas for all using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_ebooks      on ebooks        for all using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_orders      on orders        for select using (is_staff('admin'));
create policy admin_email_log   on email_log     for select using (is_staff('admin'));
create policy owner_audit       on audit_log     for select using (is_staff('owner'));
-- Clinical notes: admin+ only, reception cannot read
create policy clinical_admin    on clinical_notes for all using (is_staff('admin')) with check (is_staff('admin'));
-- webhook_events & download_tokens: no policies => service role only.

-- Storage: create bucket 'ebooks' with public = false in the dashboard.
-- No storage policies for anon; files are served only via signed URLs
-- minted by the download function after token verification.
