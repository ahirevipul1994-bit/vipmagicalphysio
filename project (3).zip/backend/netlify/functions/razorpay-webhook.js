// POST /api/razorpay-webhook — the ONLY path that marks an order paid and releases a download.
// The browser "success" callback is ignored for fulfilment.
const crypto = require('crypto');
const { db, json } = require('./_lib');

const safeEq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

exports.handler = async (event) => {
  const raw = event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString('utf8') : event.body;
  const sig = event.headers['x-razorpay-signature'] || '';
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET).update(raw).digest('hex');
  if (!safeEq(sig, expected)) return json(401, { error: 'bad_signature' });

  const eventId = event.headers['x-razorpay-event-id'];
  const payload = JSON.parse(raw);

  // Idempotency: first insert wins; replays return 200 without side-effects.
  const { error: dup } = await db.from('webhook_events').insert({ event_id: eventId, type: payload.event });
  if (dup) return json(200, { ok: true, duplicate: true });

  if (payload.event === 'payment.captured' || payload.event === 'order.paid') {
    const p = payload.payload.payment.entity;
    const { data: order } = await db.from('orders')
      .select('id,amount_paise,status,customer_id').eq('razorpay_order_id', p.order_id).single();
    if (!order) return json(200, { ok: true, ignored: 'unknown_order' });
    if (order.status === 'paid') return json(200, { ok: true });
    if (p.amount !== order.amount_paise || p.currency !== 'INR') {
      console.error('amount_mismatch', order.id);
      return json(200, { ok: true, flagged: true });
    }

    await db.from('orders').update({ status: 'paid', razorpay_payment_id: p.id, paid_at: new Date().toISOString() })
      .eq('id', order.id).eq('status', 'created');

    // One-time raw token is emailed; only its hash is stored.
    const token = crypto.randomBytes(32).toString('base64url');
    const hash = crypto.createHash('sha256').update(token).digest('hex');
    await db.from('download_tokens').insert({
      token_hash: hash, order_id: order.id, expires_at: new Date(Date.now() + 72 * 3600e3).toISOString(),
    });
    await require('./send-email').queue('ebook_purchase', {
      customerId: order.customer_id, orderId: order.id,
      downloadUrl: `${process.env.SITE_URL}/api/download?t=${token}`,
    });
  }

  if (payload.event === 'payment.failed') {
    const p = payload.payload.payment.entity;
    await db.from('orders').update({ status: 'failed' }).eq('razorpay_order_id', p.order_id).eq('status', 'created');
  }
  return json(200, { ok: true });
};
