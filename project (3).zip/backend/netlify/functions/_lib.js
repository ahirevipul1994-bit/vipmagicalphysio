// Shared helpers for Netlify Functions. Server-side only — never bundled to the browser.
const { createClient } = require('@supabase/supabase-js');

const db = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

const json = (status, body) => ({
  statusCode: status,
  headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  body: JSON.stringify(body),
});

// Normalise Indian mobile to E.164. Returns null if invalid.
function toE164(raw) {
  const d = String(raw || '').replace(/\D/g, '').replace(/^(91|0)(?=[6-9]\d{9}$)/, '');
  return /^[6-9]\d{9}$/.test(d) ? `+91${d}` : null;
}

const LANGS = ['en', 'mr', 'hi'];
const clean = (s, max) => String(s || '').trim().slice(0, max);

// Upsert a CRM customer by phone and append consent rows. Returns customer id.
async function upsertCustomer({ name, phone, email, lang, source, consents, page }) {
  const { data, error } = await db
    .from('customers')
    .upsert({ full_name: name, phone_e164: phone, email: email || null, preferred_lang: lang, first_source: source },
            { onConflict: 'phone_e164', ignoreDuplicates: false })
    .select('id').single();
  if (error) throw error;
  const rows = Object.entries(consents).map(([purpose, granted]) => ({
    customer_id: data.id, purpose, granted: !!granted, policy_ver: process.env.PRIVACY_POLICY_VERSION || '2026-11', source_page: page,
  }));
  if (rows.length) await db.from('consents').insert(rows);
  return data.id;
}

module.exports = { db, json, toE164, LANGS, clean, upsertCustomer };
