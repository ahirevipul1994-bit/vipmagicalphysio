// POST /api/razorpay-create-order  { ebook_slug, name, phone, email, lang, consent_marketing }
// Price is read from the DATABASE, never from the browser.
const Razorpay = require('razorpay');
const { db, json, toE164, LANGS, clean, upsertCustomer } = require('./_lib');

const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'method_not_allowed' });
  const b = JSON.parse(event.body || '{}');
  const phone = toE164(b.phone);
  const email = clean(b.email, 160);
  if (!phone || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json(422, { error: 'validation' });

  const { data: book } = await db.from('ebooks').select('id,title,price_paise').eq('slug', b.ebook_slug).eq('published', true).single();
  if (!book) return json(404, { error: 'not_found' });

  const customerId = await upsertCustomer({
    name: clean(b.name, 120) || 'Customer', phone, email, lang: LANGS.includes(b.lang) ? b.lang : 'en',
    source: 'ebook', consents: { contact_for_request: true, marketing_email: !!b.consent_marketing }, page: `/ebooks/${b.ebook_slug}`,
  });

  const { data: order } = await db.from('orders')
    .insert({ customer_id: customerId, ebook_id: book.id, amount_paise: book.price_paise }).select('id').single();

  const rz = await rzp.orders.create({ amount: book.price_paise, currency: 'INR', receipt: order.id, notes: { order_id: order.id } });
  await db.from('orders').update({ razorpay_order_id: rz.id }).eq('id', order.id);

  // Only the PUBLIC key id is returned to the browser.
  return json(200, { key: process.env.RAZORPAY_KEY_ID, rz_order_id: rz.id, amount: book.price_paise, title: book.title });
};
