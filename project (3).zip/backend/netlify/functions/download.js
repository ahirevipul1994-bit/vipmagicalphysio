// GET /api/download?t=<token> — verifies token, decrements uses, redirects to a 5-minute signed URL
// from the PRIVATE 'ebooks' bucket. Files are never publicly addressable.
const crypto = require('crypto');
const { db } = require('./_lib');

exports.handler = async (event) => {
  const t = event.queryStringParameters?.t || '';
  const hash = crypto.createHash('sha256').update(t).digest('hex');
  const { data: tok } = await db.from('download_tokens')
    .select('order_id,expires_at,uses_left, orders!inner(status, ebooks!inner(storage_path))')
    .eq('token_hash', hash).single();

  const fail = (msg) => ({ statusCode: 403, headers: { 'content-type': 'text/plain' }, body: msg });
  if (!tok) return fail('This download link is not valid. Please contact the clinic on WhatsApp.');
  if (new Date(tok.expires_at) < new Date()) return fail('This link has expired. Reply to your purchase email for a fresh link.');
  if (tok.uses_left < 1) return fail('Download limit reached. Please contact us for help.');
  if (tok.orders.status !== 'paid') return fail('Payment not confirmed for this order.');

  await db.from('download_tokens').update({ uses_left: tok.uses_left - 1 }).eq('token_hash', hash).eq('uses_left', tok.uses_left);
  const { data: signed } = await db.storage.from('ebooks').createSignedUrl(tok.orders.ebooks.storage_path, 300, { download: true });
  return { statusCode: 302, headers: { location: signed.signedUrl, 'cache-control': 'no-store' } };
};
