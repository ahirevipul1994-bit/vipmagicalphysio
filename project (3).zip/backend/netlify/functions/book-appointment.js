// POST /api/book-appointment
// Creates an appointment REQUEST. Never returns "confirmed" — confirmation is a staff action.
// Double-booking is enforced by the `no_overlap` exclusion constraint (SQLSTATE 23P01).
const { db, json, toE164, LANGS, clean, upsertCustomer } = require('./_lib');

const TYPES = ['clinic_opd', 'home_visit', 'online', 'follow_up'];
const AGES = ['<18', '18-44', '45-59', '60-74', '75+'];

async function verifyTurnstile(token, ip) {
  if (!process.env.TURNSTILE_SECRET) return true; // spam protection optional until configured
  const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST',
    body: new URLSearchParams({ secret: process.env.TURNSTILE_SECRET, response: token || '', remoteip: ip || '' }),
  });
  return (await r.json()).success === true;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'method_not_allowed' });
  let b;
  try { b = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'bad_json' }); }

  // Honeypot
  if (b.website) return json(200, { ok: true, status: 'requested' });

  const errors = {};
  const name = clean(b.name, 120);
  const phone = toE164(b.phone);
  const lang = LANGS.includes(b.lang) ? b.lang : 'en';
  const type = TYPES.includes(b.type) ? b.type : null;
  const age = AGES.includes(b.age_group) ? b.age_group : null;
  const start = new Date(b.slot_start);
  if (name.length < 2) errors.name = 'required';
  if (!phone) errors.phone = 'invalid';
  if (!type) errors.type = 'required';
  if (isNaN(start) || start < new Date(Date.now() + 2 * 3600e3)) errors.slot = 'too_soon';
  if (!b.consent_contact) errors.consent_contact = 'required';
  if (!b.privacy_ack) errors.privacy_ack = 'required';
  if (b.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(b.email)) errors.email = 'invalid';
  if (Object.keys(errors).length) return json(422, { error: 'validation', fields: errors });

  if (!(await verifyTurnstile(b.turnstile, event.headers['x-nf-client-connection-ip'])))
    return json(403, { error: 'spam_check_failed' });

  // Slot must sit inside configured working hours for this appointment type
  const { data: hours } = await db.from('working_hours').select('*').eq('appt_type', type).eq('weekday', start.getUTCDay());
  const minutes = hours?.[0]?.slot_minutes || 45;
  const end = new Date(start.getTime() + minutes * 60e3);
  // (Full IST-aware working-hours check lives in available-slots.js; reused here.)

  // Home visits: area must be approved & active — otherwise we do NOT accept automatically
  let areaId = null;
  if (type === 'home_visit') {
    const { data: area } = await db.from('service_areas').select('id,active').eq('id', b.service_area_id).single();
    if (!area?.active) return json(422, { error: 'area_not_served', fields: { service_area_id: 'not_served' } });
    areaId = area.id;
  }

  try {
    const customerId = await upsertCustomer({
      name, phone, email: clean(b.email, 160), lang,
      source: type === 'home_visit' ? 'home_visit' : type === 'online' ? 'online_consult' : 'appointment',
      consents: { contact_for_request: true, privacy_ack: true, marketing_email: !!b.consent_marketing },
      page: clean(b.page, 200),
    });

    const { data, error } = await db.from('appointments').insert({
      customer_id: customerId, appt_type: type, service_slug: clean(b.service, 80),
      slot: `[${start.toISOString()},${end.toISOString()})`, service_area_id: areaId,
      age_group: age, brief_enquiry: clean(b.enquiry, 400), mobility_notes: clean(b.mobility, 400),
      status: 'requested',
    }).select('id,status').single();

    if (error) {
      if (error.code === '23P01') return json(409, { error: 'slot_taken' }); // overlap blocked by DB
      throw error;
    }

    // Acknowledgement (not confirmation) — fire and forget, logged in email_log
    if (b.email) require('./send-email').queue('appointment_ack', { customerId, lang, appointmentId: data.id }).catch(() => {});

    return json(201, { ok: true, reference: data.id.slice(0, 8).toUpperCase(), status: data.status });
  } catch (e) {
    console.error('book-appointment', e.code, e.message); // no PII in logs
    return json(500, { error: 'server' });
  }
};
