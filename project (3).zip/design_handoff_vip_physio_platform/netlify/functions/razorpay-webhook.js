// POST /api/razorpay-webhook — the ONLY path that marks an order paid and releases a download.
// HMAC-SHA256 verified, idempotent by event id, amount/currency re-checked, conditional status update prevents races.
const crypto = require('crypto');
const { db, json, token, sha256, safeEq, fail } = require('./lib/core');
const mailer = require('./lib/mailer');

function verify(raw, sig, secret) {
  if (!secret || !sig) return false;
  return safeEq(sig, crypto.createHmac('sha256', secret).update(raw).digest('hex'));
}

async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'method_not_allowed' });
  const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
  const h = Object.fromEntries(Object.entries(event.headers || {}).map(([k, v]) => [k.toLowerCase(), v]));
  if (!verify(raw, h['x-razorpay-signature'], process.env.RAZORPAY_WEBHOOK_SECRET)) return json(401, { error: 'bad_signature' });

  let payload; try { payload = JSON.parse(raw); } catch { return json(400, { error: 'bad_json' }); }
  const eventId = h['x-razorpay-event-id'] || sha256(raw);
  try {
    const { error: dup } = await db().from('webhook_events').insert({ event_id: eventId, type: payload.event });
    if (dup) return json(200, { ok: true, duplicate: true });

    if (payload.event === 'payment.captured' || payload.event === 'order.paid') {
      const p = payload.payload?.payment?.entity; if (!p) return json(200, { ok: true, ignored: 'no_payment' });
      const { data: order } = await db().from('orders').select('id,amount_paise,status,customer_id,ebook_id').eq('razorpay_order_id', p.order_id).maybeSingle();
      if (!order) return json(200, { ok: true, ignored: 'unknown_order' });
      if (p.amount !== order.amount_paise || p.currency !== 'INR') {
        await db().from('webhook_events').update({ error: 'amount_mismatch' }).eq('event_id', eventId);
        return json(200, { ok: true, flagged: 'amount_mismatch' });
      }
      // conditional update: only the first processor flips created->paid
      const { data: flipped } = await db().from('orders').update({ status: 'paid', razorpay_payment_id: p.id, paid_at: new Date().toISOString() })
        .eq('id', order.id).eq('status', 'created').select('id');
      if (flipped?.length) {
        const t = token(32);
        await db().from('download_tokens').insert({ token_hash: sha256(t), order_id: order.id, expires_at: new Date(Date.now() + 72 * 3600e3).toISOString() });
        const [{ data: c }, { data: e }] = await Promise.all([
          db().from('customers').select('full_name,email,preferred_lang').eq('id', order.customer_id).single(),
          db().from('ebooks').select('title').eq('id', order.ebook_id).single()]);
        if (c?.email) {
          await mailer.queue('ebook_purchase', { to: c.email, lang: c.preferred_lang, customerId: order.customer_id, dedupe: `ebook:${order.id}`,
            vars: { name: c.full_name, title: e?.title, order: order.id.slice(0, 8).toUpperCase(), download: `${process.env.SITE_URL}/api/download?t=${t}` } });
          await mailer.processQueue(3).catch(() => {});
        }
        await db().from('customers').update({ category: 'ebook_buyer' }).eq('id', order.customer_id).neq('category', 'patient');
      }
    } else if (payload.event === 'payment.failed') {
      const p = payload.payload?.payment?.entity;
      if (p) await db().from('orders').update({ status: 'failed' }).eq('razorpay_order_id', p.order_id).eq('status', 'created');
    } else if (payload.event === 'refund.processed') {
      const r = payload.payload?.refund?.entity;
      if (r) {
        const { data: o } = await db().from('orders').update({ status: 'refunded', refunded_at: new Date().toISOString() }).eq('razorpay_payment_id', r.payment_id).select('id');
        if (o?.[0]) await db().from('download_tokens').update({ uses_left: 0 }).eq('order_id', o[0].id); // revoke access
      }
    }
    await db().from('webhook_events').update({ processed_at: new Date().toISOString() }).eq('event_id', eventId);
    return json(200, { ok: true });
  } catch (e) {
    // allow Razorpay to retry: remove the idempotency row so the retry is processed
    await db().from('webhook_events').delete().eq('event_id', eventId).is('processed_at', null).then(() => {}, () => {});
    return fail(e, 'webhook');
  }
}
exports.handler = handler;
exports._verify = verify;
