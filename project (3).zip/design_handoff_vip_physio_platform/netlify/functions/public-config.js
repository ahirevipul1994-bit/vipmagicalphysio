// GET /api/public-config → only PUBLIC values the browser may know (Supabase anon key is designed to be public; RLS protects data).
const { json } = require('./lib/core');
exports.handler = async () => json(200, {
  supabaseUrl: process.env.SUPABASE_URL || null,
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || null,
  turnstileSiteKey: process.env.TURNSTILE_SITE_KEY || null,
  ga4: process.env.GA4_MEASUREMENT_ID || null,
  payments: !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
  email: !!process.env.BREVO_API_KEY,
}, { 'cache-control': 'public, max-age=300' });
