// POST /api/book-appointment — creates a REQUEST (never "confirmed").
// Layers: validation → spam check → slot must match working hours → DB exclusion constraint (23P01) as final guard.
const { db, json, parse, toE164, isEmail, lang, clean, verifyTurnstile, upsertCustomer, fail } = require('./lib/core');
const { matchSlot } = require('./lib/slots');
const mailer = require('./lib/mailer');

const TYPES = ['clinic_opd', 'home_visit', 'online', 'follow_up'];
const AGES = ['<18', '18-44', '45-59', '60-74', '75+'];
const TYPE_LABEL = { en: { clinic_opd: 'Clinic OPD', home_visit: 'Home visit', online: 'Online consultation', follow_up: 'Follow-up' },
  mr: { clinic_opd: 'क्लिनिक OPD', home_visit: 'घरी भेट', online: 'ऑनलाइन सल्ला', follow_up: 'फॉलो-अप' },
  hi: { clinic_opd: 'क्लिनिक OPD', home_visit: 'घर पर विज़िट', online: 'ऑनलाइन परामर्श', follow_up: 'फॉलो-अप' } };

function validate(b) {
  const f = {};
  const out = {
    name: clean(b.name, 120), phone: toE164(b.phone), email: clean(b.email, 160).toLowerCase(), lang: lang(b.lang),
    type: TYPES.includes(b.type) ? b.type : null, age: AGES.includes(b.age_group) ? b.age_group : null,
    service: clean(b.service, 80).replace(/[^a-z0-9-]/g, ''), start: b.slot_start,
    areaId: Number.isInteger(b.service_area_id) ? b.service_area_id : null, locality: clean(b.locality_text, 80),
    enquiry: clean(b.enquiry, 400), mobility: clean(b.mobility, 400), page: clean(b.page, 200),
  };
  if (out.name.length < 2) f.name = 'required';
  if (!out.phone) f.phone = 'invalid';
  if (out.email && !isEmail(out.email)) f.email = 'invalid';
  if (!out.type) f.type = 'required';
  if (!out.age) f.age_group = 'required';
  if (!out.service) f.service = 'required';
  if (!b.slot_start || isNaN(new Date(b.slot_start))) f.slot = 'required';
  if (out.type === 'home_visit' && !out.areaId && out.locality.length < 2) f.service_area_id = 'required';
  if (b.consent_contact !== true) f.consent_contact = 'required';
  if (b.privacy_ack !== true) f.privacy_ack = 'required';
  return { v: out, fields: f };
}

async function handler(event) {
  const { body: b, err } = parse(event); if (err) return err;
  if (b.website) return json(201, { ok: true, reference: 'RECEIVED', status: 'requested' }); // honeypot: silently drop
  const { v, fields } = validate(b);
  if (Object.keys(fields).length) return json(422, { error: 'validation', fields });
  if (!(await verifyTurnstile(b.turnstile, event.headers['x-nf-client-connection-ip']))) return json(403, { error: 'spam_check_failed' });

  try {
    // Slot must be a real, currently-free slot from configured hours (prevents arbitrary times)
    const { data: hours } = await db().from('working_hours').select('weekday,opens,closes,slot_minutes').eq('appt_type', v.type);
    const slot = matchSlot(v.start, hours || [], []);
    if (!slot) return json(422, { error: 'validation', fields: { slot: 'outside_hours' } });

    let areaId = null, needsReview = false, localityName = v.locality;
    if (v.type === 'home_visit') {
      if (v.areaId) {
        const { data: area } = await db().from('service_areas').select('id,name,active').eq('id', v.areaId).maybeSingle();
        if (area?.active) { areaId = area.id; localityName = area.name; } else needsReview = true;
      } else needsReview = true; // unlisted → accepted as request, flagged, can never be auto-confirmed (DB check)
    }

    const customerId = await upsertCustomer({
      name: v.name, phone: v.phone, email: v.email, lang: v.lang,
      source: v.type === 'home_visit' ? 'home_visit' : v.type === 'online' ? 'online_consult' : 'appointment',
      consents: { contact_for_request: true, privacy_ack: true, marketing_email: b.consent_marketing === true },
      page: v.page,
    });

    const { data, error } = await db().from('appointments').insert({
      customer_id: customerId, appt_type: v.type, service_slug: v.service, status: 'requested',
      slot: `[${slot.start},${slot.end})`, service_area_id: areaId, locality_text: needsReview ? (v.locality || 'unlisted') : null,
      needs_area_review: needsReview, age_group: v.age, brief_enquiry: v.enquiry || null, mobility_notes: v.mobility || null,
    }).select('id,reference,status').single();
    if (error) {
      if (error.code === '23P01') return json(409, { error: 'slot_taken' });
      throw error;
    }

    if (v.email) {
      const when = new Date(slot.start).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' });
      const tpl = v.type === 'home_visit' ? 'home_visit_ack' : 'appointment_ack';
      try {
        await mailer.queue(tpl, { to: v.email, lang: v.lang, customerId, dedupe: `ack:${data.id}`,
          vars: { name: v.name, ref: data.reference, when, type: TYPE_LABEL[v.lang][v.type], locality: localityName, review: needsReview ? '1' : '' } });
        await mailer.processQueue(3);
      } catch (e) { console.error('ack_email', e.message); } // never fail the booking because of email
    }
    return json(201, { ok: true, reference: data.reference, status: data.status, needs_area_review: needsReview });
  } catch (e) { return fail(e, 'book-appointment'); }
}
exports.handler = handler;
exports._validate = validate;
