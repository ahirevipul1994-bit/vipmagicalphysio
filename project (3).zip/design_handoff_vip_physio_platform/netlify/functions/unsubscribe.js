// GET /api/unsubscribe?t=<subscriber token>  OR  ?c=<customer id>&s=<hmac>  → withdraws marketing consent (one click, no login)
const { db, sha256, safeEq, recordConsents } = require('./lib/core');
const page = (msg) => ({ statusCode: 200, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' },
  body: `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Unsubscribed</title><body style="font-family:system-ui;max-width:520px;margin:15vh auto;padding:0 20px;color:#1F1C1D"><h1 style="font-family:Georgia;color:#7A1F2B">Unsubscribed</h1><p>${msg}</p><p><a href="/">VIP Magical Physio Clinic →</a></p>` });

exports.handler = async (event) => {
  const q = event.queryStringParameters || {};
  try {
    if (q.t) {
      await db().from('subscribers').update({ status: 'unsubscribed', unsubscribed_at: new Date().toISOString() }).eq('unsub_token', q.t);
    } else if (q.c && q.s && safeEq(q.s, sha256((process.env.UNSUB_SECRET || '') + q.c).slice(0, 24))) {
      await recordConsents(q.c, { marketing_email: false }, '/api/unsubscribe');
    } else return page('This link is not valid. Reply to any of our emails and we will remove you manually.');
    return page('You will no longer receive marketing emails from us. Appointment and order messages you request will still be sent.');
  } catch (e) { console.error('unsub', e.message); return page('We could not process this right now. Reply to the email and we will remove you manually.'); }
};
