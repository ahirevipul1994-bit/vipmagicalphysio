// POST /api/admin-api {action, ...}  — every action re-verifies the caller's JWT + staff role server-side.
// Reads that RLS already protects can also go direct from the dashboard; writes with side-effects come here.
const { db, json, parse, requireStaff, audit, clean, fail } = require('./lib/core');
const mailer = require('./lib/mailer');
const STATUSES = ['requested', 'pending_confirmation', 'confirmed', 'completed', 'cancelled', 'rescheduled', 'no_show'];
const TL = { en: { clinic_opd: 'Clinic OPD', home_visit: 'Home visit', online: 'Online consultation', follow_up: 'Follow-up' },
  mr: { clinic_opd: 'क्लिनिक OPD', home_visit: 'घरी भेट', online: 'ऑनलाइन सल्ला', follow_up: 'फॉलो-अप' },
  hi: { clinic_opd: 'क्लिनिक OPD', home_visit: 'घर पर विज़िट', online: 'ऑनलाइन परामर्श', follow_up: 'फॉलो-अप' } };
const csv = (rows, cols) => [cols.join(','), ...rows.map((r) => cols.map((c) => `"${String(r[c] ?? '').replace(/"/g, '""').replace(/^[=+\-@]/, "'$&")}"`).join(','))].join('\n');

const ACTIONS = {
  // ---- appointments ----
  async set_status({ id, status, fee_inr, video_link }, ctx) {
    if (!STATUSES.includes(status)) return json(422, { error: 'bad_status' });
    const { data: a } = await db().from('appointments').select('id,status,appt_type,needs_area_review,slot,customer_id,customers(full_name,email,preferred_lang),service_areas(name)').eq('id', id).single();
    if (!a) return json(404, { error: 'not_found' });
    if (status === 'confirmed' && a.needs_area_review) return json(409, { error: 'area_review_required' });
    if (status === 'confirmed' && a.appt_type === 'online' && !video_link) return json(422, { error: 'video_link_required' });
    const patch = { status };
    if (Number.isInteger(fee_inr) && fee_inr >= 0) patch.fee_inr = fee_inr;
    if (video_link) { if (!/^https:\/\//.test(video_link)) return json(422, { error: 'video_link_https' }); patch.video_link = video_link; }
    const { error } = await db().from('appointments').update(patch).eq('id', id);
    if (error) return json(error.code === 'P0001' ? 409 : 400, { error: error.message });
    if (status === 'completed') await db().from('customers').update({ category: 'patient' }).eq('id', a.customer_id);
    await audit(ctx.user.id, `appt:${status}`, 'appointment', id, { from: a.status });
    const c = a.customers;
    if (status === 'confirmed' && c?.email) {
      const l = c.preferred_lang; const d = new Date(String(a.slot).match(/[\[(]"?([^",]+)/)[1]);
      await mailer.queue('appointment_confirmed', { to: c.email, lang: l, customerId: a.customer_id, dedupe: `confirm:${id}:${d.toISOString()}`,
        vars: { name: c.full_name, type: TL[l][a.appt_type], when: d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'full', timeStyle: 'short' }),
          location: a.appt_type === 'home_visit' ? a.service_areas?.name || '' : a.appt_type === 'online' ? '' : 'VIP Magical Physio Clinic, Shirur', video: patch.video_link || '' } });
      await mailer.processQueue(3).catch(() => {});
    }
    return json(200, { ok: true });
  },
  async approve_area({ id, service_area_id }, ctx) {
    const { error } = await db().from('appointments').update({ needs_area_review: false, service_area_id: service_area_id || null, status: 'pending_confirmation' })
      .eq('id', id).eq('needs_area_review', true);
    if (error) return json(400, { error: error.message });
    await audit(ctx.user.id, 'appt:area_approved', 'appointment', id, { service_area_id });
    return json(200, { ok: true });
  },
  async reschedule({ id, slot_start, minutes = 45 }, ctx) {
    const { data: old } = await db().from('appointments').select('*').eq('id', id).single();
    if (!old || !['requested', 'pending_confirmation', 'confirmed'].includes(old.status)) return json(409, { error: 'not_reschedulable' });
    const s = new Date(slot_start); if (isNaN(s)) return json(422, { error: 'bad_slot' });
    const e = new Date(s.getTime() + minutes * 60e3);
    // Atomic in Postgres (single function = single transaction): old→rescheduled + new row, or nothing.
    const { data: nw, error } = await db().rpc('reschedule_appointment', { p_id: id, p_start: s.toISOString(), p_end: e.toISOString() });
    if (error) return json(error.code === '23P01' ? 409 : 400, { error: error.code === '23P01' ? 'slot_taken' : error.message });
    await audit(ctx.user.id, 'appt:rescheduled', 'appointment', id, { new_id: (Array.isArray(nw) ? nw[0] : nw)?.id });
    const row = Array.isArray(nw) ? nw[0] : nw;
    return json(200, { ok: true, new_id: row?.id, reference: row?.reference });
  },
  // ---- CRM ----
  async add_note({ customer_id, body }, ctx) {
    const b = clean(body, 2000); if (!b) return json(422, { error: 'empty' });
    await db().from('crm_notes').insert({ customer_id, body: b, author: ctx.user.id });
    return json(200, { ok: true });
  },
  async set_followup({ customer_id, follow_up_status, follow_up_on }, ctx) {
    await db().from('customers').update({ follow_up_status, follow_up_on: follow_up_on || null }).eq('id', customer_id);
    await audit(ctx.user.id, 'crm:followup', 'customer', customer_id, { follow_up_status, follow_up_on });
    return json(200, { ok: true });
  },
  async export_crm(_, ctx) { // admin+: business fields only, NO enquiry text / clinical data
    if (ctx.staff.role === 'reception') return json(403, { error: 'forbidden' });
    const { data } = await db().from('customers').select('id,full_name,phone_e164,email,preferred_lang,first_source,last_source,category,follow_up_status,follow_up_on,created_at').order('created_at', { ascending: false }).limit(5000);
    const { data: cons } = await db().from('customer_consent_current').select('customer_id,purpose,granted');
    const mk = new Map((cons || []).filter((c) => c.purpose === 'marketing_email').map((c) => [c.customer_id, c.granted]));
    const rows = (data || []).map((r) => ({ ...r, marketing_consent: mk.get(r.id) ? 'yes' : 'no' }));
    await audit(ctx.user.id, 'crm:export', 'customers', null, { count: rows.length });
    return { statusCode: 200, headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="crm-${new Date().toISOString().slice(0, 10)}.csv"`, 'cache-control': 'no-store' },
      body: '\ufeff' + csv(rows, ['id', 'full_name', 'phone_e164', 'email', 'preferred_lang', 'first_source', 'last_source', 'category', 'follow_up_status', 'follow_up_on', 'marketing_consent', 'created_at']) };
  },
  // ---- Email ----
  async retry_email({ id }, ctx) {
    await db().from('email_queue').update({ status: 'queued', send_after: new Date().toISOString(), attempts: 0 }).eq('id', id).eq('status', 'failed');
    const r = await mailer.processQueue(5);
    return json(200, { ok: true, ...r });
  },
  async newsletter({ subject_en, body_en, subject_mr, body_mr, subject_hi, body_hi, test_to }, ctx) {
    if (ctx.staff.role !== 'owner') return json(403, { error: 'owner_only' });
    const L = { en: [subject_en, body_en], mr: [subject_mr, body_mr], hi: [subject_hi, body_hi] };
    for (const [l, [s, b]] of Object.entries(L)) if (s && b) await db().from('email_templates').upsert({ key: 'newsletter', lang: l, subject: clean(s, 150), body_html: String(b).slice(0, 20000), is_marketing: true });
    // Only ACTIVE (double-opt-in) subscribers. DB trigger also skips any row without consent.
    let q = db().from('subscribers').select('id,email,lang').eq('status', 'active');
    if (test_to) q = q.eq('email', test_to);
    const { data: subs } = await q;
    const tag = new Date().toISOString().slice(0, 10);
    let n = 0;
    for (const s of subs || []) { if (!L[s.lang]?.[0]) continue; await mailer.queue('newsletter', { to: s.email, lang: s.lang, subscriberId: s.id, dedupe: `nl:${tag}:${s.id}` }); n++; }
    await audit(ctx.user.id, 'email:newsletter', 'subscribers', null, { queued: n, test: !!test_to });
    return json(200, { ok: true, queued: n });
  },
  // ---- Settings (admin) ----
  async upsert_area(a, ctx) {
    if (ctx.staff.role === 'reception') return json(403, { error: 'forbidden' });
    const row = { name: clean(a.name, 80), active: a.active !== false, visit_fee_inr: +a.visit_fee_inr || 0, travel_fee_inr: +a.travel_fee_inr || 0 };
    const r = a.id ? await db().from('service_areas').update(row).eq('id', a.id) : await db().from('service_areas').insert(row);
    if (r.error) return json(400, { error: r.error.message });
    await audit(ctx.user.id, 'settings:area', 'service_area', a.id || row.name, row);
    return json(200, { ok: true });
  },
  async replace_hours({ type, rows }, ctx) {
    if (ctx.staff.role === 'reception') return json(403, { error: 'forbidden' });
    await db().from('working_hours').delete().eq('appt_type', type);
    if (rows?.length) { const { error } = await db().from('working_hours').insert(rows.map((r) => ({ ...r, appt_type: type }))); if (error) return json(400, { error: error.message }); }
    await audit(ctx.user.id, 'settings:hours', 'working_hours', type, { rows: rows?.length || 0 });
    return json(200, { ok: true });
  },
  async block_period({ start, end, reason }, ctx) {
    if (ctx.staff.role === 'reception') return json(403, { error: 'forbidden' });
    await db().from('blocked_periods').insert({ period: `[${new Date(start).toISOString()},${new Date(end).toISOString()})`, reason: clean(reason, 120) });
    return json(200, { ok: true });
  },
  async update_settings(s, ctx) {
    if (ctx.staff.role !== 'owner') return json(403, { error: 'owner_only' });
    const allowed = ['address_line', 'pin_code', 'google_place_id', 'google_review_url', 'opd_fee_inr', 'online_fee_inr', 'reminder_hours', 'booking_horizon_days'];
    const patch = Object.fromEntries(Object.entries(s).filter(([k]) => allowed.includes(k)));
    await db().from('clinic_settings').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', true);
    await audit(ctx.user.id, 'settings:clinic', 'clinic_settings', 'singleton', patch);
    return json(200, { ok: true });
  },
};

exports.handler = async (event) => {
  const { body: b, err } = parse(event); if (err) return err;
  try {
    const ctx = await requireStaff(event); if (ctx.err) return ctx.err;
    const fn = ACTIONS[b.action]; if (!fn) return json(400, { error: 'unknown_action' });
    return await fn(b, ctx);
  } catch (e) { return fail(e, 'admin-api:' + b.action); }
};
exports._ACTIONS = Object.keys(ACTIONS);
