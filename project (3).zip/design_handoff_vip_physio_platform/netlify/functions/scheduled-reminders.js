// Scheduled hourly (netlify.toml). Queues 24h reminders for CONFIRMED appointments, review requests after
// COMPLETED visits (sent to all eligible patients — no filtering by expected sentiment), and flushes the queue.
const { db } = require('./lib/core');
const mailer = require('./lib/mailer');
const TL = { en: { clinic_opd: 'Clinic OPD', home_visit: 'Home visit', online: 'Online consultation', follow_up: 'Follow-up' },
  mr: { clinic_opd: 'क्लिनिक OPD', home_visit: 'घरी भेट', online: 'ऑनलाइन सल्ला', follow_up: 'फॉलो-अप' },
  hi: { clinic_opd: 'क्लिनिक OPD', home_visit: 'घर पर विज़िट', online: 'ऑनलाइन परामर्श', follow_up: 'फॉलो-अप' } };
const lower = (r) => new Date(String(r).match(/[\[(]"?([^",]+)/)[1]);

exports.handler = async () => {
  if (!process.env.SUPABASE_URL) return { statusCode: 200, body: 'not_configured' };
  const now = Date.now();
  const { data: settings } = await db().from('clinic_settings').select('reminder_hours,google_review_url').single();
  const hrs = settings?.reminder_hours || 24;
  const from = new Date(now + (hrs - 1) * 3600e3).toISOString(), to = new Date(now + (hrs + 1) * 3600e3).toISOString();

  const { data: due } = await db().from('appointments').select('id,slot,appt_type,video_link, customers!inner(id,full_name,email,preferred_lang)')
    .eq('status', 'confirmed').is('reminder_sent_at', null).overlaps('slot', `[${from},${to})`);
  for (const a of due || []) {
    const c = a.customers; if (!c.email) continue;
    const d = lower(a.slot);
    await mailer.queue('appointment_reminder', { to: c.email, lang: c.preferred_lang, customerId: c.id, dedupe: `reminder:${a.id}`,
      vars: { name: c.full_name, type: TL[c.preferred_lang][a.appt_type], when: d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' }),
        time: d.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit' }), video: a.video_link || '' } });
    await db().from('appointments').update({ reminder_sent_at: new Date().toISOString() }).eq('id', a.id);
  }

  if (settings?.google_review_url) {
    const { data: done } = await db().from('appointments').select('id, customers!inner(id,full_name,email,preferred_lang)')
      .eq('status', 'completed').gte('updated_at', new Date(now - 48 * 3600e3).toISOString()).lte('updated_at', new Date(now - 20 * 3600e3).toISOString());
    for (const a of done || []) {
      const c = a.customers; if (!c.email) continue;
      await mailer.queue('review_request', { to: c.email, lang: c.preferred_lang, customerId: c.id, dedupe: `review:${c.id}:${new Date().toISOString().slice(0, 7)}`,
        vars: { name: c.full_name, review: settings.google_review_url } });
    }
  }
  const r = await mailer.processQueue(50);
  return { statusCode: 200, body: JSON.stringify({ reminders: (due || []).length, ...r }) };
};
