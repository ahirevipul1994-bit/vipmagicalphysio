// POST /api/razorpay-create-order {ebook_slug,name,phone,email,lang,consent_marketing}
// Price is read from the DATABASE, never trusted from the browser. Only the public key id is returned.
const { db, json, parse, toE164, isEmail, lang, clean, upsertCustomer, fail } = require('./lib/core');

exports.handler = async (event) => {
  const { body: b, err } = parse(event); if (err) return err;
  const phone = toE164(b.phone), email = clean(b.email, 160).toLowerCase();
  if (!phone || !isEmail(email) || b.privacy_ack !== true) return json(422, { error: 'validation' });
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return json(503, { error: 'payments_not_configured' });
  try {
    const { data: book } = await db().from('ebooks').select('id,title,price_paise').eq('slug', clean(b.ebook_slug, 80)).eq('published', true).maybeSingle();
    if (!book) return json(404, { error: 'not_found' });
    const customerId = await upsertCustomer({ name: clean(b.name, 120) || 'Customer', phone, email, lang: lang(b.lang), source: 'ebook', category: 'ebook_buyer',
      consents: { contact_for_request: true, privacy_ack: true, marketing_email: b.consent_marketing === true }, page: `/ebooks/${b.ebook_slug}` });
    const { data: order, error } = await db().from('orders').insert({ customer_id: customerId, ebook_id: book.id, amount_paise: book.price_paise }).select('id').single();
    if (error) throw error;
    const Razorpay = require('razorpay');
    const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const rz = await rzp.orders.create({ amount: book.price_paise, currency: 'INR', receipt: order.id, notes: { order_id: order.id } });
    await db().from('orders').update({ razorpay_order_id: rz.id }).eq('id', order.id);
    return json(200, { key: process.env.RAZORPAY_KEY_ID, rz_order_id: rz.id, amount: book.price_paise, title: book.title, order_ref: order.id.slice(0, 8).toUpperCase() });
  } catch (e) { return fail(e, 'create-order'); }
};
