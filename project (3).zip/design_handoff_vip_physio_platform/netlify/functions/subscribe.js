// POST /api/subscribe {email, lang, consent:true, source?, guide?}  → double opt-in
const { db, json, parse, isEmail, lang, clean, token, fail } = require('./lib/core');
const mailer = require('./lib/mailer');

exports.handler = async (event) => {
  const { body: b, err } = parse(event); if (err) return err;
  if (b.website) return json(200, { ok: true });
  const email = clean(b.email, 160).toLowerCase();
  if (!isEmail(email) || b.consent !== true) return json(422, { error: 'validation' });
  const l = lang(b.lang); const source = b.source === 'free_guide' ? 'free_guide' : 'newsletter';
  try {
    const { data: ex } = await db().from('subscribers').select('id,status,confirm_token').eq('email', email).maybeSingle();
    if (ex?.status === 'active') return json(200, { ok: true, status: 'already_active' });
    const ct = token(24);
    const row = ex
      ? (await db().from('subscribers').update({ status: 'pending', confirm_token: ct, lang: l, consented_at: new Date().toISOString() }).eq('id', ex.id).select('id').single()).data
      : (await db().from('subscribers').insert({ email, lang: l, source, confirm_token: ct }).select('id').single()).data;
    const site = process.env.SITE_URL || 'https://vipmagicalphysio.com';
    await mailer.queue('subscribe_confirm', { to: email, lang: l, subscriberId: row.id, vars: { confirm: `${site}/api/confirm-subscription?t=${ct}` }, dedupe: `confirm:${ct}` });
    await mailer.processQueue(3).catch(() => {});
    return json(200, { ok: true, status: 'pending_confirmation' });
  } catch (e) { return fail(e, 'subscribe'); }
};
