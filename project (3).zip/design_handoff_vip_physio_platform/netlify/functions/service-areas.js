// GET /api/service-areas → { areas:[{id,name}] }  (fees are disclosed by phone/confirmation, not here)
const { db, json, fail } = require('./lib/core');
exports.handler = async () => {
  try {
    const { data, error } = await db().from('service_areas').select('id,name').eq('active', true).order('sort').order('name');
    if (error) throw error;
    return json(200, { areas: data || [] }, { 'cache-control': 'public, max-age=300' });
  } catch (e) { return fail(e, 'service-areas'); }
};
