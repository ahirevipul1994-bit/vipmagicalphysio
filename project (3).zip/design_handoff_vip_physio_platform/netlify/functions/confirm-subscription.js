// GET /api/confirm-subscription?t=… → activates subscriber, queues welcome email, shows a simple page
const { db, fail } = require('./lib/core');
const mailer = require('./lib/mailer');
const page = (title, msg) => ({ statusCode: 200, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' },
  body: `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>${title}</title><body style="font-family:system-ui;max-width:520px;margin:15vh auto;padding:0 20px;color:#1F1C1D"><h1 style="font-family:Georgia;color:#7A1F2B">${title}</h1><p>${msg}</p><p><a href="/">VIP Magical Physio Clinic →</a></p>` });

exports.handler = async (event) => {
  const t = (event.queryStringParameters || {}).t || '';
  if (t.length < 20) return page('Link not valid', 'This confirmation link is not valid.');
  try {
    const { data: s } = await db().from('subscribers').update({ status: 'active', confirmed_at: new Date().toISOString(), confirm_token: null })
      .eq('confirm_token', t).eq('status', 'pending').select('id,email,lang').maybeSingle();
    if (!s) return page('Already confirmed', 'This link has already been used or has expired.');
    await mailer.queue('welcome', { to: s.email, lang: s.lang, subscriberId: s.id, dedupe: `welcome:${s.id}` });
    await mailer.processQueue(3).catch(() => {});
    return page('Subscription confirmed', 'Thank you. You will receive one practical health email a month. You can unsubscribe at any time from any email.');
  } catch (e) { const r = fail(e, 'confirm'); return page('Something went wrong', 'Please try again later.'); }
};
