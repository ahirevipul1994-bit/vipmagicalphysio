// GET /api/available-slots?date=YYYY-MM-DD&type=clinic_opd  → { slots:[{time,available}], taken:[time] }
// Never exposes who booked — only free/busy.
const { db, json, fail } = require('./lib/core');
const { generateSlots } = require('./lib/slots');
const TYPES = ['clinic_opd', 'home_visit', 'online', 'follow_up'];

exports.handler = async (event) => {
  const q = event.queryStringParameters || {};
  if (!/^\d{4}-\d{2}-\d{2}$/.test(q.date || '')) return json(400, { error: 'bad_date' });
  const type = TYPES.includes(q.type) ? q.type : 'clinic_opd';
  try {
    const dayStart = new Date(`${q.date}T00:00:00+05:30`), dayEnd = new Date(dayStart.getTime() + 864e5);
    const [{ data: hours }, { data: appts }, { data: blocks }] = await Promise.all([
      db().from('working_hours').select('weekday,opens,closes,slot_minutes').eq('appt_type', type),
      db().from('appointments').select('slot').in('status', ['requested', 'pending_confirmation', 'confirmed'])
        .overlaps('slot', `[${dayStart.toISOString()},${dayEnd.toISOString()})`),
      db().from('blocked_periods').select('period').overlaps('period', `[${dayStart.toISOString()},${dayEnd.toISOString()})`),
    ]);
    const rng = (r) => { const m = String(r).match(/[\[(]"?([^",]+)"?,"?([^",\])]+)"?[\])]/); return m ? { start: new Date(m[1]), end: new Date(m[2]) } : null; };
    const busy = [...(appts || []).map((a) => rng(a.slot)), ...(blocks || []).map((b) => rng(b.period))].filter(Boolean);
    const slots = generateSlots(q.date, hours || [], busy);
    return json(200, { date: q.date, type, slots: slots.map(({ time, start, available }) => ({ time, start, available })), taken: slots.filter((s) => !s.available).map((s) => s.time) },
      { 'cache-control': 'no-store' });
  } catch (e) { return fail(e, 'available-slots'); }
};
