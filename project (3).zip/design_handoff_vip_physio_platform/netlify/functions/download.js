// GET /api/download?t=<token> — hashed, expiring, use-limited token → 5-minute signed URL from PRIVATE bucket.
const { db, sha256 } = require('./lib/core');
const page = (code, msg) => ({ statusCode: code, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex' },
  body: `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Download</title><body style="font-family:system-ui;max-width:520px;margin:15vh auto;padding:0 20px"><h1 style="font-family:Georgia;color:#7A1F2B">Download</h1><p>${msg}</p><p>WhatsApp: <a href="https://wa.me/918624860808">+91 86248 60808</a></p>` });

exports.handler = async (event) => {
  const t = (event.queryStringParameters || {}).t || '';
  if (t.length < 32) return page(403, 'This download link is not valid.');
  try {
    const hash = sha256(t);
    const { data: tok } = await db().from('download_tokens').select('order_id,expires_at,uses_left, orders!inner(status, ebooks!inner(storage_path))').eq('token_hash', hash).maybeSingle();
    if (!tok) return page(403, 'This download link is not valid.');
    if (new Date(tok.expires_at) < new Date()) return page(403, 'This link has expired. Reply to your purchase email and we will send a fresh link.');
    if (tok.uses_left < 1) return page(403, 'This link has reached its download limit or access was withdrawn. Please contact us.');
    if (tok.orders.status !== 'paid') return page(403, 'Payment is not confirmed for this order.');
    const { data: dec } = await db().from('download_tokens').update({ uses_left: tok.uses_left - 1 }).eq('token_hash', hash).eq('uses_left', tok.uses_left).select('uses_left');
    if (!dec?.length) return page(409, 'Please try the link again.');
    const { data: signed, error } = await db().storage.from('ebooks').createSignedUrl(tok.orders.ebooks.storage_path, 300, { download: true });
    if (error) throw error;
    return { statusCode: 302, headers: { location: signed.signedUrl, 'cache-control': 'no-store' } };
  } catch (e) { console.error('download', e.message); return page(500, 'Something went wrong. Please try again shortly.'); }
};
