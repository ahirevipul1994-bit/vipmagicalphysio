/* Views — plain DOM templating (no build step). All dynamic values pass through esc(). */
(function () {
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const lowerOf = (r) => { const m = String(r || '').match(/[\[(]"?([^",]+)/); return m ? new Date(m[1]) : null; };
  const fmt = (d, o = { dateStyle: 'medium', timeStyle: 'short' }) => (d ? new Date(d).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', ...o }) : '—');
  const fmtD = (d) => fmt(d, { dateStyle: 'medium' });
  const TYPE = { clinic_opd: 'Clinic OPD', home_visit: 'Home visit', online: 'Online', follow_up: 'Follow-up' };
  const ST = { requested: 'Requested', pending_confirmation: 'Pending', confirmed: 'Confirmed', completed: 'Completed', cancelled: 'Cancelled', rescheduled: 'Rescheduled', no_show: 'No-show' };
  const pill = (s, label) => `<span class="pill s-${esc(s)}">${esc(label || ST[s] || s)}</span>`;
  const svc = (slug) => { const S = window.VIP_SERVICES?.[slug]; return S ? S.en.n : String(slug || '').replace(/-/g, ' '); };
  const inr = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
  const isToday = (d) => d && new Date(d).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) === new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });

  function overview(d) {
    const A = d.appointments, now = Date.now();
    const pend = A.filter((a) => ['requested', 'pending_confirmation'].includes(a.status));
    const today = A.filter((a) => a.status === 'confirmed' && isToday(lowerOf(a.slot)));
    const upcoming = A.filter((a) => a.status === 'confirmed' && lowerOf(a.slot) > now).sort((x, y) => lowerOf(x.slot) - lowerOf(y.slot));
    const m0 = new Date(); m0.setDate(1); m0.setHours(0, 0, 0, 0);
    const paid = d.orders.filter((o) => o.status === 'paid' && new Date(o.paid_at) >= m0);
    const svcRev = A.filter((a) => a.status === 'completed' && lowerOf(a.slot) >= m0).reduce((s, a) => s + (a.fee_inr || 0), 0);
    const ebRev = paid.reduce((s, o) => s + o.amount_paise / 100, 0);
    const k = [
      ['Pending requests', pend.length, pend.length ? 'alert' : ''], ["Today's confirmed", today.length, 'wine'], ['Upcoming confirmed', upcoming.length, ''],
      ['Home-visit requests', pend.filter((a) => a.appt_type === 'home_visit').length, ''], ['Area review needed', A.filter((a) => a.needs_area_review && ['requested', 'pending_confirmation'].includes(a.status)).length, 'alert'],
      ['New leads (month)', d.customers.filter((c) => new Date(c.created_at) >= m0).length, ''], ['Follow-ups due', d.customers.filter((c) => c.follow_up_status === 'due' && c.follow_up_on && new Date(c.follow_up_on) <= new Date()).length, 'alert'],
      ['Ebook orders (month)', paid.length, ''], ['Revenue (month)', inr(svcRev + ebRev), 'good'], ['Active subscribers', d.subscribers.filter((s) => s.status === 'active').length, ''],
      ['Email failures', d.email_queue.filter((e) => e.status === 'failed').length, d.email_queue.some((e) => e.status === 'failed') ? 'alert' : ''],
    ];
    const last30 = A.filter((a) => new Date(a.created_at) > now - 30 * 864e5);
    const f = [last30.length, last30.filter((a) => ['confirmed', 'completed', 'no_show'].includes(a.status)).length, last30.filter((a) => a.status === 'completed').length, last30.filter((a) => ['cancelled', 'no_show'].includes(a.status)).length];
    const fmax = Math.max(1, ...f);
    const pop = Object.entries(A.reduce((m, a) => ((m[a.service_slug] = (m[a.service_slug] || 0) + 1), m), {})).sort((a, b) => b[1] - a[1]).slice(0, 6);
    const pmax = Math.max(1, ...pop.map((p) => p[1]));
    const src = Object.entries(d.customers.reduce((m, c) => ((m[c.last_source] = (m[c.last_source] || 0) + 1), m), {})).sort((a, b) => b[1] - a[1]);
    const smax = Math.max(1, ...src.map((p) => p[1]));
    const conv = f[0] ? Math.round((f[1] / f[0]) * 100) : 0;
    return `
<div class="kpis">${k.map(([l, v, c]) => `<div class="kpi ${c}"><small>${esc(l)}</small><b>${esc(v)}</b></div>`).join('')}</div>
<div class="grid2">
  <div class="card"><h2>Needs action <button class="btn btn--sm" data-go="appointments">All appointments →</button></h2>${apptTable(pend.slice(0, 8), true)}</div>
  <div class="card"><h2>Booking funnel · 30 days <span class="muted" style="font-weight:400">${conv}% confirmed</span></h2>
    <div class="funnel">${f.map((v) => `<div style="height:${(v / fmax) * 100}%" title="${v}"></div>`).join('')}</div>
    <div class="funnel-l"><span>Requests ${f[0]}</span><span>Confirmed ${f[1]}</span><span>Completed ${f[2]}</span><span>Lost ${f[3]}</span></div>
  </div>
  <div class="card"><h2>Popular services · 90 days</h2><div class="bars">${pop.map(([s, n]) => `<div class="bar"><span>${esc(svc(s))}</span><i><span style="width:${(n / pmax) * 100}%"></span></i><b>${n}</b></div>`).join('') || '<p class="muted">No data yet</p>'}</div></div>
  <div class="card"><h2>Lead sources</h2><div class="bars">${src.map(([s, n]) => `<div class="bar"><span>${esc(s.replace('_', ' '))}</span><i><span style="width:${(n / smax) * 100}%"></span></i><b>${n}</b></div>`).join('')}</div></div>
</div>
<div class="card" style="margin-top:1rem"><h2>Upcoming confirmed</h2>${apptTable(upcoming.slice(0, 8))}</div>`;
  }

  function apptTable(rows, compact) {
    if (!rows.length) return '<div class="empty">Nothing here.</div>';
    return `<div class="tbl-wrap"><table><thead><tr><th>When (IST)</th><th>Patient</th><th>Type</th>${compact ? '' : '<th>Service</th>'}<th>Status</th><th>Ref</th></tr></thead><tbody>
${rows.map((a) => `<tr data-appt="${esc(a.id)}"><td>${esc(fmt(lowerOf(a.slot)))}</td><td><b>${esc(a.customers?.full_name)}</b><br><span class="muted mono">${esc(a.customers?.phone_e164)}</span></td>
<td>${esc(TYPE[a.appt_type])}${a.needs_area_review ? '<br><span class="flag">AREA REVIEW</span>' : ''}</td>${compact ? '' : `<td>${esc(svc(a.service_slug))}</td>`}<td>${pill(a.status)}</td><td class="mono">${esc(a.reference)}</td></tr>`).join('')}
</tbody></table></div>`;
  }

  function appointments(d, f) {
    let rows = d.appointments.slice().sort((a, b) => lowerOf(b.slot) - lowerOf(a.slot));
    if (f.status) rows = rows.filter((a) => a.status === f.status);
    if (f.type) rows = rows.filter((a) => a.appt_type === f.type);
    if (f.q) { const q = f.q.toLowerCase(); rows = rows.filter((a) => (a.customers?.full_name || '').toLowerCase().includes(q) || (a.customers?.phone_e164 || '').includes(q) || (a.reference || '').toLowerCase().includes(q)); }
    return `<div class="toolbar"><input type="search" data-f="q" placeholder="Search name, phone or reference" value="${esc(f.q || '')}" aria-label="Search">
<select data-f="status" aria-label="Status"><option value="">All statuses</option>${Object.entries(ST).map(([k, v]) => `<option value="${k}" ${f.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
<select data-f="type" aria-label="Type"><option value="">All types</option>${Object.entries(TYPE).map(([k, v]) => `<option value="${k}" ${f.type === k ? 'selected' : ''}>${v}</option>`).join('')}</select></div>${apptTable(rows)}`;
  }

  function apptDrawer(a, d) {
    const next = { requested: ['pending_confirmation', 'confirmed', 'cancelled'], pending_confirmation: ['confirmed', 'cancelled'], confirmed: ['completed', 'no_show', 'cancelled'] }[a.status] || [];
    return `<button class="btn btn--ghost" data-close>← Close</button>
<p class="muted mono" style="margin:.75rem 0 0">REF ${esc(a.reference)}</p><h2>${esc(a.customers?.full_name)}</h2>
${a.needs_area_review ? `<div class="warn"><b>Unlisted locality: ${esc(a.locality_text)}.</b> This request cannot be confirmed until you approve the area (after a phone call). It was never auto-confirmed.</div>` : ''}
${a.appt_type === 'online' && a.status !== 'confirmed' ? '<div class="info">Online consultations need a secure https video link before confirming.</div>' : ''}
<dl class="dl"><dt>Status</dt><dd>${pill(a.status)}</dd><dt>When (IST)</dt><dd>${esc(fmt(lowerOf(a.slot), { dateStyle: 'full', timeStyle: 'short' }))}</dd>
<dt>Type</dt><dd>${esc(TYPE[a.appt_type])}</dd><dt>Service</dt><dd>${esc(svc(a.service_slug))}</dd>
${a.appt_type === 'home_visit' ? `<dt>Locality</dt><dd>${esc(a.service_areas?.name || a.locality_text || '—')}</dd><dt>Mobility</dt><dd>${esc(a.mobility_notes || '—')}</dd>` : ''}
<dt>Age group</dt><dd>${esc(a.age_group || '—')}</dd><dt>Enquiry</dt><dd>${esc(a.brief_enquiry || '—')}</dd>
<dt>Phone</dt><dd><a href="tel:${esc(a.customers?.phone_e164)}">${esc(a.customers?.phone_e164)}</a> · <a href="https://wa.me/${esc(String(a.customers?.phone_e164 || '').replace('+', ''))}" target="_blank" rel="noopener">WhatsApp</a></dd>
<dt>Email</dt><dd>${esc(a.customers?.email || '—')}</dd><dt>Fee</dt><dd>${a.fee_inr != null ? inr(a.fee_inr) : '—'}</dd>${a.video_link ? `<dt>Video</dt><dd><a href="${esc(a.video_link)}" target="_blank" rel="noopener">${esc(a.video_link)}</a></dd>` : ''}</dl>
<div class="acts">
${a.needs_area_review ? `<button class="btn btn--wine" data-act="approve_area">Approve area after call</button>` : ''}
${next.map((s) => `<button class="btn ${s === 'confirmed' ? 'btn--sage' : s === 'completed' ? 'btn--wine' : ''}" data-act="status" data-s="${s}" ${s === 'confirmed' && a.needs_area_review ? 'disabled' : ''}>→ ${esc(ST[s])}</button>`).join('')}
</div>
${next.includes('confirmed') && a.appt_type === 'online' ? `<div class="fld"><label for="vlink">Secure video link (https)</label><input id="vlink" placeholder="https://meet.example.com/…" value="${esc(a.video_link || '')}"></div>` : ''}
${next.includes('completed') ? `<div class="fld"><label for="fee">Fee collected (₹) — used for revenue reports</label><input id="fee" type="number" min="0" step="50" value="${esc(a.fee_inr ?? '')}"></div>` : ''}
<p class="muted" style="font-size:.85rem">Confirming sends the patient a confirmation email in their language (if they gave an email). Clinical notes are kept separately and are not part of the CRM.</p>
<p><button class="btn" data-cust="${esc(a.customer_id)}">Open CRM record →</button></p>`;
  }

  function crm(d, f) {
    let rows = d.customers.slice().sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    if (f.cat) rows = rows.filter((c) => c.category === f.cat);
    if (f.fu === 'due') rows = rows.filter((c) => c.follow_up_status === 'due');
    if (f.q) { const q = f.q.toLowerCase(); rows = rows.filter((c) => c.full_name.toLowerCase().includes(q) || c.phone_e164.includes(q) || (c.email || '').toLowerCase().includes(q)); }
    return `<div class="toolbar"><input type="search" data-f="q" placeholder="Search name, phone, email" value="${esc(f.q || '')}" aria-label="Search">
<select data-f="cat" aria-label="Category"><option value="">All categories</option>${['lead', 'patient', 'ebook_buyer', 'subscriber', 'past_patient'].map((c) => `<option ${f.cat === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
<select data-f="fu" aria-label="Follow-up"><option value="">Any follow-up</option><option value="due" ${f.fu === 'due' ? 'selected' : ''}>Follow-up due</option></select>
<button class="btn" data-export>Export CSV</button></div>
<div class="tbl-wrap"><table><thead><tr><th>Name</th><th>Phone</th><th>Lang</th><th>Source</th><th>Category</th><th>Follow-up</th><th>Since</th></tr></thead><tbody>
${rows.map((c) => `<tr data-cust="${esc(c.id)}"><td><b>${esc(c.full_name)}</b><br><span class="muted">${esc(c.email || '')}</span></td><td class="mono">${esc(c.phone_e164)}</td><td>${esc(c.preferred_lang.toUpperCase())}</td>
<td>${esc(c.first_source)}${c.last_source !== c.first_source ? ` → ${esc(c.last_source)}` : ''}</td><td>${esc(c.category)}</td>
<td>${c.follow_up_status === 'due' ? `<span class="pill s-requested">Due ${esc(fmtD(c.follow_up_on))}</span>` : '<span class="muted">—</span>'}</td><td>${esc(fmtD(c.created_at))}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">No customers match.</td></tr>'}
</tbody></table></div><p class="muted" style="font-size:.82rem;margin-top:.6rem">Export includes business fields and marketing-consent status only — never enquiry text or clinical information.</p>`;
  }

  function custDrawer(c, d) {
    const ap = d.appointments.filter((a) => a.customer_id === c.id).sort((a, b) => lowerOf(b.slot) - lowerOf(a.slot));
    const ord = d.orders.filter((o) => o.customers?.id === c.id || o.customer_id === c.id);
    const notes = d.notes.filter((n) => n.customer_id === c.id);
    return `<button class="btn btn--ghost" data-close>← Close</button><h2 style="margin-top:.75rem">${esc(c.full_name)}</h2>
<dl class="dl"><dt>Phone</dt><dd><a href="tel:${esc(c.phone_e164)}">${esc(c.phone_e164)}</a></dd><dt>Email</dt><dd>${esc(c.email || '—')}</dd><dt>Language</dt><dd>${esc(c.preferred_lang)}</dd>
<dt>Category</dt><dd>${esc(c.category)}</dd><dt>First source</dt><dd>${esc(c.first_source)}</dd><dt>Customer since</dt><dd>${esc(fmtD(c.created_at))}</dd></dl>
<div class="card" style="margin-bottom:1rem"><h2>Follow-up</h2><div class="toolbar" style="margin:0">
<select id="fuS"><option value="none" ${c.follow_up_status === 'none' ? 'selected' : ''}>None</option><option value="due" ${c.follow_up_status === 'due' ? 'selected' : ''}>Due</option><option value="done" ${c.follow_up_status === 'done' ? 'selected' : ''}>Done</option><option value="not_required" ${c.follow_up_status === 'not_required' ? 'selected' : ''}>Not required</option></select>
<input type="date" id="fuD" value="${esc(c.follow_up_on || '')}"><button class="btn btn--wine" data-act="followup">Save</button></div></div>
<div class="card" style="margin-bottom:1rem"><h2>Appointments (${ap.length})</h2>${ap.map((a) => `<div style="display:flex;justify-content:space-between;gap:.5rem;padding:.4rem 0;border-bottom:1px solid #f1ece9;font-size:.88rem"><span>${esc(fmt(lowerOf(a.slot)))} · ${esc(TYPE[a.appt_type])}</span>${pill(a.status)}</div>`).join('') || '<p class="muted">None</p>'}</div>
${ord.length ? `<div class="card" style="margin-bottom:1rem"><h2>Orders</h2>${ord.map((o) => `<div style="display:flex;justify-content:space-between;font-size:.88rem;padding:.3rem 0"><span>${esc(o.ebooks?.title)}</span>${pill(o.status)}</div>`).join('')}</div>` : ''}
<div class="card"><h2>Internal notes <span class="muted" style="font-weight:400;font-size:.8rem">admin only · not clinical records</span></h2>
<div class="fld"><textarea id="noteBody" maxlength="2000" placeholder="e.g. Prefers calls after 6 pm. Do not record diagnoses here."></textarea></div><button class="btn btn--wine" data-act="note">Add note</button>
<div class="notes">${notes.map((n) => `<div class="note">${esc(n.body)}<small>${esc(n.author_name || '')} · ${esc(fmt(n.created_at))}</small></div>`).join('')}</div></div>`;
  }

  function orders(d) {
    const rows = d.orders.slice().sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    const paid = rows.filter((o) => o.status === 'paid');
    return `<div class="kpis"><div class="kpi good"><small>Paid orders</small><b>${paid.length}</b></div><div class="kpi"><small>Revenue</small><b>${inr(paid.reduce((s, o) => s + o.amount_paise / 100, 0))}</b></div>
<div class="kpi"><small>Avg order value</small><b>${paid.length ? inr(Math.round(paid.reduce((s, o) => s + o.amount_paise, 0) / paid.length / 100)) : '—'}</b></div><div class="kpi alert"><small>Failed</small><b>${rows.filter((o) => o.status === 'failed').length}</b></div></div>
<div class="info">Orders are marked paid <b>only</b> by the verified Razorpay webhook. Refunds processed in Razorpay automatically revoke download access.</div>
<div class="tbl-wrap"><table><thead><tr><th>Date</th><th>Customer</th><th>Ebook</th><th>Amount</th><th>Status</th><th>Payment ID</th></tr></thead><tbody>
${rows.map((o) => `<tr><td>${esc(fmt(o.created_at))}</td><td>${esc(o.customers?.full_name)}</td><td>${esc(o.ebooks?.title)}</td><td>${inr(o.amount_paise / 100)}</td><td>${pill(o.status)}</td><td class="mono">${esc(o.razorpay_payment_id || '—')}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">No orders yet.</td></tr>'}
</tbody></table></div>`;
  }

  function email(d, f) {
    const tab = f.tab || 'log';
    const tabs = `<div class="tabs" role="tablist">${[['log', 'Delivery log'], ['subs', 'Subscribers'], ['news', 'Newsletter']].map(([k, l]) => `<button role="tab" aria-selected="${tab === k}" data-tab="${k}">${l}</button>`).join('')}</div>`;
    if (tab === 'subs') return tabs + `<div class="tbl-wrap"><table><thead><tr><th>Email</th><th>Lang</th><th>Source</th><th>Status</th><th>Since</th></tr></thead><tbody>
${d.subscribers.map((s) => `<tr><td>${esc(s.email)}</td><td>${esc(s.lang)}</td><td>${esc(s.source)}</td><td>${pill(s.status, s.status)}</td><td>${esc(fmtD(s.created_at))}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">No subscribers yet.</td></tr>'}</tbody></table></div>
<p class="muted" style="font-size:.82rem;margin-top:.6rem">Double opt-in: only <b>active</b> subscribers receive newsletters. Patients are never added automatically.</p>`;
    if (tab === 'news') return tabs + `<div class="card"><h2>Compose newsletter (owner only)</h2>
<div class="info">Sent only to active, double-opt-in subscribers in their chosen language. Each email includes an unsubscribe link automatically. Medical content should be clinically reviewed before sending.</div>
<div class="set-grid">${['en', 'mr', 'hi'].map((l) => `<div><div class="fld"><label>Subject (${l.toUpperCase()})</label><input data-nl="subject_${l}" maxlength="150"></div><div class="fld"><label>Body (${l.toUpperCase()}, simple HTML)</label><textarea data-nl="body_${l}" rows="6"></textarea></div></div>`).join('')}</div>
<div class="toolbar"><input data-nl="test_to" type="email" placeholder="Send test to (optional)"><button class="btn" data-act="nl_test">Send test</button><button class="btn btn--wine" data-act="nl_send">Queue for all active subscribers</button></div></div>`;
    return tabs + `<div class="tbl-wrap"><table><thead><tr><th>Queued</th><th>Template</th><th>Lang</th><th>To</th><th>Status</th><th>Attempts</th><th></th></tr></thead><tbody>
${d.email_queue.map((e) => `<tr><td>${esc(fmt(e.created_at))}</td><td class="mono">${esc(e.template)}</td><td>${esc(e.lang)}</td><td>${esc(e.to_email)}</td><td>${pill(e.status, e.status)}${e.error ? `<br><span class="muted mono" style="font-size:.75rem">${esc(e.error)}</span>` : ''}</td><td>${esc(e.attempts)}</td>
<td>${e.status === 'failed' ? `<button class="btn btn--sm" data-retry="${esc(e.id)}">Retry</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">No emails yet.</td></tr>'}</tbody></table></div>`;
  }

  function settings(d) {
    const s = d.settings || {}, WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return `<div class="set-grid">
<div class="card"><h2>Clinic details (owner)</h2><div class="warn">Publish only <b>verified</b> address, PIN and Google profile details.</div>
${[['address_line', 'Street address'], ['pin_code', 'PIN code'], ['google_place_id', 'Google Place ID'], ['google_review_url', 'Google review link'], ['opd_fee_inr', 'Clinic OPD fee (₹)'], ['online_fee_inr', 'Online consult fee (₹)'], ['reminder_hours', 'Reminder lead time (hours)']]
  .map(([k, l]) => `<div class="fld"><label for="set_${k}">${l}</label><input id="set_${k}" data-set="${k}" value="${esc(s[k] ?? '')}"></div>`).join('')}
<button class="btn btn--wine" data-act="save_settings">Save details</button></div>
<div class="card"><h2>Home-visit service areas</h2>
<div class="tbl-wrap" style="margin-bottom:.75rem"><table><thead><tr><th>Area</th><th>Visit ₹</th><th>Travel ₹</th><th>Active</th><th></th></tr></thead><tbody>
${d.areas.map((a) => `<tr><td><input data-area-name="${a.id}" value="${esc(a.name)}" style="border:1px solid var(--line);border-radius:6px;padding:.3rem;width:100%"></td><td><input type="number" data-area-v="${a.id}" value="${esc(a.visit_fee_inr)}" style="width:80px"></td><td><input type="number" data-area-t="${a.id}" value="${esc(a.travel_fee_inr)}" style="width:80px"></td><td><input type="checkbox" data-area-a="${a.id}" ${a.active ? 'checked' : ''}></td><td><button class="btn btn--sm" data-save-area="${a.id}">Save</button></td></tr>`).join('')}
</tbody></table></div><div class="toolbar"><input id="newArea" placeholder="Add area, e.g. Ranjangaon"><button class="btn" data-act="add_area">Add</button></div>
<p class="muted" style="font-size:.82rem">Requests from unlisted areas are accepted as requests but flagged and can never be auto-confirmed.</p></div>
<div class="card" style="grid-column:1/-1"><h2>Working hours (IST) — all appointment types</h2>
<div class="warn">Seeded hours are placeholders. Replace them with your real clinic hours before going live.</div>
<div id="hoursRows">${d.hours.map((h, i) => hoursRow(h, i, WD)).join('')}</div>
<div class="toolbar"><button class="btn" data-act="add_hour">+ Add session</button><button class="btn btn--wine" data-act="save_hours">Save hours</button></div></div></div>`;
  }
  const hoursRow = (h, i, WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']) => `<div class="hours-row" data-hr="${i}"><select data-h="weekday">${WD.map((w, j) => `<option value="${j}" ${+h.weekday === j ? 'selected' : ''}>${w}</option>`).join('')}</select>
<input type="time" data-h="opens" value="${esc(String(h.opens).slice(0, 5))}"><input type="time" data-h="closes" value="${esc(String(h.closes).slice(0, 5))}"><input type="number" data-h="slot_minutes" value="${esc(h.slot_minutes)}" min="15" max="120" step="5" title="Slot minutes"><button class="btn btn--sm" data-del-hour="${i}" aria-label="Remove">×</button></div>`;

  function setup(st) {
    const ok = (b) => (b ? '<span class="pill s-confirmed">Connected</span>' : '<span class="pill s-requested">Not configured</span>');
    const c = st.cfg || {};
    return `<div class="card"><h2>Integration status</h2><div class="tbl-wrap"><table><tbody>
<tr><td>Database (Supabase)</td><td>${ok(st.mode === 'live')}</td></tr><tr><td>Email (Brevo)</td><td>${ok(c.email)}</td></tr>
<tr><td>Payments (Razorpay)</td><td>${ok(c.payments)}</td></tr><tr><td>Spam protection (Turnstile)</td><td>${ok(c.turnstileSiteKey)}</td></tr><tr><td>Analytics (GA4)</td><td>${ok(c.ga4)}</td></tr>
</tbody></table></div><p class="muted" style="margin-top:.75rem">See <span class="mono">docs/DEPLOYMENT.md</span> for step-by-step setup.</p></div>`;
  }

  window.VIPVIEWS = { overview, appointments, apptDrawer, crm, custDrawer, orders, email, settings, setup, hoursRow, esc, lowerOf };
})();
