/* Data layer: real Supabase (RLS-protected) when configured, otherwise a clearly-labelled DEMO dataset in memory.
   Demo data is fictional and never sent anywhere. */
(function () {
  const API = '/api';
  const st = { mode: 'loading', sb: null, session: null, staff: null };

  // ---------- DEMO dataset (fictional) ----------
  function demo() {
    const now = new Date(); const day = (d, h, m = 0) => { const x = new Date(now); x.setDate(x.getDate() + d); x.setHours(h, m, 0, 0); return x.toISOString(); };
    const rng = (s, mins = 45) => `["${s}","${new Date(new Date(s).getTime() + mins * 6e4).toISOString()}")`;
    const C = [
      ['c1', 'Sunita Patil', '+919800000001', 'sunita@example.com', 'mr', 'appointment', 'patient'],
      ['c2', 'Rahul Shinde', '+919800000002', null, 'mr', 'home_visit', 'lead'],
      ['c3', 'Anita Kulkarni', '+919800000003', 'anita@example.com', 'en', 'online_consult', 'lead'],
      ['c4', 'Mohan Jadhav', '+919800000004', null, 'hi', 'appointment', 'patient'],
      ['c5', 'Priya Deshmukh', '+919800000005', 'priya@example.com', 'en', 'ebook', 'ebook_buyer'],
      ['c6', 'Ganesh Pawar', '+919800000006', null, 'mr', 'home_visit', 'lead'],
      ['c7', 'Kavita More', '+919800000007', 'kavita@example.com', 'hi', 'newsletter', 'subscriber'],
    ].map(([id, n, p, e, l, s, c], i) => ({ id, full_name: n, phone_e164: p, email: e, preferred_lang: l, first_source: s, last_source: s, category: c,
      follow_up_status: i === 0 || i === 3 ? 'due' : 'none', follow_up_on: i === 0 ? day(-1, 0).slice(0, 10) : i === 3 ? day(2, 0).slice(0, 10) : null, created_at: day(-i * 3, 10) }));
    const A = [
      ['a1', 'c1', 'clinic_opd', 'back-pain-physiotherapy', 'confirmed', day(0, 11), null, false, 600],
      ['a2', 'c2', 'home_visit', 'stroke-rehabilitation', 'requested', day(1, 16), 1, false, null],
      ['a3', 'c3', 'online', 'neck-pain-physiotherapy', 'pending_confirmation', day(2, 18), null, false, null],
      ['a4', 'c4', 'clinic_opd', 'knee-pain-physiotherapy', 'completed', day(-2, 10), null, false, 600],
      ['a5', 'c6', 'home_visit', 'knee-replacement-rehabilitation', 'requested', day(3, 17), null, true, null],
      ['a6', 'c1', 'follow_up', 'back-pain-physiotherapy', 'confirmed', day(5, 12), null, false, null],
      ['a7', 'c4', 'clinic_opd', 'geriatric-physiotherapy', 'no_show', day(-6, 19), null, false, null],
    ].map(([id, cid, t, s, status, start, area, rev, fee]) => ({ id, reference: id.toUpperCase() + 'X7Q2K', customer_id: cid, appt_type: t, service_slug: s, status, slot: rng(start),
      service_area_id: area, locality_text: rev ? 'Nhavare' : null, needs_area_review: rev, age_group: ['45-59', '60-74', '18-44', '60-74', '75+', '45-59', '60-74'][+id[1] - 1],
      brief_enquiry: rev ? 'Father had knee replacement last week' : 'Pain for 3 weeks', mobility_notes: t === 'home_visit' ? 'Uses walker' : null, fee_inr: fee, video_link: null, created_at: day(-1, 9),
      customers: C.find((c) => c.id === cid), service_areas: area ? { name: 'Shirur city' } : null }));
    return {
      customers: C, appointments: A,
      notes: [{ id: 1, customer_id: 'c1', body: 'Prefers morning slots. Discussed home exercise plan.', created_at: day(-2, 13), author_name: 'Dr. Vipul' }],
      orders: [{ id: 'o1', status: 'paid', amount_paise: 19900, created_at: day(-3, 15), paid_at: day(-3, 15), razorpay_payment_id: 'pay_DEMO1', customers: C[4], ebooks: { title: 'Knee Health (Marathi)' } },
        { id: 'o2', status: 'failed', amount_paise: 19900, created_at: day(-1, 20), customers: C[2], ebooks: { title: 'Back Pain Education (English)' } }],
      subscribers: [{ id: 's1', email: 'kavita@example.com', lang: 'hi', status: 'active', source: 'newsletter', created_at: day(-4, 9) }, { id: 's2', email: 'anita@example.com', lang: 'en', status: 'pending', source: 'free_guide', created_at: day(-1, 9) }],
      email_queue: [
        { id: 11, template: 'appointment_ack', lang: 'mr', to_email: 'sunita@example.com', status: 'sent', created_at: day(-1, 9), attempts: 1 },
        { id: 12, template: 'appointment_confirmed', lang: 'mr', to_email: 'sunita@example.com', status: 'sent', created_at: day(-1, 12), attempts: 1 },
        { id: 13, template: 'subscribe_confirm', lang: 'en', to_email: 'anita@example.com', status: 'failed', error: 'brevo_not_configured', created_at: day(-1, 9), attempts: 5 },
        { id: 14, template: 'welcome', lang: 'hi', to_email: 'kavita@example.com', status: 'sent', created_at: day(-4, 10), attempts: 1 }],
      areas: [{ id: 1, name: 'Shirur city', active: true, visit_fee_inr: 0, travel_fee_inr: 0 }],
      hours: [1, 2, 3, 4, 5, 6].flatMap((d) => [{ weekday: d, opens: '10:00', closes: '13:30', slot_minutes: 45 }, { weekday: d, opens: '16:00', closes: '20:00', slot_minutes: 45 }]),
      settings: { address_line: null, pin_code: null, google_place_id: null, google_review_url: null, opd_fee_inr: null, online_fee_inr: null, reminder_hours: 24 },
      events: [],
    };
  }
  let D = null;

  async function init() {
    let cfg = null;
    try { const r = await fetch(API + '/public-config'); if (r.ok) cfg = await r.json(); } catch {}
    if (cfg?.supabaseUrl && cfg?.supabaseAnonKey && window.supabase) {
      st.sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true } });
      st.mode = 'live'; st.cfg = cfg;
      const { data } = await st.sb.auth.getSession(); st.session = data.session;
      if (st.session) await loadStaff();
    } else { st.mode = 'demo'; D = demo(); }
    return st;
  }
  async function loadStaff() {
    const { data } = await st.sb.from('staff').select('full_name,role,active').eq('user_id', st.session.user.id).maybeSingle();
    st.staff = data && data.active ? data : null;
  }
  async function signIn(email, password) {
    if (st.mode === 'demo') { st.session = { user: { email } }; st.staff = { full_name: 'Demo owner', role: 'owner' }; return {}; }
    const { data, error } = await st.sb.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    st.session = data.session; await loadStaff();
    if (!st.staff) { await st.sb.auth.signOut(); st.session = null; return { error: 'This account is not authorised for the clinic console.' }; }
    return {};
  }
  async function resetPassword(email) {
    if (st.mode === 'demo') return {};
    const { error } = await st.sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + '/admin/' });
    return error ? { error: error.message } : {};
  }
  async function signOut() { if (st.sb) await st.sb.auth.signOut(); st.session = null; st.staff = null; }

  async function q(table, build) {
    if (st.mode === 'demo') return D[table] || [];
    let b = st.sb.from(table); b = build ? build(b) : b.select('*');
    const { data, error } = await b; if (error) throw error; return data;
  }
  async function admin(action, payload = {}) {
    if (st.mode === 'demo') return demoAction(action, payload);
    const { data: s } = await st.sb.auth.getSession();
    const r = await fetch(API + '/admin-api', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + s.session.access_token }, body: JSON.stringify({ action, ...payload }) });
    if (action === 'export_crm' && r.ok) return { blob: await r.blob() };
    const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || 'request_failed'); return d;
  }
  // Demo mirrors the server's rules so the UI behaves identically
  function demoAction(action, p) {
    const A = D.appointments.find((a) => a.id === p.id);
    const allowed = { requested: ['pending_confirmation', 'confirmed', 'cancelled', 'rescheduled'], pending_confirmation: ['confirmed', 'cancelled', 'rescheduled'], confirmed: ['completed', 'cancelled', 'rescheduled', 'no_show'] };
    if (action === 'set_status') {
      if (!(allowed[A.status] || []).includes(p.status)) throw new Error(`invalid status transition ${A.status} -> ${p.status}`);
      if (p.status === 'confirmed' && A.needs_area_review) throw new Error('area_review_required');
      if (p.status === 'confirmed' && A.appt_type === 'online' && !p.video_link) throw new Error('video_link_required');
      A.status = p.status; if (p.fee_inr != null) A.fee_inr = p.fee_inr; if (p.video_link) A.video_link = p.video_link;
      if (p.status === 'confirmed' && A.customers.email) D.email_queue.unshift({ id: Date.now(), template: 'appointment_confirmed', lang: A.customers.preferred_lang, to_email: A.customers.email, status: 'queued', created_at: new Date().toISOString(), attempts: 0 });
      return { ok: true };
    }
    if (action === 'approve_area') { A.needs_area_review = false; A.status = 'pending_confirmation'; return { ok: true }; }
    if (action === 'add_note') { D.notes.unshift({ id: Date.now(), customer_id: p.customer_id, body: p.body, created_at: new Date().toISOString(), author_name: 'You' }); return { ok: true }; }
    if (action === 'set_followup') { const c = D.customers.find((x) => x.id === p.customer_id); Object.assign(c, { follow_up_status: p.follow_up_status, follow_up_on: p.follow_up_on }); return { ok: true }; }
    if (action === 'upsert_area') { if (p.id) Object.assign(D.areas.find((a) => a.id === p.id), p); else D.areas.push({ ...p, id: Date.now() }); return { ok: true }; }
    if (action === 'update_settings') { Object.assign(D.settings, p); return { ok: true }; }
    if (action === 'replace_hours') { D.hours = p.rows; return { ok: true }; }
    if (action === 'retry_email') { const e = D.email_queue.find((x) => x.id === p.id); e.status = 'queued'; return { ok: true }; }
    if (action === 'export_crm') return { blob: new Blob(['\ufeffid,full_name,phone_e164,category\n' + D.customers.map((c) => `${c.id},"${c.full_name}",${c.phone_e164},${c.category}`).join('\n')], { type: 'text/csv' }) };
    if (action === 'newsletter') return { ok: true, queued: D.subscribers.filter((s) => s.status === 'active').length };
    if (action === 'block_period') return { ok: true };
    throw new Error('unknown_action');
  }

  window.VIPDATA = { st, init, signIn, signOut, resetPassword, q, admin, demoData: () => D };
})();
