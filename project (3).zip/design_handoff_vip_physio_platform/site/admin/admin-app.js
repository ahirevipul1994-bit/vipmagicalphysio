/* Controller: auth gate, navigation, data loading, actions. */
(async function () {
  const D = window.VIPDATA, V = window.VIPVIEWS, esc = V.esc;
  const root = document.getElementById('root');
  const S = { view: localStorage.getItem('vip_admin_view') || 'overview', f: {}, data: null, drawer: null };
  const NAV = [['overview', 'Overview'], ['appointments', 'Appointments'], ['crm', 'CRM'], ['orders', 'Ebook orders'], ['email', 'Email'], ['settings', 'Settings'], ['setup', 'Setup']];
  const toast = (m) => { const t = document.createElement('div'); t.className = 'toast'; t.textContent = m; document.body.appendChild(t); setTimeout(() => t.remove(), 3200); };

  // Services index for readable names
  await new Promise((r) => { const s = document.createElement('script'); s.src = '../assets/services-index.js'; s.onload = s.onerror = r; document.head.appendChild(s); });
  const st = await D.init();

  function loginView(msg = '') {
    root.innerHTML = `<div class="login"><form id="lf" novalidate><span class="mark" aria-hidden="true">V</span><h1>Clinic console</h1>
<p>${st.mode === 'demo' ? 'Demo mode — no backend connected. Any email signs you in to explore with fictional sample data.' : 'Staff sign-in. Access is limited to authorised clinic accounts.'}</p>
<div class="fld"><label for="em">Email</label><input id="em" type="email" autocomplete="username" required></div>
<div class="fld"><label for="pw">Password</label><input id="pw" type="password" autocomplete="current-password" ${st.mode === 'demo' ? '' : 'required'}></div>
<button class="btn btn--wine" style="width:100%;justify-content:center;min-height:44px">Sign in</button>
<button type="button" class="btn btn--ghost" id="fp" style="margin-top:.5rem">Forgot password?</button><p class="msg" id="lm" role="status">${esc(msg)}</p></form></div>`;
    document.getElementById('lf').onsubmit = async (e) => {
      e.preventDefault(); const em = document.getElementById('em').value.trim(), pw = document.getElementById('pw').value, m = document.getElementById('lm');
      if (!em) { m.className = 'msg err'; m.textContent = 'Enter your email.'; return; }
      m.className = 'msg'; m.textContent = 'Signing in…';
      const r = await D.signIn(em, pw); if (r.error) { m.className = 'msg err'; m.textContent = r.error; return; }
      boot();
    };
    document.getElementById('fp').onclick = async () => {
      const em = document.getElementById('em').value.trim(), m = document.getElementById('lm');
      if (!em) { m.className = 'msg err'; m.textContent = 'Enter your email first.'; return; }
      const r = await D.resetPassword(em); m.className = r.error ? 'msg err' : 'msg ok'; m.textContent = r.error || 'If this account exists, a reset link has been sent.';
    };
  }

  async function load() {
    const sel = (cols) => (b) => b.select(cols);
    const [customers, appointments, orders, subscribers, email_queue, areas, hours, settings, notes] = await Promise.all([
      D.q('customers', (b) => b.select('*').order('created_at', { ascending: false }).limit(2000)),
      D.q('appointments', (b) => b.select('*, customers(id,full_name,phone_e164,email,preferred_lang), service_areas(name)').order('created_at', { ascending: false }).limit(2000)),
      st.staff.role === 'reception' ? Promise.resolve([]) : D.q('orders', (b) => b.select('*, customers(id,full_name), ebooks(title)').order('created_at', { ascending: false }).limit(1000)),
      D.q('subscribers', (b) => b.select('id,email,lang,status,source,created_at').order('created_at', { ascending: false }).limit(2000)),
      st.staff.role === 'reception' ? Promise.resolve([]) : D.q('email_queue', (b) => b.select('id,template,lang,to_email,status,error,attempts,created_at').order('id', { ascending: false }).limit(300)),
      D.q('areas' in (D.demoData() || {}) ? 'areas' : 'service_areas', (b) => b.select('*').order('sort').order('name')),
      D.q(st.mode === 'demo' ? 'hours' : 'working_hours', (b) => b.select('weekday,opens,closes,slot_minutes,appt_type').eq('appt_type', 'clinic_opd').order('weekday').order('opens')),
      st.mode === 'demo' ? Promise.resolve(D.demoData().settings) : D.q('clinic_settings', (b) => b.select('*').single()),
      D.q('notes' in (D.demoData() || {}) ? 'notes' : 'crm_notes', (b) => b.select('*').order('created_at', { ascending: false }).limit(1000)),
    ]);
    S.data = { customers, appointments, orders, subscribers, email_queue, areas, hours, settings, notes };
  }

  function shell() {
    const d = S.data, pend = d.appointments.filter((a) => ['requested', 'pending_confirmation'].includes(a.status)).length;
    const nav = NAV.filter(([k]) => !(st.staff.role === 'reception' && ['orders', 'settings', 'email'].includes(k)));
    const counts = { appointments: pend, crm: d.customers.filter((c) => c.follow_up_status === 'due').length, email: d.email_queue.filter((e) => e.status === 'failed').length };
    const btn = ([k, l]) => `<button data-nav="${k}" ${S.view === k ? 'aria-current="page"' : ''}>${l}${counts[k] ? `<span class="ct">${counts[k]}</span>` : ''}</button>`;
    const title = NAV.find(([k]) => k === S.view)?.[1] || '';
    const body = V[S.view] ? V[S.view](S.view === 'setup' ? st : d, S.f) : '';
    root.innerHTML = `<div class="app">
<nav class="side" aria-label="Console"><div class="brand"><span class="mark" aria-hidden="true">V</span><span>VIP Magical Physio<small>Clinic console</small></span></div>${nav.map(btn).join('')}<div class="grow"></div>
<div class="who">${esc(st.staff.full_name)} · ${esc(st.staff.role)}<br><button class="btn btn--sm" style="margin-top:.4rem;background:#2e2a2b;color:#fff;border-color:#3a3536" data-signout>Sign out</button></div></nav>
<div><nav class="mob-nav" aria-label="Console">${nav.map(btn).join('')}<button data-signout>Sign out</button></nav>
<main class="main"><div class="top"><h1>${esc(title)}</h1><div style="display:flex;gap:.5rem"><button class="btn" data-refresh>Refresh</button><a class="btn" href="/" target="_blank" rel="noopener">View site ↗</a></div></div>
${st.mode === 'demo' ? '<div class="demo" role="note"><b>DEMO MODE</b> No database connected. All names and numbers below are fictional sample data held only in this browser tab. Connect Supabase to see real records.</div>' : ''}
${body}</main></div></div>${S.drawer ? `<div class="drawer" data-close-bg><div role="dialog" aria-modal="true">${S.drawer}</div></div>` : ''}`;
    if (S.drawer) root.querySelector('.drawer [data-close]')?.focus();
  }

  const openAppt = (id) => { const a = S.data.appointments.find((x) => x.id === id); if (a) { S.drawer = V.apptDrawer(a, S.data); S.dId = id; S.dType = 'appt'; shell(); } };
  const openCust = (id) => { const c = S.data.customers.find((x) => x.id === id); if (c) { S.drawer = V.custDrawer(c, S.data); S.dId = id; S.dType = 'cust'; shell(); } };
  const reopen = () => (S.dType === 'appt' ? openAppt(S.dId) : S.dType === 'cust' ? openCust(S.dId) : shell());
  async function act(fn, okMsg) {
    try { await fn(); toast(okMsg); if (st.mode === 'live') await load(); reopen(); }
    catch (e) { toast('⚠ ' + ({ area_review_required: 'Approve the area first.', video_link_required: 'Add a secure video link first.', slot_taken: 'That slot is taken.', forbidden: 'You do not have permission.', owner_only: 'Owner only.' }[e.message] || e.message)); }
  }

  root.addEventListener('click', async (e) => {
    const t = e.target.closest('button, tr, [data-close-bg]'); if (!t) return;
    if (t.matches('[data-close-bg]') && e.target === t) { S.drawer = null; return shell(); }
    if (t.dataset.nav || t.dataset.go) { S.view = t.dataset.nav || t.dataset.go; S.f = {}; S.drawer = null; localStorage.setItem('vip_admin_view', S.view); return shell(); }
    if (t.hasAttribute('data-close')) { S.drawer = null; return shell(); }
    if (t.hasAttribute('data-signout')) { await D.signOut(); return loginView('Signed out.'); }
    if (t.hasAttribute('data-refresh')) { await load(); return shell(); }
    if (t.dataset.appt) return openAppt(t.dataset.appt);
    if (t.dataset.cust) return openCust(t.dataset.cust);
    if (t.dataset.tab) { S.f.tab = t.dataset.tab; return shell(); }
    if (t.hasAttribute('data-export')) { const r = await D.admin('export_crm'); const a = document.createElement('a'); a.href = URL.createObjectURL(r.blob); a.download = `crm-${new Date().toISOString().slice(0, 10)}.csv`; a.click(); return toast('CSV exported'); }
    if (t.dataset.retry) return act(() => D.admin('retry_email', { id: +t.dataset.retry }), 'Retry queued');
    const A = t.dataset.act;
    if (A === 'status') {
      const s = t.dataset.s; const fee = document.getElementById('fee')?.value; const vl = document.getElementById('vlink')?.value.trim();
      if (['cancelled', 'no_show'].includes(s) && !confirm(`Mark as ${s.replace('_', '-')}?`)) return;
      return act(() => D.admin('set_status', { id: S.dId, status: s, fee_inr: fee !== undefined && fee !== '' ? +fee : undefined, video_link: vl || undefined }), 'Status updated');
    }
    if (A === 'approve_area') { if (!confirm('Confirm you have spoken to the patient and can serve this locality?')) return; return act(() => D.admin('approve_area', { id: S.dId }), 'Area approved — now pending confirmation'); }
    if (A === 'note') { const b = document.getElementById('noteBody').value.trim(); if (!b) return; return act(() => D.admin('add_note', { customer_id: S.dId, body: b }), 'Note added'); }
    if (A === 'followup') return act(() => D.admin('set_followup', { customer_id: S.dId, follow_up_status: document.getElementById('fuS').value, follow_up_on: document.getElementById('fuD').value || null }), 'Follow-up saved');
    if (A === 'save_settings') { const p = {}; root.querySelectorAll('[data-set]').forEach((i) => { const v = i.value.trim(); p[i.dataset.set] = /_inr$|_hours$/.test(i.dataset.set) ? (v === '' ? null : +v) : v || null; }); return act(() => D.admin('update_settings', p), 'Settings saved'); }
    if (A === 'add_area') { const n = document.getElementById('newArea').value.trim(); if (!n) return; return act(() => D.admin('upsert_area', { name: n, visit_fee_inr: 0, travel_fee_inr: 0, active: true }), 'Area added'); }
    if (t.dataset.saveArea) { const id = +t.dataset.saveArea; const g = (k) => root.querySelector(`[data-area-${k}="${id}"]`);
      return act(() => D.admin('upsert_area', { id, name: g('name').value.trim(), visit_fee_inr: +g('v').value, travel_fee_inr: +g('t').value, active: g('a').checked }), 'Area saved'); }
    if (A === 'add_hour') { S.data.hours.push({ weekday: 1, opens: '10:00', closes: '13:00', slot_minutes: 45 }); return shell(); }
    if (t.dataset.delHour) { S.data.hours.splice(+t.dataset.delHour, 1); return shell(); }
    if (A === 'save_hours') {
      const rows = [...root.querySelectorAll('.hours-row')].map((r) => ({ weekday: +r.querySelector('[data-h=weekday]').value, opens: r.querySelector('[data-h=opens]').value, closes: r.querySelector('[data-h=closes]').value, slot_minutes: +r.querySelector('[data-h=slot_minutes]').value }));
      if (rows.some((r) => r.closes <= r.opens)) return toast('⚠ Closing time must be after opening time');
      return act(async () => { for (const ty of ['clinic_opd', 'home_visit', 'online', 'follow_up']) await D.admin('replace_hours', { type: ty, rows }); }, 'Hours saved');
    }
    if (A === 'nl_test' || A === 'nl_send') {
      const p = {}; root.querySelectorAll('[data-nl]').forEach((i) => (p[i.dataset.nl] = i.value.trim()));
      if (A === 'nl_test' && !p.test_to) return toast('⚠ Enter a test email');
      if (A === 'nl_send') { delete p.test_to; if (!confirm('Queue this newsletter for all active subscribers?')) return; }
      return act(async () => { const r = await D.admin('newsletter', p); toast(`Queued ${r.queued}`); }, 'Newsletter processed');
    }
  });
  root.addEventListener('input', (e) => { const f = e.target.dataset.f; if (!f) return; S.f[f] = e.target.value; clearTimeout(S.tm); S.tm = setTimeout(() => { const pos = e.target.selectionStart; shell(); const el = root.querySelector(`[data-f="${f}"]`); el?.focus(); try { el.setSelectionRange(pos, pos); } catch {} }, 220); });
  root.addEventListener('change', (e) => { const f = e.target.dataset.f; if (f && e.target.tagName === 'SELECT') { S.f[f] = e.target.value; shell(); } });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && S.drawer) { S.drawer = null; shell(); } });

  async function boot() {
    if (!st.session || !st.staff) return loginView();
    root.innerHTML = '<div class="empty">Loading…</div>';
    try { await load(); shell(); } catch (e) { root.innerHTML = `<div class="login"><div class="card"><h2>Could not load data</h2><p class="muted">${esc(e.message)}</p><button class="btn" onclick="location.reload()">Retry</button></div></div>`; }
  }
  if (st.sb) st.sb.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT') loginView(); if (ev === 'PASSWORD_RECOVERY') { const np = prompt('Enter a new password (min 10 characters)'); if (np && np.length >= 10) st.sb.auth.updateUser({ password: np }).then(() => toast('Password updated')); } });
  boot();
})();
