/* VIP MAGICAL PHYSIO — Phase 1 front-end
   - EN/MR/HI switching (persisted, URL-aware: /en/ /mr/ /hi/ or ?lang=)
   - 4-step booking wizard → POST /api/book-appointment
   - Honest fallback: if the API isn't deployed, NOTHING is claimed as saved; user is handed a prefilled WhatsApp.
   - Analytics: dataLayer events only, never PII. */
(() => {
  const D = window.VIP_I18N;
  const API = '/api';
  const WA = '918624860808';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const track = (event, params = {}) => { (window.dataLayer = window.dataLayer || []).push({ event, ...params }); };

  // ---------- Language ----------
  const pathLang = (location.pathname.match(/^\/(en|mr|hi)(\/|$)/) || [])[1];
  const qLang = new URLSearchParams(location.search).get('lang');
  let lang = [qLang, pathLang, localStorage.getItem('vip_lang')].find(l => D[l]) || 'en';
  const t = (k) => (D[lang][k] ?? D.en[k] ?? k);

  function applyLang() {
    document.documentElement.lang = lang;
    document.title = t('meta_title');
    $$('[data-i]').forEach(el => {
      const v = t(el.dataset.i);
      if (el.hasAttribute('data-html')) el.innerHTML = v; else el.textContent = v;
    });
    $$('[data-ph]').forEach(el => el.placeholder = t(el.dataset.ph));
    $$('.lang button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.lang === lang)));
    renderConds(); renderServices(); renderAreas(); renderSlots();
    if (step === 4) renderSummary();
    const nb = $('#nextBtn span'); if (nb) nb.textContent = step === 4 ? t('send') : t('next');
    const pl = $('#plang'); if (pl && !pl.dataset.touched) pl.value = lang;
  }
  $$('.lang button').forEach(b => b.addEventListener('click', () => {
    lang = b.dataset.lang; localStorage.setItem('vip_lang', lang);
    // keep current page, swap language prefix if routed
    if (pathLang) history.replaceState(null, '', location.pathname.replace(/^\/(en|mr|hi)/, '/' + lang) + location.hash);
    applyLang(); track('language_switch', { language: lang });
  }));

  // ---------- Conditions ----------
  // Featured on homepage (i18n keys) → full list comes from generated services-index.js (all 18, 3 languages)
  const CONDS = [
    ['c_back', 'back-pain-physiotherapy'], ['c_neck', 'neck-pain-physiotherapy'], ['c_knee', 'knee-pain-physiotherapy'],
    ['c_shoulder', 'shoulder-pain-physiotherapy'], ['c_stroke', 'stroke-rehabilitation'], ['c_postop', 'post-operative-rehabilitation'],
    ['c_geri', 'geriatric-physiotherapy'], ['c_posture', 'posture-correction'],
  ];
  const SVC = window.VIP_SERVICES || {};
  const qp = new URLSearchParams(location.search);
  var pendingService = qp.get('service') || '';
  const condHref = slug => `/${lang}/conditions/${slug}/`;
  function renderConds() {
    const el = $('#conds'); if (!el) return;
    el.innerHTML = CONDS.map(([k, slug]) =>
      `<a class="cond" href="${condHref(slug)}"><h3>${t(k)}</h3><p>${t(k + '_p')}</p><span class="go">${t('learn')}</span></a>`).join('');
    document.querySelectorAll('[data-href-conds]').forEach(a => a.href = `/${lang}/conditions/`);
  }

  // ---------- Booking wizard ----------
  const form = $('#bookForm');
  let step = 1, slot = null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const iso = d => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);

  function renderServices() {
    const s = $('#service'); if (!s) return; const v = s.value;
    const list = Object.keys(SVC).length
      ? Object.entries(SVC).map(([slug, L]) => [slug, (L[lang] || L.en).n])
      : CONDS.map(([k, slug]) => [slug, t(k)]);
    s.innerHTML = `<option value="">${t('f_choose')}</option>` + list.map(([slug, n]) => `<option value="${slug}">${n}</option>`).join('') + `<option value="other">${t('svc_other')}</option>`;
    s.value = v || pendingService || '';
  }
  // Approved areas come from the admin-managed `service_areas` table once the API is live.
  // id:null => server treats as "needs manual area check" (never auto-confirmed)
  let AREAS = [];
  fetch(API + '/service-areas').then(r => r.ok ? r.json() : null).then(d => { if (d?.areas?.length) { AREAS = d.areas; renderAreas(); } }).catch(() => {});
  function renderAreas() {
    const s = $('#area'); if (!s) return; const v = s.value;
    s.innerHTML = `<option value="">${t('f_choose')}</option>` + AREAS.map(a => `<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('') + `<option value="other">${t('f_area_other')}</option>`;
    s.value = v;
  }
  // Fallback grid until /api/available-slots is deployed; server re-checks every request.
  const DEFAULT_SLOTS = ['10:00', '11:00', '12:00', '13:00', '16:00', '17:00', '18:00', '19:00'];
  let taken = [];
  function renderSlots() {
    const box = $('#slots'); if (!box) return;
    const date = $('#date').value;
    box.innerHTML = DEFAULT_SLOTS.map(s => {
      const dis = taken.includes(s) || !date;
      return `<button type="button" class="slot" data-s="${s}" aria-pressed="${slot === s}" ${dis ? 'disabled' : ''}>${s}</button>`;
    }).join('');
  }
  $('#slots')?.addEventListener('click', e => {
    const b = e.target.closest('.slot'); if (!b || b.disabled) return;
    slot = b.dataset.s; renderSlots(); $('#g-slot').classList.remove('bad');
  });
  const dateEl = $('#date');
  if (dateEl) {
    const min = new Date(today); min.setDate(min.getDate() + 1);
    const max = new Date(today); max.setDate(max.getDate() + 45);
    dateEl.min = iso(min); dateEl.max = iso(max);
    dateEl.addEventListener('change', async () => {
      slot = null; taken = []; renderSlots();
      try {
        const r = await fetch(`${API}/available-slots?date=${dateEl.value}&type=${typeVal() || 'clinic_opd'}`);
        if (r.ok) { const d = await r.json(); taken = d.taken || []; renderSlots(); }
      } catch {}
    });
  }
  const typeVal = () => $('input[name=type]:checked')?.value;

  function syncType() {
    const v = typeVal();
    $('#f-area').hidden = v !== 'home_visit';
    $('#f-mob').hidden = v !== 'home_visit';
    $('#onlineNote').hidden = v !== 'online';
    const other = v === 'home_visit' && $('#area').value === 'other';
    $('#areaNote').hidden = !other; $('#f-areaText').hidden = !other;
    $('#g-type').classList.remove('bad');
  }
  $$('input[name=type]').forEach(r => r.addEventListener('change', syncType));
  $('#area')?.addEventListener('change', syncType);
  $('#plang')?.addEventListener('change', e => e.target.dataset.touched = '1');

  // deep-link buttons preselect a type
  $$('[data-type]').forEach(a => a.addEventListener('click', () => {
    if (result.hidden === false) resetForm();
    const r = $(`input[name=type][value="${a.dataset.type}"]`); if (r) { r.checked = true; syncType(); }
    closeDrawer();
  }));

  const setBad = (id, bad) => { const el = $('#' + id); el?.classList.toggle('bad', bad); el?.querySelector('input,select,textarea')?.setAttribute('aria-invalid', String(bad)); return bad; };
  const phoneOk = v => /^[6-9]\d{9}$/.test(v.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, ''));

  function validate(n) {
    let bad = false;
    if (n === 1) {
      bad = setBad('g-type', !typeVal()) | bad;
      bad = setBad('f-service', !$('#service').value) | bad;
      if (typeVal() === 'home_visit') {
        bad = setBad('f-area', !$('#area').value) | bad;
        if ($('#area').value === 'other') bad = setBad('f-areaText', ($('#areaText').value || '').trim().length < 2) | bad;
      }
    }
    if (n === 2) bad = setBad('g-slot', !($('#date').value && slot)) | bad;
    if (n === 3) {
      bad = setBad('f-name', $('#name').value.trim().length < 2) | bad;
      bad = setBad('f-phone', !phoneOk($('#phone').value)) | bad;
      const em = $('#email').value.trim();
      bad = setBad('f-email', !!em && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) | bad;
      bad = setBad('f-age', !$('#age').value) | bad;
      bad = setBad('c-1', !$('#c1').checked) | bad;
      bad = setBad('c-2', !$('#c2').checked) | bad;
    }
    if (bad) form.querySelector('.bad input, .bad select, .bad textarea')?.focus();
    return !bad;
  }

  const typeLabel = { clinic_opd: 't_clinic', home_visit: 't_home', online: 't_online', follow_up: 't_follow' };
  function renderSummary() {
    const svc = $('#service'); const area = $('#area');
    const rows = [
      ['sum_type', t(typeLabel[typeVal()])],
      ['sum_service', svc.options[svc.selectedIndex]?.text],
      typeVal() === 'home_visit' ? ['sum_area', area.options[area.selectedIndex]?.text] : null,
      ['sum_when', `${$('#date').value} · ${slot}`],
      ['sum_name', $('#name').value.trim()],
      ['sum_phone', $('#phone').value.trim()],
    ].filter(Boolean);
    $('#summary').innerHTML = rows.map(([k, v]) => `<dt>${t(k)}</dt><dd>${escapeHtml(v || '—')}</dd>`).join('');
  }
  const escapeHtml = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let booted = false;
  function show(n) {
    step = n;
    $$('.fstep').forEach(f => f.hidden = +f.dataset.step !== n);
    $$('.form__steps span').forEach((s, i) => s.classList.toggle('on', i < n));
    $('#prevBtn').style.visibility = n === 1 ? 'hidden' : 'visible';
    $('#nextBtn span').textContent = n === 4 ? t('send') : t('next');
    if (n === 4) renderSummary();
    form.querySelector(`.fstep[data-step="${n}"] h3`)?.setAttribute('tabindex', '-1');
    if (booted) form.querySelector(`.fstep[data-step="${n}"] h3`)?.focus({ preventScroll: true });
    booted = true;
  }
  $('#prevBtn')?.addEventListener('click', () => show(Math.max(1, step - 1)));
  $('#nextBtn')?.addEventListener('click', () => {
    if (step < 4) { if (validate(step)) show(step + 1); }
    else submit();
  });

  const result = $('#result');
  function showResult(kind, extra = '') {
    $$('.fstep').forEach(f => f.hidden = true);
    $('#formNav').hidden = true;
    result.hidden = false;
    result.innerHTML = {
      ok: `<span class="eyebrow">${t('st_req')}</span><h3 style="margin-top:.75rem">${t('ok_t')}</h3><div class="result__ref">${extra}</div><p class="hint">${t('ok_p')}</p>`,
      off: `<div class="notice notice--warn"><b>${t('off_t')}</b></div><p class="hint">${t('off_p')}</p><a class="btn btn--sage" target="_blank" rel="noopener" href="${extra}" data-track="whatsapp_fallback">${t('off_btn')}</a>`,
      err: `<div class="notice notice--warn"><b>${t('err_t')}</b></div><p class="hint">${t('err_p')}</p><button type="button" class="btn btn--wine" id="retry">${t('back')}</button>`,
    }[kind];
    result.focus();
    $('#retry')?.addEventListener('click', () => { result.hidden = true; $('#formNav').hidden = false; show(4); });
  }
  function resetForm() { form.reset(); slot = null; taken = []; result.hidden = true; $('#formNav').hidden = false; syncType(); renderSlots(); show(1); }

  function waText() {
    const s = $('#service'); const a = $('#area');
    const loc = a.value === 'other' ? $('#areaText')?.value : a.options[a.selectedIndex]?.text;
    const lines = [
      'Hello Dr. Vipul, appointment request:',
      `Type: ${D.en[typeLabel[typeVal()]]}`,
      `Reason: ${s.options[s.selectedIndex]?.text}`,
      typeVal() === 'home_visit' ? `Locality: ${loc || ''}` : '',
      `Preferred: ${$('#date').value} ${slot}`,
      `Name: ${$('#name').value.trim()}`,
      `Age group: ${$('#age').value}`,
    ].filter(Boolean);
    return `https://wa.me/${WA}?text=${encodeURIComponent(lines.join('\n'))}`;
  }

  async function submit() {
    if (form.website.value) return; // honeypot
    const btn = $('#nextBtn'); btn.disabled = true; btn.setAttribute('aria-busy', 'true');
    const [h, m] = slot.split(':');
    const start = new Date(`${$('#date').value}T${h}:${m}:00+05:30`);
    const payload = {
      type: typeVal(), service: $('#service').value,
      service_area_id: /^\d+$/.test($('#area').value) ? +$('#area').value : null,
      locality_text: $('#area').value === 'other' ? ($('#areaText')?.value || '').trim() : '',
      slot_start: start.toISOString(), name: $('#name').value.trim(), phone: $('#phone').value,
      email: $('#email').value.trim(), age_group: $('#age').value, lang: $('#plang').value,
      enquiry: $('#enq').value.trim(), mobility: $('#mob').value.trim(),
      consent_contact: $('#c1').checked, privacy_ack: $('#c2').checked, consent_marketing: $('#c3').checked,
      page: location.pathname, website: '',
    };
    try {
      const r = await fetch(API + '/book-appointment', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
      if (r.status === 201) { const d = await r.json(); track('booking_submitted', { appointment_type: payload.type, service: payload.service }); showResult('ok', 'VIP-' + d.reference); }
      else if (r.status === 409) { taken.push(slot); slot = null; show(2); renderSlots(); setBad('g-slot', true); $('#g-slot .err').textContent = t('taken_p'); }
      else if (r.status === 404 || r.status === 405) { track('booking_fallback_whatsapp', { appointment_type: payload.type }); showResult('off', waText()); }
      else if (r.status === 422) { const d = await r.json().catch(() => ({})); console.warn('validation', d.fields); showResult('err'); }
      else showResult('err');
    } catch { track('booking_fallback_whatsapp', { appointment_type: payload.type }); showResult('off', waText()); }
    finally { btn.disabled = false; btn.removeAttribute('aria-busy'); }
  }

  // ---------- Newsletter ----------
  $('#newsForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const em = $('#nlEmail').value.trim(), ok = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em) && $('#nlC').checked, msg = $('#nlMsg');
    if (!ok) { msg.textContent = t('nl_err'); return; }
    try {
      const r = await fetch(API + '/subscribe', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: em, lang, consent: true }) });
      msg.textContent = r.ok ? t('nl_ok') : t('nl_off');
      if (r.ok) { track('newsletter_subscribe'); e.target.reset(); }
    } catch { msg.textContent = t('nl_off'); }
  });

  // ---------- Click tracking (no PII) ----------
  document.addEventListener('click', e => { const a = e.target.closest('[data-track]'); if (a) track('cta_click', { cta: a.dataset.track }); });

  // ---------- Drawer ----------
  const drawer = $('#drawer'), mb = $('.menu-btn');
  function closeDrawer() { drawer.classList.remove('open'); drawer.setAttribute('aria-hidden', 'true'); mb.setAttribute('aria-expanded', 'false'); }
  mb.addEventListener('click', () => { drawer.classList.add('open'); drawer.setAttribute('aria-hidden', 'false'); mb.setAttribute('aria-expanded', 'true'); $('.drawer__close').focus(); });
  $('.drawer__close').addEventListener('click', closeDrawer);
  drawer.addEventListener('click', e => { if (e.target === drawer || e.target.closest('a')) closeDrawer(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });

  // ---------- Reveal ----------
  const io = new IntersectionObserver(es => es.forEach(x => { if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); } }), { rootMargin: '0px 0px -8% 0px' });
  $$('.reveal').forEach(el => io.observe(el));

  // ---------- Deep links: ?service=slug&type=home_visit#book ----------
  applyLang(); show(1);
  if (qp.get('type')) { const r = $(`input[name=type][value="${qp.get('type')}"]`); if (r) r.checked = true; }
  syncType();
})();
