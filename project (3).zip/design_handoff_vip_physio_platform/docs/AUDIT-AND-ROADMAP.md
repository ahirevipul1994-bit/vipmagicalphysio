# VIP MAGICAL PHYSIO CLINIC — Technical Audit, Roadmap, Risks & Costs
_Audit date: 21 Nov 2026 · Source audited: live build at vipmagicalphysio.netlify.app (public HTML/CSS/sitemap/robots). Git repository and Netlify dashboard were **not** accessible — see §6._

## 1. Audit findings

| Area | Finding | Verdict |
|---|---|---|
| Stack | Static multi-page HTML + 3 CSS files (`tokens.css`, `site.css`, `extras.css`), no framework, clean URLs | **Keep** — fast, cheap, Netlify-native. Add Netlify Functions rather than migrate to React. |
| Content | 12 service pages, 10 blog posts, about, FAQ, resources, videos, 4 legal pages. Copy is clinically responsible, no fake reviews | **Preserve** — strongest asset of the current site |
| Brand | Two theme directions (navy/teal, ink/terracotta); **no burgundy** as briefed | Replaced with burgundy + sage layer (Phase 1) |
| Booking | 4-step form → saves to `localStorage` + opens WhatsApp. **No server, no DB, no slot check** | Rebuilt: server endpoint + DB constraint; honest WhatsApp fallback until live |
| Contact form | WhatsApp-prefill only, nothing stored | Integrate into CRM (Phase 3) |
| Admin | `/admin.html` exists (blocked in robots) — "lead console" reading browser storage | **Security note:** robots.txt does not protect a page. Replace with Supabase-Auth admin |
| Ebooks | 4 "coming soon" cards, `/ebooks/` blocked, no payment | Razorpay + private storage functions written |
| i18n | `inLanguage` claims mr/hi but `/mr/` and `/hi/` **return errors** | Fixed on homepage; full route set in Phase 4 |
| SEO | Good titles/meta/OG, MedicalClinic schema, sitemap, robots | Issues: canonical → `vipmagicalphysio.com` (domain not confirmed live); sitemap lists `.html` URLs while site serves clean URLs; address is literally `[ADD CLINIC ADDRESS]` in schema; postcode 412208 likely wrong for Shirur (412210) — **verify** |
| GBP | Not integrated; address, hours, map are placeholders | Blocked on verified profile details |
| Analytics | GTM preconnect only, no container seen | Event layer added (no PII) |
| Fonts | 4 families loaded (2 unused per theme) | Reduced; Devanagari fonts added for MR/HI |
| Hero image | 609 KB JPEG, 1728×2304 | Convert to AVIF/WebP @ 3 widths (Phase 1 task, needs build step) |

## 2. What's delivered in this pass

| Deliverable | Path | Status |
|---|---|---|
| Phase 1 homepage, EN/MR/HI live switch, burgundy system, sticky mobile CTA, floating WhatsApp, accessible 4-step booking | `site/index.html`, `site/assets/*` | **COMPLETED — needs your review + clinical sign-off on MR/HI copy** |
| Booking with server submit, 409 slot-taken handling, honest offline fallback | `site/assets/app.js` | **IMPLEMENTED BUT REQUIRES CREDENTIALS** (Supabase + deploy) |
| DB schema: CRM, consent ledger, appointments w/ GiST exclusion (DB-level double-booking block), status audit trail, service areas, clinical notes separated, ebooks, orders, webhook idempotency, hashed download tokens, RLS on all tables | `backend/supabase/migrations/001_core_schema.sql` | **IMPLEMENTED BUT REQUIRES CREDENTIALS** — not yet executed against a database |
| Functions: book-appointment, razorpay-create-order, razorpay-webhook (HMAC + idempotent + amount check), download (expiring, use-limited, private bucket) | `backend/netlify/functions/` | **IMPLEMENTED BUT REQUIRES CREDENTIALS**; `send-email`, `available-slots`, `service-areas`, `subscribe` still **NOT IMPLEMENTED** |
| Env template | `backend/.env.example` | Done |
| Razorpay live | — | **PENDING THIRD-PARTY APPROVAL** (KYC) |
| WhatsApp automation | — | **PENDING THIRD-PARTY APPROVAL** (Meta verification) |
| GBP reviews/map | — | **PENDING** your verified profile |
| Admin dashboard, Brevo templates, 18 condition pages, full /mr /hi routes | — | **NOT IMPLEMENTED** (Phases 2–4) |

> Nothing here has been deployed to Netlify. No live test results exist yet — I won't claim any.

## 3. Roadmap

| Phase | Weeks | Scope | Exit test |
|---|---|---|---|
| 1 Foundation | 1–2 | Merge new homepage into repo, port brand layer to all existing pages, fix sitemap/canonical, real address/hours, image optimisation, replace `/admin.html` | Lighthouse ≥90 mobile; all 40 sitemap URLs 200 |
| 2 Revenue | 3–5 | Run migration, deploy functions, slots API, admin (appointments + areas + hours), Razorpay test mode → live, 4 ebooks uploaded to private bucket | Concurrent-booking test rejects overlap; webhook replay creates no duplicate; expired token 403 |
| 3 CRM | 6–8 | CRM views, notes, follow-ups, Brevo templates ×10 in 3 languages, consent withdrawal, Google Calendar sync | Unsubscribe honoured; no marketing mail without consent row |
| 4 Growth | 9–12 | `/en /mr /hi` for all pages + hreflang sitemap, 6 new condition pages (frozen shoulder, paralysis, knee/hip replacement, sports, ergonomics split), video library, GBP embed + review QR | Search Console: no hreflang errors |
| 5 Optimise | 13+ | KPI dashboard, funnel analysis, security review, perf budget | Monthly KPI report |

## 4. Risks

| Risk | Impact | Mitigation |
|---|---|---|
| No repo access → edits overwrite live work | High | Get GitHub access before merge; I built in a separate `site/` folder |
| Unverified address/hours published | High (trust + local SEO) | Kept as visible "awaiting verified details" — never guessed |
| MR/HI medical wording errors | High (patient safety) | UI copy only; all clinical text gated on your review |
| Health data under DPDP | High | Minimal fields, consent ledger, clinical notes isolated + admin-only RLS, no PII to GA |
| Razorpay KYC delay | Med | Store shows "coming soon"; enquiry fallback |
| Solo-practitioner capacity | Med | Requests, not auto-confirmations; configurable slots |
| Domain `vipmagicalphysio.com` not pointed | Med | Confirm ownership or switch canonicals to Netlify URL |

## 5. Estimated monthly infrastructure cost (INR, at current small-clinic volume)

| Service | Plan | Est. / month |
|---|---|---|
| Netlify | Free (100 GB, 125k function calls) | ₹0 |
| Supabase | Free tier to start → Pro when you need daily backups | ₹0 → ~₹2,100 |
| Razorpay | No fixed fee; ~2% per transaction (+GST) | variable |
| Brevo | Free (300 emails/day) | ₹0 |
| Cloudflare Turnstile | Free | ₹0 |
| WhatsApp Cloud API | Per-conversation (utility templates, low ₹ per message) | ~₹200–800 |
| Domain | .com renewal | ~₹100 (₹1,200/yr) |
| GA4 / Search Console / GBP | Free | ₹0 |
| **Total** | | **≈ ₹300 – ₹3,000 / month** |

Recommendation: stay on free tiers until ~50 bookings/month, then move Supabase to Pro mainly for backups.

## 6. What I need from you
1. GitHub repo access (and Netlify team invite) — to merge and deploy safely.
2. Verified clinic street address, PIN code, opening hours, Google Business Profile link / Place ID.
3. Approved home-visit localities + visit and travel charges.
4. Clinic slot length and consultation fees (OPD, home, online).
5. Supabase project (free) + Razorpay account status.
6. Clinical review of Marathi and Hindi copy.
7. 3–5 real clinic photos (assessment, home visit, elderly mobility) — please don't use AI-generated clinical scenes.
