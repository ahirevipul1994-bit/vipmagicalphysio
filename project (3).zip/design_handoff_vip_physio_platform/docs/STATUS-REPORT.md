# Status report — 21 Nov 2026

Status labels: **DONE+TESTED** · **NEEDS CREDENTIALS** · **PENDING APPROVAL** · **NOT IMPLEMENTED**

## Test evidence (actually run)
| Test | Result |
|---|---|
| Backend unit/integration suite (`node --test tests/`) on Node 22 | **38 / 38 pass** |
| SQL migrations 001 + 002 on **PostgreSQL 16** | Apply cleanly, 0 errors |
| DB: overlapping booking | Rejected by `no_overlap` (23P01) ✔ |
| DB: adjacent booking / freed slot after completion | Accepted ✔ |
| DB: invalid status jump (requested→completed) | Rejected ✔ |
| DB: confirming an unlisted-area home visit | Rejected by `unlisted_never_confirmed` ✔ |
| DB: atomic reschedule into a taken slot | Rolled back, original unchanged ✔ |
| DB: marketing email without consent | Auto-`skipped` ✔ · duplicate send blocked by `dedupe_key` ✔ |
| DB: publishing an unreviewed ebook | Rejected ✔ |
| DB: anonymous role reading customers | Permission denied ✔ |
| Netlify build command (`node site/tools/build.js`) | Builds 62 files ✔ |
| Static audit: 93 HTML pages, 2,097 internal links, all JSON-LD blocks, sitemap | 0 broken links after image recovery ✔ |

The tests use an in-memory database that mirrors the SQL constraints. The SQL constraints themselves were verified separately on real Postgres. **Not yet tested against a live Supabase project, live Brevo or live Razorpay.**

## Features
| Feature | Status |
|---|---|
| 18 condition pages × EN/MR/HI = 54 pages + 3 hubs: hook, symptoms, causes, red flags, assessment, 3-phase roadmap, exercise safety, myth vs fact, FAQ, video, ebook, related, CTAs, schema | **DONE+TESTED** (build/audit). Medical copy is **awaiting your clinical sign-off** and ships `noindex` until each page is marked reviewed |
| Language homes `/en/ /mr/ /hi/` with hreflang, localised titles and canonicals | **DONE+TESTED** |
| Recovery of all live pages, scripts and images into the deploy bundle; old `/services/*` → 301 to new pages; `/admin.html` → `/admin/` | **DONE+TESTED** |
| Booking: validation, honeypot, IST slot engine, DB double-booking guard, unlisted-area flagging, honest fallback | **DONE+TESTED** · live use **NEEDS CREDENTIALS** (Supabase) |
| CRM: customers, consent ledger, notes, follow-ups, first/last source, sticky patient category, safe CSV export (no clinical text, formula-injection safe) | **DONE+TESTED** · **NEEDS CREDENTIALS** |
| Email automation: 10 templates × 3 languages, queue with retry/backoff, dedupe, double opt-in, one-click unsubscribe, consent guard, hourly reminders + honest review requests | **DONE+TESTED** · **NEEDS CREDENTIALS** (Brevo + domain auth) |
| Admin console: sign-in, password reset, roles (owner/admin/reception), overview KPIs, funnel, sources, appointments workflow, CRM, orders, email log/subscribers/newsletter, settings (hours, areas, clinic details), audit log | **DONE** (demo mode reviewable now) · **NEEDS CREDENTIALS** |
| Razorpay ebook checkout: server-priced orders, HMAC webhook, idempotency, amount check, refunds revoke access, hashed expiring tokens, private bucket | **DONE+TESTED** · **PENDING APPROVAL** (Razorpay KYC) |
| Ebook storefront checkout UI on `/ebooks/*` pages | **NOT IMPLEMENTED** (legacy "coming soon" pages kept) |
| Google Business Profile reviews/map | **PENDING** your verified profile (review link field ready in Settings) |
| WhatsApp Business API automation | **PENDING APPROVAL** (Meta). Click-to-chat links work now |
| Google Calendar sync | **NOT IMPLEMENTED** |
| Legacy pages restyled to burgundy brand | **NOT IMPLEMENTED** (still the original navy theme. They work and link correctly) |
| Video consultation provider | **NOT IMPLEMENTED** (admin requires an https link per consult. Use Google Meet/Zoom links for now) |

## Repairs made this round
1. **Trigger bug:** the status log used a BEFORE trigger that would fail its foreign key on insert. It is now an AFTER trigger.
2. **Source overwrite:** repeat contacts were overwriting `first_source`. A new `upsert_customer()` function preserves it.
3. **Unlisted localities:** home-visit requests from unlisted localities were rejected outright. They are now accepted, flagged, and blocked at DB level from confirmation.
4. **Webhook race:** two near-simultaneous events could double-fulfil an order. A conditional `created→paid` update now guarantees a single fulfilment, and refunds revoke access.
5. **Webhook retries:** a failed webhook left an idempotency row that blocked Razorpay's retry. The row is now released on failure.
6. **Reschedule:** rescheduling was not atomic. It is now a single Postgres transaction.
7. **Missing config:** when Supabase is not configured, the API now returns `503` instead of crashing, so the frontend shows the honest WhatsApp fallback.
8. **Script collision:** the homepage strings file collided with the legacy `assets/i18n.js` and would have broken old pages. It was renamed.
9. **Broken images:** 12 legacy service images were missing from the bundle. Recovered.
10. **Migration syntax:** an SQL quoting error (introduced during patching) was caught by the real Postgres run and fixed.

## What I need from you
1. Clinical review of the 18 conditions (EN first, then MR/HI wording)
2. Verified address, PIN and opening hours
3. Your Google Business Profile review link
4. Home-visit localities and charges
5. Fees for OPD and online consultations
6. Supabase, Brevo and Netlify access, or follow DEPLOYMENT.md yourself
7. Razorpay KYC status
8. Ebook PDFs
