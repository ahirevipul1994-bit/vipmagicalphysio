# Deployment guide — VIP Magical Physio Clinic

Estimated time: ~90 minutes for the first setup. Everything below uses free tiers.

## 0. Back up the current live site (do this first)
- Netlify → your current site → **Deploys** → open the latest deploy → **Download** (zip). Keep it.
- All live pages, scripts, images and the old `admin.html` are already recovered into `site/` and `recovered/` in this project.

## 1. Put the code on GitHub
1. Create a private repo, e.g. `vip-magical-physio`.
2. Upload this project's folders: `site/`, `netlify/`, `supabase/`, `tests/`, `docs/`, plus `netlify.toml`, `package.json`, `.env.example` and `.gitignore`.
3. Run `npm install && npm test` locally (needs Node 20+). It should report **38 passing**.

## 2. Supabase (database, login, private file storage)
1. Create a project at supabase.com and choose the **Mumbai (ap-south-1)** region, so data stays close to patients.
2. SQL Editor → paste and run `supabase/migrations/001_core_schema.sql`, then `002_crm_email_reports.sql`.
3. Authentication → Providers: keep **Email** on. Turn **off** "Allow new users to sign up". Staff accounts are created by you only.
4. Authentication → Users → **Invite user** → your email.
5. SQL Editor (replace the email):
   ```sql
   insert into staff (user_id, full_name, role)
   select id, 'Dr. Vipul Ahire', 'owner' from auth.users where email = 'YOUR@EMAIL';
   ```
6. Storage → **New bucket** `ebooks` → **Public: OFF**.
7. Project Settings → API: copy the URL, the `anon` key and the `service_role` key (the last one is **secret**).

## 3. Netlify
1. Add new site → Import from GitHub → pick the repo. The build settings come automatically from `netlify.toml`.
2. Site configuration → Environment variables → add every value from `.env.example`.
3. Deploy. Then check:
   - `https://<site>/api/public-config` → shows `supabaseUrl`
   - `/en/`, `/mr/` and `/hi/` load
   - `/admin/` shows the sign-in page (NOT demo mode)
4. Domain: Domain management → add `vipmagicalphysio.com` → follow the DNS steps. HTTPS is automatic.

## 4. Brevo (email)
1. Create a free Brevo account → **Senders & domains** → add and authenticate your domain (SPF and DKIM records in your DNS).
2. SMTP & API → create an API key → add it in Netlify as `BREVO_API_KEY`. Set `BREVO_SENDER_EMAIL`.
3. Add `UNSUB_SECRET` (any long random text).
4. Test: subscribe on the homepage → the confirmation email arrives → confirm → the welcome email arrives.

## 5. Razorpay (after KYC approval)
1. Dashboard → Settings → API Keys → generate keys in **Test mode** first → add `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`.
2. Settings → Webhooks → add `https://vipmagicalphysio.com/api/razorpay-webhook`.
   - Events: `payment.captured`, `order.paid`, `payment.failed`, `refund.processed`
   - Set a secret and add it as `RAZORPAY_WEBHOOK_SECRET`.
3. Upload each ebook PDF to the `ebooks` bucket and insert a row in `ebooks`. It can only be published once `clinically_reviewed = true`.
4. Test with Razorpay test cards: the order becomes paid, the purchase email arrives, the download works, and it expires.
5. Switch to Live keys.

## 6. Spam protection (optional, free)
Cloudflare Turnstile → create a widget → add `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET`.

## 7. Before announcing the site
- [ ] Admin → Settings → real **address, PIN, Google review link, fees**.
- [ ] Admin → Settings → real **working hours**. The seeded hours are placeholders.
- [ ] Admin → Settings → real **home-visit areas and charges**.
- [ ] Dr. Vipul reviews each condition page. In `site/content/conditions.en.js`, set `reviewed:true` per item → redeploy. Reviewed pages become indexable and enter the sitemap.
- [ ] Submit `sitemap.xml` in Google Search Console.
- [ ] Make one real test booking end-to-end, then cancel it from the admin console.

## Rollback
Netlify → Deploys → pick the previous deploy → **Publish deploy**. This takes seconds and the database is unaffected.
