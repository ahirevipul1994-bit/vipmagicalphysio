// In-memory Supabase mock that mirrors the SQL constraints relevant to the business rules:
// - appointments exclusion constraint (overlapping live slots → 23P01)
// - unique: webhook_events.event_id, email_queue.dedupe_key, orders.razorpay_payment_id, customers.phone_e164, subscribers.email
// - appointment status transition rules (P0001) and unlisted_never_confirmed check
// - marketing email guard (skips without consent)
const crypto = require('crypto');
const LIVE = ['requested', 'pending_confirmation', 'confirmed'];
const TRANS = { requested: ['pending_confirmation', 'confirmed', 'cancelled', 'rescheduled'], pending_confirmation: ['confirmed', 'cancelled', 'rescheduled'], confirmed: ['completed', 'cancelled', 'rescheduled', 'no_show'] };
const UNIQUE = { webhook_events: ['event_id'], email_queue: ['dedupe_key'], orders: ['razorpay_payment_id', 'razorpay_order_id'], customers: ['phone_e164'], subscribers: ['email', 'confirm_token'], download_tokens: ['token_hash'] };
const MARKETING = new Set(['welcome', 'followup_education', 'newsletter']);
const rng = (r) => { const m = String(r).match(/[\[(]"?([^",]+)"?,"?([^",\])]+)"?[\])]/); return m ? [new Date(m[1]).getTime(), new Date(m[2]).getTime()] : null; };
const ov = (a, b) => { const x = rng(a), y = rng(b); return x && y && x[0] < y[1] && y[0] < x[1]; };

function createMockDb(seed = {}) {
  const T = { customers: [], consents: [], appointments: [], appointment_events: [], working_hours: [], service_areas: [], blocked_periods: [], orders: [], ebooks: [],
    webhook_events: [], download_tokens: [], email_queue: [], email_templates: [], subscribers: [], audit_log: [], crm_notes: [], clinic_settings: [{ id: true, reminder_hours: 24 }], staff: [], ...seed };
  let seq = 1; const id = () => crypto.randomUUID();
  const stats = { signedUrls: 0 };

  function embed(table, row, sel) {
    const out = { ...row };
    if (/customers(!inner)?\(/.test(sel) && row.customer_id) out.customers = T.customers.find((c) => c.id === row.customer_id) || null;
    if (/service_areas\(/.test(sel)) out.service_areas = row.service_area_id ? T.service_areas.find((a) => a.id === row.service_area_id) || null : null;
    if (/ebooks(!inner)?\(/.test(sel) && row.ebook_id && table === 'orders') out.ebooks = T.ebooks.find((e) => e.id === row.ebook_id) || null;
    if (/orders!inner\(/.test(sel) && table === 'download_tokens') { const o = T.orders.find((x) => x.id === row.order_id); out.orders = o ? { status: o.status, ebooks: T.ebooks.find((e) => e.id === o.ebook_id) } : null; }
    return out;
  }
  function checkInsert(table, r) {
    for (const k of UNIQUE[table] || []) if (r[k] != null && T[table].some((x) => x[k] === r[k])) return { code: '23505', message: `duplicate ${table}.${k}` };
    if (table === 'appointments') {
      if (r.needs_area_review && ['confirmed', 'completed'].includes(r.status)) return { code: '23514', message: 'unlisted_never_confirmed' };
      if (LIVE.includes(r.status) && T.appointments.some((a) => a.id !== r.id && LIVE.includes(a.status) && ov(a.slot, r.slot))) return { code: '23P01', message: 'conflicting key value violates exclusion constraint "no_overlap"' };
    }
    return null;
  }
  function defaults(table, r) {
    const now = new Date().toISOString();
    const base = { created_at: now };
    if (table === 'appointments') Object.assign(base, { id: id(), reference: crypto.randomBytes(4).toString('hex').toUpperCase(), status: 'requested', needs_area_review: false, updated_at: now });
    else if (table === 'email_queue') Object.assign(base, { id: seq++, status: 'queued', attempts: 0, send_after: now, vars: {} });
    else if (table === 'subscribers') Object.assign(base, { id: id(), status: 'pending', unsub_token: crypto.randomBytes(9).toString('hex') });
    else if (['orders', 'ebooks'].includes(table)) Object.assign(base, { id: id(), status: 'created' });
    else if (['consents', 'crm_notes', 'audit_log'].includes(table)) base.id = seq++;
    else if (table === 'download_tokens') base.uses_left = 5;
    const row = { ...base, ...r };
    if (table === 'email_queue' && MARKETING.has(row.template)) {
      let ok = false;
      if (row.subscriber_id) ok = T.subscribers.find((s) => s.id === row.subscriber_id)?.status === 'active';
      else if (row.customer_id) { const c = T.consents.filter((x) => x.customer_id === row.customer_id && x.purpose === 'marketing_email').pop(); ok = !!c?.granted; }
      if (!ok) { row.status = 'skipped'; row.error = 'no_marketing_consent'; }
    }
    return row;
  }

  function builder(table) {
    const st = { op: 'select', sel: '*', filters: [], patch: null, rows: null, single: false, maybe: false, ret: false, order: null, limit: null };
    const match = (r) => st.filters.every((f) => f(r));
    const exec = () => {
      const list = T[table];
      if (st.op === 'insert') {
        const out = [];
        for (const raw of st.rows) {
          const r = defaults(table, raw); const e = checkInsert(table, r); if (e) return { data: null, error: e };
          list.push(r); out.push(r);
          if (table === 'appointments') T.appointment_events.push({ appointment_id: r.id, from_status: null, to_status: r.status });
        }
        return fin(out);
      }
      if (st.op === 'upsert') { for (const r of st.rows) { const i = list.findIndex((x) => x.key === r.key && x.lang === r.lang); if (i >= 0) list[i] = { ...list[i], ...r }; else list.push(r); } return fin(st.rows); }
      if (st.op === 'update') {
        const hit = list.filter(match), out = [];
        for (const r of hit) {
          const next = { ...r, ...st.patch };
          if (table === 'appointments') {
            if (st.patch.status && st.patch.status !== r.status && !(TRANS[r.status] || []).includes(st.patch.status)) return { data: null, error: { code: 'P0001', message: `invalid status transition ${r.status} -> ${st.patch.status}` } };
            if (next.needs_area_review && ['confirmed', 'completed'].includes(next.status)) return { data: null, error: { code: '23514', message: 'unlisted_never_confirmed' } };
            if (LIVE.includes(next.status) && list.some((a) => a.id !== r.id && LIVE.includes(a.status) && ov(a.slot, next.slot))) return { data: null, error: { code: '23P01', message: 'exclusion' } };
            if (st.patch.status && st.patch.status !== r.status) T.appointment_events.push({ appointment_id: r.id, from_status: r.status, to_status: st.patch.status });
          }
          Object.assign(r, st.patch); out.push(r);
        }
        return fin(out);
      }
      if (st.op === 'delete') { const keep = list.filter((r) => !match(r)); const n = list.length - keep.length; T[table] = keep; return { data: null, error: null, count: n }; }
      let rows = list.filter(match);
      if (st.order) rows = rows.slice().sort((a, b) => (a[st.order] > b[st.order] ? 1 : -1));
      if (st.limit) rows = rows.slice(0, st.limit);
      return fin(rows);
    };
    const fin = (rows) => {
      const data = rows.map((r) => embed(table, r, st.sel));
      if (st.single || st.maybe) {
        if (data.length === 0) return st.maybe ? { data: null, error: null } : { data: null, error: { code: 'PGRST116', message: 'no rows' } };
        return { data: data[0], error: null };
      }
      return { data: (st.op === 'select' || st.ret) ? data : null, error: null };
    };
    const api = {
      select(s = '*') { st.sel = s; if (st.op !== 'select') st.ret = true; return api; },
      insert(r) { st.op = 'insert'; st.rows = Array.isArray(r) ? r : [r]; return api; },
      upsert(r) { st.op = 'upsert'; st.rows = Array.isArray(r) ? r : [r]; return api; },
      update(p) { st.op = 'update'; st.patch = p; return api; },
      delete() { st.op = 'delete'; return api; },
      eq(k, v) { st.filters.push((r) => r[k] === v); return api; },
      neq(k, v) { st.filters.push((r) => r[k] !== v); return api; },
      in(k, v) { st.filters.push((r) => v.includes(r[k])); return api; },
      is(k, v) { st.filters.push((r) => (r[k] ?? null) === v); return api; },
      lte(k, v) { st.filters.push((r) => r[k] <= v); return api; },
      gte(k, v) { st.filters.push((r) => r[k] >= v); return api; },
      overlaps(k, v) { st.filters.push((r) => ov(r[k], v)); return api; },
      order(k) { st.order = k; return api; },
      limit(n) { st.limit = n; return api; },
      single() { st.single = true; return api; },
      maybeSingle() { st.maybe = true; return api; },
      then(res, rej) { try { res(exec()); } catch (e) { rej(e); } },
    };
    return api;
  }

  return {
    T, stats,
    from: (t) => { if (!T[t]) T[t] = []; return builder(t); },
    async rpc(fn, a) {
      if (fn === 'reschedule_appointment') { // emulate single-transaction semantics
        const o = T.appointments.find((x) => x.id === a.p_id);
        if (!o || !LIVE.includes(o.status)) return { data: null, error: { code: 'P0001', message: 'not_reschedulable' } };
        const slot = `[${a.p_start},${a.p_end})`;
        if (T.appointments.some((x) => x.id !== o.id && LIVE.includes(x.status) && ov(x.slot, slot))) return { data: null, error: { code: '23P01', message: 'exclusion' } };
        o.status = 'rescheduled';
        const n = { ...o, id: id(), reference: crypto.randomBytes(4).toString('hex').toUpperCase(), slot, status: 'pending_confirmation', rescheduled_from: o.id };
        T.appointments.push(n); return { data: [{ id: n.id, reference: n.reference }], error: null };
      }
      if (fn !== 'upsert_customer') return { data: null, error: { message: 'unknown rpc' } };
      let c = T.customers.find((x) => x.phone_e164 === a.p_phone);
      if (c) Object.assign(c, { full_name: a.p_name, email: a.p_email || c.email, preferred_lang: a.p_lang, last_source: a.p_source, category: c.category === 'patient' ? 'patient' : a.p_category || c.category });
      else { c = { id: id(), full_name: a.p_name, phone_e164: a.p_phone, email: a.p_email || null, preferred_lang: a.p_lang, first_source: a.p_source, last_source: a.p_source, category: a.p_category || 'lead', follow_up_status: 'none', created_at: new Date().toISOString() }; T.customers.push(c); }
      return { data: c.id, error: null };
    },
    storage: { from: () => ({ createSignedUrl: async (p, secs) => { stats.signedUrls++; return { data: { signedUrl: `https://storage.example/signed/${p}?exp=${secs}` }, error: null }; } }) },
    auth: { getUser: async (jwt) => { const s = T.staff.find((x) => x.jwt === jwt); return s ? { data: { user: { id: s.user_id } }, error: null } : { data: null, error: { message: 'bad jwt' } }; } },
  };
}
module.exports = { createMockDb };
