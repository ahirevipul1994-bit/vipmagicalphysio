// Run: node --test tests/
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const { createMockDb } = require('./mock-db');
const core = require('../netlify/functions/lib/core');

process.env.SUPABASE_URL = 'https://x.supabase.co'; process.env.SUPABASE_SERVICE_ROLE_KEY = 'svc';
process.env.SITE_URL = 'https://vipmagicalphysio.com'; process.env.RAZORPAY_WEBHOOK_SECRET = 'whsec_test'; process.env.UNSUB_SECRET = 'u';
delete process.env.BREVO_API_KEY; delete process.env.TURNSTILE_SECRET;

const HOURS = [1, 2, 3, 4, 5, 6].flatMap((d) => [{ weekday: d, opens: '10:00:00', closes: '13:30:00', slot_minutes: 45, appt_type: 'clinic_opd' },
  { weekday: d, opens: '16:00:00', closes: '20:00:00', slot_minutes: 45, appt_type: 'clinic_opd' }, { weekday: d, opens: '10:00:00', closes: '20:00:00', slot_minutes: 60, appt_type: 'home_visit' },
  { weekday: d, opens: '10:00:00', closes: '20:00:00', slot_minutes: 45, appt_type: 'online' }]);
function nextWeekdayIST(daysAhead = 3) { let d = new Date(Date.now() + daysAhead * 864e5); while (new Date(d.toISOString().slice(0, 10) + 'T12:00:00+05:30').getUTCDay() === 0) d = new Date(d.getTime() + 864e5); return d.toISOString().slice(0, 10); }
const DATE = nextWeekdayIST();
const at = (hhmm) => new Date(`${DATE}T${hhmm}:00+05:30`).toISOString();
function fresh() { const db = createMockDb({ working_hours: HOURS.map((h) => ({ ...h })), service_areas: [{ id: 1, name: 'Shirur city', active: true, sort: 0 }, { id: 2, name: 'Old area', active: false, sort: 1 }] }); core.setDb(db); return db; }
const post = (body, headers = {}) => ({ httpMethod: 'POST', headers, body: JSON.stringify(body) });
const base = (o = {}) => ({ type: 'clinic_opd', service: 'back-pain-physiotherapy', slot_start: at('10:00'), name: 'Test Patient', phone: '9876543210', email: 'p@example.com',
  age_group: '45-59', lang: 'mr', consent_contact: true, privacy_ack: true, consent_marketing: false, page: '/mr/', ...o });
const book = require('../netlify/functions/book-appointment').handler;
const body = (r) => JSON.parse(r.body);

// ---------------- core helpers ----------------
test('toE164 normalises Indian mobiles and rejects invalid', () => {
  assert.equal(core.toE164('98765 43210'), '+919876543210');
  assert.equal(core.toE164('+91-9876543210'), '+919876543210');
  assert.equal(core.toE164('09876543210'), '+919876543210');
  assert.equal(core.toE164('12345'), null);
  assert.equal(core.toE164('5876543210'), null); // must start 6-9
});

// ---------------- booking ----------------
test('valid booking → 201 REQUESTED (never confirmed) + CRM + consent ledger + ack email queued in patient language', async () => {
  const db = fresh();
  const r = await book(post(base()));
  assert.equal(r.statusCode, 201, r.body);
  assert.equal(body(r).status, 'requested');
  assert.equal(db.T.appointments[0].status, 'requested');
  assert.equal(db.T.customers.length, 1);
  assert.equal(db.T.customers[0].phone_e164, '+919876543210');
  const purposes = db.T.consents.map((c) => `${c.purpose}:${c.granted}`).sort();
  assert.deepEqual(purposes, ['contact_for_request:true', 'marketing_email:false', 'privacy_ack:true']);
  const q = db.T.email_queue[0]; assert.equal(q.template, 'appointment_ack'); assert.equal(q.lang, 'mr');
  assert.equal(q.status, 'queued'); // Brevo not configured → stays queued for retry, booking still succeeds
});

test('validation: missing consent / bad phone / missing age → 422 with field errors', async () => {
  fresh();
  const r = await book(post(base({ consent_contact: false, phone: '123', age_group: '' })));
  assert.equal(r.statusCode, 422);
  const f = body(r).fields; assert.ok(f.consent_contact && f.phone && f.age_group);
});

test('double-booking: second request for same slot → 409 slot_taken (DB exclusion constraint)', async () => {
  const db = fresh();
  assert.equal((await book(post(base()))).statusCode, 201);
  const r2 = await book(post(base({ phone: '9876500000', name: 'Other Person' })));
  assert.equal(r2.statusCode, 409); assert.equal(body(r2).error, 'slot_taken');
  assert.equal(db.T.appointments.length, 1);
});

test('concurrent identical requests: exactly one wins', async () => {
  const db = fresh();
  const rs = await Promise.all([1, 2, 3, 4, 5].map((i) => book(post(base({ phone: `98765000${10 + i}` })))));
  assert.equal(rs.filter((r) => r.statusCode === 201).length, 1);
  assert.equal(rs.filter((r) => r.statusCode === 409).length, 4);
  assert.equal(db.T.appointments.length, 1);
});

test('cancelled appointment frees the slot', async () => {
  const db = fresh();
  await book(post(base())); db.T.appointments[0].status = 'cancelled';
  assert.equal((await book(post(base({ phone: '9876500001' })))).statusCode, 201);
});

test('slot outside working hours or misaligned → 422', async () => {
  fresh();
  assert.equal((await book(post(base({ slot_start: at('14:00') })))).statusCode, 422);
  assert.equal((await book(post(base({ slot_start: at('10:10') })))).statusCode, 422);
  const sun = (() => { let d = new Date(Date.now() + 3 * 864e5); while (new Date(d.toISOString().slice(0, 10) + 'T12:00:00+05:30').getUTCDay() !== 0) d = new Date(d.getTime() + 864e5); return d.toISOString().slice(0, 10); })();
  assert.equal((await book(post(base({ slot_start: new Date(`${sun}T10:00:00+05:30`).toISOString() })))).statusCode, 422);
});

test('slot in the past / within 2h lead time → 422', async () => {
  fresh();
  assert.equal((await book(post(base({ slot_start: new Date(Date.now() - 864e5).toISOString() })))).statusCode, 422);
});

test('home visit in approved area → normal request; unlisted area → flagged, never confirmable', async () => {
  const db = fresh();
  const ok = await book(post(base({ type: 'home_visit', service: 'stroke-rehabilitation', slot_start: at('11:00'), service_area_id: 1 })));
  assert.equal(ok.statusCode, 201); assert.equal(body(ok).needs_area_review, false);
  const un = await book(post(base({ type: 'home_visit', service: 'stroke-rehabilitation', slot_start: at('13:00'), phone: '9876500002', locality_text: 'Nhavare' })));
  assert.equal(un.statusCode, 201); assert.equal(body(un).needs_area_review, true);
  const flagged = db.T.appointments.find((a) => a.needs_area_review);
  assert.equal(flagged.locality_text, 'Nhavare');
  assert.equal(db.T.email_queue.find((e) => e.template === 'home_visit_ack' && e.vars.review === '1') != null, true);
  // inactive area also flagged
  const inact = await book(post(base({ type: 'home_visit', service: 'stroke-rehabilitation', slot_start: at('15:00'), phone: '9876500003', service_area_id: 2, locality_text: 'x' })));
  assert.equal(body(inact).needs_area_review, true);
});

test('home visit with no area and no locality → 422', async () => {
  fresh();
  const r = await book(post(base({ type: 'home_visit', slot_start: at('11:00') })));
  assert.equal(r.statusCode, 422); assert.ok(body(r).fields.service_area_id);
});

test('honeypot submissions are silently dropped (no DB writes)', async () => {
  const db = fresh();
  const r = await book(post(base({ website: 'http://spam' })));
  assert.equal(r.statusCode, 201); assert.equal(db.T.appointments.length, 0); assert.equal(db.T.customers.length, 0);
});

test('repeat contact keeps first_source, updates last_source, patient category is sticky', async () => {
  const db = fresh();
  await book(post(base()));
  db.T.customers[0].category = 'patient';
  const r2 = await book(post(base({ type: 'online', service: 'neck-pain-physiotherapy', slot_start: at('16:00') })));
  assert.equal(r2.statusCode, 201, r2.body);
  const c = db.T.customers[0];
  assert.equal(db.T.customers.length, 1); assert.equal(c.first_source, 'appointment'); assert.equal(c.last_source, 'online_consult'); assert.equal(c.category, 'patient');
});

test('backend not configured → 503 (frontend then offers honest WhatsApp fallback)', async () => {
  core.setDb(null); const save = process.env.SUPABASE_URL; delete process.env.SUPABASE_URL;
  const r = await book(post(base())); assert.equal(r.statusCode, 503);
  process.env.SUPABASE_URL = save;
});

test('GET is rejected', async () => { fresh(); assert.equal((await book({ httpMethod: 'GET', headers: {} })).statusCode, 405); });

// ---------------- slots ----------------
test('slot engine: IST sessions, busy slots marked unavailable', () => {
  const { generateSlots } = require('../netlify/functions/lib/slots');
  const hours = HOURS.filter((h) => h.appt_type === 'clinic_opd');
  const s = generateSlots(DATE, hours, [{ start: new Date(at('11:30')), end: new Date(at('12:15')) }]);
  assert.deepEqual(s.map((x) => x.time).slice(0, 4), ['10:00', '10:45', '11:30', '12:15']);
  assert.equal(s.find((x) => x.time === '11:30').available, false);
  assert.equal(s.find((x) => x.time === '10:00').available, true);
  assert.ok(!s.some((x) => x.time === '13:00')); // 13:00+45 > 13:30 close
  assert.equal(s.find((x) => x.time === '16:00').start, at('16:00'));
});

test('available-slots API returns free/busy only, no patient data', async () => {
  fresh(); await book(post(base()));
  const r = await require('../netlify/functions/available-slots').handler({ queryStringParameters: { date: DATE, type: 'clinic_opd' } });
  const d = body(r); assert.equal(r.statusCode, 200);
  assert.ok(d.taken.includes('10:00'));
  assert.ok(!JSON.stringify(d).includes('Test Patient') && !JSON.stringify(d).includes('9876543210'));
});

// ---------------- payments ----------------
const hook = require('../netlify/functions/razorpay-webhook').handler;
function signed(payload, eventId = 'evt_' + crypto.randomBytes(4).toString('hex'), secret = 'whsec_test') {
  const raw = JSON.stringify(payload);
  return { httpMethod: 'POST', body: raw, headers: { 'X-Razorpay-Signature': crypto.createHmac('sha256', secret).update(raw).digest('hex'), 'X-Razorpay-Event-Id': eventId } };
}
function shop() {
  const db = fresh();
  db.T.ebooks.push({ id: 'b1', slug: 'knee-health-mr', title: 'Knee Health', price_paise: 19900, published: true, storage_path: 'mr/knee.pdf' });
  db.T.customers.push({ id: 'c1', full_name: 'Buyer', phone_e164: '+919876543210', email: 'buyer@example.com', preferred_lang: 'hi', category: 'lead' });
  db.T.orders.push({ id: 'o1', customer_id: 'c1', ebook_id: 'b1', amount_paise: 19900, status: 'created', razorpay_order_id: 'order_1' });
  return db;
}
const captured = (amount = 19900, currency = 'INR') => ({ event: 'payment.captured', payload: { payment: { entity: { id: 'pay_1', order_id: 'order_1', amount, currency } } } });

test('webhook: invalid signature → 401, order untouched', async () => {
  const db = shop();
  const r = await hook(signed(captured(), 'e1', 'wrong_secret'));
  assert.equal(r.statusCode, 401); assert.equal(db.T.orders[0].status, 'created'); assert.equal(db.T.download_tokens.length, 0);
});

test('webhook: valid payment → paid, one hashed token, purchase email (no raw token stored)', async () => {
  const db = shop();
  const r = await hook(signed(captured(), 'e2'));
  assert.equal(r.statusCode, 200, r.body);
  assert.equal(db.T.orders[0].status, 'paid'); assert.equal(db.T.download_tokens.length, 1);
  const em = db.T.email_queue.find((e) => e.template === 'ebook_purchase'); assert.ok(em); assert.equal(em.lang, 'hi');
  const rawTok = em.vars.download.split('t=')[1];
  assert.notEqual(db.T.download_tokens[0].token_hash, rawTok); assert.equal(db.T.download_tokens[0].token_hash, core.sha256(rawTok));
  assert.equal(db.T.customers[0].category, 'ebook_buyer');
});

test('webhook: replayed event id → idempotent (no second token/email)', async () => {
  const db = shop(); const ev = signed(captured(), 'e3');
  await hook(ev); const r2 = await hook(ev);
  assert.equal(body(r2).duplicate, true); assert.equal(db.T.download_tokens.length, 1);
  assert.equal(db.T.email_queue.filter((e) => e.template === 'ebook_purchase').length, 1);
});

test('webhook: different event ids for same payment (order.paid + payment.captured) → still one fulfilment', async () => {
  const db = shop();
  await hook(signed(captured(), 'e4a')); await hook(signed({ ...captured(), event: 'order.paid' }, 'e4b'));
  assert.equal(db.T.download_tokens.length, 1);
});

test('webhook: amount mismatch → flagged, not paid', async () => {
  const db = shop();
  const r = await hook(signed(captured(100), 'e5'));
  assert.equal(body(r).flagged, 'amount_mismatch'); assert.equal(db.T.orders[0].status, 'created'); assert.equal(db.T.download_tokens.length, 0);
});

test('webhook: payment.failed → order failed', async () => {
  const db = shop();
  await hook(signed({ event: 'payment.failed', payload: { payment: { entity: { id: 'pay_x', order_id: 'order_1' } } } }, 'e6'));
  assert.equal(db.T.orders[0].status, 'failed');
});

test('webhook: refund revokes download access', async () => {
  const db = shop();
  await hook(signed(captured(), 'e7'));
  await hook(signed({ event: 'refund.processed', payload: { refund: { entity: { payment_id: 'pay_1' } } } }, 'e8'));
  assert.equal(db.T.orders[0].status, 'refunded'); assert.equal(db.T.download_tokens[0].uses_left, 0);
});

test('create-order without Razorpay credentials → 503 (no fake checkout)', async () => {
  shop(); delete process.env.RAZORPAY_KEY_ID;
  const r = await require('../netlify/functions/razorpay-create-order').handler(post({ ebook_slug: 'knee-health-mr', phone: '9876543210', email: 'a@b.co', privacy_ack: true }));
  assert.equal(r.statusCode, 503);
});

// ---------------- downloads ----------------
const dl = require('../netlify/functions/download').handler;
async function paidToken(db) { await hook(signed(captured(), 'e' + Math.random())); return db.T.email_queue.find((e) => e.template === 'ebook_purchase').vars.download.split('t=')[1]; }

test('download: valid token → 302 to short-lived signed URL; uses decrement', async () => {
  const db = shop(); const t = await paidToken(db);
  const r = await dl({ queryStringParameters: { t } });
  assert.equal(r.statusCode, 302); assert.match(r.headers.location, /signed\/mr\/knee\.pdf\?exp=300/);
  assert.equal(db.T.download_tokens[0].uses_left, 4);
});

test('download: forged, expired, exhausted and unpaid tokens → 403', async () => {
  const db = shop(); const t = await paidToken(db);
  assert.equal((await dl({ queryStringParameters: { t: 'x'.repeat(43) } })).statusCode, 403);
  db.T.download_tokens[0].expires_at = new Date(Date.now() - 1000).toISOString();
  assert.equal((await dl({ queryStringParameters: { t } })).statusCode, 403);
  db.T.download_tokens[0].expires_at = new Date(Date.now() + 1e6).toISOString(); db.T.download_tokens[0].uses_left = 0;
  assert.equal((await dl({ queryStringParameters: { t } })).statusCode, 403);
  db.T.download_tokens[0].uses_left = 3; db.T.orders[0].status = 'refunded';
  assert.equal((await dl({ queryStringParameters: { t } })).statusCode, 403);
  assert.equal(db.stats.signedUrls, 0);
});

// ---------------- email / consent ----------------
test('marketing email without consent is skipped (DB guard); with active subscription it queues', async () => {
  const db = fresh(); const mailer = require('../netlify/functions/lib/mailer');
  db.T.customers.push({ id: 'cx', full_name: 'X', phone_e164: '+919800000009', preferred_lang: 'en' });
  await mailer.queue('followup_education', { to: 'x@example.com', customerId: 'cx', vars: {} });
  assert.equal(db.T.email_queue[0].status, 'skipped');
  db.T.subscribers.push({ id: 's1', email: 'y@example.com', status: 'active', unsub_token: 'tok' });
  await mailer.queue('welcome', { to: 'y@example.com', subscriberId: 's1' });
  assert.equal(db.T.email_queue[1].status, 'queued');
});

test('subscribe is double opt-in; confirm activates and queues welcome; unsubscribe works', async () => {
  const db = fresh();
  const r = await require('../netlify/functions/subscribe').handler(post({ email: 'new@example.com', lang: 'hi', consent: true }));
  assert.equal(body(r).status, 'pending_confirmation'); assert.equal(db.T.subscribers[0].status, 'pending');
  assert.equal((await require('../netlify/functions/subscribe').handler(post({ email: 'new@example.com', consent: false }))).statusCode, 422);
  const ct = db.T.subscribers[0].confirm_token;
  await require('../netlify/functions/confirm-subscription').handler({ queryStringParameters: { t: ct } });
  assert.equal(db.T.subscribers[0].status, 'active');
  assert.ok(db.T.email_queue.some((e) => e.template === 'welcome' && e.status === 'queued' && e.lang === 'hi'));
  await require('../netlify/functions/unsubscribe').handler({ queryStringParameters: { t: db.T.subscribers[0].unsub_token } });
  assert.equal(db.T.subscribers[0].status, 'unsubscribed');
});

test('patient unsubscribe link (HMAC) records consent withdrawal; forged link rejected', async () => {
  const db = fresh(); const un = require('../netlify/functions/unsubscribe').handler;
  const good = core.sha256('u' + 'c9').slice(0, 24);
  await un({ queryStringParameters: { c: 'c9', s: good } });
  assert.equal(db.T.consents.at(-1).purpose, 'marketing_email'); assert.equal(db.T.consents.at(-1).granted, false);
  const n = db.T.consents.length; await un({ queryStringParameters: { c: 'c9', s: 'forged' } }); assert.equal(db.T.consents.length, n);
});

test('templates: all keys exist in EN/MR/HI, escape HTML, marketing requires unsubscribe', () => {
  const { TEMPLATES, render } = require('../netlify/functions/lib/email-templates');
  for (const [k, t] of Object.entries(TEMPLATES)) for (const l of ['en', 'mr', 'hi']) assert.ok(t[l] && t[l][0] && t[l][1], `${k}.${l}`);
  const m = render('appointment_ack', 'en', { name: '<script>x</script>', ref: 'R1', when: 'Mon', type: 'Clinic' });
  assert.ok(!m.html.includes('<script>x')); assert.ok(m.html.includes('&lt;script&gt;'));
  assert.throws(() => render('welcome', 'en', {}), /unsubscribe/);
  assert.ok(render('welcome', 'mr', { unsubscribe: 'https://u' }).html.includes('https://u'));
  assert.ok(render('appointment_ack', 'hi', { ref: 'X' }).html.includes('108'));
});

test('mailer: failed send stays queued with backoff, marks failed after 5 attempts', async () => {
  const db = fresh(); const mailer = require('../netlify/functions/lib/mailer');
  await mailer.queue('appointment_ack', { to: 'a@example.com', lang: 'en', vars: { ref: 'R' } });
  await mailer.processQueue(); assert.equal(db.T.email_queue[0].status, 'queued'); assert.match(db.T.email_queue[0].error, /brevo_not_configured/);
  db.T.email_queue[0].attempts = 4; db.T.email_queue[0].send_after = new Date(0).toISOString();
  await mailer.processQueue(); assert.equal(db.T.email_queue[0].status, 'failed');
});

// ---------------- admin authorisation ----------------
const adm = require('../netlify/functions/admin-api').handler;
function adminDb() {
  const db = fresh();
  db.T.staff.push({ user_id: 'u-owner', role: 'owner', active: true, full_name: 'Dr V', jwt: 'JWT_OWNER' }, { user_id: 'u-rec', role: 'reception', active: true, full_name: 'Rec', jwt: 'JWT_REC' },
    { user_id: 'u-off', role: 'admin', active: false, full_name: 'Old', jwt: 'JWT_OFF' });
  return db;
}
test('admin API: no token → 401; bad token → 401; inactive staff → 403', async () => {
  adminDb();
  assert.equal((await adm(post({ action: 'export_crm' }))).statusCode, 401);
  assert.equal((await adm(post({ action: 'export_crm' }, { authorization: 'Bearer nope' }))).statusCode, 401);
  assert.equal((await adm(post({ action: 'export_crm' }, { authorization: 'Bearer JWT_OFF' }))).statusCode, 403);
});

test('admin API: reception cannot export CRM, change settings or send newsletters', async () => {
  adminDb(); const h = { authorization: 'Bearer JWT_REC' };
  assert.equal((await adm(post({ action: 'export_crm' }, h))).statusCode, 403);
  assert.equal((await adm(post({ action: 'update_settings', address_line: 'x' }, h))).statusCode, 403);
  assert.equal((await adm(post({ action: 'newsletter', subject_en: 's', body_en: 'b' }, h))).statusCode, 403);
  assert.equal((await adm(post({ action: 'upsert_area', name: 'x' }, h))).statusCode, 403);
});

test('admin API: CSV export excludes enquiry/clinical text and neutralises formula injection', async () => {
  const db = adminDb(); await book(post(base({ name: '=HYPERLINK("x")', enquiry: 'SECRET CLINICAL DETAIL' })));
  const r = await adm(post({ action: 'export_crm' }, { authorization: 'Bearer JWT_OWNER' }));
  assert.equal(r.statusCode, 200); assert.ok(!r.body.includes('SECRET CLINICAL DETAIL')); assert.ok(r.body.includes(`"'=HYPERLINK`));
  assert.ok(db.T.audit_log.some((a) => a.action === 'crm:export'));
});

test('admin workflow: requested → confirmed sends confirmation; invalid transition blocked; audit logged', async () => {
  const db = adminDb(); await book(post(base())); const id = db.T.appointments[0].id; const h = { authorization: 'Bearer JWT_REC' };
  assert.equal((await adm(post({ action: 'set_status', id, status: 'completed' }, h))).statusCode, 409); // requested → completed not allowed
  assert.equal((await adm(post({ action: 'set_status', id, status: 'confirmed' }, h))).statusCode, 200);
  assert.ok(db.T.email_queue.some((e) => e.template === 'appointment_confirmed' && e.lang === 'mr'));
  assert.equal((await adm(post({ action: 'set_status', id, status: 'completed', fee_inr: 600 }, h))).statusCode, 200);
  assert.equal(db.T.customers[0].category, 'patient'); assert.equal(db.T.appointments[0].fee_inr, 600);
  assert.deepEqual(db.T.appointment_events.map((e) => e.to_status), ['requested', 'confirmed', 'completed']);
  assert.ok(db.T.audit_log.filter((a) => a.entity === 'appointment').length >= 2);
});

test('admin: unlisted-area request cannot be confirmed until area approved', async () => {
  const db = adminDb(); const h = { authorization: 'Bearer JWT_OWNER' };
  await book(post(base({ type: 'home_visit', slot_start: at('11:00'), locality_text: 'Far village' }))); const id = db.T.appointments[0].id;
  const r = await adm(post({ action: 'set_status', id, status: 'confirmed' }, h)); assert.equal(r.statusCode, 409); assert.equal(body(r).error, 'area_review_required');
  assert.equal((await adm(post({ action: 'approve_area', id }, h))).statusCode, 200);
  assert.equal((await adm(post({ action: 'set_status', id, status: 'confirmed' }, h))).statusCode, 200);
});

test('admin: online consult needs https video link to confirm', async () => {
  const db = adminDb(); const h = { authorization: 'Bearer JWT_OWNER' };
  await book(post(base({ type: 'online', slot_start: at('12:15') }))); const id = db.T.appointments[0].id;
  assert.equal((await adm(post({ action: 'set_status', id, status: 'confirmed' }, h))).statusCode, 422);
  assert.equal((await adm(post({ action: 'set_status', id, status: 'confirmed', video_link: 'http://insecure' }, h))).statusCode, 422);
  assert.equal((await adm(post({ action: 'set_status', id, status: 'confirmed', video_link: 'https://meet.example.com/abc' }, h))).statusCode, 200);
});

test('admin: reschedule into a taken slot fails and restores original', async () => {
  const db = adminDb(); const h = { authorization: 'Bearer JWT_OWNER' };
  await book(post(base())); await book(post(base({ phone: '9876500077', slot_start: at('10:45') })));
  const id = db.T.appointments[0].id;
  const r = await adm(post({ action: 'reschedule', id, slot_start: at('10:45') }, h));
  assert.equal(r.statusCode, 409); assert.equal(db.T.appointments.find((a) => a.id === id).status, 'requested');
  const ok = await adm(post({ action: 'reschedule', id, slot_start: at('16:00') }, h));
  assert.equal(ok.statusCode, 200); assert.equal(db.T.appointments.find((a) => a.id === id).status, 'rescheduled');
});
