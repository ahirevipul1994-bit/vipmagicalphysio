# Handoff: VIP Magical Physio Clinic — Website, Booking, CRM & Admin Platform

## Overview
This is a trilingual (English / Marathi / Hindi) healthcare website and business system for **VIP Magical Physio Clinic** (Dr. Vipul Ahire, Physio — Shirur, Pune District, India). Its educational brand is **Dard E Body Care**, and its brand promise is **"Move Better. Live Better."**

It includes:
1. **Public site.** A homepage with a 4-step appointment wizard, 18 condition landing pages × 3 languages (54 pages plus 3 index pages), and per-language homepages.
2. **Backend.** Netlify Functions plus Supabase Postgres covering:
   - Appointment requests with database-level double-booking prevention.
   - Customer records (CRM) with a consent history.
   - An email queue (Brevo) with 10 templates × 3 languages.
   - Razorpay ebook checkout with secure, expiring downloads.
   - Hourly reminders.
3. **Admin console.** `/admin/` with staff login, roles, overview KPIs, appointment workflow, CRM, orders, email and settings.

Existing legacy pages (About, Blog, FAQ, legal pages, ebooks) live on the current site, https://vipmagicalphysio.netlify.app. They are **not** part of this bundle and should be kept and linked as they are. The plan is to restyle them to the new brand later.

## About the Design Files
The HTML/CSS/JS files in `site/` are **design references created in HTML**: working prototypes that show the intended look, copy and behaviour. They are not production code to drop in unchanged.
- **Frontend:** recreate these designs in the target codebase's environment. If there isn't one yet, pick a framework. Recommended: **Astro or Next.js (SSG)** for the public site, because the condition pages must be pre-rendered for SEO, and **React** for the admin.
- **Backend** (`netlify/functions/`, `supabase/migrations/`, `tests/`): this part is written to production standard and is tested (see "Verified" below). It can be reused nearly as-is, or ported faithfully.
- **Deploy target:** the next step is Genspark Code. The included `netlify.toml` documents the intended routing and headers.

## Fidelity
**High-fidelity.** Colours, typography, spacing, copy, states and responsive behaviour are final. Recreate the public site and the admin pixel-faithfully. The Marathi and Hindi copy is final UI copy. The *medical* content is a draft that needs clinical sign-off (each condition has `reviewed:false`).

---

## Design Tokens

### Colours (public site — `site/assets/home.css :root`)
| Token | Hex | Use |
|---|---|---|
| `--ink` | `#1F1C1D` | Primary text, footer background, utility bar |
| `--ink-2` | `#3A3536` | Nav links, secondary text |
| `--ink-soft` | `#5E5759` | Muted text, hints |
| `--paper` | `#FFFFFF` | Page background |
| `--paper-2` | `#FAF8F6` | Tinted sections, hero gradient start |
| `--paper-3` | `#F3EFEC` | Pills, placeholders, myth column |
| `--line` | `#E6E0DC` | Borders |
| `--line-soft` | `#EFEAE7` | Hairlines |
| `--wine` | `#7A1F2B` | **Primary**: CTAs, eyebrows, accents |
| `--wine-2` | `#5E1520` | Primary hover, newsletter section background |
| `--wine-soft` | `#F6EBEC` | Selected option background, soft button |
| `--wine-tint` | `#EAD3D6` | Card hover border |
| `--sage` | `#3F6B55` | **Secondary**: WhatsApp, "referral" step, positive |
| `--sage-soft` | `#E8F0EB` | Info notices, "ways" pills |
| `--alert` | `#9A2B1E` | Errors, red-flag box |
| `--alert-soft` | `#FBEDEA` | Red-flag and warning backgrounds |
| Review flag | `#FFF7E6` bg / `#F0DDB0` border / `#6B4A0E` text / `#C98A1B` dot | "Clinical review pending" |

Admin-only additions (`site/admin/admin.css`): `--amber #A86A0C` / `--amber-soft #FBF1DE` (requested, demo banner), `--blue #2E5A88` / `--blue-soft #E7EEF6` (pending), `--red #9A2B1E`, admin page background `#FAF8F6`.

### Typography
- **Display (Latin):** `Newsreader` (Google Fonts; opsz 6..72, weights 300–600, italic). Weight 400, letter-spacing −0.02em, line-height 1.1, `text-wrap: balance`.
- **Body (Latin):** `Public Sans` 400–700. 17px (1.0625rem) / line-height 1.65.
- **Devanagari:** when `html[lang=mr]`, display font is `Tiro Devanagari Marathi`; when `html[lang=hi]`, `Tiro Devanagari Hindi`. Body font is `Mukta` 400/500/600, at **18px / 1.75** for both. Italics are turned off for Devanagari (hero `em`, hook, myth).
- **Scale:**
  - Hero H1: `clamp(3rem, 1.6rem+5.6vw, 6rem)`, line-height 1.02 (Devanagari: `clamp(2.6rem,1.4rem+4.6vw,5rem)`, line-height 1.2).
  - Section H2: `clamp(2rem,1.3rem+2.6vw,3.2rem)`.
  - Condition H1: `clamp(2.6rem,1.5rem+4vw,4.6rem)`.
  - Card H3: 1.3–1.75rem.
  - Eyebrow: 600 .78rem, uppercase, letter-spacing .16em, colour wine, preceded by a 22×1.5px line (Devanagari: no uppercase, letter-spacing .04em, .95rem).
  - Lede: 1.2rem, ink-soft, max 58ch.

### Spacing, radius, shadow
- Shell max-width **1240px**. Gutter `clamp(1.1rem,4vw,2.75rem)`. Section padding `clamp(3.75rem,7vw,7.5rem)`.
- Radius: `--r 10px` (inputs, notices), `--r-lg 18px` (cards, hero image, form), `--r-pill 999px` (buttons, chips). Ebook cover: `6px 12px 12px 6px`.
- Shadow `--sh-md`: `0 18px 40px -22px rgba(60,20,26,.28), 0 2px 6px rgba(31,28,29,.05)`.
- **Minimum tap target 52px** (`--tap`). Slot buttons 46px. Admin buttons 38px (sm 30px).
- Easing `cubic-bezier(.22,.61,.36,1)`. Reveal on scroll: opacity 0→1 and translateY 14px→0 over 0.7s. Respect `prefers-reduced-motion`.

### Buttons
| Variant | Style |
|---|---|
| `.btn--wine` | bg `#7A1F2B`, white text, hover `#5E1520` |
| `.btn--line` | 1.5px ink border, transparent; hover fills ink with white text |
| `.btn--soft` | bg wine-soft, wine text; hover wine-tint |
| `.btn--sage` | bg sage, white text |
| `.btn--ghost` | wine text, underlined (offset 5px, 1.5px thick) |
| `.btn--onwine` / `.btn--linewhite` | white button / white outline for use on wine backgrounds |

All buttons: min-height 52px, padding 0 1.4rem, 600 1rem, pill radius. The arrow nudges 3px right on hover. Active state: translateY 1px.

---

## Screens / Views

### 1. Homepage — `site/index.html` (rendered to `/en/`, `/mr/`, `/hi/`)
From top to bottom:
1. **Utility bar.** Ink background, height 40, 0.875rem. A note on the left. "Call 86248 60808" (`tel:+918624860808`) and a WhatsApp link (`wa.me/918624860808`) on the right.
2. **Sticky header.** Height 76, white at 94% opacity with a backdrop blur.
   - **Brand:** 42px wine circle "V" + "VIP Magical Physio Clinic" / "Dr. Vipul Ahire (Physio) · Shirur".
   - **Nav:** Services → `/{lang}/conditions/`, Home visits, Online consult, Health guides, About, Contact.
   - **Language switcher:** pill with three buttons, EN / मरा / हि. The active one is filled ink.
   - **CTA:** "Book appointment".
   - **Below 1240px:** the nav collapses into a ☰ drawer (right side, max 360px wide).
3. **Hero.** Two-column grid (1.08fr / .92fr); on mobile the image goes on top.
   - Eyebrow "Physiotherapy · Shirur, Pune District". H1 "Move better.<br><em>Live better.</em>" with the `em` in wine italic. Lede.
   - **CTAs:** Book appointment (wine), Request home visit (line), Online consultation (soft), plus a ghost link "Explore health guides".
   - Sage dot + "Every request is checked against availability before we confirm."
   - **Image:** `hero-hands.jpg`, aspect 4/5, radius 18. A floating white card sits at bottom-left (−2rem): "Dr. Vipul Ahire (Physio)" / experience line.
4. **Facts strip.** 4 columns (2×2 on mobile): `1 : 1` · `3 ways` · `EN · मरा · हि` · `Honest`, each with a caption. Number style: Newsreader 2rem wine.
5. **Ways to be seen.** 3 cards (Clinic OPD / Home visit / Online). Each has an italic number, H3, paragraph, 3 bullets with sage dots, and a wine button that pre-selects the appointment type in the booking form.
6. **Conditions.** 4-column hairline grid with 8 featured conditions linking to `/{lang}/conditions/{slug}/`.
7. **Process.** 4 steps (Assessment / Your plan / Review / Referral), each with a 2px ink top border. The Referral step's border is sage.
8. **Booking (`#book`).** Left aside, right form card (see Interactions). The aside shows the status chips: Requested (wine) → Pending confirmation → Confirmed → Completed.
9. **Ebooks.** 4 CSS covers coloured `#7A1F2B` / `#3F6B55` / `#4A3B3D` / `#8C5A3C`, labelled "Coming soon" with a "Notify me" link to the newsletter.
10. **Learn.**
    - YouTube placeholder (striped, 16:9) with "Watch on YouTube" and "Subscribe" buttons for `youtube.com/@drvipulahireofficial`.
    - Side cards: Free guides; Instagram (`instagram.com/dr.vipul.dardebody`).
11. **Find us.**
    - Wine panel "Google reviews": honest copy, "Read reviews on Google" and "Leave a review". **No fake stars.**
    - Outlined panel with address, hours, phone and service area. Address and hours show a red "Awaiting verified details" chip. A map placeholder and a Directions button.
12. **Newsletter.** Wine-2 background. Email field + Subscribe + a consent checkbox, which is required.
13. **Disclaimer line** and a **footer** with 4 columns.
14. **Mobile (≤760px).** A sticky bottom bar with 3 buttons (Call / WhatsApp / Book), height 50 + safe-area. The floating WhatsApp pill is hidden on mobile and shown bottom-right on desktop.

### 2. Condition page — e.g. `site/en/conditions/back-pain-physiotherapy/index.html`
Generated by `site/tools/render-conditions.js` from `site/content/conditions.{en,mr,hi}.js`. Each entry has `slug`, `name`, `title`, `hook`, `short`, `intro`, `who`, `sym[5]`, `cause[5]`, `red[5]`, `assess[5]`, `plan[3][title,text]`, `ex[3]`, `myth[myth,fact]`, `faq[3][q,a]`, `vid`, `book`, `rel[3]` and `reviewed`.

Sections:
1. **Breadcrumb**, then the **hero** in a 2-column grid (1.35fr / .65fr).
   - Left: eyebrow, H1, **hook** (italic Newsreader, wine, 3px wine left border), intro, three CTAs that deep-link to `/{lang}/?service={slug}&type=…#book`, byline, and a review flag (amber "pending" or sage "reviewed").
   - Right: sticky "At a glance" card (top 96px) containing *who it's for*, the three ways to be seen as sage chips, a Book button and a Call button.
2. Symptoms | Contributing factors (two columns, wine and sage dot lists).
3. **Red-flag box.** alert-soft background, a 34px "!" badge, list, and a `tel:108` emergency link.
4. Assessment: numbered cards, auto-fit at min 220px, with "01" in Newsreader wine.
5. Rehabilitation roadmap: 3 phases on a horizontal line, with 40px circles in wine / `#9b3a46` / sage, plus a note.
6. Exercise education with a sage safety note | Myth vs Fact. Two columns; the myth text is struck through.
7. FAQ as `<details>` accordions; the "+" rotates 45° when open.
8. Learn cards: a dark card linking to a YouTube search on the channel; an ebook card linking to `/ebooks/{book}`.
9. Related conditions (3).
10. Wine CTA band with Book and WhatsApp (prefilled message).
11. Footer with the disclaimer.

**SEO and schema on each page:** canonical URL, hreflang en-IN / mr-IN / hi-IN / x-default, and a JSON-LD `@graph` containing `MedicalWebPage` (+ `reviewedBy` only once reviewed), `BreadcrumbList`, `FAQPage`, `MedicalClinic` and `Person`. When `REQUIRE_CLINICAL_REVIEW=true` and `reviewed:false`, the page gets `noindex, follow` and is left out of the sitemap.

### 3. Conditions hub — `/{lang}/conditions/`
A 3-column card grid (2 on tablet, 1 on mobile). Each card shows the name (Newsreader 1.45rem), the hook (wine) and the short description.

### 4. Admin console — `site/admin/index.html`
- **Login.** A centred 400px card: "V" mark, "Clinic console", email, password, Sign in, and Forgot password. In demo mode (no backend), any email works and an amber banner reads "DEMO MODE … fictional sample data".
- **Shell.** Sticky 232px ink sidebar listing Overview, Appointments, CRM, Ebook orders, Email, Settings and Setup, with red count badges. The active item is white. At ≤900px it becomes a horizontal pill nav. The main area pads `1.5rem clamp(1rem,3vw,2.25rem)`.
- **Overview.**
  - 11 KPI cards (auto-fill, min 170px), with `alert`, `good` and `wine` colour variants.
  - "Needs action" table, booking funnel (4 bars), popular services bars, lead-source bars, and an upcoming confirmed table.
- **Appointments.**
  - Search box plus status and type filters; table columns are When (IST), Patient, Type, Service, Status pill and Ref.
  - Clicking a row opens a right-hand drawer (max 520px) with details and **only the allowed next statuses**.
  - An unlisted-area request shows a red warning, the Confirm button is disabled, and "Approve area after call" opens a confirm dialog.
  - Online consults require an https video link before they can be confirmed. Completing an appointment asks for the fee in ₹.
- **CRM.**
  - Search, category and follow-up filters, plus Export CSV.
  - Clicking a customer opens a drawer with follow-up status and date, the appointment history, orders, and internal notes. A note in the UI warns that these notes are not clinical records.
- **Orders.** KPIs and a table, with a note that orders are marked paid only by the verified Razorpay webhook.
- **Email.** Three tabs: Delivery log (Retry on failed items), Subscribers, Newsletter (EN/MR/HI subject and body; owner only; test send).
- **Settings.**
  - Clinic details (owner only), with a warning to publish only verified data.
  - Home-visit areas table (name, visit ₹, travel ₹, active).
  - Working-hours editor (weekday, opens, closes, slot minutes).
- **Setup.** Shows the status of each integration (connected or not).
- **Status pill colours:** requested amber · pending_confirmation blue · confirmed sage · completed grey · cancelled/no_show red · rescheduled `#5a3d82` on `#f0eaf6`.

---

## Interactions & Behavior

### Booking wizard (`site/assets/home-app.js`)
**Step 1: type and reason**
- Choose a type with radio cards (Clinic OPD / Home visit / Online / Follow-up). Checked style: wine border on wine-soft.
- Choose a service from a select holding all 18 services in the current language, plus "Other / not sure".
- **Home visit** shows the Locality select (areas come from `GET /api/service-areas`, plus "My area isn't listed").
  - Picking "My area isn't listed" shows a free-text locality field and a red notice: "Areas outside the approved list are not confirmed automatically."
  - Home visit also shows a "Mobility limitations" field.
- **Online** shows a sage notice that some problems need an in-person exam.

**Step 2: date and slot**
- Date picker allows tomorrow up to +45 days.
- Slots come from `GET /api/available-slots?date&type`, shown as a grid of 4 (3 on mobile). Taken slots are disabled and struck through. Fallback slots: 10:00, 11:00, 12:00, 13:00, 16:00, 17:00, 18:00, 19:00.

**Step 3: details**
| Field | Rule |
|---|---|
| Name | Required, 2–120 characters |
| Mobile | Indian mobile, regex `^[6-9]\d{9}$` after stripping +91 or 0 |
| Email | Optional, validated if given |
| Age group | Required: <18 / 18-44 / 45-59 / 60-74 / 75+ |
| Preferred language | Optional |
| Enquiry | Optional, max 400; hint: "don't send reports" |
| Consent: contact | **Required** |
| Consent: privacy acknowledgement | **Required** |
| Consent: marketing | Optional, unticked by default |

There is also a hidden honeypot field named `website`.

**Step 4: review and submit**
- Shows a summary `<dl>`, then **Send request** → `POST /api/book-appointment`.

**Results**
| Response | What the patient sees |
|---|---|
| 201 | "Request received", status REQUESTED, reference `VIP-XXXXXXXX`, and copy stating clearly that this is **not** a confirmed appointment |
| 409 | Back to step 2; the slot is disabled with the message "That slot was just taken" |
| 404 / 405 / network error / 503 | Honest fallback: "Online booking isn't connected yet — your details have not been sent or stored" plus a prefilled WhatsApp button. **Never show a fake success.** |
| 422 / 500 | Error notice with Back and the phone number |

**Behaviour throughout**
- Invalid fields get `aria-invalid` and the error text is shown; focus moves to the first invalid field.
- A progress bar of 4 segments (4px high) tracks the steps.
- Deep links `?service=slug&type=home_visit#book` pre-fill the form.
- `[hidden]{display:none!important}` is required, because `.field` uses `display:flex`.

### Language switching
- The current language comes from the path `/en|mr|hi/`, then `?lang=`, then localStorage `vip_lang`.
- Switching updates `html[lang]`, the document title, every `[data-i]` text node and every `[data-ph]` placeholder.
- If the URL has a language prefix, `history.replaceState` swaps it so the visitor stays on the same page.

### Newsletter
- `POST /api/subscribe` (double opt-in). States: ok → "check your inbox"; invalid or no consent → error; service unavailable → "not connected — nothing was stored".

### Analytics
- `dataLayer.push({event:'cta_click', cta})` on every `[data-track]` element. Other events: `booking_submitted`, `booking_fallback_whatsapp`, `language_switch`, `newsletter_subscribe`.
- **Never send names, phone numbers or health details.**

### Responsive breakpoints
| Width | Change |
|---|---|
| 1320px | Nav gap tightens |
| 1240px | Nav collapses into the drawer |
| 1060 / 960 / 900px | Grids collapse |
| 760px | Facts become 2×2; mobile bottom bar appears |
| 560px | Two-field rows stack |
| 480px | Brand subtitle hidden, brand name wraps |

The admin console switches to its mobile layout at 900px.

---

## State Management
**Public site**
- `lang`, wizard `step` (1–4), selected `slot`, the list of `taken` slots, `AREAS` and `pendingService`.

**Admin**
- Session and staff role from Supabase Auth.
- The current `view` (persisted in localStorage `vip_admin_view`).
- Filters `f` (q, status, type, cat, fu, tab), the loaded data set, and which drawer is open.

**Appointment status machine** (enforced in both the database and the API):
- `requested` → `pending_confirmation` | `confirmed` | `cancelled` | `rescheduled`
- `pending_confirmation` → `confirmed` | `cancelled` | `rescheduled`
- `confirmed` → `completed` | `cancelled` | `rescheduled` | `no_show`

Unlisted-area requests can never become confirmed or completed until an admin approves the area.

### API (Netlify Functions, routed as `/api/*`)
| Endpoint | Purpose |
|---|---|
| `GET available-slots` | Free/busy only, no patient data |
| `GET service-areas` | Approved home-visit areas |
| `POST book-appointment` | Creates a request (never confirms) |
| `POST subscribe`, `GET confirm-subscription`, `GET unsubscribe` | Newsletter double opt-in and one-click unsubscribe |
| `POST razorpay-create-order` | Price read from the database, never from the browser |
| `POST razorpay-webhook` | HMAC-verified, idempotent; the only path that marks an order paid |
| `GET download` | Hashed token, 72h expiry, 5 uses; serves a 5-minute signed URL from a private bucket |
| `POST admin-api` | JWT plus staff role checked server-side for every action |
| `GET public-config` | Public keys only |
| `scheduled-reminders` | Runs hourly |

The database schema and row-level security policies are in `supabase/migrations/`.

---

## Verified (actually run)
- `node --test tests/backend.test.js`: **38/38 pass** on Node 22.
- Both migrations apply cleanly on **PostgreSQL 16**. Confirmed on real Postgres:
  - Overlapping bookings are rejected, and an atomic reschedule rolls back if the new slot is taken.
  - Invalid status transitions are blocked.
  - Unlisted-area requests can't be confirmed.
  - Marketing email without consent is skipped.
  - An unreviewed ebook can't be published.
  - The anonymous role is denied access to `customers`.
- `node site/tools/build.js` produces 62 files. A static audit found 0 broken internal links across 93 pages.
- **Not yet tested** against live Supabase, Brevo or Razorpay. See `docs/STATUS-REPORT.md`.

## Assets
| File | Source | Use |
|---|---|---|
| `site/assets/img/hero-hands.jpg` (1728×2304) | Existing live site | Homepage hero, OG image |
| `site/assets/img/svc-*.jpg` (11) and `clinic-detail.jpg` | Existing live site | Used by legacy pages |
| `favicon.svg` | Existing live site | Favicon |

The images are not included in this bundle (binary). Get them from the project or from vipmagicalphysio.netlify.app/assets/img/.

There are no icon libraries: the design uses CSS dots and the "V" monogram. The YouTube block and the map are deliberate placeholders. The client has asked for **real clinic photos, not AI-generated clinical scenes**.

## Files
| Path | What it is |
|---|---|
| `site/index.html`, `site/assets/home.css`, `home-app.js`, `home-i18n.js` | Homepage, styles, wizard logic, EN/MR/HI UI strings |
| `site/assets/cond.css`, `site/tools/render-conditions.js`, `build.js`, `build-lib.js` | Condition page styles and static generator |
| `site/content/conditions.{en,mr,hi}.js` | All medical content (source of truth) |
| `site/assets/services-index.js` | Generated list of service names in 3 languages |
| `site/en/conditions/…`, `site/mr/conditions/knee-pain-physiotherapy/` | Sample rendered pages |
| `site/admin/*` | Admin console (data layer with demo mode, views, controller, CSS) |
| `netlify/functions/**` | Backend functions |
| `supabase/migrations/*.sql` | Database schema, triggers, row-level security, views |
| `tests/*` | Mock database plus 38 tests |
| `netlify.toml`, `package.json`, `.env.example` | Routing, redirects, security headers, dependencies, environment variables |
| `docs/DEPLOYMENT.md`, `docs/STATUS-REPORT.md`, `docs/AUDIT-AND-ROADMAP.md` | Setup guide, feature status, audit and roadmap |

## Open items for implementation
1. Restyle the legacy pages to these tokens.
2. Add an ebook checkout UI (Razorpay Checkout.js → `razorpay-create-order`; show "processing" until the emailed link arrives).
3. Google Calendar sync.
4. WhatsApp Business API (after Meta approval).
5. Real clinic address, hours, Google Place ID and photos from the client.
6. Clinical sign-off flips `reviewed:true` per condition.
