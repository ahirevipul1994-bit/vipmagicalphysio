-- =====================================================================
-- VIP MAGICAL PHYSIO CLINIC — 001 Core schema (Supabase / PostgreSQL 15+)
-- Repaired 2026-11-21: AFTER-trigger for status log (FK bug), first_source
-- preserved on repeat contacts, unlisted home-visit areas allowed but flagged.
-- =====================================================================
create extension if not exists btree_gist;
create extension if not exists pgcrypto;
create extension if not exists citext;

create type appointment_type   as enum ('clinic_opd','home_visit','online','follow_up');
create type appointment_status as enum ('requested','pending_confirmation','confirmed','completed','cancelled','rescheduled','no_show');
create type lang_code          as enum ('en','mr','hi');
create type lead_source        as enum ('appointment','home_visit','online_consult','ebook','newsletter','free_guide','contact','walk_in','other');
create type order_status       as enum ('created','paid','failed','refunded');
create type staff_role         as enum ('owner','admin','reception');

-- ---------- Staff ----------
create table staff (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  full_name  text not null,
  role       staff_role not null default 'reception',
  active     boolean not null default true,
  created_at timestamptz not null default now()
);

create or replace function is_staff(min_role staff_role default 'reception')
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from staff s where s.user_id = auth.uid() and s.active
    and (min_role = 'reception'
      or (min_role = 'admin' and s.role in ('admin','owner'))
      or (min_role = 'owner' and s.role = 'owner')));
$$;

-- ---------- CRM (administrative / marketing data only — NO clinical detail) ----------
create table customers (
  id               uuid primary key default gen_random_uuid(),
  full_name        text not null check (char_length(full_name) between 2 and 120),
  phone_e164       text not null unique check (phone_e164 ~ '^\+91[6-9][0-9]{9}$'),
  email            citext,
  preferred_lang   lang_code not null default 'en',
  first_source     lead_source not null,
  last_source      lead_source not null,
  category         text not null default 'lead' check (category in ('lead','patient','ebook_buyer','subscriber','past_patient')),
  follow_up_status text not null default 'none' check (follow_up_status in ('none','due','done','not_required')),
  follow_up_on     date,
  utm_source       text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index on customers (lower(full_name));
create index on customers (email);
create index on customers (follow_up_on) where follow_up_status = 'due';

create table consents (
  id          bigserial primary key,
  customer_id uuid not null references customers(id) on delete cascade,
  purpose     text not null check (purpose in ('contact_for_request','marketing_email','marketing_whatsapp','privacy_ack')),
  granted     boolean not null,
  policy_ver  text not null,
  source_page text,
  recorded_at timestamptz not null default now()
);
create index on consents (customer_id, purpose, recorded_at desc);

-- latest consent per purpose
create or replace view customer_consent_current as
  select distinct on (customer_id, purpose) customer_id, purpose, granted, recorded_at
  from consents order by customer_id, purpose, recorded_at desc;

create table crm_notes (
  id          bigserial primary key,
  customer_id uuid not null references customers(id) on delete cascade,
  author      uuid references staff(user_id),
  body        text not null check (char_length(body) between 1 and 2000),
  created_at  timestamptz not null default now()
);

-- ---------- Scheduling config ----------
create table working_hours (
  id           serial primary key,
  weekday      smallint not null check (weekday between 0 and 6),   -- 0 = Sunday (IST)
  opens        time not null,
  closes       time not null check (closes > opens),
  appt_type    appointment_type not null,
  slot_minutes smallint not null default 45 check (slot_minutes between 15 and 120),
  unique (weekday, appt_type, opens)
);

create table blocked_periods (
  id     serial primary key,
  period tstzrange not null,
  reason text
);

create table service_areas (
  id             serial primary key,
  name           text not null unique,
  active         boolean not null default true,
  visit_fee_inr  integer not null check (visit_fee_inr >= 0),
  travel_fee_inr integer not null default 0 check (travel_fee_inr >= 0),
  sort           smallint not null default 0
);

create table appointments (
  id                uuid primary key default gen_random_uuid(),
  reference         text not null unique default upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)),
  customer_id       uuid not null references customers(id),
  appt_type         appointment_type not null,
  service_slug      text not null,
  status            appointment_status not null default 'requested',
  slot              tstzrange not null,
  service_area_id   int references service_areas(id),
  locality_text     text check (char_length(locality_text) <= 80),
  needs_area_review boolean not null default false,
  age_group         text check (age_group in ('<18','18-44','45-59','60-74','75+')),
  brief_enquiry     text check (char_length(brief_enquiry) <= 400),
  mobility_notes    text check (char_length(mobility_notes) <= 400),
  fee_inr           integer,
  video_link        text,
  reminder_sent_at  timestamptz,
  rescheduled_from  uuid references appointments(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint home_visit_has_location check (appt_type <> 'home_visit' or service_area_id is not null or locality_text is not null),
  constraint unlisted_area_flagged  check (appt_type <> 'home_visit' or service_area_id is not null or needs_area_review),
  constraint unlisted_never_confirmed check (not needs_area_review or status not in ('confirmed','completed')),
  -- Double-booking guard: no two live appointments may overlap (single-practitioner diary)
  constraint no_overlap exclude using gist (slot with &&) where (status in ('requested','pending_confirmation','confirmed'))
);
create index on appointments (customer_id);
create index on appointments (status, lower(slot));

create table appointment_events (
  id             bigserial primary key,
  appointment_id uuid not null references appointments(id) on delete cascade,
  from_status    appointment_status,
  to_status      appointment_status not null,
  actor          uuid,
  at             timestamptz not null default now()
);

create or replace function touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create or replace function log_appt_status() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' or new.status is distinct from old.status then
    insert into appointment_events(appointment_id, from_status, to_status, actor)
    values (new.id, case when tg_op = 'UPDATE' then old.status end, new.status, auth.uid());
  end if;
  return null;
end $$;

-- Allowed transitions (server + DB both enforce)
create or replace function check_appt_transition() returns trigger language plpgsql as $$
begin
  if new.status is distinct from old.status and not (
       (old.status = 'requested'            and new.status in ('pending_confirmation','confirmed','cancelled','rescheduled'))
    or (old.status = 'pending_confirmation' and new.status in ('confirmed','cancelled','rescheduled'))
    or (old.status = 'confirmed'            and new.status in ('completed','cancelled','rescheduled','no_show'))
  ) then
    raise exception 'invalid status transition % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;

create trigger trg_appt_touch      before update on appointments for each row execute function touch_updated_at();
create trigger trg_appt_transition before update on appointments for each row execute function check_appt_transition();
create trigger trg_appt_log        after insert or update on appointments for each row execute function log_appt_status();
create trigger trg_cust_touch      before update on customers for each row execute function touch_updated_at();

-- ---------- Clinical records: separate, admin+ only, never exported ----------
create table clinical_notes (
  id             bigserial primary key,
  appointment_id uuid not null references appointments(id) on delete restrict,
  author         uuid not null references staff(user_id),
  body           text not null,
  created_at     timestamptz not null default now()
);

-- ---------- Dard E Body Care store ----------
create table ebooks (
  id                  uuid primary key default gen_random_uuid(),
  slug                text not null unique,
  title               text not null,
  lang                lang_code not null,
  category            text not null,
  price_paise         integer not null check (price_paise > 0),
  storage_path        text not null,
  published           boolean not null default false,
  clinically_reviewed boolean not null default false,
  created_at          timestamptz not null default now(),
  constraint publish_requires_review check (not published or clinically_reviewed)
);

create table orders (
  id                  uuid primary key default gen_random_uuid(),
  customer_id         uuid not null references customers(id),
  ebook_id            uuid not null references ebooks(id),
  amount_paise        integer not null,
  status              order_status not null default 'created',
  razorpay_order_id   text unique,
  razorpay_payment_id text unique,
  paid_at             timestamptz,
  refunded_at         timestamptz,
  created_at          timestamptz not null default now()
);
create index on orders (status, created_at desc);

create table webhook_events (
  event_id     text primary key,
  type         text not null,
  processed_at timestamptz,
  error        text,
  received_at  timestamptz not null default now()
);

create table download_tokens (
  token_hash text primary key,
  order_id   uuid not null references orders(id) on delete cascade,
  expires_at timestamptz not null,
  uses_left  smallint not null default 5 check (uses_left >= 0),
  created_at timestamptz not null default now()
);

create table audit_log (
  id        bigserial primary key,
  actor     uuid,
  action    text not null,
  entity    text not null,
  entity_id text,
  detail    jsonb,
  at        timestamptz not null default now()
);

-- ---------- CRM upsert that preserves first_source ----------
create or replace function upsert_customer(p_name text, p_phone text, p_email text, p_lang lang_code, p_source lead_source, p_category text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into customers (full_name, phone_e164, email, preferred_lang, first_source, last_source, category)
  values (p_name, p_phone, nullif(p_email,''), p_lang, p_source, p_source, coalesce(p_category,'lead'))
  on conflict (phone_e164) do update set
    full_name      = excluded.full_name,
    email          = coalesce(excluded.email, customers.email),
    preferred_lang = excluded.preferred_lang,
    last_source    = excluded.last_source,
    category       = case
                       when customers.category = 'patient' then 'patient'
                       when p_category is not null then p_category
                       else customers.category end
  returning id into v_id;
  return v_id;
end $$;
revoke all on function upsert_customer from public, anon, authenticated;

-- =====================================================================
-- ROW LEVEL SECURITY — anon has no table access; public writes go via server functions.
-- =====================================================================
do $$ declare t text; begin
  foreach t in array array['staff','customers','consents','crm_notes','working_hours','blocked_periods','service_areas',
    'appointments','appointment_events','clinical_notes','ebooks','orders','webhook_events','download_tokens','audit_log'] loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

create policy pub_read_ebooks on ebooks        for select using (published);
create policy pub_read_areas  on service_areas for select using (active);
create policy pub_read_hours  on working_hours for select using (true);

create policy staff_self      on staff              for select using (user_id = auth.uid() or is_staff('owner'));
create policy owner_staff     on staff              for all    using (is_staff('owner')) with check (is_staff('owner'));
create policy staff_customers on customers          for all    using (is_staff()) with check (is_staff());
create policy staff_consents  on consents           for select using (is_staff());
create policy staff_notes     on crm_notes          for all    using (is_staff()) with check (is_staff());
create policy staff_appts     on appointments       for all    using (is_staff()) with check (is_staff());
create policy staff_appt_ev   on appointment_events for select using (is_staff());
create policy admin_hours     on working_hours      for all    using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_blocks    on blocked_periods    for all    using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_areas     on service_areas      for all    using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_ebooks    on ebooks             for all    using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_orders    on orders             for select using (is_staff('admin'));
create policy owner_audit     on audit_log          for select using (is_staff('owner'));
create policy clinical_admin  on clinical_notes     for all    using (is_staff('admin')) with check (is_staff('admin'));
-- webhook_events, download_tokens: no policies => service role only.
-- Storage: bucket 'ebooks' must be PRIVATE (public = false). Files served only via signed URLs.
