-- =====================================================================
-- 002 — Subscribers, email automation queue, clinic settings, dashboard views
-- =====================================================================

-- ---------- Newsletter / free-guide subscribers (double opt-in) ----------
create table subscribers (
  id             uuid primary key default gen_random_uuid(),
  email          citext not null unique,
  lang           lang_code not null default 'en',
  source         lead_source not null default 'newsletter',
  status         text not null default 'pending' check (status in ('pending','active','unsubscribed','bounced')),
  confirm_token  text unique,
  unsub_token    text not null unique default encode(gen_random_bytes(18),'hex'),
  customer_id    uuid references customers(id) on delete set null,
  consented_at   timestamptz not null default now(),
  confirmed_at   timestamptz,
  unsubscribed_at timestamptz,
  created_at     timestamptz not null default now()
);

-- ---------- Email automation ----------
create table email_templates (
  key        text not null,
  lang       lang_code not null,
  subject    text not null,
  body_html  text not null,             -- {{placeholders}}
  is_marketing boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (key, lang)
);

create table email_queue (
  id            bigserial primary key,
  template      text not null,
  lang          lang_code not null,
  to_email      citext not null,
  customer_id   uuid references customers(id) on delete set null,
  subscriber_id uuid references subscribers(id) on delete set null,
  vars          jsonb not null default '{}',
  send_after    timestamptz not null default now(),
  status        text not null default 'queued' check (status in ('queued','sending','sent','failed','skipped','bounced')),
  attempts      smallint not null default 0,
  provider_id   text,
  error         text,
  dedupe_key    text unique,               -- e.g. 'reminder:<appt_id>' prevents double sends
  created_at    timestamptz not null default now(),
  sent_at       timestamptz
);
create index on email_queue (status, send_after);

-- Marketing guard: refuses to queue a marketing template without current consent / active subscription
create or replace function guard_marketing_email() returns trigger language plpgsql as $$
declare mk boolean; ok boolean := false;
begin
  select is_marketing into mk from email_templates where key = new.template and lang = new.lang;
  if coalesce(mk,false) then
    if new.subscriber_id is not null then
      select status = 'active' into ok from subscribers where id = new.subscriber_id;
    elsif new.customer_id is not null then
      select granted into ok from customer_consent_current where customer_id = new.customer_id and purpose = 'marketing_email';
    end if;
    if not coalesce(ok,false) then new.status := 'skipped'; new.error := 'no_marketing_consent'; end if;
  end if;
  return new;
end $$;
create trigger trg_guard_marketing before insert on email_queue for each row execute function guard_marketing_email();

-- ---------- Clinic settings (single row) ----------
create table clinic_settings (
  id                 boolean primary key default true check (id),
  clinic_name        text not null default 'VIP Magical Physio Clinic',
  address_line       text,                 -- MUST be verified before publishing
  pin_code           text,
  google_place_id    text,
  google_review_url  text,
  opd_fee_inr        integer,
  online_fee_inr     integer,
  reminder_hours     smallint not null default 24,
  booking_horizon_days smallint not null default 45,
  updated_at         timestamptz not null default now()
);
insert into clinic_settings default values;

alter table subscribers     enable row level security;
alter table email_templates enable row level security;
alter table email_queue     enable row level security;
alter table clinic_settings enable row level security;
create policy staff_subs      on subscribers     for select using (is_staff());
create policy admin_subs      on subscribers     for update using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_templates on email_templates for all using (is_staff('admin')) with check (is_staff('admin'));
create policy admin_queue     on email_queue     for select using (is_staff('admin'));
create policy pub_settings    on clinic_settings for select using (true);
create policy admin_settings  on clinic_settings for update using (is_staff('owner')) with check (is_staff('owner'));

-- =====================================================================
-- DASHBOARD VIEWS (security_invoker → RLS of the caller applies)
-- =====================================================================
create or replace view v_dashboard_kpis with (security_invoker = true) as
select
  (select count(*) from customers where created_at >= date_trunc('month', now()))                              as new_leads_month,
  (select count(*) from appointments where status in ('requested','pending_confirmation'))                     as pending_requests,
  (select count(*) from appointments where status = 'confirmed' and lower(slot)::date = (now() at time zone 'Asia/Kolkata')::date) as today_confirmed,
  (select count(*) from appointments where status = 'confirmed' and lower(slot) > now())                       as upcoming_confirmed,
  (select count(*) from appointments where appt_type = 'home_visit' and status in ('requested','pending_confirmation')) as home_visit_pending,
  (select count(*) from appointments where needs_area_review and status in ('requested','pending_confirmation')) as area_review_pending,
  (select count(*) from appointments where appt_type = 'online' and lower(slot) > now() and status = 'confirmed') as online_upcoming,
  (select count(*) from orders where status = 'paid' and paid_at >= date_trunc('month', now()))                 as ebook_orders_month,
  (select coalesce(sum(amount_paise),0)/100 from orders where status = 'paid' and paid_at >= date_trunc('month', now())) as ebook_revenue_month_inr,
  (select coalesce(sum(fee_inr),0) from appointments where status = 'completed' and lower(slot) >= date_trunc('month', now())) as service_revenue_month_inr,
  (select count(*) from subscribers where status = 'active')                                                   as active_subscribers,
  (select count(*) from customers where follow_up_status = 'due' and follow_up_on <= current_date)              as followups_due,
  (select count(*) from email_queue where status = 'failed')                                                   as email_failures;

create or replace view v_funnel_30d with (security_invoker = true) as
select
  count(*)                                                       as requests,
  count(*) filter (where status in ('confirmed','completed','no_show')) as confirmed,
  count(*) filter (where status = 'completed')                   as completed,
  count(*) filter (where status = 'no_show')                     as no_show,
  count(*) filter (where status = 'cancelled')                   as cancelled
from appointments where created_at >= now() - interval '30 days';

create or replace view v_source_30d with (security_invoker = true) as
select last_source as source, count(*) as leads from customers
where updated_at >= now() - interval '30 days' group by 1 order by 2 desc;

create or replace view v_popular_services_90d with (security_invoker = true) as
select service_slug, count(*) as requests from appointments
where created_at >= now() - interval '90 days' group by 1 order by 2 desc limit 10;

-- Admin status change with audit (called from dashboard via RPC)
create or replace function admin_set_appt_status(p_id uuid, p_status appointment_status, p_fee integer default null)
returns appointments language plpgsql security invoker set search_path = public as $$
declare r appointments;
begin
  if not is_staff() then raise exception 'forbidden' using errcode = '42501'; end if;
  update appointments set status = p_status, fee_inr = coalesce(p_fee, fee_inr) where id = p_id returning * into r;
  insert into audit_log(actor, action, entity, entity_id, detail) values (auth.uid(), 'status:' || p_status, 'appointment', p_id::text, jsonb_build_object('fee', p_fee));
  if p_status = 'completed' then update customers set category = 'patient' where id = r.customer_id; end if;
  return r;
end $$;

-- Atomic reschedule: frees the old slot and books the new one in ONE transaction (rolls back on overlap)
create or replace function reschedule_appointment(p_id uuid, p_start timestamptz, p_end timestamptz)
returns table (id uuid, reference text) language plpgsql security invoker set search_path = public as $$
declare o appointments;
begin
  if not is_staff() and current_setting('request.jwt.claim.role', true) is distinct from 'service_role' then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  select * into o from appointments a where a.id = p_id for update;
  if o.id is null or o.status not in ('requested','pending_confirmation','confirmed') then
    raise exception 'not_reschedulable' using errcode = 'P0001';
  end if;
  update appointments set status = 'rescheduled' where appointments.id = p_id;
  return query insert into appointments (customer_id, appt_type, service_slug, status, slot, service_area_id, locality_text, needs_area_review,
      age_group, brief_enquiry, mobility_notes, fee_inr, video_link, rescheduled_from)
    values (o.customer_id, o.appt_type, o.service_slug, 'pending_confirmation', tstzrange(p_start, p_end, '[)'), o.service_area_id, o.locality_text,
      o.needs_area_review, o.age_group, o.brief_enquiry, o.mobility_notes, o.fee_inr, o.video_link, p_id)
    returning appointments.id, appointments.reference;
end $$;

-- Seed defaults (edit in dashboard). Hours are PLACEHOLDERS until the owner confirms them.
insert into working_hours (weekday, opens, closes, appt_type, slot_minutes)
select d, t.o, t.c, ty, 45 from generate_series(1,6) d,
  (values ('10:00'::time,'13:30'::time), ('16:00'::time,'20:00'::time)) t(o,c),
  unnest(enum_range(null::appointment_type)) ty;
